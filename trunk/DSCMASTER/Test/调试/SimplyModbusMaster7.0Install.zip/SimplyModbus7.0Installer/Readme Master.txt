Simply Modbus RTU/ASCII Master 7.0

SPECIFICATIONS / SUPPORTED FEATURES :
 - RTU and ASCII mode
 - serial ports: COM1 to COM99
 - baud rates: tested to 76800
 - Modbus modes: RTU and ASCII
 - Function codes 01,02,03,04,05,06,15,16 (read and write registers and coils)
 - register addresses from hex 0000 to FFFF (equal to register names from 40001 to 105537 with offset=40001)
 - Data Types: 32bit IEEE Floating Point
               32bit Unsigned Integer (0 to 4.3 billion)
               32bit Signed Integer   (-2.1 to 2.1 billion)
               16bit Unsigned Integer (0 to 65535)
               16bit Signed Integer   (-32768 to 32767)
               2chString   - 16bit - 2 character STRING
               4chString   - 32bit - 4 character STRING
               6chString   - 48bit - 6 character STRING
               8chString   - 64bit - 8 character STRING
               12chString  - 96bit -12 character STRING
               16chString  - 128bit-16 character STRING
               8 boolean   - 8 bit - 8 status ON/OFF
 - High byte/Low byte (big endian) or Low byte/High byte (little endian)
 - Low word/High word (big endian) or Low word/High high (little endian)
 - Register size selection: 16 bit registers or 32 bit registers
 - Saves and Restores settings to/from a csv file
 - displays and the saves communication log to a text file.

***** Context help is available by pressing Ctrl-H while in the program *****
***** information is displayed about items as the cursor hovers over them   *****



INSTALLATION INSTRUCTIONS

SimplyModbus7.0.zip includes these 7 files:
	setup.exe   
	setup.ini
	data.cab
	install.msi
	InstMsi.exe
	InstMsiW.exe
	Readme Master.txt  - this file

	- Unzip these 7 install files into a folder.

	- Run setup.exe to start the Simply Modbus 7.0 Installation Wizard

	- Follow the prompts.  The program will start automatically when the installation is complete.

	- Running setup.exe a second time will uninstall the program.


STARTING THE PROGRAM

	- From the Start menu, select Programs > Simply Modbus > Simply Modbus 7.0


OPERATING INSTRUCTIONS

A detailed manual is available at http:/www.simplymodbus.ca/manual2.htm

- Enter the input information (boxes shown with yellow background)
           Mode = RTU (forces data bits=8)
                  ASCII (forces databits=7)
           Serial port = 1 to 99 (COM1 to COM99)
           port settings: baud rate = 19200, for example
                          data bits = 7 or 8 (RTU mode requires 8 data bits)
                          stop bit = 1, 1.5 or 2
                          parity = none, odd, even, mark or space
           Slave ID = 1 to 247
           First Register = 40001 
           No. of Registers = 10
   The Command to be sent will appear in "Request".

-  Press the SEND button.  All bytes received will appear in "Response".
   The response time is shown in 0.1 increments. 
   The response progress bar fills as the the time approached the "fail in" time entered.
   If no answer appears within the "fail in" time, the program stops monitoring the serial port for new bytes.
   Try increasing the "fail in" time and pressing SEND again or checking the settings or wiring.

-  Change the format of the received data until the correct results are shown. 
   check or uncheck 'High byte/Low byte'
   check or uncheck 'Low word/High word'
   Data Types: 32bit Float - 32bit IEEE Floating Point
               32bit UINT  - Unsigned Integer (0 to 4.3 billion)
               32bit INT   - Signed Integer   (-2.1 to 2.1 billion)
               16bit UINT  - Unsigned Integer (0 to 65535)
               16bit INT   - Signed Integer   (-32768 to 32767)
               2chString   - 16bit - 2 character STRING
               4chString   - 32bit - 4 character STRING
               6chString   - 48bit - 6 character STRING
               8chString   - 64bit - 8 character STRING
               12chString  - 96bit -12 character STRING
               16chString  - 128bit-16 character STRING
               8 boolean   - 8 bit - 8 status ON/OFF

   If all the expected response bytes are received and the expected crc or lrc matches the recieved error detection bytes, 
   pressing SEND again is not required to re-analyze the response. Simply change the byte order, word order and data types 
   to apply the new settings to the original response.


OTHER SETTINGS

--- Auto set ---
The automatic settings are shown inside the Auto set box.
These settings are automatically set to these defaults whenever "First Register" is changed.

First Register   Function Code   Register Size   Offset
00001-10000           1           1 bit coils        1
10001-30000           2           1 bit coils    10001
30001-40000           4           16 bit regs    30001
40001+                3           16 bit regs    40001

Enron exceptions:
32        (events)    3           32 bit regs        0
701-799   (history)   3           32 bit regs        0
1001-1999 (boolean)   1           1 bit coils        0
3001-3999 (short int) 3           16 bit regs        0
5001-5999 (long int)  3           32 bit regs        0
7001-7999 (floats)    3           32 bit regs        0

For Simply Write Modbus:
First Register   Function Code   Register Size   Offset
00001-10000           5(15*)      1 bit coils        1
10001-30000           5(15*)      1 bit coils    10001
30001-40000           6(16*)      16 bit regs    30001
40001+                6(16*)      16 bit regs    40001
 *Function codes 15 and 16 are used when writing multiple values.


--- send continuously ---
When the "send continuously" check box is checked, the program will repeatedly SEND back-to-back requests. 
Increase "pause between sends" in seconds to slow down the rate the requests are sent.
"response time" is the seconds it took to receive the latest response.
                This will be equal to the "fail in" time if all the expected response bytes were not received.
"responses" is the total number of complete responses received since the last reset.
"failed" is the total number of incomplete responses received since the last reset.
"max" is the largest response time of all the complete responses received since the last reset.
"avg" is the average response time of all the complete responses received since the last reset.
"min" is the shortest response time of all the complete responses received since the last reset.


--- RTS delay ---
If RTS delay is required, for communication through MDS4310A and MDS4710B radios for example, check the RTS delay check box. 
Enter the 'ON' and 'OFF' delay in milliseconds.  
The RTS pin will be asserted for the 'ON' duration before the message bytes are transmitted.
The RTS pin will be remain asserted for the 'OFF' duration after the message bytes are transmitted.


OTHER BUTTONS:
  SAVE CFG
  RESTORE CFG  The settings entered can be saved-to and restored-from a CSV (comma separated values) file.


--- Saved Configuration file ---
The settings can be saved to text files with the SAVE CFG button and resored with the RESTORE CFG button.

The format of the file is csv (comma separated values).
1st column contains the setting descriptions, 2nd column contains the setting values:
serial port      0=COM1, 1=COM2 etc
baud rate
data bits
stop bits        0=1bit, 1=1.5bits, 2=2bits			
parity           0=none , 1=odd, 2=even, 3=mark, 4=space
slave ID
1st register
No. of registers or No.of Events (for Events) or Record No.(for History)
Record size      (for History)
mode             0=RTU, 1=ASCII
byte order       0=Low byte first, 1=High byte first
word order       0=Low word first, 1=High word first
autoset          1=Auto set advanced settings when 1st Register changes
Function Code
register size    0=1 bit coils, 1=16bit registers, 2=32bit registers
offset
Events           0=not Events, 1= Event Poll
History          0=not History, 1= History Poll
2 byte addr      0=1byte addr, 1=2byte addr
RTS delay        0=off, 1=on
ON delay         milliseconds
OFF delay        milliseconds
Read twice       0=off, 1=try again if timeout
fail in          seconds until poll failure if expected bytes are not received
pause            seconds from the response to the next request when send continuously is checked.

3rd column contains data formats.
  0=32bit Float - 32bit IEEE Floating Point
  1=32bit UINT  - Unsigned Integer (0 to 4.3 billion)
  2=32bit INT   - Signed Integer   (-2.1 to 2.1 billion)
  3=16bit UINT  - Unsigned Integer (0 to 65535)
  4=16bit INT   - Signed Integer   (-32768 to 32767)
  5=2chString   - 16bit - 2 character STRING
  6=4chString   - 32bit - 4 character STRING
  7=6chString   - 48bit - 6 character STRING
  8=8chString   - 64bit - 8 character STRING
  9=12chString  - 96bit -12 character STRING
 10=16chString  - 128bit-16 character STRING
 11=8 boolean   - 8 bit - 8 status ON/OFF

4th column contains data notes.

5th column contains data register numbers.

6th column contains data values.

7th column contains the latest response received.

--------------
Visit www.simplymodbus.ca for updates and detailed information on how the modbus protocol works.

See www.simplymodbus.ca/manual2.htm for a detailed manual.

Send all questions and comments to info@simplymodbus.ca