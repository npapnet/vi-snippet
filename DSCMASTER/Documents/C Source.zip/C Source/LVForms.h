#ifndef _LVForms_h
#define _LVForms_h

extern TextPtr Open_Controller_handle_VIName;
extern eRunStatus Open_Controller_handle_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Open_Controller_handle_formID 2000

extern TextPtr Watflow_F4_lvlib_Initialize_VIName;
extern eRunStatus Watflow_F4_lvlib_Initialize_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Initialize_formID 2100

extern TextPtr Watflow_F4_lvlib_Utility_Read_From_Register_VIName;
extern eRunStatus Watflow_F4_lvlib_Utility_Read_From_Register_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Utility_Read_From_Register_formID 2200

extern TextPtr Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_VIName;
extern eRunStatus Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_formID 2300

extern TextPtr Watflow_F4_lvlib_Utility_Generate_Instrument_Error_VIName;
extern eRunStatus Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Utility_Generate_Instrument_Error_formID 2400

extern TextPtr Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_VIName;
extern eRunStatus Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_formID 2500

extern TextPtr Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_VIName;
extern eRunStatus Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_formID 2600

extern TextPtr Watflow_F4_lvlib_Reset_VIName;
extern eRunStatus Watflow_F4_lvlib_Reset_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Reset_formID 2700

extern TextPtr Watflow_F4_lvlib_Utility_Write_To_Register_VIName;
extern eRunStatus Watflow_F4_lvlib_Utility_Write_To_Register_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Utility_Write_To_Register_formID 2800

extern TextPtr Watflow_F4_lvlib_Close_VIName;
extern eRunStatus Watflow_F4_lvlib_Close_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define Watflow_F4_lvlib_Close_formID 2900

extern TextPtr VISA_Configure_Serial_Port__Instr__VIName;
extern eRunStatus VISA_Configure_Serial_Port__Instr__Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define VISA_Configure_Serial_Port__Instr__formID 3000

extern TextPtr F4_Controller_handle_Global_Function_Variable_VIName;
extern eRunStatus F4_Controller_handle_Global_Function_Variable_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define F4_Controller_handle_Global_Function_Variable_formID 3100

extern TextPtr F4_Visa_Handle_Constant_VIName;
extern eRunStatus F4_Visa_Handle_Constant_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList *argsIn, ArgList *argsOut, Boolean *pause);
#define F4_Visa_Handle_Constant_formID 3200

#ifdef LV_MAIN
FormTableEntry formTable[] = {
{ Open_Controller_handle_formID, Open_Controller_handle_Run, &Open_Controller_handle_VIName },
};
uInt8 formTableSize = 1;
#ifndef No_OS
LVCriticalSection gVICriticalSections[1];
uInt8 gVICriticalSectionsSize = 0;
#endif
#else
extern FormTableEntry formTable[];
#endif

#endif
