/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Utility Generate Instrument Error.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Private\Utility Generate Instrument Error.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 4;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snode72FE14C = false;
struct _Watflow_F4_lvlib_Utility_Generate_Instrument_Error_heap { 
	cl_00000 c_Bundle_By_Name_output_cluster_1;
	cl_00000 c_error_in__no_error__3;
	cl_00000 c_Case_Structure_CT_23;
	cl_00000 c_error_in__no_error__CT_3;
	cl_00000 c_error_in__no_error__CT_4;
	cl_00000 c_Case_Structure_CT_22;
	cl_00000 c_Error_Out;
	int32 l_Code__0_;
	int32 l_Array_Index;
	int32 l_Array_Size_size_s__1;
	int32 l_Decrement_x_1;
	VoidHand s_delimiter__Tab_;
	VoidHand ArgsEB12031;  
	VoidHand s_VISA_resource_name_3;
	VoidHand a_Call_Chain_call_chain;
	VoidHand a_Array_Subset_subarray_1;
	VoidHand s_Array_To_Spreadsheet_String_s;
	VoidHand s_format_string;
	VoidHand ArgsEB12211;  
	uInt8 runStat2;  
	uInt8 runStatEBFACD2;  
	uInt8 runStatEB11DF0;  
	uInt8 runStat72FE14C;  
	uInt8 runStatEB12210;  
	uInt8 runStatEBFAC91;  
	uInt8 runStatEBFAC92;  
	uInt8 runStat1;  
	uInt8 runStatEBFACD1;  
	Boolean b_Unbundle_By_Name_status_3;
	Boolean b_Not__not__x_;
	Boolean b_Status__F__Off_;
	Boolean b_And_x__and__y__1;
	Boolean b_And_x__and__y__CS_1;
	Boolean b_And_x__and__y__CS;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_Generate_Instrument_Error_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Utility_Generate_Instrument_Error_signalsReadyTable[3];

static struct _Watflow_F4_lvlib_Utility_Generate_Instrument_Error_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Utility_Generate_Instrument_Error_heap; /* heap */

struct _tWatflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeap {
	uInt8	refCnt;
	cl_00000	i0E9BDF30;
	String	i0E9BDFD8;
	String	i0E9BE080;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeap;
static struct _tWatflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeap _DATA_SECTION *Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr = &__Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Utility_Generate_Instrument_Error_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[3] = {1, 1, 1};
struct _g_string_5 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_5 g_string_5 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_cluster_1 = { 
	0, 0, &g_string_5.el_1
};

struct _g_string_4 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[4];
};
static struct _g_string_4 g_string_4 = { 
	0, 1, 2, _LVT("%s")
};

struct _g_string_3 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[4];
};
static struct _g_string_3 g_string_3 = { 
	0, 1, 2, _LVT("->")
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

static NumericData g_control_1 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ClusterControlData g_control_5 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_9 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static BooleanData g_control_10 = {
	true, false, false, true
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2400UL
#define Code__0___259409152_ctlid 2400
#define error_out__259410304_ctlid 2401
#define error_in__no_error___259411456_ctlid 2402
#define Status__F__Off___259411648_ctlid 2403
#define VISA_resource_name_out__259412128_ctlid 2404
#define VISA_resource_name__259412608_ctlid 2405
#define N_CONTROLS 6L
#define gArrControlData Watflow_F4_lvlib_Utility_Generate_Instrument_Error_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_gArrControlData[6] = {
	{ Code__0___259409152_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ error_out__259410304_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_in__no_error___259411456_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ Status__F__Off___259411648_ctlid, 0, NULL, VoidHandDataType, pushbutton_control },
	{ VISA_resource_name_out__259412128_ctlid, 0, NULL, StringDataType, nonui_control },
	{ VISA_resource_name__259412608_ctlid, 0, NULL, StringDataType, nonui_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	{int32 dVal = (int32)0 ;
		{
			static NumericInitialData numData = {
				Code__0___259409152_ctlid,
				0,
				0,
				66,
				int32DataType,
				-2.1474836480000000000E+9,
				2.1474836470000000000E+9,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Code__0___259409152_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_1, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Code__0___259409152_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[1].pValue, argsIn->args[1].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Code__0___259409152_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Code (0)"),8,-18,-20,55,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__259410304_ctlid) = ClusterControlDataCreateStatic(&g_control_5, GetControlDataPtr(), gFormID, error_out__259410304_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb43);
		}
		InitClusterControlFieldValue( FPData(error_out__259410304_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__259410304_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-2,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(error_in__no_error___259411456_ctlid) = ClusterControlDataCreateStatic(&g_control_9, GetControlDataPtr(), gFormID, error_in__no_error___259411456_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___259411456_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[0].pValue, argsIn->args[0].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb45);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___259411456_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___259411456_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,-1,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(Status__F__Off___259411648_ctlid) = BooleanDataCreateStatic(&g_control_10, Status__F__Off___259411648_ctlid, (Boolean)0, (Boolean)1, (Boolean)false, (uInt8)1, (!version35)?std_button:std_button))){
		return false;
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		{
			int32 lVal;
			nIdx = CalcControlOffset( gFormID, Status__F__Off___259411648_ctlid);
			lVal = LVPtrToLong( argsIn->args[2].pValue, argsIn->args[2].nType );
			if (!SetBooleanFieldValue( gArrControlData[nIdx].hValue, (Boolean)lVal )) {
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Status__F__Off___259411648_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Status (F: Off)"),15,-1,-16,99,16,
	_LVT("0"),12,0,0,0, false);
	FPData(VISA_resource_name_out__259412128_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb47);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__259412128_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-16,157,16,
	_LVT("0"),12,0,1000,0, false);
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__259412608_ctlid);
			vhIn = *(VoidHand *)argsIn->args[3].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[3].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[3].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[3].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__259412608_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,1,-16,129,16,
	_LVT("0"),12,0,1000,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Utility_Generate_Instrument_Error_FrontPanelInit NULL
#define Watflow_F4_lvlib_Utility_Generate_Instrument_Error_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_out__259410304_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__259410304_ctlid), false );
	if (FPData(error_in__no_error___259411456_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___259411456_ctlid), false );
	(void)BooleanFreeData( FPData(Status__F__Off___259411648_ctlid) );
PDAStrFree( FPData(VISA_resource_name_out__259412128_ctlid) );
	FPData(VISA_resource_name_out__259412128_ctlid) = NULL;
PDAStrFree( FPData(VISA_resource_name__259412608_ctlid) );
	FPData(VISA_resource_name__259412608_ctlid) = NULL;
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__259410304_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__259412128_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[1].pValue = GetControlHValue(nIdx);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_AddSubVIInstanceData(void) {
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_AddVIGlobalConstants(void) {
	(Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->refCnt)++;
	if (Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->refCnt > 1) return;

	if ( !(((cl_00000*)&Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDF30)->el_2)) {
		{
			cl_00000* cl_002;
			cl_002 = (cl_00000*)&Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDF30;
			MemSet( cl_002, sizeof(cl_00000), 0 );
			cl_002->el_0 = false;
			cl_002->el_1 = 0 ;
			cl_002->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb52);
		}
	}
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDFD8 = (void*)&g_string_4.el_1;
	((PDAStrPtr)&g_string_4.el_1)->len = 2;
	((PDAStrPtr)&g_string_4.el_1)->refcnt = 1;
	((PDAStrPtr)&g_string_4.el_1)->staticStr = 1;
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BE080 = (void*)&g_string_3.el_1;
	((PDAStrPtr)&g_string_3.el_1)->len = 2;
	((PDAStrPtr)&g_string_3.el_1)->refcnt = 1;
	((PDAStrPtr)&g_string_3.el_1)->staticStr = 1;
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupVIGlobalConstants(void) {
	if (Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->refCnt > 0) return;

	/* Free Cluster */
	{
		cl_00000* cl_003 = (cl_00000*)&Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDF30;
				if (cl_003->el_2 && --((PDAStrPtr)cl_003->el_2)->refcnt == 0 && !((PDAStrPtr)cl_003->el_2)->staticStr) {
			MemHandleFree( cl_003->el_2 );
		}
	}
	if (Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDFD8 && --((PDAStrPtr)Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDFD8)->refcnt == 0 && !((PDAStrPtr)Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDFD8)->staticStr) {
		MemHandleFree( Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDFD8 );
	}
	if (Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BE080 && --((PDAStrPtr)Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BE080)->refcnt == 0 && !((PDAStrPtr)Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BE080)->staticStr) {
		MemHandleFree( Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BE080 );
	}
	MemSet(Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr,sizeof(*(Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr)),0);
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_InitVIConstantList(void) {
	heap->s_delimiter__Tab_ = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BE080;
	heap->s_format_string = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDFD8;
	heap->c_Error_Out = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->i0E9BDF30;
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_RunFunc_72FE14C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_RunFunc_72FE14C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72FE14C == eReady) {
			CCGDebugSynchSNode(&state, 4, 5, 1, &snode72FE14C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatEBFAC91 = eReady;
			heap->runStatEB11DF0 = eReady;
			heap->runStatEBFAC92 = eReady;
			heap->runStatEBFACD1 = eReady;
			heap->runStatEBFACD2 = eReady;
			heap->b_And_x__and__y__CS = heap->b_And_x__and__y__1;
			/*SetSignalReady( 0x4, 1);*//* b_And_x__and__y__CS */
			MemMove( &heap->c_error_in__no_error__CT_3, &heap->c_error_in__no_error__3, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x0, 3);*//* c_error_in__no_error__CT_3 */
		}
		/* begin case */
		if ( heap->b_And_x__and__y__CS ) {
			uInt32 diagramIdx = 7;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					/*InitSignalReady( 0x1, 7);*//* a_Array_Subset_subarray_1 */
					/*InitSignalReady( 0x4, 0);*//* b_And_x__and__y__CS_1 */
					InitSignalReady(0, 1);
					/*InitSignalReady( 0x0, 0);*//* c_Bundle_By_Name_output_cluster_1 */
					/*InitSignalReady( 0x2, 0);*//* s_Array_To_Spreadsheet_String_s */
					/*InitSignalReady( 0x0, 7);*//* l_Code__0_ */
					/*InitSignalReady( 0x0, 6);*//* c_Error_Out */
					/*InitSignalReady( 0x2, 1);*//* s_format_string */
					/*InitSignalReady( 0x1, 3);*//* s_delimiter__Tab_ */
					/*InitSignalReady( 0x1, 2);*//* l_Decrement_x_1 */
					/*InitSignalReady( 0x1, 1);*//* l_Array_Size_size_s__1 */
					/*InitSignalReady( 0x1, 6);*//* a_Call_Chain_call_chain */
					/*InitSignalReady( 0x1, 0);*//* l_Array_Index */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->b_And_x__and__y__CS_1 = heap->b_And_x__and__y__CS;
					/*SetSignalReady( 0x4, 0);*//* b_And_x__and__y__CS_1 */
					UpdateProbes(&state, debugOffset, 10 /*0xEB11550*/, (uChar*)&(heap->b_And_x__and__y__CS_1)); /* assign */
					heap->l_Array_Index = 1;
					/*SetSignalReady( 0x1, 0);*//* l_Array_Index */
					UpdateProbes(&state, debugOffset, 20 /*0xEAC1878*/, (uChar*)&(heap->l_Array_Index)); /* assign */
					/*SetSignalReady( 0x1, 3);*//* s_delimiter__Tab_ */
					UpdateProbes(&state, debugOffset, 16 /*0xEAC19F8*/, (uChar*)&(heap->s_delimiter__Tab_)); /* assign */
					PDAStrIncRefCnt(heap->s_delimiter__Tab_, (uInt16)1); /* BDConst - alloc type */
					/*SetSignalReady( 0x2, 1);*//* s_format_string */
					UpdateProbes(&state, debugOffset, 15 /*0xEAC1AB8*/, (uChar*)&(heap->s_format_string)); /* assign */
					PDAStrIncRefCnt(heap->s_format_string, (uInt16)1); /* BDConst - alloc type */
					/*SetSignalReady( 0x0, 6);*//* c_Error_Out */
					UpdateProbes(&state, debugOffset, 14 /*0xEB113D0*/, (uChar*)&(heap->c_Error_Out)); /* assign */
					/* Cluster Inc Ref Count:  BDConst - alloc type*/
					{
						cl_00000* cl_005 = (cl_00000*)&heap->c_Error_Out;
						PDAStrIncRefCnt(cl_005->el_2, (uInt16)1); /* BDConst - alloc type */
					}
					/* Free unwired input select tunnel. */
	/* Free Cluster */
					{
						cl_00000* cl_006 = (cl_00000*)&heap->c_error_in__no_error__CT_3;
				if (cl_006->el_2 && --((PDAStrPtr)cl_006->el_2)->refcnt == 0 && !((PDAStrPtr)cl_006->el_2)->staticStr) {
							MemHandleFree( cl_006->el_2 );
						}
					}
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					/**/
					/* Call Chain */
					/**/
					CCGDebugSynchNode(&state, 7, 8, 7, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (!ExecStackCallChain(&(heap->a_Call_Chain_call_chain))) {
						CGenErr();
					}
					/*SetSignalReady( 0x1, 6);*//* a_Call_Chain_call_chain */
					UpdateProbes(&state, debugOffset, 19 /*0xEAC18D8*/, (uChar*)&(heap->a_Call_Chain_call_chain)); /* assign */
					PDAArrIncRefCnt(heap->a_Call_Chain_call_chain, (uInt16)1); /* Primitive */
					/**/
					/* Array Size */
					/**/
					CCGDebugSynchNode(&state, 8, 9, 7, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (heap->a_Call_Chain_call_chain) {
						heap->l_Array_Size_size_s__1 = NthDim( ((PDAArrPtr)heap->a_Call_Chain_call_chain), 0 );
					}
					else {
						heap->l_Array_Size_size_s__1 = 0;
					}
	PDAArrFree(heap->a_Call_Chain_call_chain);
					/*SetSignalReady( 0x1, 1);*//* l_Array_Size_size_s__1 */
					UpdateProbes(&state, debugOffset, 18 /*0xEAC1938*/, (uChar*)&(heap->l_Array_Size_size_s__1)); /* assign */
					/**/
					/* Decrement */
					/**/
					CCGDebugSynchNode(&state, 9, 10, 7, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->l_Decrement_x_1 = (int32)(heap->l_Array_Size_size_s__1 - 1);
					/*SetSignalReady( 0x1, 2);*//* l_Decrement_x_1 */
					UpdateProbes(&state, debugOffset, 17 /*0xEAC1998*/, (uChar*)&(heap->l_Decrement_x_1)); /* assign */
					CCGDebugSynchNode(&state, 10, 11, 7, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					/* Array Subset */
					{
						Boolean bEmpty = false;
						Boolean bNullInput=false;
						ArrDimSize start0;
						{
							ArrDimSize nDimSize0=0;
							start0 = (ArrDimSize)heap->l_Array_Index;
							if (start0 < 0) {
								start0 = 0;
							}

							if (start0 >= PDAArrNthDim(((PDAArrPtr)heap->a_Call_Chain_call_chain), (ArrDimSize)0)) {
								start0 = PDAArrNthDim(((PDAArrPtr)heap->a_Call_Chain_call_chain), (ArrDimSize)0);
							}
							nDimSize0 = (ArrDimSize)heap->l_Decrement_x_1;
							if (nDimSize0 <= 0) {
								nDimSize0 = 0;
							}
							if ((start0 + nDimSize0) > PDAArrNthDim(((PDAArrPtr)heap->a_Call_Chain_call_chain), (ArrDimSize)0)) {
								nDimSize0 = PDAArrNthDim(((PDAArrPtr)heap->a_Call_Chain_call_chain), (ArrDimSize)0) - start0;
							}
							if (!(heap->a_Array_Subset_subarray_1 = PDAArrNew1DStatic((ArrDimSize)nDimSize0, StringDataType, &g_staticArray_17))){
								CGenErr();
							}
						}
						{
							ArrDimSize end0;
							if (start0 >= PDAArrNthDim(((PDAArrPtr)heap->a_Call_Chain_call_chain), (ArrDimSize)0)) {
								bEmpty = true;
							}
							end0 = start0 + (ArrDimSize)heap->l_Decrement_x_1;
							if ((end0 < 0) || (end0 <= start0)) {
								bEmpty = true;;	}
							if (end0 > PDAArrNthDim(((PDAArrPtr)heap->a_Call_Chain_call_chain), (ArrDimSize)0)) {
								end0 = PDAArrNthDim(((PDAArrPtr)heap->a_Call_Chain_call_chain), (ArrDimSize)0);
								PDAArrSetDim(((PDAArrPtr)heap->a_Array_Subset_subarray_1), (ArrDimSize)0, (end0 - start0) );
							}
							if (!bEmpty) {
								{ArrDimSize i0;
									for (i0=start0;i0<end0;i0++) {
										if (!PDAArrSetData(((PDAArrPtr)heap->a_Array_Subset_subarray_1), (i0-start0), PDAArrGetData( ((PDAArrPtr)heap->a_Call_Chain_call_chain), i0 ), StringDataType )) {
											CGenErr();
										}
									}}
							}
							else {
								MemHandleFree( heap->a_Array_Subset_subarray_1 ); //  Uninitialized
							}
	PDAArrFree(heap->a_Call_Chain_call_chain);
						}
						if (bNullInput) heap->a_Call_Chain_call_chain = NULL;
					}
					/*SetSignalReady( 0x1, 7);*//* a_Array_Subset_subarray_1 */
					UpdateProbes(&state, debugOffset, 9 /*0xEB115B0*/, (uChar*)&(heap->a_Array_Subset_subarray_1)); /* assign */
					/**/
					/* Array To Spreadsheet String */
					/**/
					CCGDebugSynchNode(&state, 11, 12, 7, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if(!PDAArrayToString(heap->a_Array_Subset_subarray_1,heap->s_format_string,heap->s_delimiter__Tab_,&(heap->s_Array_To_Spreadsheet_String_s))) {
						CGenErr();
					}
					/*SetSignalReady( 0x2, 0);*//* s_Array_To_Spreadsheet_String_s */
					UpdateProbes(&state, debugOffset, 12 /*0xEB11490*/, (uChar*)&(heap->s_Array_To_Spreadsheet_String_s)); /* assign */
					if (!GetNumericFieldValue( FPData(Code__0___259409152_ctlid), &heap->l_Code__0_, int32DataType )){
						CGenErr();
					}
					/*SetSignalReady( 0x0, 7);*//* l_Code__0_ */
					UpdateProbes(&state, debugOffset, 13 /*0xEB11430*/, (uChar*)&(heap->l_Code__0_)); /* assign */
					CCGDebugSynchNode(&state, 12, 13, 7, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
/* Bundle by name */
					{
						cl_00000* cl_007 = NULL;
						/* Cluster CopyOnModify */
						MemMove( &heap->c_Bundle_By_Name_output_cluster_1, &heap->c_Error_Out, sizeof( cl_00000 ) );
						{
							cl_00000* clSrc_008 = (cl_00000*)&heap->c_Error_Out;
							cl_00000* clDest_009 = (cl_00000*)&heap->c_Bundle_By_Name_output_cluster_1;
							clDest_009->el_2 = clSrc_008->el_2;
						}
						cl_007 = (cl_00000*)&heap->c_Bundle_By_Name_output_cluster_1;
	cl_007->el_0 = heap->b_And_x__and__y__CS_1;
	cl_007->el_1 = heap->l_Code__0_;
	if (cl_007->el_2 && --((PDAStrPtr)cl_007->el_2)->refcnt == 0 && !((PDAStrPtr)cl_007->el_2)->staticStr) {
							MemHandleFree( cl_007->el_2 );
						}
						cl_007->el_2 = heap->s_Array_To_Spreadsheet_String_s;
						/*SetSignalReady( 0x0, 0);*//* c_Bundle_By_Name_output_cluster_1 */
						UpdateProbes(&state, debugOffset, 11 /*0xEB114F0*/, (uChar*)&(heap->c_Bundle_By_Name_output_cluster_1)); /* assign */
						SetSignalReady(0, 1);
					}
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 2 : {
					MemMove( &heap->c_Case_Structure_CT_23, &heap->c_Bundle_By_Name_output_cluster_1, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 2);*//* c_Case_Structure_CT_23 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 13, 7, &snode72FE14C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 6;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(1, 1);
					/*InitSignalReady( 0x0, 4);*//* c_error_in__no_error__CT_4 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					MemMove( &heap->c_error_in__no_error__CT_4, &heap->c_error_in__no_error__CT_3, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 4);*//* c_error_in__no_error__CT_4 */
					UpdateProbes(&state, debugOffset, 8 /*0xEB12150*/, (uChar*)&(heap->c_error_in__no_error__CT_4)); /* assign */
					SetSignalReady(1, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_23, &heap->c_error_in__no_error__CT_4, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 2);*//* c_Case_Structure_CT_23 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 6, 6, &snode72FE14C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		MemMove( &heap->c_Case_Structure_CT_22, &heap->c_Case_Structure_CT_23, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x0, 5);*//* c_Case_Structure_CT_22 */
		UpdateProbes(&state, debugOffset, 6 /*0xEAC1518*/, (uChar*)&(heap->c_Case_Structure_CT_22)); /* assign */
		CCGDebugSynchAfterSNode(&state, &snode72FE14C, 5, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	{
		if (!SetClusterControlFieldValue( FPData(error_out__259410304_ctlid), &heap->c_Case_Structure_CT_22, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, error_out__259410304_ctlid);
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			/*InitSignalReady( 0x1, 5);*//* s_VISA_resource_name_3 */
			/*InitSignalReady( 0x0, 1);*//* c_error_in__no_error__3 */
			InitSignalReady(2, 1);
			/*InitSignalReady( 0x3, 7);*//* b_And_x__and__y__1 */
			/*InitSignalReady( 0x3, 6);*//* b_Status__F__Off_ */
			/*InitSignalReady( 0x3, 5);*//* b_Not__not__x_ */
			/*InitSignalReady( 0x0, 5);*//* c_Case_Structure_CT_22 */
			/*InitSignalReady( 0x3, 4);*//* b_Unbundle_By_Name_status_3 */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			heap->s_VISA_resource_name_3 = FPData(VISA_resource_name__259412608_ctlid);
			PDAStrIncRefCnt(heap->s_VISA_resource_name_3, (uInt16)1);
			/*SetSignalReady( 0x1, 5);*//* s_VISA_resource_name_3 */
			UpdateProbes(&state, debugOffset, 1 /*0xEAC16F8*/, (uChar*)&(heap->s_VISA_resource_name_3)); /* assign */
			nStep++;}
/* start q el linear (0 or 1 struct) */
		case 1 : {
			MemMove( &heap->c_error_in__no_error__3, ((ClusterControlData*)FPData(error_in__no_error___259411456_ctlid))->pVal, sizeof( cl_00000 ) );
			MemSet(((ClusterControlData*)FPData(error_in__no_error___259411456_ctlid))->pVal, sizeof( cl_00000 ), 0);
			/*SetSignalReady( 0x0, 1);*//* c_error_in__no_error__3 */
			UpdateProbes(&state, debugOffset, 2 /*0xEAC1698*/, (uChar*)&(heap->c_error_in__no_error__3)); /* assign */
			/* Cluster Inc Ref Count:  FPTerm*/
			{
				cl_00000* cl_010 = (cl_00000*)&heap->c_error_in__no_error__3;
				PDAStrIncRefCnt(cl_010->el_2, (uInt16)1); /* FPTerm */
			}
			CCGDebugSynchNode(&state, 1, 2, 1, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
/* Unbundle by name */
			{
				cl_00000* cl_011 = (cl_00000*)&heap->c_error_in__no_error__3;
				heap->b_Unbundle_By_Name_status_3 = cl_011->el_0;
				/*SetSignalReady( 0x3, 4);*//* b_Unbundle_By_Name_status_3 */
				UpdateProbes(&state, debugOffset, 7 /*0xEAC1458*/, (uChar*)&(heap->b_Unbundle_By_Name_status_3)); /* assign */
	/* Free Cluster */
				{
					cl_00000* cl_012 = (cl_00000*)&heap->c_error_in__no_error__3;
				if (cl_012->el_2 && --((PDAStrPtr)cl_012->el_2)->refcnt == 0 && !((PDAStrPtr)cl_012->el_2)->staticStr) {
						MemHandleFree( cl_012->el_2 );
					}
				}
			}
			/**/
			/* Not */
			/**/
			CCGDebugSynchNode(&state, 2, 3, 1, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->b_Not__not__x_ = (Boolean)(!heap->b_Unbundle_By_Name_status_3);
			/*SetSignalReady( 0x3, 5);*//* b_Not__not__x_ */
			UpdateProbes(&state, debugOffset, 5 /*0xEAC1578*/, (uChar*)&(heap->b_Not__not__x_)); /* assign */
			if (!GetBooleanFieldValue( FPData(Status__F__Off___259411648_ctlid), &heap->b_Status__F__Off_ )){
				CGenErr();
			}
			/*SetSignalReady( 0x3, 6);*//* b_Status__F__Off_ */
			UpdateProbes(&state, debugOffset, 4 /*0xEAC15D8*/, (uChar*)&(heap->b_Status__F__Off_)); /* assign */
			/**/
			/* And */
			/**/
			CCGDebugSynchNode(&state, 3, 4, 1, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->b_And_x__and__y__1 =  (heap->b_Status__F__Off_ & heap->b_Not__not__x_);
			/*SetSignalReady( 0x3, 7);*//* b_And_x__and__y__1 */
			UpdateProbes(&state, debugOffset, 3 /*0xEAC1638*/, (uChar*)&(heap->b_And_x__and__y__1)); /* assign */
			SetSignalReady(2, 1);
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 2 : {
			heap->runStat72FE14C = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_RunFunc_72FE14C( bRunToFinish  );
			if (heap->runStat72FE14C == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStat72FE14C == eFail) {
				CGenErr();
			}
			heap->runStat72FE14C = eReady;
			nStep++; }
/* start q el linear (0 or 1 struct) */
		case 3 : {
	if (FPData(VISA_resource_name_out__259412128_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__259412128_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__259412128_ctlid))->staticStr) {
				MemHandleFree( FPData(VISA_resource_name_out__259412128_ctlid) );
			}
			FPData(VISA_resource_name_out__259412128_ctlid)=PDAStrCopyOnModify(heap->s_VISA_resource_name_3);
			/* Update front panel indicator */
			CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__259412128_ctlid);
			nStep++;}
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 5, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	(Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GlobalConstantsHeapPtr->refCnt)--;
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Utility_Generate_Instrument_Error_VIName = "Watflow F4.lvlib:Utility Generate Instrument Error.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Utility_Generate_Instrument_Error_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Utility_Generate_Instrument_Error_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)12,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	NULL,
	0,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_InitFPTerms,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_FrontPanelInit,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_BlockDiagram,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_DrawLabels,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_GetFPTerms,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Cleanup,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupLSRs,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_AddSubVIInstanceData,
	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


