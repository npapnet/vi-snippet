/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Open Controller handle.vi
 *	Generated from: C:\Documents and Settings\pansino\����\Source Code(0925 check UI)\SubVIs\Controller Communication.llb\Open Controller handle.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#define DEBUG_TABLE_MAIN
#include "LVDebugTable.h"
static uInt32 debugOffset = 0;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snodeF85422C = false;
static Boolean snode72F77CC = false;
static Boolean snode72F3CCC = false;
struct _Open_Controller_handle_heap { 
	cl_B0000 c_Ctrllers_LT;
	cl_C0000 c_F4_Visa_Handle_Constant_vi_F4;
	cl_C0000 c_Bundle_By_Name_output_cluster;
	cl_00000 c_VISA_Configure_Serial_Port_er;
	cl_00000 c_Initialize_vi_error_out;
	cl_00000 c_Initialize_vi_error_out_CS_1;
	double n_Unbundle_By_Name_Baud_CT;
	double n_Unbundle_By_Name_Baud;
	double n_Unbundle_By_Name_Baud_CT_1;
	int32 l_For_Loop_i;
	int32 l_Decimal_String_To_Number_numb;
	int32 l_For_Loop_N;
	int32 l_Decimal_String_To_Number_numb_1;
	int32 l_Decimal_String_To_Number_num_1;
	VoidHand ArgsF503E39;  
	VoidHand s_Unbundle_By_Name_Ctrller_Addr_1;
	VoidHand s_Unbundle_By_Name_Port_CT;
	VoidHand s_Unbundle_By_Name_Ctrller_Name_1;
	VoidHand ArgsF5019F1;  
	VoidHand ArgsF503CB9;  
	VoidHand ArgsF503D79;  
	VoidHand s_Unbundle_By_Name_Ctrller_Nam_1;
	VoidHand s_Unbundle_By_Name_Ctrller_Addr;
	VoidHand s_Unbundle_By_Name_Port_CT_1;
	VoidHand s_VISA_Configure_Serial_Port_VI;
	VoidHand s_Initialize_vi_VISA_resource_n;
	VoidHand s_Unbundle_By_Name_Port;
	VoidHand s_Initialize_vi_VISA_resource_1;
	VoidHand s_Unbundle_By_Name_Ctrller_Na_2;
	VoidHand s_Unbundle_By_Name_Ctrller_Add_1;
	VoidHand s_Initialize_vi_VISA_resource__1;
	VoidHand s_Unbundle_By_Name_Ctrller_Name;
	VoidHand Args12C2D52D;  
	VoidHand a_Ctrllers_LT;
	VoidHand ArgsF503479;  
	VoidHand a_Ctrllers;
	VoidHand s_Unbundle_By_Name_Ctrller_Na_1;
	VoidHand s_Initialize_vi_VISA_resource_n_1;
	uInt16 e_Unbundle_By_Name_Ctrller_Type_1;
	uInt16 e_Unbundle_By_Name_Ctrller_Type;
	uInt16 e_F4_Controller_handle_Global_F;
	uInt8 runStatF503478;  
	uInt8 runStat12C2D52C;  
	uInt8 runStatF5034D8;  
	uInt8 runStatF504E61;  
	uInt8 runStat72F3CCC;  
	uInt8 runStatF503E38;  
	uInt8 runStat72F77CC;  
	uInt8 runStatF503CB8;  
	uInt8 runStatF5019F0;  
	uInt8 runStatF503D78;  
	uInt8 runStatF5091E9;  
	uInt8 runStatF504721;  
	uInt8 runStatF85422C;  
	uInt8 runStat1;  
	uInt8 runStatF5036B8;  
	uInt8 runStatF509929;  
	uInt8 runStatF504CE1;  
	uInt8 runStat2;  
	Boolean b_Reset__T__Reset_;
	Boolean b_ID_Query__T__Check_;
	Boolean c_Initialize_vi_error_out_CS;
} _DATA_SECTION __Open_Controller_handle_heap; /* heap */

static uInt32 _DATA_SECTION _Open_Controller_handle_signalsReadyTable[9];

static struct _Open_Controller_handle_heap _DATA_SECTION *heap = &__Open_Controller_handle_heap; /* heap */

struct _tOpen_Controller_handle_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i0F503478;
	subVIInstanceData	i0F503D78;
	subVIInstanceData	i0F503E38;
	subVIInstanceData	i12C2D52C;
} _DATA_SECTION __Open_Controller_handle_viInstanceHeap;
static struct _tOpen_Controller_handle_viInstanceHeap _DATA_SECTION *Open_Controller_handle_viInstanceHeapPtr = &__Open_Controller_handle_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Open_Controller_handle_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[9] = {2, 2, 4, 4, 5, 2, 1, 5, 1};
struct _g_array_1 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_1 g_array_1 = { 
	0xB0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_array_2 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_2 g_array_2 = { 
	0xB0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_string_3 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_3 g_string_3 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_4 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_4 g_string_4 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_5 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_5 g_string_5 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_6 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_6 g_string_6 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_7 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_7 g_string_7 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_8 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_8 g_string_8 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_9 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_9 g_string_9 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_10 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_10 g_string_10 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

static ClusterControlData g_control_9 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ArrayControlData g_control_10 = {
	0, 0, true, 1, 0, 0
};

static NumericData g_control_11 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ClusterControlData g_control_19 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ArrayControlData g_control_20 = {
	0, 0, true, 1, 0, 0
};

static NumericData g_control_1 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2000UL
#define Ctrllers__239109704_ctlid 2000
#define Ctrllers__239112584_ctlid 2001
#define N_CONTROLS 2L
#define gArrControlData Open_Controller_handle_gArrControlData
ControlDataItem _DATA_SECTION Open_Controller_handle_gArrControlData[2] = {
	{ Ctrllers__239109704_ctlid, 0, NULL, 0xD0000 | ArrayDataType, array_control },
	{ Ctrllers__239112584_ctlid, 0, NULL, 0xD0000 | ArrayDataType, array_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Open_Controller_handle_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Open_Controller_handle_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	FPData(Ctrllers__239109704_ctlid) = NULL;
	if(bShowFrontPanel) {
/* Declare array */
		{
			FPData(Ctrllers__239109704_ctlid) = (void*)&g_array_1.el_1;
			NDims(((PDAArrPtr)&g_array_1.el_1)) = 1;
			((PDAArrPtr)&g_array_1.el_1)->datatype = 0xB0000 | ClusterDataType;
			((PDAArrPtr)&g_array_1.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_1.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_1.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(Ctrllers__239109704_ctlid) = ArrayControlDataCreateStatic(&g_control_10, FPData(Ctrllers__239109704_ctlid), Ctrllers__239109704_ctlid, 0, 0, 1, bShowFrontPanel, 1, 0xD0000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Ctrllers__239109704_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Ctrllers"),8,0,-16,51,16,
	_LVT("0"),12,0,0,0, false);
	FPData(Ctrllers__239112584_ctlid) = NULL;
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		{
			VoidHand vhIn, vhOut;
			DataType dtIn, dtOut;
			nIdx = CalcControlOffset( gFormID, Ctrllers__239112584_ctlid);
			FPDataType(Ctrllers__239112584_ctlid) = 0xD0000 | ArrayDataType;
			dtIn = argsIn->args[0].nType;
			vhIn = *(VoidHand *)argsIn->args[0].pValue;
			dtOut = gArrControlData[nIdx].dataType;
			vhOut = gArrControlData[nIdx].hValue;
			if (vhOut) {
				PDAArrFree(vhOut);
			}
			if (IsArray(dtIn)) {
				vhOut = PDAArrCopyOnModifyStatic( vhIn, &g_staticArray_1);
			}
			FPData(Ctrllers__239112584_ctlid) = vhOut;
		}
	}
	else {
/* Declare array */
		{
			FPData(Ctrllers__239112584_ctlid) = (void*)&g_array_2.el_1;
			NDims(((PDAArrPtr)&g_array_2.el_1)) = 1;
			((PDAArrPtr)&g_array_2.el_1)->datatype = 0xB0000 | ClusterDataType;
			((PDAArrPtr)&g_array_2.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_2.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_2.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(Ctrllers__239112584_ctlid) = ArrayControlDataCreateStatic(&g_control_20, FPData(Ctrllers__239112584_ctlid), Ctrllers__239112584_ctlid, 1, 0, 1, bShowFrontPanel, 1, 0xD0000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Ctrllers__239112584_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Ctrllers"),8,0,-16,51,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Open_Controller_handle_FrontPanelInit NULL
#define Open_Controller_handle_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Open_Controller_handle_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Open_Controller_handle_Cleanup(Boolean bShowFrontPanel){
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(Ctrllers__239109704_ctlid), 1 );
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(Ctrllers__239112584_ctlid), 1 );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Open_Controller_handle_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Open_Controller_handle_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, Ctrllers__239109704_ctlid);
		GetArrayControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Open_Controller_handle_CleanupLSRs(void);
void _TEXT_SECTION Open_Controller_handle_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Open_Controller_handle_AddSubVIInstanceData(void);
void _TEXT_SECTION Open_Controller_handle_AddSubVIInstanceData(void) {
	if (Open_Controller_handle_viInstanceHeapPtr->initialized) return;
	Open_Controller_handle_viInstanceHeapPtr->initialized = TRUE;

	Open_Controller_handle_viInstanceHeapPtr->i0F503478.next = gVIInstanceListHead;
	gVIInstanceListHead = &Open_Controller_handle_viInstanceHeapPtr->i0F503478;
	Open_Controller_handle_viInstanceHeapPtr->i0F503D78.next = gVIInstanceListHead;
	gVIInstanceListHead = &Open_Controller_handle_viInstanceHeapPtr->i0F503D78;
	Open_Controller_handle_viInstanceHeapPtr->i0F503E38.next = gVIInstanceListHead;
	gVIInstanceListHead = &Open_Controller_handle_viInstanceHeapPtr->i0F503E38;
	Open_Controller_handle_viInstanceHeapPtr->i12C2D52C.next = gVIInstanceListHead;
	gVIInstanceListHead = &Open_Controller_handle_viInstanceHeapPtr->i12C2D52C;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Open_Controller_handle_AddVIGlobalConstants(void);
void _TEXT_SECTION Open_Controller_handle_AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Open_Controller_handle_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Open_Controller_handle_CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Open_Controller_handle_InitVIConstantList(void);
void _TEXT_SECTION Open_Controller_handle_InitVIConstantList(void) {
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION Open_Controller_handle_RunFunc_72F3CCC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Open_Controller_handle_RunFunc_72F3CCC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F3CCC == eReady) {
			CCGDebugSynchSNode(&state, 9, 10, 6, &snode72F3CCC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatF509929 = eReady;
			heap->runStatF5036B8 = eReady;
			heap->runStatF504721 = eReady;
			heap->runStatF503E38 = eReady;
			heap->runStatF503CB8 = eReady;
			heap->runStatF503D78 = eReady;
			if (!PDAClusterGetElemByPosStatic( &heap->c_Initialize_vi_error_out, 0x0 | ClusterDataType, 0, &heap->c_Initialize_vi_error_out_CS, BooleanDataType, NULL )) {
				CGenErr();
			}
			/*SetSignalReady( 0x7, 5);*//* c_Initialize_vi_error_out_CS */
			heap->s_Initialize_vi_VISA_resource_n_1 = heap->s_Initialize_vi_VISA_resource_n;
			/*SetSignalReady( 0x4, 5);*//* s_Initialize_vi_VISA_resource_n_1 */
			heap->s_Unbundle_By_Name_Ctrller_Na_1 = heap->s_Unbundle_By_Name_Ctrller_Nam_1;
			/*SetSignalReady( 0x4, 4);*//* s_Unbundle_By_Name_Ctrller_Na_1 */
			heap->l_Decimal_String_To_Number_numb_1 = heap->l_Decimal_String_To_Number_numb;
			/*SetSignalReady( 0x1, 4);*//* l_Decimal_String_To_Number_numb_1 */
		}
		switch ( heap->c_Initialize_vi_error_out_CS ) {
			/* begin case */
			case 1 : {
				uInt32 diagramIdx = 15;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(0, 2);
						/*InitSignalReady( 0x0, 5);*//* c_Initialize_vi_error_out_CS_1 */
						/*InitSignalReady( 0x3, 3);*//* s_Initialize_vi_VISA_resource_1 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						/* Free unwired input select tunnel. */
	if (heap->s_Unbundle_By_Name_Ctrller_Na_1 && --((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Na_1)->refcnt == 0 && !((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Na_1)->staticStr) {
							MemHandleFree( heap->s_Unbundle_By_Name_Ctrller_Na_1 );
						}
						MemMove( &heap->c_Initialize_vi_error_out_CS_1, &heap->c_Initialize_vi_error_out, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x0, 5);*//* c_Initialize_vi_error_out_CS_1 */
						UpdateProbes(&state, debugOffset, 25 /*0xF5035F8*/, (uChar*)&(heap->c_Initialize_vi_error_out_CS_1)); /* assign */
						SetSignalReady(0, 1);
						heap->s_Initialize_vi_VISA_resource_1 = heap->s_Initialize_vi_VISA_resource_n_1;
						/*SetSignalReady( 0x3, 3);*//* s_Initialize_vi_VISA_resource_1 */
						UpdateProbes(&state, debugOffset, 26 /*0xF503598*/, (uChar*)&(heap->s_Initialize_vi_VISA_resource_1)); /* assign */
						SetSignalReady(0, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						/**/
						/* VISA Close */
						/**/
						CCGDebugSynchNode(&state, 15, 16, 15, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (!VisaClose(heap->s_Initialize_vi_VISA_resource_1,  &(heap->c_Initialize_vi_error_out_CS_1),  (VoidHand*)NULL )) {
							CGenErr();
						}
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 16, 15, &snode72F3CCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				int16 pass;
				Boolean bEndDiagram = false;
				uInt32 diagramIdx = 11;
				uInt32 id = LVGetTimerFlag();
				while (!gAppStop && !gLastError) {
					nReady = 0;
					bEndDiagram = false;
					runStat = eFinished;
					for (pass=0;pass<2;pass++) {
						{
/* start q el linear (2 struct) */
							if ((heap->runStatF504721 != eFinished)
							/*) {*/
							) {
								if (pass == 0) {
									InitSignalReady(2, 4);
									/*InitSignalReady( 0x0, 1);*//* c_F4_Visa_Handle_Constant_vi_F4 */
									InitSignalReady(1, 2);
									/*InitSignalReady( 0x5, 0);*//* e_F4_Controller_handle_Global_F */
									/*InitSignalReady( 0x0, 2);*//* c_Bundle_By_Name_output_cluster */
									/*InitSignalReady( 0x3, 6);*//* s_Initialize_vi_VISA_resource__1 */
									/*InitSignalReady( 0x3, 4);*//* s_Unbundle_By_Name_Ctrller_Na_2 */
									/*InitSignalReady( 0x1, 5);*//* l_Decimal_String_To_Number_num_1 */
								}
								else {
									HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
									{
										heap->s_Unbundle_By_Name_Ctrller_Na_2 = heap->s_Unbundle_By_Name_Ctrller_Na_1;
										/*SetSignalReady( 0x3, 4);*//* s_Unbundle_By_Name_Ctrller_Na_2 */
										UpdateProbes(&state, debugOffset, 23 /*0xF503778*/, (uChar*)&(heap->s_Unbundle_By_Name_Ctrller_Na_2)); /* assign */
										SetSignalReady(2, 1);
										heap->l_Decimal_String_To_Number_num_1 = heap->l_Decimal_String_To_Number_numb_1;
										/*SetSignalReady( 0x1, 5);*//* l_Decimal_String_To_Number_num_1 */
										UpdateProbes(&state, debugOffset, 24 /*0xF503718*/, (uChar*)&(heap->l_Decimal_String_To_Number_num_1)); /* assign */
										SetSignalReady(2, 1);
										heap->s_Initialize_vi_VISA_resource__1 = heap->s_Initialize_vi_VISA_resource_n_1;
										/*SetSignalReady( 0x3, 6);*//* s_Initialize_vi_VISA_resource__1 */
										UpdateProbes(&state, debugOffset, 22 /*0xF5037D8*/, (uChar*)&(heap->s_Initialize_vi_VISA_resource__1)); /* assign */
										SetSignalReady(2, 1);
										heap->e_F4_Controller_handle_Global_F = 0;
										/*SetSignalReady( 0x5, 0);*//* e_F4_Controller_handle_Global_F */
										UpdateProbes(&state, debugOffset, 20 /*0xF5038F8*/, (uChar*)&(heap->e_F4_Controller_handle_Global_F)); /* assign */
										SetSignalReady(1, 1);
									}
									heap->runStatF504721 = eFinished;
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStatF503E38 != eFinished)
							/*) {*/
							) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStatF503E38 == eReady) {
									}
									CCGDebugSynchIUse(&state, 11, 12, 11, debugOffset, &gPauseThisVI, "F4 Visa Handle Constant.vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStatF503E38 == eReady) {
											CreateArgListStatic(heap->ArgsF503E39, 0, 1 );
											argOut(heap->ArgsF503E39, 0).nType = 0xC0000 | ClusterDataType;
											argOut(heap->ArgsF503E39, 0).pValue = (void *)&heap->c_F4_Visa_Handle_Constant_vi_F4;
										}
										if (!Open_Controller_handle_viInstanceHeapPtr->i0F503E38.callerID) {
											Open_Controller_handle_viInstanceHeapPtr->i0F503E38.callerID = ++gCallerID;
										}
										heap->runStatF503E38 = F4_Visa_Handle_Constant_Run( &Open_Controller_handle_viInstanceHeapPtr->i0F503E38, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsF503E39)[0], (ArgList *)((ArgList **)heap->ArgsF503E39)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStatF503E38 == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStatF503E38 == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStatF503E38 == eFinished)) {
											/*SetSignalReady( 0x0, 1);*//* c_F4_Visa_Handle_Constant_vi_F4 */
											UpdateProbes(&state, debugOffset, 19 /*0xF503958*/, (uChar*)&(heap->c_F4_Visa_Handle_Constant_vi_F4)); /* assign */
											SetSignalReady(2, 1);
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStatF503E38 == eFinished) {
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStatF503CB8 != eFinished)
							/*&& GetSignalReady( 0x0, 1)*//* c_F4_Visa_Handle_Constant_vi_F4 */
							/*&& GetSignalReady( 0x3, 4)*//* s_Unbundle_By_Name_Ctrller_Na_2 */
							/*&& GetSignalReady( 0x1, 5)*//* l_Decimal_String_To_Number_num_1 */
							/*&& GetSignalReady( 0x3, 6)*//* s_Initialize_vi_VISA_resource__1 *//*) {*/
							&& GetSignalReady( 2 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										CCGDebugSynchNode(&state, 12, 13, 11, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
/* Bundle by name */
										{
											cl_C0000* cl_000 = NULL;
											/* Cluster CopyOnModify */
											MemMove( &heap->c_Bundle_By_Name_output_cluster, &heap->c_F4_Visa_Handle_Constant_vi_F4, sizeof( cl_C0000 ) );
											{
												cl_C0000* clSrc_001 = (cl_C0000*)&heap->c_F4_Visa_Handle_Constant_vi_F4;
												cl_C0000* clDest_002 = (cl_C0000*)&heap->c_Bundle_By_Name_output_cluster;
												clDest_002->el_0 = clSrc_001->el_0;
												clDest_002->el_2 = clSrc_001->el_2;
											}
											cl_000 = (cl_C0000*)&heap->c_Bundle_By_Name_output_cluster;
	if (cl_000->el_0 && --((PDAStrPtr)cl_000->el_0)->refcnt == 0 && !((PDAStrPtr)cl_000->el_0)->staticStr) {
												MemHandleFree( cl_000->el_0 );
											}
											cl_000->el_0 = heap->s_Unbundle_By_Name_Ctrller_Na_2;
	cl_000->el_1 = heap->l_Decimal_String_To_Number_num_1;
	if (cl_000->el_2 && --((PDAStrPtr)cl_000->el_2)->refcnt == 0 && !((PDAStrPtr)cl_000->el_2)->staticStr) {
												MemHandleFree( cl_000->el_2 );
											}
											cl_000->el_2 = heap->s_Initialize_vi_VISA_resource__1;
											/*SetSignalReady( 0x0, 2);*//* c_Bundle_By_Name_output_cluster */
											UpdateProbes(&state, debugOffset, 21 /*0xF503898*/, (uChar*)&(heap->c_Bundle_By_Name_output_cluster)); /* assign */
											SetSignalReady(1, 1);
										}
									}
									heap->runStatF503CB8 = eFinished;
									InitSignalReady(2, 4);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStatF503D78 != eFinished)
							/*&& GetSignalReady( 0x5, 0)*//* e_F4_Controller_handle_Global_F */
							/*&& GetSignalReady( 0x0, 2)*//* c_Bundle_By_Name_output_cluster *//*) {*/
							&& GetSignalReady( 1 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStatF503D78 == eReady) {
									}
									CCGDebugSynchIUse(&state, 13, 14, 11, debugOffset, &gPauseThisVI, "F4 Controller handle Global Function Variable.vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStatF503D78 == eReady) {
											CreateArgListStatic(heap->ArgsF503D79, 3, 4 );
											argIn(heap->ArgsF503D79, 0).nType = 0;
											argIn(heap->ArgsF503D79, 0).pValue = NULL;
											argIn(heap->ArgsF503D79, 1).nType = 0xE0000 | Enum16DataType;
											argIn(heap->ArgsF503D79, 1).pValue = (void *)&heap->e_F4_Controller_handle_Global_F;
											argIn(heap->ArgsF503D79, 2).nType = 0xC0000 | ClusterDataType;
											argIn(heap->ArgsF503D79, 2).pValue = (void *)&heap->c_Bundle_By_Name_output_cluster;
											argOut(heap->ArgsF503D79, 0).nType = 0;
											argOut(heap->ArgsF503D79, 0).pValue = NULL;
											argOut(heap->ArgsF503D79, 1).nType = 0;
											argOut(heap->ArgsF503D79, 1).pValue = NULL;
											argOut(heap->ArgsF503D79, 2).nType = 0;
											argOut(heap->ArgsF503D79, 2).pValue = NULL;
											argOut(heap->ArgsF503D79, 3).nType = 0;
											argOut(heap->ArgsF503D79, 3).pValue = NULL;
										}
										if (!Open_Controller_handle_viInstanceHeapPtr->i0F503D78.callerID) {
											Open_Controller_handle_viInstanceHeapPtr->i0F503D78.callerID = ++gCallerID;
										}
										heap->runStatF503D78 = F4_Controller_handle_Global_Function_Variable_Run( &Open_Controller_handle_viInstanceHeapPtr->i0F503D78, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsF503D79)[0], (ArgList *)((ArgList **)heap->ArgsF503D79)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 14, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStatF503D78 == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStatF503D78 == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStatF503D78 == eFinished)) {
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStatF503D78 == eFinished) {
										InitSignalReady(1, 2);
										continue;
									}
								}
							}
						}
						if( runStat == eFinished && pass )
						{
							volatile int dummy;
							CCGDebugSynchSRN(&state, 14, 11, &snode72F3CCC, debugOffset);
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}

							dummy=1;
						}
						if (pass) {
							if (runStat == eFinished) {
								bEndDiagram = true;
							}
							if (!bRunToFinish) {
								if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
									if (gAppStop) {
										return eFinished;
									}
									if (gLastError) {
										CGenErr();
									}
									if (!gAppStop && !gLastError) {
										return eNotFinished;
									}
								}
							}
						}
					} /* end for */
					if (bEndDiagram) break;
				} /* end while */
			} /* end case */
			break;
		}
		heap->runStatF504721 = eReady;
		heap->runStatF503E38 = eReady;
		heap->runStatF503CB8 = eReady;
		heap->runStatF503D78 = eReady;
		/* FreeCaseSelDCO. */
	/* Free Cluster */
		{
			cl_00000* cl_003 = (cl_00000*)&heap->c_Initialize_vi_error_out;
				if (cl_003->el_2 && --((PDAStrPtr)cl_003->el_2)->refcnt == 0 && !((PDAStrPtr)cl_003->el_2)->staticStr) {
				MemHandleFree( cl_003->el_2 );
			}
		}
		CCGDebugSynchAfterSNode(&state, &snode72F3CCC, 10, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Open_Controller_handle_RunFunc_72F77CC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Open_Controller_handle_RunFunc_72F77CC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F77CC == eReady) {
			CCGDebugSynchSNode(&state, 4, 5, 3, &snode72F77CC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatF5091E9 = eReady;
			heap->runStatF504CE1 = eReady;
			heap->runStatF5034D8 = eReady;
			heap->runStat12C2D52C = eReady;
			heap->runStatF503478 = eReady;
			heap->runStat72F3CCC = eReady;
			heap->e_Unbundle_By_Name_Ctrller_Type_1 = heap->e_Unbundle_By_Name_Ctrller_Type;
			/*SetSignalReady( 0x4, 6);*//* e_Unbundle_By_Name_Ctrller_Type_1 */
			heap->s_Unbundle_By_Name_Ctrller_Addr_1 = heap->s_Unbundle_By_Name_Ctrller_Addr;
			/*SetSignalReady( 0x1, 7);*//* s_Unbundle_By_Name_Ctrller_Addr_1 */
			heap->s_Unbundle_By_Name_Port_CT = heap->s_Unbundle_By_Name_Port;
			/*SetSignalReady( 0x2, 0);*//* s_Unbundle_By_Name_Port_CT */
			heap->s_Unbundle_By_Name_Ctrller_Name_1 = heap->s_Unbundle_By_Name_Ctrller_Name;
			/*SetSignalReady( 0x2, 1);*//* s_Unbundle_By_Name_Ctrller_Name_1 */
			heap->n_Unbundle_By_Name_Baud_CT = heap->n_Unbundle_By_Name_Baud;
			/*SetSignalReady( 0x0, 6);*//* n_Unbundle_By_Name_Baud_CT */
		}
		switch ( heap->e_Unbundle_By_Name_Ctrller_Type_1 ) {
			/* begin case */
			case 1 : {
				uInt32 diagramIdx = 17;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						/* Free unwired input select tunnel. */
	if (heap->s_Unbundle_By_Name_Ctrller_Addr_1 && --((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Addr_1)->refcnt == 0 && !((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Addr_1)->staticStr) {
							MemHandleFree( heap->s_Unbundle_By_Name_Ctrller_Addr_1 );
						}
						/* Free unwired input select tunnel. */
	if (heap->s_Unbundle_By_Name_Port_CT && --((PDAStrPtr)heap->s_Unbundle_By_Name_Port_CT)->refcnt == 0 && !((PDAStrPtr)heap->s_Unbundle_By_Name_Port_CT)->staticStr) {
							MemHandleFree( heap->s_Unbundle_By_Name_Port_CT );
						}
						/* Free unwired input select tunnel. */
	if (heap->s_Unbundle_By_Name_Ctrller_Name_1 && --((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Name_1)->refcnt == 0 && !((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Name_1)->staticStr) {
							MemHandleFree( heap->s_Unbundle_By_Name_Ctrller_Name_1 );
						}
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 17, 17, &snode72F77CC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				int16 pass;
				Boolean bEndDiagram = false;
				uInt32 diagramIdx = 6;
				uInt32 id = LVGetTimerFlag();
				while (!gAppStop && !gLastError) {
					nReady = 0;
					bEndDiagram = false;
					runStat = eFinished;
					for (pass=0;pass<2;pass++) {
						{
/* start q el linear (2 struct) */
							if ((heap->runStatF504CE1 != eFinished)
							/*) {*/
							) {
								if (pass == 0) {
									InitSignalReady(5, 2);
									/*InitSignalReady( 0x1, 0);*//* n_Unbundle_By_Name_Baud_CT_1 */
									InitSignalReady(3, 4);
									InitSignalReady(4, 5);
									/*InitSignalReady( 0x1, 2);*//* l_Decimal_String_To_Number_numb */
									/*InitSignalReady( 0x2, 5);*//* s_Unbundle_By_Name_Ctrller_Nam_1 */
									/*InitSignalReady( 0x0, 3);*//* c_VISA_Configure_Serial_Port_er */
									/*InitSignalReady( 0x2, 7);*//* s_Unbundle_By_Name_Port_CT_1 */
									/*InitSignalReady( 0x3, 0);*//* s_VISA_Configure_Serial_Port_VI */
									/*InitSignalReady( 0x3, 1);*//* s_Initialize_vi_VISA_resource_n */
									/*InitSignalReady( 0x0, 4);*//* c_Initialize_vi_error_out */
									/*InitSignalReady( 0x7, 3);*//* b_Reset__T__Reset_ */
									/*InitSignalReady( 0x7, 4);*//* b_ID_Query__T__Check_ */
									InitSignalReady(6, 1);
									/*InitSignalReady( 0x3, 5);*//* s_Unbundle_By_Name_Ctrller_Add_1 */
								}
								else {
									HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
									{
										heap->s_Unbundle_By_Name_Ctrller_Add_1 = heap->s_Unbundle_By_Name_Ctrller_Addr_1;
										/*SetSignalReady( 0x3, 5);*//* s_Unbundle_By_Name_Ctrller_Add_1 */
										UpdateProbes(&state, debugOffset, 18 /*0xF501B10*/, (uChar*)&(heap->s_Unbundle_By_Name_Ctrller_Add_1)); /* assign */
										SetSignalReady(6, 1);
										heap->s_Unbundle_By_Name_Port_CT_1 = heap->s_Unbundle_By_Name_Port_CT;
										/*SetSignalReady( 0x2, 7);*//* s_Unbundle_By_Name_Port_CT_1 */
										UpdateProbes(&state, debugOffset, 12 /*0xF501E70*/, (uChar*)&(heap->s_Unbundle_By_Name_Port_CT_1)); /* assign */
										SetSignalReady(5, 1);
										heap->b_ID_Query__T__Check_ = true;
										/*SetSignalReady( 0x7, 4);*//* b_ID_Query__T__Check_ */
										UpdateProbes(&state, debugOffset, 17 /*0xF501B70*/, (uChar*)&(heap->b_ID_Query__T__Check_)); /* assign */
										SetSignalReady(4, 1);
										heap->b_Reset__T__Reset_ = false;
										/*SetSignalReady( 0x7, 3);*//* b_Reset__T__Reset_ */
										UpdateProbes(&state, debugOffset, 16 /*0xF501BD0*/, (uChar*)&(heap->b_Reset__T__Reset_)); /* assign */
										SetSignalReady(4, 1);
										heap->s_Unbundle_By_Name_Ctrller_Nam_1 = heap->s_Unbundle_By_Name_Ctrller_Name_1;
										/*SetSignalReady( 0x2, 5);*//* s_Unbundle_By_Name_Ctrller_Nam_1 */
										UpdateProbes(&state, debugOffset, 10 /*0xF502FF8*/, (uChar*)&(heap->s_Unbundle_By_Name_Ctrller_Nam_1)); /* assign */
										SetSignalReady(3, 1);
										heap->n_Unbundle_By_Name_Baud_CT_1 = heap->n_Unbundle_By_Name_Baud_CT;
										/*SetSignalReady( 0x1, 0);*//* n_Unbundle_By_Name_Baud_CT_1 */
										UpdateProbes(&state, debugOffset, 8 /*0xF503118*/, (uChar*)&(heap->n_Unbundle_By_Name_Baud_CT_1)); /* assign */
										SetSignalReady(5, 1);
									}
									heap->runStatF504CE1 = eFinished;
									continue;
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStatF5034D8 != eFinished)
							/*&& GetSignalReady( 0x3, 5)*//* s_Unbundle_By_Name_Ctrller_Add_1 *//*) {*/
							&& GetSignalReady( 6 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										/**/
										/* Decimal String To Number */
										/**/
										CCGDebugSynchNode(&state, 6, 7, 6, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										PDAStrTextToNum( &(heap->s_Unbundle_By_Name_Ctrller_Add_1), StringDataType, 'd', NULL, uCharDataType, NULL, uCharDataType, NULL, &(heap->l_Decimal_String_To_Number_numb), int32DataType );
	if (heap->s_Unbundle_By_Name_Ctrller_Add_1 && --((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Add_1)->refcnt == 0 && !((PDAStrPtr)heap->s_Unbundle_By_Name_Ctrller_Add_1)->staticStr) {
											MemHandleFree( heap->s_Unbundle_By_Name_Ctrller_Add_1 );
										}
										/*SetSignalReady( 0x1, 2);*//* l_Decimal_String_To_Number_numb */
										UpdateProbes(&state, debugOffset, 9 /*0xF503058*/, (uChar*)&(heap->l_Decimal_String_To_Number_numb)); /* assign */
										SetSignalReady(3, 1);
										SetSignalReady(4, 1);
									}
									heap->runStatF5034D8 = eFinished;
									InitSignalReady(6, 1);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat12C2D52C != eFinished)
							/*&& GetSignalReady( 0x2, 7)*//* s_Unbundle_By_Name_Port_CT_1 */
							/*&& GetSignalReady( 0x1, 0)*//* n_Unbundle_By_Name_Baud_CT_1 *//*) {*/
							&& GetSignalReady( 5 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStat12C2D52C == eReady) {
									}
									CCGDebugSynchIUse(&state, 7, 8, 6, debugOffset, &gPauseThisVI, "VISA Configure Serial Port (Instr).vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStat12C2D52C == eReady) {
											CreateArgListStatic(heap->Args12C2D52D, 10, 2 );
											argIn(heap->Args12C2D52D, 0).nType = StringDataType;
											argIn(heap->Args12C2D52D, 0).pValue = (void *)&heap->s_Unbundle_By_Name_Port_CT_1;
											argIn(heap->Args12C2D52D, 1).nType = 0;
											argIn(heap->Args12C2D52D, 1).pValue = NULL;
											argIn(heap->Args12C2D52D, 2).nType = 0;
											argIn(heap->Args12C2D52D, 2).pValue = NULL;
											argIn(heap->Args12C2D52D, 3).nType = 0;
											argIn(heap->Args12C2D52D, 3).pValue = NULL;
											argIn(heap->Args12C2D52D, 4).nType = doubleDataType;
											argIn(heap->Args12C2D52D, 4).pValue = (void *)&heap->n_Unbundle_By_Name_Baud_CT_1;
											argIn(heap->Args12C2D52D, 5).nType = 0;
											argIn(heap->Args12C2D52D, 5).pValue = NULL;
											argIn(heap->Args12C2D52D, 6).nType = 0;
											argIn(heap->Args12C2D52D, 6).pValue = NULL;
											argIn(heap->Args12C2D52D, 7).nType = 0;
											argIn(heap->Args12C2D52D, 7).pValue = NULL;
											argIn(heap->Args12C2D52D, 8).nType = 0;
											argIn(heap->Args12C2D52D, 8).pValue = NULL;
											argIn(heap->Args12C2D52D, 9).nType = 0;
											argIn(heap->Args12C2D52D, 9).pValue = NULL;
											argOut(heap->Args12C2D52D, 0).nType = StringDataType;
											argOut(heap->Args12C2D52D, 0).pValue = (void *)&heap->s_VISA_Configure_Serial_Port_VI;
											argOut(heap->Args12C2D52D, 1).nType = 0x0 | ClusterDataType;
											argOut(heap->Args12C2D52D, 1).pValue = (void *)&heap->c_VISA_Configure_Serial_Port_er;
										}
										if (!Open_Controller_handle_viInstanceHeapPtr->i12C2D52C.callerID) {
											Open_Controller_handle_viInstanceHeapPtr->i12C2D52C.callerID = ++gCallerID;
										}
										heap->runStat12C2D52C = VISA_Configure_Serial_Port__Instr__Run( &Open_Controller_handle_viInstanceHeapPtr->i12C2D52C, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args12C2D52D)[0], (ArgList *)((ArgList **)heap->Args12C2D52D)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 8, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStat12C2D52C == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStat12C2D52C == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStat12C2D52C == eFinished)) {
											/*SetSignalReady( 0x3, 0);*//* s_VISA_Configure_Serial_Port_VI */
											UpdateProbes(&state, debugOffset, 13 /*0xF501E10*/, (uChar*)&(heap->s_VISA_Configure_Serial_Port_VI)); /* assign */
											SetSignalReady(4, 1);
											/*SetSignalReady( 0x0, 3);*//* c_VISA_Configure_Serial_Port_er */
											UpdateProbes(&state, debugOffset, 11 /*0xF501F30*/, (uChar*)&(heap->c_VISA_Configure_Serial_Port_er)); /* assign */
											SetSignalReady(4, 1);
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStat12C2D52C == eFinished) {
										InitSignalReady(5, 2);
										continue;
									}
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStatF503478 != eFinished)
							/*&& GetSignalReady( 0x3, 0)*//* s_VISA_Configure_Serial_Port_VI */
							/*&& GetSignalReady( 0x1, 2)*//* l_Decimal_String_To_Number_numb */
							/*&& GetSignalReady( 0x7, 4)*//* b_ID_Query__T__Check_ */
							/*&& GetSignalReady( 0x7, 3)*//* b_Reset__T__Reset_ */
							/*&& GetSignalReady( 0x0, 3)*//* c_VISA_Configure_Serial_Port_er *//*) {*/
							&& GetSignalReady( 4 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStatF503478 == eReady) {
									}
									CCGDebugSynchIUse(&state, 8, 9, 6, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Initialize.vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStatF503478 == eReady) {
											CreateArgListStatic(heap->ArgsF503479, 5, 2 );
											argIn(heap->ArgsF503479, 0).nType = StringDataType;
											argIn(heap->ArgsF503479, 0).pValue = (void *)&heap->s_VISA_Configure_Serial_Port_VI;
											argIn(heap->ArgsF503479, 1).nType = int32DataType;
											argIn(heap->ArgsF503479, 1).pValue = (void *)&heap->l_Decimal_String_To_Number_numb;
											argIn(heap->ArgsF503479, 2).nType = BooleanDataType;
											argIn(heap->ArgsF503479, 2).pValue = (void *)&heap->b_ID_Query__T__Check_;
											argIn(heap->ArgsF503479, 3).nType = BooleanDataType;
											argIn(heap->ArgsF503479, 3).pValue = (void *)&heap->b_Reset__T__Reset_;
											argIn(heap->ArgsF503479, 4).nType = 0x0 | ClusterDataType;
											argIn(heap->ArgsF503479, 4).pValue = (void *)&heap->c_VISA_Configure_Serial_Port_er;
											argOut(heap->ArgsF503479, 0).nType = StringDataType;
											argOut(heap->ArgsF503479, 0).pValue = (void *)&heap->s_Initialize_vi_VISA_resource_n;
											argOut(heap->ArgsF503479, 1).nType = 0x0 | ClusterDataType;
											argOut(heap->ArgsF503479, 1).pValue = (void *)&heap->c_Initialize_vi_error_out;
										}
										if (!Open_Controller_handle_viInstanceHeapPtr->i0F503478.callerID) {
											Open_Controller_handle_viInstanceHeapPtr->i0F503478.callerID = ++gCallerID;
										}
										heap->runStatF503478 = Watflow_F4_lvlib_Initialize_Run( &Open_Controller_handle_viInstanceHeapPtr->i0F503478, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsF503479)[0], (ArgList *)((ArgList **)heap->ArgsF503479)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 9, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStatF503478 == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStatF503478 == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStatF503478 == eFinished)) {
											/*SetSignalReady( 0x3, 1);*//* s_Initialize_vi_VISA_resource_n */
											UpdateProbes(&state, debugOffset, 14 /*0xF501D50*/, (uChar*)&(heap->s_Initialize_vi_VISA_resource_n)); /* assign */
											SetSignalReady(3, 1);
											/*SetSignalReady( 0x0, 4);*//* c_Initialize_vi_error_out */
											UpdateProbes(&state, debugOffset, 15 /*0xF501C90*/, (uChar*)&(heap->c_Initialize_vi_error_out)); /* assign */
											SetSignalReady(3, 1);
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStatF503478 == eFinished) {
										InitSignalReady(4, 5);
										continue;
									}
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat72F3CCC != eFinished)
							/*&& GetSignalReady( 0x0, 4)*//* c_Initialize_vi_error_out */
							/*&& GetSignalReady( 0x3, 1)*//* s_Initialize_vi_VISA_resource_n */
							/*&& GetSignalReady( 0x2, 5)*//* s_Unbundle_By_Name_Ctrller_Nam_1 */
							/*&& GetSignalReady( 0x1, 2)*//* l_Decimal_String_To_Number_numb *//*) {*/
							&& GetSignalReady( 3 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									heap->runStat72F3CCC = Open_Controller_handle_RunFunc_72F3CCC( (Boolean)(bRunToFinish && (nReady < 2)) );
									if (heap->runStat72F3CCC == eNotFinished) {
										runStat = eNotFinished;
									}
									else if (heap->runStat72F3CCC == eFail) {
										CGenErr();
									}
									else {
										InitSignalReady(3, 4);
									}
									if (runStat == eFinished) {
										continue;
									}
								}
							}
						}
						if( runStat == eFinished && pass )
						{
							volatile int dummy;
							CCGDebugSynchSRN(&state, 10, 6, &snode72F77CC, debugOffset);
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}

							dummy=1;
						}
						if (pass) {
							if (runStat == eFinished) {
								bEndDiagram = true;
							}
							if (!bRunToFinish) {
								if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
									if (gAppStop) {
										return eFinished;
									}
									if (gLastError) {
										CGenErr();
									}
									if (!gAppStop && !gLastError) {
										return eNotFinished;
									}
								}
							}
						}
					} /* end for */
					if (bEndDiagram) break;
				} /* end while */
			} /* end case */
			break;
		}
		heap->runStatF504CE1 = eReady;
		heap->runStatF5034D8 = eReady;
		heap->runStat12C2D52C = eReady;
		heap->runStatF503478 = eReady;
		heap->runStat72F3CCC = eReady;
		CCGDebugSynchAfterSNode(&state, &snode72F77CC, 5, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Open_Controller_handle_RunFunc_F85422C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Open_Controller_handle_RunFunc_F85422C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* for loop */
		uInt32 id = LVGetTimerFlag();
		static uInt16 nStep = 0;
		uInt32 diagramIdx = 3;
		if (heap->runStatF85422C == eReady) {
			CCGDebugSynchSNode(&state, 1, 2, 1, &snodeF85422C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->l_For_Loop_N = MaxArrDimSize;
			heap->l_For_Loop_N = LVMIN(heap->l_For_Loop_N, ( heap->a_Ctrllers ? FirstDim( heap->a_Ctrllers ) : 0 ));
			heap->a_Ctrllers_LT = heap->a_Ctrllers;
			/*SetSignalReady( 0x4, 1);*//* a_Ctrllers_LT */
			heap->l_For_Loop_i = 0;
		}
		while (!gAppStop && !gLastError) {
			if (heap->l_For_Loop_i < heap->l_For_Loop_N) {
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(7, 5);
						/*InitSignalReady( 0x0, 7);*//* n_Unbundle_By_Name_Baud */
						/*InitSignalReady( 0x3, 7);*//* s_Unbundle_By_Name_Ctrller_Name */
						/*InitSignalReady( 0x3, 2);*//* s_Unbundle_By_Name_Port */
						/*InitSignalReady( 0x2, 6);*//* s_Unbundle_By_Name_Ctrller_Addr */
						/*InitSignalReady( 0x4, 7);*//* e_Unbundle_By_Name_Ctrller_Type */
						InitSignalReady(8, 1);
						/*InitSignalReady( 0x0, 0);*//* c_Ctrllers_LT */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						{ /* Array Index 1D */
							int32 nIndex = 0;
							nIndex = (int32)heap->l_For_Loop_i;
							MemSet( &heap->c_Ctrllers_LT, GetClusterSize( ((PDAArrPtr)heap->a_Ctrllers_LT)->datatype ), 0 );
							PDAClusterSet(NthElem(((PDAArrPtr)heap->a_Ctrllers_LT), nIndex), ((PDAArrPtr)heap->a_Ctrllers_LT)->datatype, &heap->c_Ctrllers_LT, ((PDAArrPtr)heap->a_Ctrllers_LT)->datatype );
							/*SetSignalReady( 0x0, 0);*//* c_Ctrllers_LT */
							UpdateProbes(&state, debugOffset, 7 /*0xF501630*/, (uChar*)&(heap->c_Ctrllers_LT)); /* assign */
							SetSignalReady(8, 1);
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						CCGDebugSynchNode(&state, 3, 4, 3, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
/* Unbundle by name */
						{
							cl_B0000* cl_004 = (cl_B0000*)&heap->c_Ctrllers_LT;
							heap->e_Unbundle_By_Name_Ctrller_Type = cl_004->el_0;
							/*SetSignalReady( 0x4, 7);*//* e_Unbundle_By_Name_Ctrller_Type */
							UpdateProbes(&state, debugOffset, 6 /*0xF501690*/, (uChar*)&(heap->e_Unbundle_By_Name_Ctrller_Type)); /* assign */
							SetSignalReady(7, 1);
							PDAStrIncRefCnt(cl_004->el_1, (uInt16)1); /*  */
							heap->s_Unbundle_By_Name_Ctrller_Name = cl_004->el_1;
							/*SetSignalReady( 0x3, 7);*//* s_Unbundle_By_Name_Ctrller_Name */
							UpdateProbes(&state, debugOffset, 3 /*0xF5018D0*/, (uChar*)&(heap->s_Unbundle_By_Name_Ctrller_Name)); /* assign */
							SetSignalReady(7, 1);
							PDAStrIncRefCnt(cl_004->el_2, (uInt16)1); /*  */
							heap->s_Unbundle_By_Name_Ctrller_Addr = cl_004->el_2;
							/*SetSignalReady( 0x2, 6);*//* s_Unbundle_By_Name_Ctrller_Addr */
							UpdateProbes(&state, debugOffset, 5 /*0xF501750*/, (uChar*)&(heap->s_Unbundle_By_Name_Ctrller_Addr)); /* assign */
							SetSignalReady(7, 1);
							PDAStrIncRefCnt(cl_004->el_5, (uInt16)1); /*  */
							heap->s_Unbundle_By_Name_Port = cl_004->el_5;
							/*SetSignalReady( 0x3, 2);*//* s_Unbundle_By_Name_Port */
							UpdateProbes(&state, debugOffset, 4 /*0xF501810*/, (uChar*)&(heap->s_Unbundle_By_Name_Port)); /* assign */
							SetSignalReady(7, 1);
							heap->n_Unbundle_By_Name_Baud = cl_004->el_6;
							/*SetSignalReady( 0x0, 7);*//* n_Unbundle_By_Name_Baud */
							UpdateProbes(&state, debugOffset, 2 /*0xF501930*/, (uChar*)&(heap->n_Unbundle_By_Name_Baud)); /* assign */
							SetSignalReady(7, 1);
	/* Free Cluster */
							{
								cl_B0000* cl_005 = (cl_B0000*)&heap->c_Ctrllers_LT;
			if (cl_005->el_1 && --((PDAStrPtr)cl_005->el_1)->refcnt == 0 && !((PDAStrPtr)cl_005->el_1)->staticStr) {
									MemHandleFree( cl_005->el_1 );
								}
	if (cl_005->el_2 && --((PDAStrPtr)cl_005->el_2)->refcnt == 0 && !((PDAStrPtr)cl_005->el_2)->staticStr) {
									MemHandleFree( cl_005->el_2 );
								}
	if (cl_005->el_3 && --((PDAStrPtr)cl_005->el_3)->refcnt == 0 && !((PDAStrPtr)cl_005->el_3)->staticStr) {
									MemHandleFree( cl_005->el_3 );
								}
	if (cl_005->el_4 && --((PDAStrPtr)cl_005->el_4)->refcnt == 0 && !((PDAStrPtr)cl_005->el_4)->staticStr) {
									MemHandleFree( cl_005->el_4 );
								}
	if (cl_005->el_5 && --((PDAStrPtr)cl_005->el_5)->refcnt == 0 && !((PDAStrPtr)cl_005->el_5)->staticStr) {
									MemHandleFree( cl_005->el_5 );
								}
	}
						}
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 2 : {
						heap->runStat72F77CC = Open_Controller_handle_RunFunc_72F77CC( bRunToFinish  );
						if (heap->runStat72F77CC == eNotFinished) {
							return eNotFinished;
						}
						else if (heap->runStat72F77CC == eFail) {
							CGenErr();
						}
						heap->runStat72F77CC = eReady;
						nStep++; }
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 5, 3, &snodeF85422C, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep=0;
			}
			(heap->l_For_Loop_i)++;
			if (heap->l_For_Loop_i >= heap->l_For_Loop_N) {
				/* FreeLoopInputs. */
	PDAArrFree(heap->a_Ctrllers_LT);
				break;
			}
			if (!bRunToFinish) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		} /* end while */
	} /* end for loop */
	CCGDebugSynchAfterSNode(&state, &snodeF85422C, 2, debugOffset);
	if(gAppStop) {
		gAppStop = true;
		return eFinished;
	}

	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Open_Controller_handle_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Open_Controller_handle_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			/*InitSignalReady( 0x4, 3);*//* a_Ctrllers */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			heap->a_Ctrllers = ((ArrayControlData*)FPData(Ctrllers__239112584_ctlid))->hValue;
			((ArrayControlData*)FPData(Ctrllers__239112584_ctlid))->hValue = NULL;
			/*SetSignalReady( 0x4, 3);*//* a_Ctrllers */
			UpdateProbes(&state, debugOffset, 1 /*0xF501510*/, (uChar*)&(heap->a_Ctrllers)); /* assign */
			PDAArrIncRefCnt(heap->a_Ctrllers, (uInt16)1); /* FPTerm */
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStatF85422C = Open_Controller_handle_RunFunc_F85422C( bRunToFinish  );
			if (heap->runStatF85422C == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStatF85422C == eFail) {
				CGenErr();
			}
			heap->runStatF85422C = eReady;
			nStep++; }
/* start q el linear (0 or 1 struct) */
		case 2 : {
			if (!SetArrayControlFieldValueStatic( FPData(Ctrllers__239109704_ctlid), &heap->a_Ctrllers, false, &g_staticArray_2))
			CGenErr();
			/* Update front panel indicator */
			CCGDebugUpdateFPControl(&state, debugOffset, Ctrllers__239109704_ctlid);
			nStep++;}
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 2, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Open_Controller_handle_VIName = "Open Controller handle.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Open_Controller_handle_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Open_Controller_handle_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)36,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &Open_Controller_handle_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tOpen_Controller_handle_viInstanceHeap),
	Open_Controller_handle_InitFPTerms,
	Open_Controller_handle_FrontPanelInit,
	Open_Controller_handle_BlockDiagram,
	Open_Controller_handle_DrawLabels,
	Open_Controller_handle_GetFPTerms,
	Open_Controller_handle_Cleanup,
	Open_Controller_handle_CleanupLSRs,
	Open_Controller_handle_AddSubVIInstanceData,
	Open_Controller_handle_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Open_Controller_handle_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	DebugInitState();
	CCGDebugInitialize(&state);
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	CCGDebugEnd();
	return stat;
}


/****** End of generated code **********/


