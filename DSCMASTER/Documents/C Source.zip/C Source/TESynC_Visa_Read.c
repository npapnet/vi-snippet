/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: TESynC Visa Read.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\TESynC_1_1.llb\TESynC Visa Read.vi
 *	Generated on: 2010-2-8 14:39
 *  Generated UI: false
 *  Generated Debug Info: false
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: true
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: dynamic
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
struct _TESynC_Visa_Read_heap { 
	cl_00000 c_VISA_Write_error_out;
	cl_00000 c_error_in__no_error__1;
	cl_00000 c_Time_Delay_error_out;
	cl_00000 c_Case_Structure_CT_16;
	cl_00000 c_error_in__no_error__CS_2;
	cl_00000 c_Case_Structure_CT_17;
	cl_00000 c_error_in__no_error__CS_1;
	double n_Delay_Time__s_;
	uInt32 dw_byte_count;
	VoidHand s_Case_Structure_CT_13;
	VoidHand s_Command_String;
	VoidHand s_Case_Structure_CT_12;
	VoidHand s_VISA_Read_read_buffer;
	VoidHand s_read_buffer;
	VoidHand Args10384391;  
	uInt8 runStat10384390;  
	uInt8 runStat103842D0;  
	uInt8 runStat10386219;  
	uInt8 runStat1038621A;  
	uInt8 runStat10384270;  
	uInt8 runStat1;  
	uInt8 runStat72F174C;  
	uInt8 runStat103859D9;  
	uInt8 runStat103859DA;  
	Boolean c_error_in__no_error__CS;
} _DATA_SECTION __TESynC_Visa_Read_heap; /* heap */

static uInt32 _DATA_SECTION _TESynC_Visa_Read_signalsReadyTable[5];

static struct _TESynC_Visa_Read_heap _DATA_SECTION *heap = &__TESynC_Visa_Read_heap; /* heap */

struct _tTESynC_Visa_Read_GlobalConstantsHeap {
	uInt8	refCnt;
	String	i10384730;
} _DATA_SECTION __TESynC_Visa_Read_GlobalConstantsHeap;
static struct _tTESynC_Visa_Read_GlobalConstantsHeap _DATA_SECTION *TESynC_Visa_Read_GlobalConstantsHeapPtr = &__TESynC_Visa_Read_GlobalConstantsHeap;

struct _tTESynC_Visa_Read_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i10384390;
} _DATA_SECTION __TESynC_Visa_Read_viInstanceHeap;
static struct _tTESynC_Visa_Read_viInstanceHeap _DATA_SECTION *TESynC_Visa_Read_viInstanceHeapPtr = &__TESynC_Visa_Read_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _TESynC_Visa_Read_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[5] = {3, 3, 3, 2, 3};
static ClusterControlData g_control_4 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_8 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

struct {
	int32	el_0;
	int32	el_1;
	uInt8	el_2:1;
	uInt8	el_3[3];
	int32	el_4;
}
static g_control_9 = {
	0, 1, true, 0, 0, 0, 0
};

struct {
	int32	el_0;
	int32	el_1;
	uInt8	el_2:1;
	uInt8	el_3[3];
	int32	el_4;
}
static g_control_10 = {
	0, 1, true, 0, 0, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2200UL
#define error_in__no_error___322005640_ctlid 2200
#define VISA_session_in__322006120_ctlid 2201
#define error_out__322007272_ctlid 2202
#define VISA_session_out__322007752_ctlid 2203
#define Command_String__322011664_ctlid 2204
#define read_buffer__322011984_ctlid 2205
#define N_CONTROLS 6L
#define gArrControlData TESynC_Visa_Read_gArrControlData
ControlDataItem _DATA_SECTION TESynC_Visa_Read_gArrControlData[6] = {
	{ error_in__no_error___322005640_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_session_in__322006120_ctlid, 0, NULL, StringDataType, nonui_control },
	{ error_out__322007272_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_session_out__322007752_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Command_String__322011664_ctlid, 0, NULL, VoidHandDataType, string_control },
	{ read_buffer__322011984_ctlid, 0, NULL, VoidHandDataType, string_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION TESynC_Visa_Read_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION TESynC_Visa_Read_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(error_in__no_error___322005640_ctlid) = ClusterControlDataCreateStatic(&g_control_4, GetControlDataPtr(), gFormID, error_in__no_error___322005640_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___322005640_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[2].pValue, argsIn->args[2].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromStr(_LVT(""));
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___322005640_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___322005640_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,1,-18,125,16,
	_LVT("0"),12,0,0,0, false);
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_session_in__322006120_ctlid);
			vhIn = *(VoidHand *)argsIn->args[0].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[0].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[0].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[0].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_session_in__322006120_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA session in"),15,1,-18,105,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(error_out__322007272_ctlid) = ClusterControlDataCreateStatic(&g_control_8, GetControlDataPtr(), gFormID, error_out__322007272_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if(bShowFrontPanel) {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromStr(_LVT(""));
		}
		InitClusterControlFieldValue( FPData(error_out__322007272_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__322007272_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-1,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_session_out__322007752_ctlid) = PDAStrNewFromStr(_LVT(""));
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_session_out__322007752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA session out"),16,0,-19,115,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(Command_String__322011664_ctlid) = StringDataCreateStatic((StringData*)&g_control_9, Command_String__322011664_ctlid, 0, true, 0, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Command_String__322011664_ctlid);
		((StringData*)GetControlHValue(nIdx))->pValue = PDAStrCopyOnModify(*(VoidHand*)argsIn->args[1].pValue);
	}
	else {
		if (!SetStringFieldValue( &FPData(Command_String__322011664_ctlid), PDAStrNewFromStr(_LVT("")), StringDataType )){
			return false;
		}

	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Command_String__322011664_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Command String"),14,-4,-20,87,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(read_buffer__322011984_ctlid) = StringDataCreateStatic((StringData*)&g_control_10, read_buffer__322011984_ctlid, 0, true, 0, NULL))){
		return false;
	}
	if (bShowFrontPanel) {
		if (!SetStringFieldValue( &FPData(read_buffer__322011984_ctlid), PDAStrNewFromStr(_LVT("")), StringDataType )){
			return false;
		}

	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	read_buffer__322011984_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("read buffer"),11,-4,-20,69,16,
	_LVT("0"),12,0,0,0, false);
	return true;
}
#define TESynC_Visa_Read_FrontPanelInit NULL
#define TESynC_Visa_Read_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION TESynC_Visa_Read_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION TESynC_Visa_Read_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_in__no_error___322005640_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___322005640_ctlid), false );
PDAStrFree( FPData(VISA_session_in__322006120_ctlid) );
	FPData(VISA_session_in__322006120_ctlid) = NULL;
	if (FPData(error_out__322007272_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__322007272_ctlid), false );
PDAStrFree( FPData(VISA_session_out__322007752_ctlid) );
	FPData(VISA_session_out__322007752_ctlid) = NULL;
	(void)StringFreeData( FPData(Command_String__322011664_ctlid) );
	(void)StringFreeData( FPData(read_buffer__322011984_ctlid) );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION TESynC_Visa_Read_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION TESynC_Visa_Read_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 2 && argsOut->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__322007272_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[2].pValue, argsOut->args[2].nType );
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_session_out__322007752_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[0].pValue = GetControlHValue(nIdx);
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, read_buffer__322011984_ctlid);
		if (!GetStringFieldValue( GetControlHValue(nIdx), (VoidHand *)argsOut->args[1].pValue )) {
			return false;
		}
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION TESynC_Visa_Read_CleanupLSRs(void);
void _TEXT_SECTION TESynC_Visa_Read_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION TESynC_Visa_Read_AddSubVIInstanceData(void);
void _TEXT_SECTION TESynC_Visa_Read_AddSubVIInstanceData(void) {
	if (TESynC_Visa_Read_viInstanceHeapPtr->initialized) return;
	TESynC_Visa_Read_viInstanceHeapPtr->initialized = TRUE;

	TESynC_Visa_Read_viInstanceHeapPtr->i10384390.next = gVIInstanceListHead;
	gVIInstanceListHead = &TESynC_Visa_Read_viInstanceHeapPtr->i10384390;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION TESynC_Visa_Read_AddVIGlobalConstants(void);
void _TEXT_SECTION TESynC_Visa_Read_AddVIGlobalConstants(void) {
	MemSet(TESynC_Visa_Read_GlobalConstantsHeapPtr,sizeof(*(TESynC_Visa_Read_GlobalConstantsHeapPtr)),0);
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION TESynC_Visa_Read_CleanupVIGlobalConstants(void);
void _TEXT_SECTION TESynC_Visa_Read_CleanupVIGlobalConstants(void) {
	(TESynC_Visa_Read_GlobalConstantsHeapPtr->refCnt)--;
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION TESynC_Visa_Read_InitVIConstantList(void);
void _TEXT_SECTION TESynC_Visa_Read_InitVIConstantList(void) {
	(TESynC_Visa_Read_GlobalConstantsHeapPtr->refCnt)++;
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION TESynC_Visa_Read_RunFunc_72F174C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Visa_Read_RunFunc_72F174C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72F174C == eReady) {
		MemMove( &heap->c_error_in__no_error__1, ((ClusterControlData*)FPData(error_in__no_error___322005640_ctlid))->pVal, sizeof( cl_00000 ) );
		MemSet(((ClusterControlData*)FPData(error_in__no_error___322005640_ctlid))->pVal, sizeof( cl_00000 ), 0);
		/*SetSignalReady( 0x0, 1);*//* c_error_in__no_error__1 */
		heap->s_Case_Structure_CT_13 = FPData(VISA_session_in__322006120_ctlid);
		PDAStrIncRefCnt(heap->s_Case_Structure_CT_13, (uInt16)1);
		/*SetSignalReady( 0x1, 1);*//* s_VISA_session_in */
		if (!GetStringFieldValue( FPData(Command_String__322011664_ctlid), &heap->s_Command_String )){
			CGenErr();
		}
		/*SetSignalReady( 0x2, 0);*//* s_Command_String */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F174C == eReady) {
			heap->runStat103859D9 = eReady;
			heap->runStat103859DA = eReady;
			heap->runStat10386219 = eReady;
			heap->runStat10384270 = eReady;
			heap->runStat10384390 = eReady;
			heap->runStat103842D0 = eReady;
			heap->runStat1038621A = eReady;
			if (!PDAClusterGetElemByPos( &heap->c_error_in__no_error__1, 0x0 | ClusterDataType, 0, &heap->c_error_in__no_error__CS, BooleanDataType )) {
				CGenErr();
			}
			/*SetSignalReady( 0x4, 2);*//* c_error_in__no_error__CS */
			/*SetSignalReady( 0x1, 5);*//* s_VISA_session_in_CT */
			/*SetSignalReady( 0x1, 2);*//* s_Command_String_CT */
		}
		switch ( heap->c_error_in__no_error__CS ) {
			/* begin case */
			case 1 : {
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						/* Free unwired input select tunnel. */
	if (heap->s_Command_String && --((PDAStrPtr)heap->s_Command_String)->refcnt == 0 && !((PDAStrPtr)heap->s_Command_String)->staticStr) {
							MemHandleFree( heap->s_Command_String );
						}
						TESynC_Visa_Read_GlobalConstantsHeapPtr->i10384730 = PDAStrNewFromBuf(_LVT("Error"),(uInt32)5);
						heap->s_read_buffer = TESynC_Visa_Read_GlobalConstantsHeapPtr->i10384730;
						MemMove( &heap->c_error_in__no_error__CS_2, &heap->c_error_in__no_error__1, sizeof( cl_00000 ) );
						/* Cluster Inc Ref Count:  CaseSelector*/
						{
							cl_00000* cl_002 = (cl_00000*)&heap->c_error_in__no_error__CS_2;
							PDAStrIncRefCnt(cl_002->el_2, (uInt16)1); /* CaseSelector */
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						heap->s_Case_Structure_CT_12 = heap->s_read_buffer;
						MemMove( &heap->c_Case_Structure_CT_17, &heap->c_error_in__no_error__CS_2, sizeof( cl_00000 ) );
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						heap->dw_byte_count = 1024;
						MemMove( &heap->c_error_in__no_error__CS_1, &heap->c_error_in__no_error__1, sizeof( cl_00000 ) );
						/* Cluster Inc Ref Count:  CaseSelector*/
						{
							cl_00000* cl_003 = (cl_00000*)&heap->c_error_in__no_error__CS_1;
							PDAStrIncRefCnt(cl_003->el_2, (uInt16)1); /* CaseSelector */
						}
						heap->n_Delay_Time__s_ = 5.0000000000000003000E-2;
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						/**/
						/* VISA Write */
						/**/
						if (VisaWrite(heap->s_Case_Structure_CT_13,  heap->s_Command_String,  &(heap->c_error_in__no_error__CS_1),  &(heap->s_Case_Structure_CT_13),  (VoidHand)NULL,  &(heap->c_VISA_Write_error_out) ) == eFail) {
							CGenErr();
						}
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 2 : {
						if (heap->runStat10384390 == eReady) {
						}
						{
							ControlDataItemPtr cdPtr = LVGetCurrentControlData();
							if (heap->runStat10384390 == eReady) {
								CreateArgListStatic(heap->Args10384391, 2, 1 );
								argIn(heap->Args10384391, 0).nType = 0x0 | ClusterDataType;
								argIn(heap->Args10384391, 0).pValue = (void *)&heap->c_VISA_Write_error_out;
								argIn(heap->Args10384391, 1).nType = doubleDataType;
								argIn(heap->Args10384391, 1).pValue = (void *)&heap->n_Delay_Time__s_;
								argOut(heap->Args10384391, 0).nType = 0x0 | ClusterDataType;
								argOut(heap->Args10384391, 0).pValue = (void *)&heap->c_Time_Delay_error_out;
							}
							if (!TESynC_Visa_Read_viInstanceHeapPtr->i10384390.callerID) {
								TESynC_Visa_Read_viInstanceHeapPtr->i10384390.callerID = ++gCallerID;
							}
							heap->runStat10384390 = TESynC_Visa_Read_vi_Instance_Instance___________1_24Saved___TESynC_Visa_Read__Run( &TESynC_Visa_Read_viInstanceHeapPtr->i10384390, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args10384391)[0], (ArgList *)((ArgList **)heap->Args10384391)[1], NULL );
							LVSetCurrentControlData(cdPtr);
							if (heap->runStat10384390 == eNotFinished) {
								runStat = eNotFinished;
							}
							if (heap->runStat10384390 == eFail || gLastError) {
								CGenErr();
							}
							if (gAppStop || (heap->runStat10384390 == eFinished)) {
								/* Cluster Inc Ref Count:  Func call*/
								{
									cl_00000* cl_004 = (cl_00000*)&heap->c_Time_Delay_error_out;
									PDAStrIncRefCnt(cl_004->el_2, (uInt16)1); /* Func call */
								}
							}
							if (gAppStop) {
								gAppStop=true;/* opt bug fix*/
								return eFinished;
							}
						}
						if (!bRunToFinish && (runStat == eNotFinished)) {
							return eNotFinished;
						}
						if (heap->runStat10384390 == eFinished) {
							heap->runStat10384390 = eReady;
						}
						nStep++; }
/* start q el linear (0 or 1 struct) */
					case 4 : {
						/**/
						/* VISA Read */
						/**/
						if (VisaRead(heap->s_Case_Structure_CT_13,  &(heap->dw_byte_count),  uInt32DataType,  &(heap->c_Time_Delay_error_out),  &(heap->s_Case_Structure_CT_13),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer),  (VoidHand*)NULL ) == eFail) {
							CGenErr();
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 5 : {
						heap->s_Case_Structure_CT_12 = heap->s_VISA_Read_read_buffer;
						MemMove( &heap->c_Case_Structure_CT_17, &heap->c_Time_Delay_error_out, sizeof( cl_00000 ) );
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				nStep = 0;
			} /* end case */
			break;
		}
		MemMove( &heap->c_Case_Structure_CT_16, &heap->c_Case_Structure_CT_17, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x0, 3);*//* c_Case_Structure_CT_16 */
		/*SetSignalReady( 0x1, 6);*//* s_Case_Structure_CT_13 */
		/*SetSignalReady( 0x2, 1);*//* s_Case_Structure_CT_12 */
		/* FreeCaseSelDCO. */
	/* Free Cluster */
		{
			cl_00000* cl_005 = (cl_00000*)&heap->c_error_in__no_error__1;
				if (cl_005->el_2 && --((PDAStrPtr)cl_005->el_2)->refcnt == 0 && !((PDAStrPtr)cl_005->el_2)->staticStr) {
				MemHandleFree( cl_005->el_2 );
			}
		}
	} /* end switch */
	{
		if (!SetClusterControlFieldValue( FPData(error_out__322007272_ctlid), &heap->c_Case_Structure_CT_16, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	if (FPData(VISA_session_out__322007752_ctlid) && --((PDAStrPtr)FPData(VISA_session_out__322007752_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_session_out__322007752_ctlid))->staticStr) {
		MemHandleFree( FPData(VISA_session_out__322007752_ctlid) );
	}
	FPData(VISA_session_out__322007752_ctlid)=PDAStrCopyOnModify(heap->s_Case_Structure_CT_13);
	{
		if (!SetStringFieldValue( &FPData(read_buffer__322011984_ctlid), heap->s_Case_Structure_CT_12, StringDataType )){
			CGenErr();
		}
	}
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION TESynC_Visa_Read_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Visa_Read_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStat72F174C = TESynC_Visa_Read_RunFunc_72F174C( bRunToFinish  );
			if (heap->runStat72F174C == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStat72F174C == eFail) {
				CGenErr();
			}
			heap->runStat72F174C = eReady;
			nStep++; }
		nStep = 0;
		default: {
			; /* do nothing */
		}
	}
	TESynC_Visa_Read_CleanupVIGlobalConstants();
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr TESynC_Visa_Read_VIName = "TESynC Visa Read.vi";

static VIInfo _DATA_SECTION viInfo = {
	&TESynC_Visa_Read_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _TESynC_Visa_Read_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)20,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &TESynC_Visa_Read_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tTESynC_Visa_Read_viInstanceHeap),
	TESynC_Visa_Read_InitFPTerms,
	TESynC_Visa_Read_FrontPanelInit,
	TESynC_Visa_Read_BlockDiagram,
	TESynC_Visa_Read_DrawLabels,
	TESynC_Visa_Read_GetFPTerms,
	TESynC_Visa_Read_Cleanup,
	TESynC_Visa_Read_CleanupLSRs,
	TESynC_Visa_Read_AddSubVIInstanceData,
	TESynC_Visa_Read_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION TESynC_Visa_Read_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	return stat;
}


/****** End of generated code **********/


