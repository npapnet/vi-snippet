/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: TESynC Close.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\TESynC_1_1.llb\TESynC Close.vi
 *	Generated on: 2010-2-8 14:39
 *  Generated UI: false
 *  Generated Debug Info: false
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: true
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: dynamic
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
struct _TESynC_Close_heap { 
	cl_00000 c_error_in__no_error__2;
	cl_00000 c_Case_Structure_CT_18;
	cl_00000 c_error_in__no_error__CS_5;
	cl_00000 c_VISA_Close_error_out;
	cl_00000 c_error_in__no_error__CS_4;
	cl_00000 c_Case_Structure_CT_19;
	VoidHand s_VISA_session_in_1;
	VoidHand s_VISA_session_in_CT_4;
	uInt8 runStatF8E9D90;  
	uInt8 runStatF8EBD19;  
	uInt8 runStatF8EBD1A;  
	uInt8 runStat72F834C;  
	uInt8 runStatF8EBC1A;  
	uInt8 runStatF8EBC19;  
	uInt8 runStat1;  
	Boolean c_error_in__no_error__CS_3;
} _DATA_SECTION __TESynC_Close_heap; /* heap */

static uInt32 _DATA_SECTION _TESynC_Close_signalsReadyTable[3];

static struct _TESynC_Close_heap _DATA_SECTION *heap = &__TESynC_Close_heap; /* heap */

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _TESynC_Close_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[3] = {1, 1, 2};
static ClusterControlData g_control_4 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_8 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2400UL
#define error_in__no_error___185470112_ctlid 2400
#define VISA_session_in__185470592_ctlid 2401
#define error_out__185471936_ctlid 2402
#define N_CONTROLS 3L
#define gArrControlData TESynC_Close_gArrControlData
ControlDataItem _DATA_SECTION TESynC_Close_gArrControlData[3] = {
	{ error_in__no_error___185470112_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_session_in__185470592_ctlid, 0, NULL, StringDataType, nonui_control },
	{ error_out__185471936_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION TESynC_Close_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION TESynC_Close_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(error_in__no_error___185470112_ctlid) = ClusterControlDataCreateStatic(&g_control_4, GetControlDataPtr(), gFormID, error_in__no_error___185470112_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___185470112_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[1].pValue, argsIn->args[1].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromStr(_LVT(""));
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___185470112_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___185470112_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,1,-18,125,16,
	_LVT("0"),12,0,0,0, false);
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_session_in__185470592_ctlid);
			vhIn = *(VoidHand *)argsIn->args[0].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[0].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[0].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[0].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_session_in__185470592_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA session in"),15,-40,-19,105,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(error_out__185471936_ctlid) = ClusterControlDataCreateStatic(&g_control_8, GetControlDataPtr(), gFormID, error_out__185471936_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if(bShowFrontPanel) {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromStr(_LVT(""));
		}
		InitClusterControlFieldValue( FPData(error_out__185471936_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__185471936_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-1,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	return true;
}
#define TESynC_Close_FrontPanelInit NULL
#define TESynC_Close_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION TESynC_Close_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION TESynC_Close_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_in__no_error___185470112_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___185470112_ctlid), false );
PDAStrFree( FPData(VISA_session_in__185470592_ctlid) );
	FPData(VISA_session_in__185470592_ctlid) = NULL;
	if (FPData(error_out__185471936_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__185471936_ctlid), false );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION TESynC_Close_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION TESynC_Close_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__185471936_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION TESynC_Close_CleanupLSRs(void);
void _TEXT_SECTION TESynC_Close_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION TESynC_Close_AddSubVIInstanceData(void);
void _TEXT_SECTION TESynC_Close_AddSubVIInstanceData(void) {
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION TESynC_Close_AddVIGlobalConstants(void);
void _TEXT_SECTION TESynC_Close_AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION TESynC_Close_CleanupVIGlobalConstants(void);
void _TEXT_SECTION TESynC_Close_CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION TESynC_Close_InitVIConstantList(void);
void _TEXT_SECTION TESynC_Close_InitVIConstantList(void) {
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION TESynC_Close_RunFunc_72F834C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Close_RunFunc_72F834C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72F834C == eReady) {
		MemMove( &heap->c_error_in__no_error__2, ((ClusterControlData*)FPData(error_in__no_error___185470112_ctlid))->pVal, sizeof( cl_00000 ) );
		MemSet(((ClusterControlData*)FPData(error_in__no_error___185470112_ctlid))->pVal, sizeof( cl_00000 ), 0);
		/*SetSignalReady( 0x0, 0);*//* c_error_in__no_error__2 */
		heap->s_VISA_session_in_1 = FPData(VISA_session_in__185470592_ctlid);
		PDAStrIncRefCnt(heap->s_VISA_session_in_1, (uInt16)1);
		/*SetSignalReady( 0x0, 6);*//* s_VISA_session_in_1 */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F834C == eReady) {
			heap->runStatF8EBC19 = eReady;
			heap->runStatF8EBC1A = eReady;
			heap->runStatF8EBD19 = eReady;
			heap->runStatF8E9D90 = eReady;
			heap->runStatF8EBD1A = eReady;
			if (!PDAClusterGetElemByPos( &heap->c_error_in__no_error__2, 0x0 | ClusterDataType, 0, &heap->c_error_in__no_error__CS_3, BooleanDataType )) {
				CGenErr();
			}
			/*SetSignalReady( 0x2, 0);*//* c_error_in__no_error__CS_3 */
			/*SetSignalReady( 0x1, 0);*//* s_VISA_session_in_CT_3 */
		}
		switch ( heap->c_error_in__no_error__CS_3 ) {
			/* begin case */
			case 1 : {
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						MemMove( &heap->c_error_in__no_error__CS_5, &heap->c_error_in__no_error__2, sizeof( cl_00000 ) );
						/* Cluster Inc Ref Count:  CaseSelector*/
						{
							cl_00000* cl_002 = (cl_00000*)&heap->c_error_in__no_error__CS_5;
							PDAStrIncRefCnt(cl_002->el_2, (uInt16)1); /* CaseSelector */
						}
						/* Free unwired input select tunnel. */
	if (heap->s_VISA_session_in_1 && --((PDAStrPtr)heap->s_VISA_session_in_1)->refcnt == 0 && !((PDAStrPtr)heap->s_VISA_session_in_1)->staticStr) {
							MemHandleFree( heap->s_VISA_session_in_1 );
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						MemMove( &heap->c_Case_Structure_CT_19, &heap->c_error_in__no_error__CS_5, sizeof( cl_00000 ) );
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						MemMove( &heap->c_error_in__no_error__CS_4, &heap->c_error_in__no_error__2, sizeof( cl_00000 ) );
						/* Cluster Inc Ref Count:  CaseSelector*/
						{
							cl_00000* cl_003 = (cl_00000*)&heap->c_error_in__no_error__CS_4;
							PDAStrIncRefCnt(cl_003->el_2, (uInt16)1); /* CaseSelector */
						}
						heap->s_VISA_session_in_CT_4 = heap->s_VISA_session_in_1;
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						/**/
						/* VISA Close */
						/**/
						if (!VisaClose(heap->s_VISA_session_in_CT_4,  &(heap->c_error_in__no_error__CS_4),  &(heap->c_VISA_Close_error_out) )) {
							CGenErr();
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 2 : {
						MemMove( &heap->c_Case_Structure_CT_19, &heap->c_VISA_Close_error_out, sizeof( cl_00000 ) );
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				nStep = 0;
			} /* end case */
			break;
		}
		MemMove( &heap->c_Case_Structure_CT_18, &heap->c_Case_Structure_CT_19, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x0, 1);*//* c_Case_Structure_CT_18 */
		/* FreeCaseSelDCO. */
	/* Free Cluster */
		{
			cl_00000* cl_004 = (cl_00000*)&heap->c_error_in__no_error__2;
				if (cl_004->el_2 && --((PDAStrPtr)cl_004->el_2)->refcnt == 0 && !((PDAStrPtr)cl_004->el_2)->staticStr) {
				MemHandleFree( cl_004->el_2 );
			}
		}
	} /* end switch */
	{
		if (!SetClusterControlFieldValue( FPData(error_out__185471936_ctlid), &heap->c_Case_Structure_CT_18, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION TESynC_Close_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Close_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStat72F834C = TESynC_Close_RunFunc_72F834C( bRunToFinish  );
			if (heap->runStat72F834C == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStat72F834C == eFail) {
				CGenErr();
			}
			heap->runStat72F834C = eReady;
			nStep++; }
		nStep = 0;
		default: {
			; /* do nothing */
		}
	}
	TESynC_Close_CleanupVIGlobalConstants();
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr TESynC_Close_VIName = "TESynC Close.vi";

static VIInfo _DATA_SECTION viInfo = {
	&TESynC_Close_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _TESynC_Close_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)12,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	NULL,
	0,
	TESynC_Close_InitFPTerms,
	TESynC_Close_FrontPanelInit,
	TESynC_Close_BlockDiagram,
	TESynC_Close_DrawLabels,
	TESynC_Close_GetFPTerms,
	TESynC_Close_Cleanup,
	TESynC_Close_CleanupLSRs,
	TESynC_Close_AddSubVIInstanceData,
	TESynC_Close_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION TESynC_Close_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	return stat;
}


/****** End of generated code **********/


