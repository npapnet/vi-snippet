/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Utility MODBUS RTU Send Message.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Private\Utility MODBUS RTU Send Message.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 6;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snode72F7BCC = false;
struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_heap { 
	cl_00000 c_error_in__no_error__5;
	cl_00000 c_error_in__no_error__CT_7;
	cl_00000 c_error_in__no_error__CT_5;
	cl_00000 c_Case_Structure_CT_24;
	cl_00000 c_error_in__no_error__CT_6;
	cl_00000 c_Utility_MODBUS_RTU_CRC16_vi__1;
	cl_00000 c_VISA_Write_error_out;
	cl_00000 c_Case_Structure_CT_25;
	int32 l_Case_Structure_CT_1;
	int32 l_Case_Structure_CT;
	int32 l_Array_Size_size_s__2;
	int32 l_Constant_6;
	VoidHand s_Case_Structure_CT_23;
	VoidHand s_VISA_resource_name_CT_5;
	VoidHand a_Message__empty_array__1;
	VoidHand s_VISA_resource_name_CT_3;
	VoidHand s_VISA_resource_name_5;
	VoidHand a_Message__empty_array__CT;
	VoidHand s_Byte_Array_To_String_string;
	VoidHand a_Message__empty_array__CT_1;
	VoidHand a_Utility_MODBUS_RTU_CRC16_vi_M;
	VoidHand ArgsF88AA01;  
	VoidHand s_VISA_resource_name_CT_4;
	VoidHand a_Build_Array_appended_array_5;
	VoidHand s_Utility_MODBUS_RTU_CRC16_vi__1;
	VoidHand s_Case_Structure_CT_22;
	VoidHand s_VISA_Write_VISA_resource_name;
	uInt8 by_Command__0__CT_1;
	uInt8 by_Unit_Address__1__CT_3;
	uInt8 by_Command__0_;
	uInt8 by_Unit_Address__1__2;
	uInt8 runStatF88A820;  
	uInt8 runStatF88AA00;  
	uInt8 runStat72F7BCC;  
	uInt8 runStatF88A940;  
	uInt8 runStatF882C21;  
	uInt8 runStatF882C22;  
	uInt8 runStatF8824A2;  
	uInt8 by_Unit_Address__1__CT_2;
	uInt8 by_Command__0__CT;
	uInt8 runStatF8824A1;  
	uInt8 runStat1;  
	Boolean c_error_in__no_error__CS_1;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_signalsReadyTable[5];

static struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_heap; /* heap */

struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i0F88AA00;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeap;
static struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeap _DATA_SECTION *Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr = &__Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[5] = {3, 3, 1, 3, 3};
struct _g_array_1 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_1 g_array_1 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

static ClusterControlData g_control_4 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_8 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_9 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_10 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_11 = {
	0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_13 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_12 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ArrayControlData g_control_14 = {
	0, 0, true, 1, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2600UL
#define error_in__no_error___268840856_ctlid 2600
#define error_out__269683432_ctlid 2601
#define Command__0___269683816_ctlid 2602
#define Unit_Address__1___269684200_ctlid 2603
#define VISA_resource_name__269684680_ctlid 2604
#define VISA_resource_name_out__269685160_ctlid 2605
#define Length_Of_Sent_MSG__269685640_ctlid 2606
#define Message__empty_array___269686600_ctlid 2607
#define N_CONTROLS 8L
#define gArrControlData Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_gArrControlData[8] = {
	{ error_in__no_error___268840856_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__269683432_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ Command__0___269683816_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ Unit_Address__1___269684200_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ VISA_resource_name__269684680_ctlid, 0, NULL, StringDataType, nonui_control },
	{ VISA_resource_name_out__269685160_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Length_Of_Sent_MSG__269685640_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ Message__empty_array___269686600_ctlid, 0, NULL, 0x100000 | ArrayDataType, array_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(error_in__no_error___268840856_ctlid) = ClusterControlDataCreateStatic(&g_control_4, GetControlDataPtr(), gFormID, error_in__no_error___268840856_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___268840856_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[2].pValue, argsIn->args[2].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb59);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___268840856_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___268840856_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,-1,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__269683432_ctlid) = ClusterControlDataCreateStatic(&g_control_8, GetControlDataPtr(), gFormID, error_out__269683432_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb61);
		}
		InitClusterControlFieldValue( FPData(error_out__269683432_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__269683432_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-2,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	{uInt8 dVal = (uInt8)0 ;
		{
			static NumericInitialData numData = {
				Command__0___269683816_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Command__0___269683816_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_9, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, Command__0___269683816_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[0].pValue, argsIn->args[0].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Command__0___269683816_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Command (0)"),11,-15,-20,76,16,
	_LVT("0"),12,0,0,0, false);
	{uInt8 dVal = (uInt8)1 ;
		{
			static NumericInitialData numData = {
				Unit_Address__1___269684200_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Unit_Address__1___269684200_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_10, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Unit_Address__1___269684200_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[1].pValue, argsIn->args[1].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Unit_Address__1___269684200_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Unit Address (1)"),16,-15,-20,111,16,
	_LVT("0"),12,0,0,0, false);
	if (argsIn && argsIn->size > 4 && argsIn->args[4].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__269684680_ctlid);
			vhIn = *(VoidHand *)argsIn->args[4].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[4].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[4].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[4].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__269684680_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,0,-16,129,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_resource_name_out__269685160_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb64);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__269685160_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-16,157,16,
	_LVT("0"),12,0,1000,0, false);
	{uInt8 dVal = (uInt8)0 ;
		{
			static NumericInitialData numData = {
				Length_Of_Sent_MSG__269685640_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
			};
			if (!(FPData(Length_Of_Sent_MSG__269685640_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_11, &numData, &dVal))){
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Length_Of_Sent_MSG__269685640_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Length Of Sent MSG"),18,0,-20,129,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(Message__empty_array___269686600_ctlid) = NULL;
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		{
			VoidHand vhIn, vhOut;
			DataType dtIn, dtOut;
			nIdx = CalcControlOffset( gFormID, Message__empty_array___269686600_ctlid);
			FPDataType(Message__empty_array___269686600_ctlid) = 0x100000 | ArrayDataType;
			dtIn = argsIn->args[3].nType;
			vhIn = *(VoidHand *)argsIn->args[3].pValue;
			dtOut = gArrControlData[nIdx].dataType;
			vhOut = gArrControlData[nIdx].hValue;
			if (vhOut) {
				PDAArrFree(vhOut);
			}
			if (IsArray(dtIn)) {
				vhOut = PDAArrCopyOnModifyStatic( vhIn, &g_staticArray_21);
			}
			FPData(Message__empty_array___269686600_ctlid) = vhOut;
		}
	}
	else {
/* Declare array */
		{
			FPData(Message__empty_array___269686600_ctlid) = (void*)&g_array_1.el_1;
			NDims(((PDAArrPtr)&g_array_1.el_1)) = 1;
			((PDAArrPtr)&g_array_1.el_1)->datatype = uCharDataType;
			((PDAArrPtr)&g_array_1.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_1.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_1.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(Message__empty_array___269686600_ctlid) = ArrayControlDataCreateStatic(&g_control_14, FPData(Message__empty_array___269686600_ctlid), Message__empty_array___269686600_ctlid, 1, 0, 1, bShowFrontPanel, 1, 0x100000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Message__empty_array___269686600_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Message (empty array)"),21,-43,-18,136,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_FrontPanelInit NULL
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_in__no_error___268840856_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___268840856_ctlid), false );
	if (FPData(error_out__269683432_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__269683432_ctlid), false );
PDAStrFree( FPData(VISA_resource_name__269684680_ctlid) );
	FPData(VISA_resource_name__269684680_ctlid) = NULL;
PDAStrFree( FPData(VISA_resource_name_out__269685160_ctlid) );
	FPData(VISA_resource_name_out__269685160_ctlid) = NULL;
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(Message__empty_array___269686600_ctlid), 1 );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__269683432_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	if (argsOut->size > 2 && argsOut->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__269685160_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[2].pValue = GetControlHValue(nIdx);
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Length_Of_Sent_MSG__269685640_ctlid);
		if (!GetNumericFieldValue(GetControlHValue(nIdx), argsOut->args[1].pValue, argsOut->args[1].nType )) {
			return false;
		}
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_AddSubVIInstanceData(void) {
	if (Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr->initialized) return;
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr->initialized = TRUE;

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr->i0F88AA00.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr->i0F88AA00;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_InitVIConstantList(void) {
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_RunFunc_72F7BCC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_RunFunc_72F7BCC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72F7BCC == eReady) {
		MemMove( &heap->c_error_in__no_error__5, ((ClusterControlData*)FPData(error_in__no_error___268840856_ctlid))->pVal, sizeof( cl_00000 ) );
		MemSet(((ClusterControlData*)FPData(error_in__no_error___268840856_ctlid))->pVal, sizeof( cl_00000 ), 0);
		/*SetSignalReady( 0x0, 0);*//* c_error_in__no_error__5 */
		UpdateProbes(&state, debugOffset, 1 /*0xF881B78*/, (uChar*)&(heap->c_error_in__no_error__5)); /* assign */
		/* Cluster Inc Ref Count:  FPTerm*/
		{
			cl_00000* cl_002 = (cl_00000*)&heap->c_error_in__no_error__5;
			PDAStrIncRefCnt(cl_002->el_2, (uInt16)1); /* FPTerm */
		}
		if (!GetNumericFieldValue( FPData(Command__0___269683816_ctlid), &heap->by_Command__0_, uCharDataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x3, 5);*//* by_Command__0_ */
		UpdateProbes(&state, debugOffset, 6 /*0xF8818D8*/, (uChar*)&(heap->by_Command__0_)); /* assign */
		if (!GetNumericFieldValue( FPData(Unit_Address__1___269684200_ctlid), &heap->by_Unit_Address__1__2, uCharDataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x3, 6);*//* by_Unit_Address__1__2 */
		UpdateProbes(&state, debugOffset, 5 /*0xF881998*/, (uChar*)&(heap->by_Unit_Address__1__2)); /* assign */
		heap->s_VISA_resource_name_5 = FPData(VISA_resource_name__269684680_ctlid);
		PDAStrIncRefCnt(heap->s_VISA_resource_name_5, (uInt16)1);
		/*SetSignalReady( 0x2, 0);*//* s_VISA_resource_name_5 */
		UpdateProbes(&state, debugOffset, 4 /*0xF881A58*/, (uChar*)&(heap->s_VISA_resource_name_5)); /* assign */
		heap->a_Message__empty_array__1 = ((ArrayControlData*)FPData(Message__empty_array___269686600_ctlid))->hValue;
		((ArrayControlData*)FPData(Message__empty_array___269686600_ctlid))->hValue = NULL;
		/*SetSignalReady( 0x1, 6);*//* a_Message__empty_array__1 */
		UpdateProbes(&state, debugOffset, 2 /*0xF881B18*/, (uChar*)&(heap->a_Message__empty_array__1)); /* assign */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F7BCC == eReady) {
			CCGDebugSynchSNode(&state, 1, 2, 1, &snode72F7BCC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatF8824A1 = eReady;
			heap->runStatF8824A2 = eReady;
			heap->runStatF882C21 = eReady;
			heap->runStatF88A820 = eReady;
			heap->runStatF88AA00 = eReady;
			heap->runStatF88A940 = eReady;
			heap->runStatF882C22 = eReady;
			if (!PDAClusterGetElemByPosStatic( &heap->c_error_in__no_error__5, 0x0 | ClusterDataType, 0, &heap->c_error_in__no_error__CS_1, BooleanDataType, NULL )) {
				CGenErr();
			}
			/*SetSignalReady( 0x5, 2);*//* c_error_in__no_error__CS_1 */
			MemMove( &heap->c_error_in__no_error__CT_5, &heap->c_error_in__no_error__5, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x0, 2);*//* c_error_in__no_error__CT_5 */
			heap->by_Command__0__CT = heap->by_Command__0_;
			/*SetSignalReady( 0x4, 7);*//* by_Command__0__CT */
			heap->by_Unit_Address__1__CT_2 = heap->by_Unit_Address__1__2;
			/*SetSignalReady( 0x4, 6);*//* by_Unit_Address__1__CT_2 */
			heap->s_VISA_resource_name_CT_3 = heap->s_VISA_resource_name_5;
			/*SetSignalReady( 0x1, 7);*//* s_VISA_resource_name_CT_3 */
			heap->a_Message__empty_array__CT = heap->a_Message__empty_array__1;
			/*SetSignalReady( 0x2, 1);*//* a_Message__empty_array__CT */
		}
		switch ( heap->c_error_in__no_error__CS_1 ) {
			/* begin case */
			case 1 : {
				uInt32 diagramIdx = 9;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(0, 3);
						/*InitSignalReady( 0x1, 3);*//* l_Constant_6 */
						/*InitSignalReady( 0x0, 1);*//* c_error_in__no_error__CT_7 */
						/*InitSignalReady( 0x1, 5);*//* s_VISA_resource_name_CT_5 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						/* Free unwired input select tunnel. */
	if (heap->a_Message__empty_array__CT){--((PDAArrPtr)heap->a_Message__empty_array__CT)->refcnt;}
						heap->l_Constant_6 = 0;
						/*SetSignalReady( 0x1, 3);*//* l_Constant_6 */
						UpdateProbes(&state, debugOffset, 22 /*0xF889C20*/, (uChar*)&(heap->l_Constant_6)); /* assign */
						SetSignalReady(0, 1);
						MemMove( &heap->c_error_in__no_error__CT_7, &heap->c_error_in__no_error__CT_5, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x0, 1);*//* c_error_in__no_error__CT_7 */
						UpdateProbes(&state, debugOffset, 23 /*0xF881E78*/, (uChar*)&(heap->c_error_in__no_error__CT_7)); /* assign */
						SetSignalReady(0, 1);
						heap->s_VISA_resource_name_CT_5 = heap->s_VISA_resource_name_CT_3;
						/*SetSignalReady( 0x1, 5);*//* s_VISA_resource_name_CT_5 */
						UpdateProbes(&state, debugOffset, 24 /*0xF881DB8*/, (uChar*)&(heap->s_VISA_resource_name_CT_5)); /* assign */
						SetSignalReady(0, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						heap->l_Case_Structure_CT_1 = heap->l_Constant_6;
						/*SetSignalReady( 0x1, 0);*//* l_Case_Structure_CT_1 */
						MemMove( &heap->c_Case_Structure_CT_25, &heap->c_error_in__no_error__CT_7, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x0, 7);*//* c_Case_Structure_CT_25 */
						heap->s_Case_Structure_CT_23 = heap->s_VISA_resource_name_CT_5;
						/*SetSignalReady( 0x1, 4);*//* s_Case_Structure_CT_23 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 9, 9, &snode72F7BCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				uInt32 diagramIdx = 3;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						/*InitSignalReady( 0x2, 2);*//* s_Byte_Array_To_String_string */
						InitSignalReady(4, 3);
						/*InitSignalReady( 0x2, 3);*//* a_Message__empty_array__CT_1 */
						InitSignalReady(2, 1);
						/*InitSignalReady( 0x2, 4);*//* a_Utility_MODBUS_RTU_CRC16_vi_M */
						InitSignalReady(1, 3);
						/*InitSignalReady( 0x1, 2);*//* l_Array_Size_size_s__2 */
						InitSignalReady(3, 3);
						/*InitSignalReady( 0x2, 6);*//* s_VISA_resource_name_CT_4 */
						/*InitSignalReady( 0x2, 7);*//* a_Build_Array_appended_array_5 */
						/*InitSignalReady( 0x3, 0);*//* s_Utility_MODBUS_RTU_CRC16_vi__1 */
						/*InitSignalReady( 0x3, 4);*//* by_Unit_Address__1__CT_3 */
						/*InitSignalReady( 0x3, 3);*//* by_Command__0__CT_1 */
						/*InitSignalReady( 0x3, 2);*//* s_VISA_Write_VISA_resource_name */
						/*InitSignalReady( 0x0, 6);*//* c_VISA_Write_error_out */
						/*InitSignalReady( 0x0, 5);*//* c_Utility_MODBUS_RTU_CRC16_vi__1 */
						/*InitSignalReady( 0x0, 4);*//* c_error_in__no_error__CT_6 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->a_Message__empty_array__CT_1 = heap->a_Message__empty_array__CT;
						/*SetSignalReady( 0x2, 3);*//* a_Message__empty_array__CT_1 */
						UpdateProbes(&state, debugOffset, 10 /*0xF88A5E0*/, (uChar*)&(heap->a_Message__empty_array__CT_1)); /* assign */
						SetSignalReady(4, 1);
						MemMove( &heap->c_error_in__no_error__CT_6, &heap->c_error_in__no_error__CT_5, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x0, 4);*//* c_error_in__no_error__CT_6 */
						UpdateProbes(&state, debugOffset, 21 /*0xF889F20*/, (uChar*)&(heap->c_error_in__no_error__CT_6)); /* assign */
						SetSignalReady(3, 1);
						heap->by_Command__0__CT_1 = heap->by_Command__0__CT;
						/*SetSignalReady( 0x3, 3);*//* by_Command__0__CT_1 */
						UpdateProbes(&state, debugOffset, 17 /*0xF88A1C0*/, (uChar*)&(heap->by_Command__0__CT_1)); /* assign */
						SetSignalReady(4, 1);
						heap->by_Unit_Address__1__CT_3 = heap->by_Unit_Address__1__CT_2;
						/*SetSignalReady( 0x3, 4);*//* by_Unit_Address__1__CT_3 */
						UpdateProbes(&state, debugOffset, 16 /*0xF88A220*/, (uChar*)&(heap->by_Unit_Address__1__CT_3)); /* assign */
						SetSignalReady(4, 1);
						heap->s_VISA_resource_name_CT_4 = heap->s_VISA_resource_name_CT_3;
						/*SetSignalReady( 0x2, 6);*//* s_VISA_resource_name_CT_4 */
						UpdateProbes(&state, debugOffset, 13 /*0xF88A400*/, (uChar*)&(heap->s_VISA_resource_name_CT_4)); /* assign */
						SetSignalReady(3, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
/* Build array */
						CCGDebugSynchNode(&state, 3, 4, 3, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						{
							ArrDimSize i;
							ArrDimSize dimSize=0;
							heap->a_Build_Array_appended_array_5 = PDAArrNewEmptyWithNDimsStatic( uCharDataType, (ArrDimSize)1, &g_staticArray_23 );
							if (!heap->a_Build_Array_appended_array_5){
								CGenErr();
							}
							dimSize += 1;
							dimSize += 1;
							dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_Message__empty_array__CT_1), (ArrDimSize)0);
							PDAArrSetDim(((PDAArrPtr)heap->a_Build_Array_appended_array_5), (ArrDimSize)0, dimSize);
							if (!PDAArrAllocData(&heap->a_Build_Array_appended_array_5)){
								CGenErr();
							}
							i=0;
							if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_5), i, &heap->by_Unit_Address__1__CT_3, uCharDataType)) {
								CGenErr();
							}
							i++;
							if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_5), i, &heap->by_Command__0__CT_1, uCharDataType)) {
								CGenErr();
							}
							i++;
							if (!PDAArrAdd(heap->a_Build_Array_appended_array_5, i, heap->a_Message__empty_array__CT_1)) {
								CGenErr();
							}
							i += PDAArrNthDim(((PDAArrPtr)heap->a_Message__empty_array__CT_1), (ArrDimSize)0);
							PDAArrFree(heap->a_Message__empty_array__CT_1);
						}
						/*SetSignalReady( 0x2, 7);*//* a_Build_Array_appended_array_5 */
						UpdateProbes(&state, debugOffset, 14 /*0xF88A340*/, (uChar*)&(heap->a_Build_Array_appended_array_5)); /* assign */
						SetSignalReady(3, 1);
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 2 : {
						if (heap->runStatF88AA00 == eReady) {
						}
						CCGDebugSynchIUse(&state, 4, 5, 3, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility MODBUS RTU CRC16.vi");
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						{
							ControlDataItemPtr cdPtr = LVGetCurrentControlData();
							if (heap->runStatF88AA00 == eReady) {
								CreateArgListStatic(heap->ArgsF88AA01, 3, 4 );
								argIn(heap->ArgsF88AA01, 0).nType = 0x0 | ClusterDataType;
								argIn(heap->ArgsF88AA01, 0).pValue = (void *)&heap->c_error_in__no_error__CT_6;
								argIn(heap->ArgsF88AA01, 1).nType = 0x100000 | ArrayDataType;
								argIn(heap->ArgsF88AA01, 1).pValue = (void *)&heap->a_Build_Array_appended_array_5;
								argIn(heap->ArgsF88AA01, 2).nType = StringDataType;
								argIn(heap->ArgsF88AA01, 2).pValue = (void *)&heap->s_VISA_resource_name_CT_4;
								argOut(heap->ArgsF88AA01, 0).nType = 0x0 | ClusterDataType;
								argOut(heap->ArgsF88AA01, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_CRC16_vi__1;
								argOut(heap->ArgsF88AA01, 1).nType = 0;
								argOut(heap->ArgsF88AA01, 1).pValue = NULL;
								argOut(heap->ArgsF88AA01, 2).nType = 0x100000 | ArrayDataType;
								argOut(heap->ArgsF88AA01, 2).pValue = (void *)&heap->a_Utility_MODBUS_RTU_CRC16_vi_M;
								argOut(heap->ArgsF88AA01, 3).nType = StringDataType;
								argOut(heap->ArgsF88AA01, 3).pValue = (void *)&heap->s_Utility_MODBUS_RTU_CRC16_vi__1;
							}
							if (!Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr->i0F88AA00.callerID) {
								Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr->i0F88AA00.callerID = ++gCallerID;
							}
							heap->runStatF88AA00 = Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Run( &Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr->i0F88AA00, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsF88AA01)[0], (ArgList *)((ArgList **)heap->ArgsF88AA01)[1], &gPauseThisVI );
							LVSetCurrentControlData(cdPtr);
							CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 5, debugOffset);
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}

							if (heap->runStatF88AA00 == eNotFinished) {
								runStat = eNotFinished;
							}
							if (heap->runStatF88AA00 == eFail || gLastError) {
								CGenErr();
							}
							if (gAppStop || (heap->runStatF88AA00 == eFinished)) {
								/*SetSignalReady( 0x0, 5);*//* c_Utility_MODBUS_RTU_CRC16_vi__1 */
								UpdateProbes(&state, debugOffset, 20 /*0xF889FE0*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_CRC16_vi__1)); /* assign */
								/*SetSignalReady( 0x2, 4);*//* a_Utility_MODBUS_RTU_CRC16_vi_M */
								UpdateProbes(&state, debugOffset, 11 /*0xF88A520*/, (uChar*)&(heap->a_Utility_MODBUS_RTU_CRC16_vi_M)); /* assign */
								SetSignalReady(2, 1);
								/*SetSignalReady( 0x3, 0);*//* s_Utility_MODBUS_RTU_CRC16_vi__1 */
								UpdateProbes(&state, debugOffset, 15 /*0xF88A2E0*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_CRC16_vi__1)); /* assign */
								PDAArrIncRefCnt(heap->a_Utility_MODBUS_RTU_CRC16_vi_M, (uInt16)1); /* Func call */
							}
							if (gAppStop) {
								gAppStop=true;/* opt bug fix*/
								return eFinished;
							}
						}
						if (!bRunToFinish && (runStat == eNotFinished)) {
							return eNotFinished;
						}
						if (heap->runStatF88AA00 == eFinished) {
							heap->runStatF88AA00 = eReady;
						}
						nStep++; }
/* start q el linear (0 or 1 struct) */
					case 4 : {
						/**/
						/* Array Size */
						/**/
						CCGDebugSynchNode(&state, 5, 6, 3, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (heap->a_Utility_MODBUS_RTU_CRC16_vi_M) {
							heap->l_Array_Size_size_s__2 = NthDim( ((PDAArrPtr)heap->a_Utility_MODBUS_RTU_CRC16_vi_M), 0 );
						}
						else {
							heap->l_Array_Size_size_s__2 = 0;
						}
	if (heap->a_Utility_MODBUS_RTU_CRC16_vi_M){--((PDAArrPtr)heap->a_Utility_MODBUS_RTU_CRC16_vi_M)->refcnt;}
						/*SetSignalReady( 0x1, 2);*//* l_Array_Size_size_s__2 */
						UpdateProbes(&state, debugOffset, 12 /*0xF88A4C0*/, (uChar*)&(heap->l_Array_Size_size_s__2)); /* assign */
						SetSignalReady(1, 1);
						/**/
						/* Byte Array To String */
						/**/
						CCGDebugSynchNode(&state, 6, 7, 3, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (!PDAArrToString(heap->a_Utility_MODBUS_RTU_CRC16_vi_M, &(heap->s_Byte_Array_To_String_string))) {
							CGenErr();
						}
						/*SetSignalReady( 0x2, 2);*//* s_Byte_Array_To_String_string */
						UpdateProbes(&state, debugOffset, 9 /*0xF88A6A0*/, (uChar*)&(heap->s_Byte_Array_To_String_string)); /* assign */
						/**/
						/* VISA Write */
						/**/
						CCGDebugSynchNode(&state, 7, 8, 3, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (VisaWrite(heap->s_Utility_MODBUS_RTU_CRC16_vi__1,  heap->s_Byte_Array_To_String_string,  &(heap->c_Utility_MODBUS_RTU_CRC16_vi__1),  &(heap->s_VISA_Write_VISA_resource_name),  (VoidHand)NULL,  &(heap->c_VISA_Write_error_out) ) == eFail) {
							CGenErr();
						}
						/*SetSignalReady( 0x0, 6);*//* c_VISA_Write_error_out */
						UpdateProbes(&state, debugOffset, 19 /*0xF88A0A0*/, (uChar*)&(heap->c_VISA_Write_error_out)); /* assign */
						SetSignalReady(1, 1);
						/*SetSignalReady( 0x3, 2);*//* s_VISA_Write_VISA_resource_name */
						UpdateProbes(&state, debugOffset, 18 /*0xF88A160*/, (uChar*)&(heap->s_VISA_Write_VISA_resource_name)); /* assign */
						SetSignalReady(1, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 5 : {
						heap->l_Case_Structure_CT_1 = heap->l_Array_Size_size_s__2;
						/*SetSignalReady( 0x1, 0);*//* l_Case_Structure_CT_1 */
						MemMove( &heap->c_Case_Structure_CT_25, &heap->c_VISA_Write_error_out, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x0, 7);*//* c_Case_Structure_CT_25 */
						heap->s_Case_Structure_CT_23 = heap->s_VISA_Write_VISA_resource_name;
						/*SetSignalReady( 0x1, 4);*//* s_Case_Structure_CT_23 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 8, 3, &snode72F7BCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
		}
		MemMove( &heap->c_Case_Structure_CT_24, &heap->c_Case_Structure_CT_25, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x0, 3);*//* c_Case_Structure_CT_24 */
		UpdateProbes(&state, debugOffset, 8 /*0xF881758*/, (uChar*)&(heap->c_Case_Structure_CT_24)); /* assign */
		heap->s_Case_Structure_CT_22 = heap->s_Case_Structure_CT_23;
		/*SetSignalReady( 0x3, 1);*//* s_Case_Structure_CT_22 */
		UpdateProbes(&state, debugOffset, 7 /*0xF881818*/, (uChar*)&(heap->s_Case_Structure_CT_22)); /* assign */
		heap->l_Case_Structure_CT = heap->l_Case_Structure_CT_1;
		/*SetSignalReady( 0x1, 1);*//* l_Case_Structure_CT */
		UpdateProbes(&state, debugOffset, 3 /*0xF881AB8*/, (uChar*)&(heap->l_Case_Structure_CT)); /* assign */
		/* FreeCaseSelDCO. */
	/* Free Cluster */
		{
			cl_00000* cl_003 = (cl_00000*)&heap->c_error_in__no_error__5;
				if (cl_003->el_2 && --((PDAStrPtr)cl_003->el_2)->refcnt == 0 && !((PDAStrPtr)cl_003->el_2)->staticStr) {
				MemHandleFree( cl_003->el_2 );
			}
		}
		CCGDebugSynchAfterSNode(&state, &snode72F7BCC, 2, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	{
		if (!SetClusterControlFieldValue( FPData(error_out__269683432_ctlid), &heap->c_Case_Structure_CT_24, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, error_out__269683432_ctlid);
	if (FPData(VISA_resource_name_out__269685160_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__269685160_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__269685160_ctlid))->staticStr) {
		MemHandleFree( FPData(VISA_resource_name_out__269685160_ctlid) );
	}
	FPData(VISA_resource_name_out__269685160_ctlid)=PDAStrCopyOnModify(heap->s_Case_Structure_CT_22);
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__269685160_ctlid);
	{
		if (!SetNumericFieldValue( FPData(Length_Of_Sent_MSG__269685640_ctlid), &heap->l_Case_Structure_CT, int32DataType )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, Length_Of_Sent_MSG__269685640_ctlid);
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			/*InitSignalReady( 0x0, 0);*//* c_error_in__no_error__5 */
			/*InitSignalReady( 0x1, 6);*//* a_Message__empty_array__1 */
			/*InitSignalReady( 0x1, 1);*//* l_Case_Structure_CT */
			/*InitSignalReady( 0x2, 0);*//* s_VISA_resource_name_5 */
			/*InitSignalReady( 0x3, 6);*//* by_Unit_Address__1__2 */
			/*InitSignalReady( 0x3, 5);*//* by_Command__0_ */
			/*InitSignalReady( 0x3, 1);*//* s_Case_Structure_CT_22 */
			/*InitSignalReady( 0x0, 3);*//* c_Case_Structure_CT_24 */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStat72F7BCC = Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_RunFunc_72F7BCC( bRunToFinish  );
			if (heap->runStat72F7BCC == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStat72F7BCC == eFail) {
				CGenErr();
			}
			heap->runStat72F7BCC = eReady;
			nStep++; }
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 2, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_VIName = "Watflow F4.lvlib:Utility MODBUS RTU Send Message.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)20,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_viInstanceHeap),
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_InitFPTerms,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_FrontPanelInit,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_BlockDiagram,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_DrawLabels,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_GetFPTerms,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_Cleanup,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupLSRs,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_AddSubVIInstanceData,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


