#ifndef _LVISRs_h
#define _LVISRs_h


#ifdef LV_MAIN
ISRInfoTableEntry gISRInfoTable[] = {
	{NULL, NULL}};
#else
extern ISRInfoTableEntry gISRInfoTable[];
#endif
#endif
