/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: TESynC Initialize.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\TESynC_1_1.llb\TESynC Initialize.vi
 *	Generated on: 2010-2-8 14:39
 *  Generated UI: false
 *  Generated Debug Info: false
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: true
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: dynamic
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
struct _TESynC_Initialize_heap { 
	cl_00000 c_Case_Structure_CT_6;
	cl_00000 c_error_IO;
	cl_00000 c_VISA_Open_error_out;
	cl_00000 c_Case_Structure_CT_10;
	cl_00000 c_Case_Structure_CT_9;
	cl_00000 c_Select_s__t_f;
	cl_00000 c_error_in__no_error_;
	cl_00000 c_Case_Structure_CT_12;
	cl_00000 c_Constant;
	cl_00000 c_Case_Structure_CT_13;
	cl_00000 c_Case_Structure_CT_8;
	cl_00000 c_Case_Structure_CT_7;
	cl_00000 c_Case_Structure_CT;
	cl_00000 c_Case_Structure_CT_5;
	cl_00000 c_Case_Structure_CT_1;
	cl_00000 c_Property_Node_error_out;
	cl_00000 c_Case_Structure_CT_4;
	cl_00000 c_Case_Structure_CT_14;
	cl_00000 c_Case_Structure_CT_15;
	cl_00000 c_Property_Node_error_out_CT_2;
	cl_00000 c_Case_Structure_CT_2;
	cl_00000 c_Case_Structure_CT_11;
	cl_00000 c_Property_Node_error_out_1;
	cl_00000 c_Property_Node_error_out_CT_1;
	cl_00000 c_Property_Node_error_out_CT;
	cl_00000 c_Case_Structure_CT_3;
	uInt32 dw_Serial_Settings_Baud_Rate;
	uInt32 dw_access_mode;
	uInt32 dw_Tmo_Value;
	int32 l_Constant;
	int32 l_Constant_1;
	int32 l_Match_Pattern_offset_past_mat;
	int32 l_Match_Pattern_offset_past_mat_1;
	VoidHand Args12C8CF29;  
	VoidHand s_Constant_1;
	VoidHand s_VISA_resource_name;
	VoidHand s_Constant;
	VoidHand s_Case_Structure_CT_7;
	VoidHand s_ID_Query;
	VoidHand s_TESynC_Visa_Read_vi_VISA_sess;
	VoidHand s_TESynC_Visa_Read_vi_read_buff;
	VoidHand ArgsE2FBE81;  
	uInt16 n_y;
	uInt16 n_Serial_Settings_Data_Bits;
	uInt16 n_Serial_Settings_Parity;
	uInt16 n_Serial_Settings_Serial_Flow_C;
	uInt16 n_Property_Node_Interface_Infor;
	uInt16 n_ASRL_End_Out;
	uInt16 n_Serial_Settings_Stop_Bits;
	int16 i_Modem_DTR_State;
	int16 i_Modem_RTS_State;
	uInt8 runStat72F84CC;  
	uInt8 runStat10B938E9;  
	uInt8 runStat10B938EA;  
	uInt8 by_TermChar;
	uInt8 runStat10B92D00;  
	uInt8 runStat72F234C;  
	uInt8 runStat10B92DAA;  
	uInt8 runStat10B92F29;  
	uInt8 runStat72FCA4C;  
	uInt8 runStat10B92DA9;  
	uInt8 runStat10B92F6A;  
	uInt8 runStat10B9396A;  
	uInt8 runStat10B93969;  
	uInt8 runStat12C8CF28;  
	uInt8 runStat72FE44C;  
	uInt8 runStat72F2A4C;  
	uInt8 runStat10B92D6A;  
	uInt8 runStat10B92D69;  
	uInt8 runStatE285820;  
	uInt8 runStat10B92F2A;  
	uInt8 runStat72F4BCC;  
	uInt8 runStat12C8D108;  
	uInt8 runStat10E8A311;  
	uInt8 runStat10E8A312;  
	uInt8 by_Message_Based_Settings_Termi;
	uInt8 runStat10B92F69;  
	uInt8 runStat10E89ED1;  
	uInt8 runStat10E89ED2;  
	uInt8 runStatE2FBE80;  
	uInt8 runStat1;  
	Boolean b_Unbundle_By_Name_status_CS;
	Boolean b_Compound_Arithmetic_result;
	Boolean b_Reset__T__Reset__CS;
	Boolean b_Not_Equal__x____y__1;
	Boolean b_Not_Equal__x____y_;
	Boolean b_Unbundle_By_Name_status;
	Boolean b_Case_Structure_CT;
	Boolean b_ID_Query__T__Check__CS;
	Boolean b_TermChar_En;
	Boolean b_Equal__x___y__CS;
	Boolean b_ID_Query__T__Check_;
	Boolean b_Reset__T__Reset_;
	Boolean b_Equal__x___y_;
	Boolean b_Message_Based_Settings_Termin;
	Boolean b_duplicate_session__F_;
} _DATA_SECTION __TESynC_Initialize_heap; /* heap */

static uInt32 _DATA_SECTION _TESynC_Initialize_signalsReadyTable[19];

static struct _TESynC_Initialize_heap _DATA_SECTION *heap = &__TESynC_Initialize_heap; /* heap */

struct _tTESynC_Initialize_GlobalConstantsHeap {
	uInt8	refCnt;
	cl_00000	i0E329D50;
	cl_00000	i10E88798;
	String	i10E88958;
	String	i10E88A00;
	String	i10E88B50;
} _DATA_SECTION __TESynC_Initialize_GlobalConstantsHeap;
static struct _tTESynC_Initialize_GlobalConstantsHeap _DATA_SECTION *TESynC_Initialize_GlobalConstantsHeapPtr = &__TESynC_Initialize_GlobalConstantsHeap;

struct _tTESynC_Initialize_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i0E2FBE80;
} _DATA_SECTION __TESynC_Initialize_viInstanceHeap;
static struct _tTESynC_Initialize_viInstanceHeap _DATA_SECTION *TESynC_Initialize_viInstanceHeapPtr = &__TESynC_Initialize_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _TESynC_Initialize_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[19] = {2, 2, 2, 2, 2, 3, 2, 2, 2, 1, 2, 2, 2, 12, 2, 3, 2, 5, 2};
struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_cluster_2 = { 
	0, 0, &g_string_2.el_1
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[17];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 15, _LVT("SynC Initialize")
};

_DATA_SECTION static cl_00000 g_cluster_1 = { 
	1, -1074003951, &g_string_1.el_1
};

static BooleanData g_control_1 = {
	true, false, false, true
};

static BooleanData g_control_2 = {
	true, false, false, true
};

static ClusterControlData g_control_6 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_10 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2100UL
#define Reset__T__Reset___315118624_ctlid 2100
#define label283666872_ctlid 2101
#define ID_Query__T__Check___315118816_ctlid 2102
#define label283667064_ctlid 2103
#define error_in__no_error___315119968_ctlid 2104
#define error_out__315121120_ctlid 2105
#define VISA_session__315121600_ctlid 2106
#define label283669752_ctlid 2107
#define VISA_resource_name__315122080_ctlid 2108
#define N_CONTROLS 9L
#define gArrControlData TESynC_Initialize_gArrControlData
ControlDataItem _DATA_SECTION TESynC_Initialize_gArrControlData[9] = {
	{ Reset__T__Reset___315118624_ctlid, 0, NULL, VoidHandDataType, pushbutton_control },
	{ label283666872_ctlid, 0, NULL, uCharDataType, nonui_control },
	{ ID_Query__T__Check___315118816_ctlid, 0, NULL, VoidHandDataType, pushbutton_control },
	{ label283667064_ctlid, 0, NULL, uCharDataType, nonui_control },
	{ error_in__no_error___315119968_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__315121120_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_session__315121600_ctlid, 0, NULL, StringDataType, nonui_control },
	{ label283669752_ctlid, 0, NULL, uCharDataType, nonui_control },
	{ VISA_resource_name__315122080_ctlid, 0, NULL, StringDataType, nonui_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION TESynC_Initialize_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION TESynC_Initialize_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(Reset__T__Reset___315118624_ctlid) = BooleanDataCreateStatic(&g_control_1, Reset__T__Reset___315118624_ctlid, (Boolean)0, (Boolean)1, (Boolean)true, (uInt8)1, (!version35)?std_button:std_button))){
		return false;
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		{
			int32 lVal;
			nIdx = CalcControlOffset( gFormID, Reset__T__Reset___315118624_ctlid);
			lVal = LVPtrToLong( argsIn->args[2].pValue, argsIn->args[2].nType );
			if (!SetBooleanFieldValue( gArrControlData[nIdx].hValue, (Boolean)lVal )) {
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Reset__T__Reset___315118624_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Reset (T: Reset)"),16,5,-17,105,16,
	_LVT("0"),12,0,1000,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283666872_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Reset"),5,57,181,69,44,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283666872_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT(""),0,57,193,69,44,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283666872_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT(""),0,57,205,69,44,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283666872_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Don\'t Reset"),11,57,217,69,44,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(ID_Query__T__Check___315118816_ctlid) = BooleanDataCreateStatic(&g_control_2, ID_Query__T__Check___315118816_ctlid, (Boolean)0, (Boolean)1, (Boolean)true, (uInt8)1, (!version35)?std_button:std_button))){
		return false;
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		{
			int32 lVal;
			nIdx = CalcControlOffset( gFormID, ID_Query__T__Check___315118816_ctlid);
			lVal = LVPtrToLong( argsIn->args[1].pValue, argsIn->args[1].nType );
			if (!SetBooleanFieldValue( gArrControlData[nIdx].hValue, (Boolean)lVal )) {
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	ID_Query__T__Check___315118816_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("ID Query (T: Check)"),19,-1,-18,126,16,
	_LVT("0"),12,0,1000,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283667064_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Check"),5,55,96,69,44,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283667064_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT(""),0,55,108,69,44,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283667064_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT(""),0,55,120,69,44,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283667064_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Don\'t Check"),11,55,132,69,44,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_in__no_error___315119968_ctlid) = ClusterControlDataCreateStatic(&g_control_6, GetControlDataPtr(), gFormID, error_in__no_error___315119968_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___315119968_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[3].pValue, argsIn->args[3].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromStr(_LVT(""));
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___315119968_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___315119968_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,1,-18,125,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__315121120_ctlid) = ClusterControlDataCreateStatic(&g_control_10, GetControlDataPtr(), gFormID, error_out__315121120_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if(bShowFrontPanel) {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromStr(_LVT(""));
		}
		InitClusterControlFieldValue( FPData(error_out__315121120_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__315121120_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-1,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_session__315121600_ctlid) = PDAStrNewFromStr(_LVT(""));
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_session__315121600_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA session"),12,3,-15,87,16,
	_LVT("0"),12,0,1000,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283669752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("WARNINGS: "),10,19,242,640,58,
	_LVT("0"),12,0,1000,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283669752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("(1) You MUSThave VISA Version 2.0 or higher installed to use this Instrument driver. "),85,19,254,640,58,
	_LVT("0"),12,0,1000,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283669752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("(2) If using the Serial Interface, the pass/fail outputs - Pins 1 & 9 - MUST NOT be enabled"),91,19,266,640,58,
	_LVT("0"),12,0,1000,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label283669752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("     on the serial connector, or instrument damage my result - See the Manual for details."),90,19,278,640,58,
	_LVT("0"),12,0,1000,0, false);
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__315122080_ctlid);
			vhIn = *(VoidHand *)argsIn->args[0].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[0].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[0].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[0].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__315122080_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,1,-17,111,16,
	_LVT("0"),12,0,0,0, false);
	return true;
}
#define TESynC_Initialize_FrontPanelInit NULL
#define TESynC_Initialize_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION TESynC_Initialize_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION TESynC_Initialize_Cleanup(Boolean bShowFrontPanel){
	(void)BooleanFreeData( FPData(Reset__T__Reset___315118624_ctlid) );
	(void)BooleanFreeData( FPData(ID_Query__T__Check___315118816_ctlid) );
	if (FPData(error_in__no_error___315119968_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___315119968_ctlid), false );
	if (FPData(error_out__315121120_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__315121120_ctlid), false );
PDAStrFree( FPData(VISA_session__315121600_ctlid) );
	FPData(VISA_session__315121600_ctlid) = NULL;
PDAStrFree( FPData(VISA_resource_name__315122080_ctlid) );
	FPData(VISA_resource_name__315122080_ctlid) = NULL;
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION TESynC_Initialize_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION TESynC_Initialize_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__315121120_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[1].pValue, argsOut->args[1].nType );
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_session__315121600_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[0].pValue = GetControlHValue(nIdx);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION TESynC_Initialize_CleanupLSRs(void);
void _TEXT_SECTION TESynC_Initialize_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION TESynC_Initialize_AddSubVIInstanceData(void);
void _TEXT_SECTION TESynC_Initialize_AddSubVIInstanceData(void) {
	if (TESynC_Initialize_viInstanceHeapPtr->initialized) return;
	TESynC_Initialize_viInstanceHeapPtr->initialized = TRUE;

	TESynC_Initialize_viInstanceHeapPtr->i0E2FBE80.next = gVIInstanceListHead;
	gVIInstanceListHead = &TESynC_Initialize_viInstanceHeapPtr->i0E2FBE80;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION TESynC_Initialize_AddVIGlobalConstants(void);
void _TEXT_SECTION TESynC_Initialize_AddVIGlobalConstants(void) {
	MemSet(TESynC_Initialize_GlobalConstantsHeapPtr,sizeof(*(TESynC_Initialize_GlobalConstantsHeapPtr)),0);
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION TESynC_Initialize_CleanupVIGlobalConstants(void);
void _TEXT_SECTION TESynC_Initialize_CleanupVIGlobalConstants(void) {
	(TESynC_Initialize_GlobalConstantsHeapPtr->refCnt)--;
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION TESynC_Initialize_InitVIConstantList(void);
void _TEXT_SECTION TESynC_Initialize_InitVIConstantList(void) {
	(TESynC_Initialize_GlobalConstantsHeapPtr->refCnt)++;
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72FCA4C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72FCA4C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72FCA4C == eReady) {
		if (!GetBooleanFieldValue( FPData(Reset__T__Reset___315118624_ctlid), &heap->b_Reset__T__Reset_ )){
			CGenErr();
		}
		/*SetSignalReady( 0xD, 7);*//* b_Reset__T__Reset_ */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72FCA4C == eReady) {
			heap->runStat10B92F29 = eReady;
			heap->runStat10B92F2A = eReady;
			heap->runStat10B92F69 = eReady;
			heap->runStat10B92F6A = eReady;
			heap->b_Reset__T__Reset__CS = heap->b_Reset__T__Reset_;
			/*SetSignalReady( 0xC, 6);*//* b_Reset__T__Reset__CS */
			MemMove( &heap->c_Case_Structure_CT_12, &heap->c_Case_Structure_CT_2, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x0, 7);*//* c_Case_Structure_CT_12 */
			/*SetSignalReady( 0x6, 1);*//* s_Case_Structure_CT_8 */
		}
		/* begin case */
		if ( heap->b_Reset__T__Reset__CS ) {
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					MemMove( &heap->c_Case_Structure_CT_15, &heap->c_Case_Structure_CT_12, sizeof( cl_00000 ) );
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_13, &heap->c_Case_Structure_CT_15, sizeof( cl_00000 ) );
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					MemMove( &heap->c_Case_Structure_CT_14, &heap->c_Case_Structure_CT_12, sizeof( cl_00000 ) );
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_13, &heap->c_Case_Structure_CT_14, sizeof( cl_00000 ) );
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			nStep = 0;
		} /* end case */
		MemMove( &heap->c_Case_Structure_CT, &heap->c_Case_Structure_CT_13, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x1, 4);*//* c_Case_Structure_CT */
		/*SetSignalReady( 0x6, 4);*//* s_Case_Structure_CT */
	} /* end switch */
	{
		if (!SetClusterControlFieldValue( FPData(error_out__315121120_ctlid), &heap->c_Case_Structure_CT, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	if (FPData(VISA_session__315121600_ctlid) && --((PDAStrPtr)FPData(VISA_session__315121600_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_session__315121600_ctlid))->staticStr) {
		MemHandleFree( FPData(VISA_session__315121600_ctlid) );
	}
	FPData(VISA_session__315121600_ctlid)=PDAStrCopyOnModify(heap->s_VISA_resource_name);
	return eFinished;
}
eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72F2A4C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72F2A4C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F2A4C == eReady) {
			heap->runStat10E89ED1 = eReady;
			heap->runStat10E89ED2 = eReady;
			heap->runStat10E8A311 = eReady;
			heap->runStat10E8A312 = eReady;
			heap->b_Unbundle_By_Name_status_CS = heap->b_Unbundle_By_Name_status;
			/*SetSignalReady( 0xC, 4);*//* b_Unbundle_By_Name_status_CS */
			/* Cluster CopyOnModify */
			MemMove( &heap->c_Case_Structure_CT_10, &heap->c_Case_Structure_CT_7, sizeof( cl_00000 ) );
			{
				cl_00000* clSrc_002 = (cl_00000*)&heap->c_Case_Structure_CT_7;
				cl_00000* clDest_003 = (cl_00000*)&heap->c_Case_Structure_CT_10;
				clDest_003->el_2 = PDAStrCopyOnModify( clSrc_002->el_2 );
			}
			/*SetSignalReady( 0x0, 3);*//* c_Case_Structure_CT_10 */
		}
		/* begin case */
		if ( heap->b_Unbundle_By_Name_status_CS ) {
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					heap->b_Compound_Arithmetic_result = heap->b_Unbundle_By_Name_status_CS;
					/* Cluster CopyOnModify */
					MemMove( &heap->c_Case_Structure_CT_11, &heap->c_Case_Structure_CT_10, sizeof( cl_00000 ) );
					{
						cl_00000* clSrc_004 = (cl_00000*)&heap->c_Case_Structure_CT_10;
						cl_00000* clDest_005 = (cl_00000*)&heap->c_Case_Structure_CT_11;
						clDest_005->el_2 = PDAStrCopyOnModify( clSrc_004->el_2 );
					}
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_9, &heap->c_Case_Structure_CT_11, sizeof( cl_00000 ) );
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					heap->b_Compound_Arithmetic_result = heap->b_Unbundle_By_Name_status_CS;
					{
						cl_00000* cl_006;
						cl_006 = (cl_00000*)&TESynC_Initialize_GlobalConstantsHeapPtr->i0E329D50;
						MemSet( cl_006, sizeof(cl_00000), 0 );
						cl_006->el_0 = false;
						cl_006->el_1 = 0 ;
						cl_006->el_2 = PDAStrNewFromStr(_LVT(""));
					}
					heap->c_error_IO = TESynC_Initialize_GlobalConstantsHeapPtr->i0E329D50;
					/* Free unwired input select tunnel. */
	/* Free Cluster */
					{
						cl_00000* cl_008 = (cl_00000*)&heap->c_Case_Structure_CT_10;
				if (cl_008->el_2 && --((PDAStrPtr)cl_008->el_2)->refcnt == 0 && !((PDAStrPtr)cl_008->el_2)->staticStr) {
							MemHandleFree( cl_008->el_2 );
						}
					}
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_9, &heap->c_error_IO, sizeof( cl_00000 ) );
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			nStep = 0;
		} /* end case */
		heap->b_Case_Structure_CT = heap->b_Compound_Arithmetic_result;
		/*SetSignalReady( 0xD, 2);*//* b_Case_Structure_CT */
		MemMove( &heap->c_Case_Structure_CT_8, &heap->c_Case_Structure_CT_9, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x1, 2);*//* c_Case_Structure_CT_8 */
	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72F234C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72F234C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72F234C == eReady) {
		if (!GetBooleanFieldValue( FPData(ID_Query__T__Check___315118816_ctlid), &heap->b_ID_Query__T__Check_ )){
			CGenErr();
		}
		/*SetSignalReady( 0xD, 6);*//* b_ID_Query__T__Check_ */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F234C == eReady) {
			heap->runStat10B92D69 = eReady;
			heap->runStat12C8CF28 = eReady;
			heap->runStat72F2A4C = eReady;
			heap->runStatE2FBE80 = eReady;
			heap->runStat12C8D108 = eReady;
			heap->runStat10B92D6A = eReady;
			heap->runStat10B92DA9 = eReady;
			heap->runStat10B92DAA = eReady;
			heap->b_ID_Query__T__Check__CS = heap->b_ID_Query__T__Check_;
			/*SetSignalReady( 0xD, 3);*//* b_ID_Query__T__Check__CS */
			/*SetSignalReady( 0x7, 0);*//* s_Case_Structure_CT_5 */
			MemMove( &heap->c_Case_Structure_CT_5, &heap->c_Case_Structure_CT_1, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x1, 5);*//* c_Case_Structure_CT_5 */
		}
		/* begin case */
		if ( heap->b_ID_Query__T__Check__CS ) {
			int16 pass;
			Boolean bEndDiagram = false;
			uInt32 id = LVGetTimerFlag();
			while (!gAppStop && !gLastError) {
				nReady = 0;
				bEndDiagram = false;
				runStat = eFinished;
				for (pass=0;pass<2;pass++) {
					{
/* start q el linear (2 struct) */
						if ((heap->runStat10B92D69 != eFinished)
						/*) {*/
						) {
							if (pass == 0) {
								InitSignalReady(5, 3);
								InitSignalReady(8, 2);
								InitSignalReady(9, 1);
								/*InitSignalReady( 0x1, 3);*//* c_Case_Structure_CT_7 */
								/*InitSignalReady( 0x1, 2);*//* c_Case_Structure_CT_8 */
								/*InitSignalReady( 0xD, 2);*//* b_Case_Structure_CT */
								/*InitSignalReady( 0xD, 1);*//* b_Unbundle_By_Name_status */
								InitSignalReady(4, 2);
								/*InitSignalReady( 0x6, 0);*//* s_TESynC_Visa_Read_vi_read_buff */
								InitSignalReady(3, 2);
								/*InitSignalReady( 0x5, 6);*//* s_TESynC_Visa_Read_vi_VISA_sess */
								/*InitSignalReady( 0x5, 5);*//* s_ID_Query */
								/*InitSignalReady( 0x5, 4);*//* s_Case_Structure_CT_7 */
								/*InitSignalReady( 0xD, 0);*//* b_Not_Equal__x____y_ */
								/*InitSignalReady( 0x3, 7);*//* l_Match_Pattern_offset_past_mat */
								/*InitSignalReady( 0x3, 5);*//* l_Constant */
								/*InitSignalReady( 0x4, 7);*//* s_Constant */
								/*InitSignalReady( 0x1, 0);*//* c_Constant */
								/*InitSignalReady( 0xC, 7);*//* b_Not_Equal__x____y__1 */
								/*InitSignalReady( 0xC, 5);*//* b_Compound_Arithmetic_result */
								/*InitSignalReady( 0x4, 4);*//* s_Constant_1 */
								/*InitSignalReady( 0x3, 6);*//* l_Constant_1 */
								/*InitSignalReady( 0x4, 0);*//* l_Match_Pattern_offset_past_mat_1 */
								/*InitSignalReady( 0x0, 5);*//* c_Select_s__t_f */
							}
							else {
								{
									heap->s_Case_Structure_CT_7 = heap->s_VISA_resource_name;
									/*SetSignalReady( 0x5, 4);*//* s_Case_Structure_CT_7 */
									SetSignalReady(5, 1);
									TESynC_Initialize_GlobalConstantsHeapPtr->i10E88B50 = PDAStrNewFromBuf(_LVT("Tidal"),(uInt32)5);
									heap->s_Constant_1 = TESynC_Initialize_GlobalConstantsHeapPtr->i10E88B50;
									/*SetSignalReady( 0x4, 4);*//* s_Constant_1 */
									heap->l_Constant_1 = -1;
									/*SetSignalReady( 0x3, 6);*//* l_Constant_1 */
									TESynC_Initialize_GlobalConstantsHeapPtr->i10E88A00 = PDAStrNewFromBuf(_LVT("*IDN?"),(uInt32)5);
									heap->s_ID_Query = TESynC_Initialize_GlobalConstantsHeapPtr->i10E88A00;
									/*SetSignalReady( 0x5, 5);*//* s_ID_Query */
									SetSignalReady(5, 1);
									TESynC_Initialize_GlobalConstantsHeapPtr->i10E88958 = PDAStrNewFromBuf(_LVT("Lunaire"),(uInt32)7);
									heap->s_Constant = TESynC_Initialize_GlobalConstantsHeapPtr->i10E88958;
									/*SetSignalReady( 0x4, 7);*//* s_Constant */
									SetSignalReady(4, 1);
									heap->l_Constant = -1;
									/*SetSignalReady( 0x3, 5);*//* l_Constant */
									MemMove( &heap->c_Case_Structure_CT_7, &heap->c_Case_Structure_CT_5, sizeof( cl_00000 ) );
									/*SetSignalReady( 0x1, 3);*//* c_Case_Structure_CT_7 */
									SetSignalReady(5, 1);
									SetSignalReady(8, 1);
									SetSignalReady(9, 1);
									/* Cluster Inc Ref Count:  SelectTunnel*/
									{
										cl_00000* cl_009 = (cl_00000*)&heap->c_Case_Structure_CT_7;
										PDAStrIncRefCnt(cl_009->el_2, (uInt16)2); /* SelectTunnel */
									}
									{
										cl_00000* cl_010;
										cl_010 = (cl_00000*)&TESynC_Initialize_GlobalConstantsHeapPtr->i10E88798;
										MemSet( cl_010, sizeof(cl_00000), 0 );
										cl_010->el_0 = true;
										cl_010->el_1 = -1074003951 ;
										cl_010->el_2 = PDAStrNewFromBuf(_LVT("SynC Initialize"),(uInt32)15);
									}
									heap->c_Constant = TESynC_Initialize_GlobalConstantsHeapPtr->i10E88798;
									/*SetSignalReady( 0x1, 0);*//* c_Constant */
								}
								heap->runStat10B92D69 = eFinished;
								continue;
							}
						}
/* start q el linear (2 struct) */
						if ((heap->runStat12C8CF28 != eFinished)
						/*&& GetSignalReady( 0x1, 3)*//* c_Case_Structure_CT_7 *//*) {*/
						&& GetSignalReady( 9 )) {
							if (pass == 0) {
								nReady++;
							}
							else {
								{
/* Unbundle by name */
									{
										cl_00000* cl_012 = (cl_00000*)&heap->c_Case_Structure_CT_7;
										heap->b_Unbundle_By_Name_status = cl_012->el_0;
										/*SetSignalReady( 0xD, 1);*//* b_Unbundle_By_Name_status */
										SetSignalReady(8, 1);
	/* Free Cluster */
										{
											cl_00000* cl_013 = (cl_00000*)&heap->c_Case_Structure_CT_7;
				if (cl_013->el_2 && --((PDAStrPtr)cl_013->el_2)->refcnt == 0 && !((PDAStrPtr)cl_013->el_2)->staticStr) {
												MemHandleFree( cl_013->el_2 );
											}
										}
									}
								}
								heap->runStat12C8CF28 = eFinished;
								InitSignalReady(9, 1);
								continue;
							}
						}
/* start q el struct (2 struct) */
						if ((heap->runStat72F2A4C != eFinished)
						/*&& GetSignalReady( 0xD, 1)*//* b_Unbundle_By_Name_status */
						/*&& GetSignalReady( 0x1, 3)*//* c_Case_Structure_CT_7 *//*) {*/
						&& GetSignalReady( 8 )) {
							if (pass == 0) {
								nReady++;
							}
							else {
								heap->runStat72F2A4C = TESynC_Initialize_RunFunc_72F2A4C( (Boolean)(bRunToFinish && (nReady < 2)) );
								if (heap->runStat72F2A4C == eNotFinished) {
									runStat = eNotFinished;
								}
								else if (heap->runStat72F2A4C == eFail) {
									CGenErr();
								}
								else {
									InitSignalReady(8, 2);
								}
								if (runStat == eFinished) {
									continue;
								}
							}
						}
/* start q el struct (2 struct) */
						if ((heap->runStatE2FBE80 != eFinished)
						/*&& GetSignalReady( 0x5, 4)*//* s_Case_Structure_CT_7 */
						/*&& GetSignalReady( 0x5, 5)*//* s_ID_Query */
						/*&& GetSignalReady( 0x1, 3)*//* c_Case_Structure_CT_7 *//*) {*/
						&& GetSignalReady( 5 )) {
							if (pass == 0) {
								nReady++;
							}
							else {
								if (heap->runStatE2FBE80 == eReady) {
								}
								{
									ControlDataItemPtr cdPtr = LVGetCurrentControlData();
									if (heap->runStatE2FBE80 == eReady) {
										CreateArgListStatic(heap->ArgsE2FBE81, 3, 3 );
										argIn(heap->ArgsE2FBE81, 0).nType = StringDataType;
										argIn(heap->ArgsE2FBE81, 0).pValue = (void *)&heap->s_Case_Structure_CT_7;
										argIn(heap->ArgsE2FBE81, 1).nType = StringDataType;
										argIn(heap->ArgsE2FBE81, 1).pValue = (void *)&heap->s_ID_Query;
										argIn(heap->ArgsE2FBE81, 2).nType = 0x0 | ClusterDataType;
										argIn(heap->ArgsE2FBE81, 2).pValue = (void *)&heap->c_Case_Structure_CT_7;
										argOut(heap->ArgsE2FBE81, 0).nType = StringDataType;
										argOut(heap->ArgsE2FBE81, 0).pValue = (void *)&heap->s_TESynC_Visa_Read_vi_VISA_sess;
										argOut(heap->ArgsE2FBE81, 1).nType = StringDataType;
										argOut(heap->ArgsE2FBE81, 1).pValue = (void *)&heap->s_TESynC_Visa_Read_vi_read_buff;
										argOut(heap->ArgsE2FBE81, 2).nType = 0;
										argOut(heap->ArgsE2FBE81, 2).pValue = NULL;
									}
									if (!TESynC_Initialize_viInstanceHeapPtr->i0E2FBE80.callerID) {
										TESynC_Initialize_viInstanceHeapPtr->i0E2FBE80.callerID = ++gCallerID;
									}
									heap->runStatE2FBE80 = TESynC_Visa_Read_Run( &TESynC_Initialize_viInstanceHeapPtr->i0E2FBE80, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsE2FBE81)[0], (ArgList *)((ArgList **)heap->ArgsE2FBE81)[1], NULL );
									LVSetCurrentControlData(cdPtr);
									if (heap->runStatE2FBE80 == eNotFinished) {
										runStat = eNotFinished;
									}
									if (heap->runStatE2FBE80 == eFail || gLastError) {
										CGenErr();
									}
									if (gAppStop || (heap->runStatE2FBE80 == eFinished)) {
										/*SetSignalReady( 0x5, 6);*//* s_TESynC_Visa_Read_vi_VISA_sess */
										SetSignalReady(3, 1);
										/*SetSignalReady( 0x6, 0);*//* s_TESynC_Visa_Read_vi_read_buff */
										SetSignalReady(4, 1);
										PDAStrIncRefCnt(heap->s_TESynC_Visa_Read_vi_read_buff, (uInt16)1); /* Func call */
									}
									if (gAppStop) {
										gAppStop=true;/* opt bug fix*/
										return eFinished;
									}
								}
								if (heap->runStatE2FBE80 == eFinished) {
									InitSignalReady(5, 3);
									continue;
								}
							}
						}
/* start q el linear (2 struct) */
						if ((heap->runStat12C8D108 != eFinished)
						/*&& GetSignalReady( 0x6, 0)*//* s_TESynC_Visa_Read_vi_read_buff */
						/*&& GetSignalReady( 0x4, 7)*//* s_Constant *//*) {*/
						&& GetSignalReady( 4 )) {
							if (pass == 0) {
								nReady++;
							}
							else {
								{
									/**/
									/* Match Pattern */
									/**/
									{
										PDAStrLen_t ofstpst;
										if (!PDAStrMatchPattern(heap->s_Constant, heap->s_TESynC_Visa_Read_vi_read_buff, NULL, uCharDataType, (VoidHand *)NULL, (VoidHand *)NULL, (VoidHand *)NULL, &ofstpst)) {
											CGenErr();
										}
										heap->l_Match_Pattern_offset_past_mat = ofstpst;
									}
									/*SetSignalReady( 0x3, 7);*//* l_Match_Pattern_offset_past_mat */
									/**/
									/* Match Pattern */
									/**/
									{
										PDAStrLen_t ofstpst;
										if (!PDAStrMatchPattern(heap->s_Constant_1, heap->s_TESynC_Visa_Read_vi_read_buff, &(heap->l_Match_Pattern_offset_past_mat), int32DataType, (VoidHand *)NULL, (VoidHand *)NULL, (VoidHand *)NULL, &ofstpst)) {
											CGenErr();
										}
										heap->l_Match_Pattern_offset_past_mat_1 = ofstpst;
									}
									/*SetSignalReady( 0x4, 0);*//* l_Match_Pattern_offset_past_mat_1 */
									/**/
									/* Not Equal? */
									/**/
									heap->b_Not_Equal__x____y__1 =  (-1 != heap->l_Match_Pattern_offset_past_mat_1);
									/*SetSignalReady( 0xC, 7);*//* b_Not_Equal__x____y__1 */
									/**/
									/* Not Equal? */
									/**/
									heap->b_Not_Equal__x____y_ =  (-1 != heap->l_Match_Pattern_offset_past_mat);
									/*SetSignalReady( 0xD, 0);*//* b_Not_Equal__x____y_ */
									/* Begin CpdArith */
									heap->b_Compound_Arithmetic_result = heap->b_Not_Equal__x____y_ | heap->b_Not_Equal__x____y__1;
									heap->b_Compound_Arithmetic_result = heap->b_Compound_Arithmetic_result | heap->b_Case_Structure_CT;
									/*SetSignalReady( 0xC, 5);*//* b_Compound_Arithmetic_result */
									/* End CpdArith */
									/**/
									/* Select */
									/**/
									if (heap->b_Compound_Arithmetic_result) {
										MemMove( &heap->c_Select_s__t_f, &heap->c_Case_Structure_CT_8, sizeof( cl_00000 ) );
	/* Free Cluster */
										{
											cl_00000* cl_014 = (cl_00000*)&heap->c_Constant;
				if (cl_014->el_2 && --((PDAStrPtr)cl_014->el_2)->refcnt == 0 && !((PDAStrPtr)cl_014->el_2)->staticStr) {
												MemHandleFree( cl_014->el_2 );
											}
										}
									}
									else {
										MemMove( &heap->c_Select_s__t_f, &heap->c_Constant, sizeof( cl_00000 ) );
	/* Free Cluster */
										{
											cl_00000* cl_015 = (cl_00000*)&heap->c_Case_Structure_CT_8;
				if (cl_015->el_2 && --((PDAStrPtr)cl_015->el_2)->refcnt == 0 && !((PDAStrPtr)cl_015->el_2)->staticStr) {
												MemHandleFree( cl_015->el_2 );
											}
										}
									}
									/*SetSignalReady( 0x0, 5);*//* c_Select_s__t_f */
									SetSignalReady(3, 1);
								}
								heap->runStat12C8D108 = eFinished;
								InitSignalReady(4, 2);
								continue;
							}
						}
/* start q el linear (2 struct) */
						if ((heap->runStat10B92D6A != eFinished)
						/*&& GetSignalReady( 0x5, 6)*//* s_TESynC_Visa_Read_vi_VISA_sess */
						/*&& GetSignalReady( 0x0, 5)*//* c_Select_s__t_f *//*) {*/
						&& GetSignalReady( 3 )) {
							if (pass == 0) {
								nReady++;
							}
							else {
								{
									heap->s_VISA_resource_name = heap->s_TESynC_Visa_Read_vi_VISA_sess;
									/*SetSignalReady( 0x6, 7);*//* s_Case_Structure_CT_4 */
									MemMove( &heap->c_Case_Structure_CT_4, &heap->c_Select_s__t_f, sizeof( cl_00000 ) );
									/*SetSignalReady( 0x2, 0);*//* c_Case_Structure_CT_4 */
								}
								heap->runStat10B92D6A = eFinished;
								InitSignalReady(3, 2);
								continue;
							}
						}
					}
					if (pass) {
						if (runStat == eFinished) {
							bEndDiagram = true;
						}
						if (!bRunToFinish) {
							if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
								if (gAppStop) {
									return eFinished;
								}
								if (gLastError) {
									CGenErr();
								}
								if (!gAppStop && !gLastError) {
									return eNotFinished;
								}
							}
						}
					}
				} /* end for */
				if (bEndDiagram) break;
			} /* end while */
		} /* end case */
		/* begin case */
		else {
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					MemMove( &heap->c_Case_Structure_CT_6, &heap->c_Case_Structure_CT_5, sizeof( cl_00000 ) );
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_4, &heap->c_Case_Structure_CT_6, sizeof( cl_00000 ) );
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			nStep = 0;
		} /* end case */
		heap->runStat10B92D69 = eReady;
		heap->runStat12C8CF28 = eReady;
		heap->runStat72F2A4C = eReady;
		heap->runStatE2FBE80 = eReady;
		heap->runStat12C8D108 = eReady;
		heap->runStat10B92D6A = eReady;
		MemMove( &heap->c_Case_Structure_CT_2, &heap->c_Case_Structure_CT_4, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x2, 4);*//* c_Case_Structure_CT_2 */
		SetSignalReady(2, 1);
		/*SetSignalReady( 0x5, 7);*//* s_Case_Structure_CT_2 */
		SetSignalReady(2, 1);
	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72F4BCC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Initialize_RunFunc_72F4BCC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F4BCC == eReady) {
			heap->runStat10B938E9 = eReady;
			heap->runStat72F84CC = eReady;
			heap->runStat10B938EA = eReady;
			heap->runStat10B93969 = eReady;
			heap->runStat10B9396A = eReady;
			heap->b_Equal__x___y__CS = heap->b_Equal__x___y_;
			/*SetSignalReady( 0xD, 5);*//* b_Equal__x___y__CS */
			/*SetSignalReady( 0x4, 6);*//* s_Property_Node_reference_out_C */
			MemMove( &heap->c_Property_Node_error_out_CT, &heap->c_Property_Node_error_out, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x3, 0);*//* c_Property_Node_error_out_CT */
		}
		/* begin case */
		if ( heap->b_Equal__x___y__CS ) {
			static uInt16 nStep = 0;
			switch(nStep)
			/*********************************************************************************/
			/* Serial (Not GPIB) */
			/*********************************************************************************/
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					heap->b_TermChar_En = true;
					heap->dw_Serial_Settings_Baud_Rate = 19200;
					MemMove( &heap->c_Property_Node_error_out_CT_2, &heap->c_Property_Node_error_out_CT, sizeof( cl_00000 ) );
					heap->by_TermChar = 10;
					heap->i_Modem_DTR_State = 1;
					heap->i_Modem_RTS_State = 0;
					heap->n_ASRL_End_Out = 2;
					heap->n_Serial_Settings_Serial_Flow_C = 0;
					heap->n_Serial_Settings_Parity = 0;
					heap->n_Serial_Settings_Data_Bits = 8;
					heap->n_Serial_Settings_Stop_Bits = 10;
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 1 : {
					if (heap->runStat72F84CC == eReady) {
					}
/* Property node */
					{
						PropInfo props[10] = {
							{kSerial_Settings_Baud_Rate, &heap->dw_Serial_Settings_Baud_Rate, uInt32DataType},
							{kSerial_Settings_End_Mode_for_Writes, &heap->n_ASRL_End_Out, uInt16DataType},
							{kMessage_Based_Settings_Termination_Character_Enable, &heap->b_TermChar_En, BooleanDataType},
							{kMessage_Based_Settings_Termination_Character, &heap->by_TermChar, uCharDataType},
							{kSerial_Settings_Stop_Bits, &heap->n_Serial_Settings_Stop_Bits, uInt16DataType},
							{kSerial_Settings_Parity, &heap->n_Serial_Settings_Parity, uInt16DataType},
							{kSerial_Settings_Data_Bits, &heap->n_Serial_Settings_Data_Bits, uInt16DataType},
							{kSerial_Settings_Flow_Control, &heap->n_Serial_Settings_Serial_Flow_C, uInt16DataType},
							{kSerial_Settings_Modem_Line_Settings_Line_DTR_State, &heap->i_Modem_DTR_State, int16DataType},
							{kSerial_Settings_Modem_Line_Settings_Line_RTS_State, &heap->i_Modem_RTS_State, int16DataType}
						};
						if (!VisaSetProperties( heap->s_VISA_resource_name, &heap->s_VISA_resource_name, &heap->c_Property_Node_error_out_CT_2, &heap->c_Property_Node_error_out_1, props, 10)) {
							CGenErr();
						}
						heap->runStat72F84CC = eFinished;
					}
					if (heap->runStat72F84CC == eFinished) {
						heap->runStat72F84CC = eReady;
					}
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 2 : {
					MemMove( &heap->c_Case_Structure_CT_3, &heap->c_Property_Node_error_out_1, sizeof( cl_00000 ) );
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			static uInt16 nStep = 0;
			switch(nStep)
			/*********************************************************************************/
			/*  Communication */
			/*********************************************************************************/
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					MemMove( &heap->c_Property_Node_error_out_CT_1, &heap->c_Property_Node_error_out_CT, sizeof( cl_00000 ) );
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_3, &heap->c_Property_Node_error_out_CT_1, sizeof( cl_00000 ) );
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			nStep = 0;
		} /* end case */
		/*SetSignalReady( 0x7, 1);*//* s_Case_Structure_CT_1 */
		SetSignalReady(11, 1);
		MemMove( &heap->c_Case_Structure_CT_1, &heap->c_Case_Structure_CT_3, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x1, 6);*//* c_Case_Structure_CT_1 */
		SetSignalReady(11, 1);
	} /* end switch */
	return eFinished;
}


/****** Block diagram main entry point **********/


/*********************************************************************************/
/* Set Serial VISA Attributes & Place Meter in Remote Mode */
/* If GPIB do nothing */
/*********************************************************************************/
/*********************************************************************************/
/* Query Instrument ID */
/*********************************************************************************/
/*********************************************************************************/
/* Reset Instrument/ */
/* No Default Setup */
/*********************************************************************************/
/*********************************************************************************/
/* Open instrument */
/*********************************************************************************/
eRunStatus _TEXT_SECTION TESynC_Initialize_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION TESynC_Initialize_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	uInt32 id = LVGetTimerFlag();
	int16 pass, numStructs = 4;
	Boolean bEndDiagram = false;
	if (gRunStatus == eReady) {;
		heap->runStat1 = eReady;
		heap->runStat10B92D00 = eReady;
		heap->runStat72FE44C = eReady;
		heap->runStatE285820 = eReady;
		heap->runStat72F4BCC = eReady;
		heap->runStat72F234C = eReady;
		heap->runStat72FCA4C = eReady;
	}
	while (!gAppStop && !gLastError) {
		nReady = 0;
		runStat = eFinished;
		bEndDiagram = false;
		for (pass=0;pass<2;pass++) {
/* start q el linear (2 struct) */
			if ((heap->runStat1 != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					InitSignalReady(17, 5);
					/*InitSignalReady( 0xB, 4);*//* by_Message_Based_Settings_Termi */
					InitSignalReady(18, 2);
					/*InitSignalReady( 0x3, 3);*//* dw_access_mode */
					/*InitSignalReady( 0x0, 2);*//* c_VISA_Open_error_out */
					/*InitSignalReady( 0xE, 2);*//* b_duplicate_session__F_ */
					/*InitSignalReady( 0x4, 5);*//* s_VISA_resource_name */
					/*InitSignalReady( 0x4, 1);*//* s_VISA_Open_VISA_resource_name_ */
					/*InitSignalReady( 0x0, 6);*//* c_error_in__no_error_ */
					/*InitSignalReady( 0xE, 1);*//* b_Message_Based_Settings_Termin */
					/*InitSignalReady( 0x3, 4);*//* dw_Tmo_Value */
					InitSignalReady(16, 2);
					/*InitSignalReady( 0x7, 7);*//* n_Property_Node_Interface_Infor */
					InitSignalReady(15, 3);
					/*InitSignalReady( 0x6, 3);*//* s_Property_Node_reference_out */
					/*InitSignalReady( 0x6, 4);*//* s_Case_Structure_CT */
					/*InitSignalReady( 0x1, 4);*//* c_Case_Structure_CT */
					InitSignalReady(11, 2);
					/*InitSignalReady( 0x7, 1);*//* s_Case_Structure_CT_1 */
					/*InitSignalReady( 0x1, 6);*//* c_Case_Structure_CT_1 */
					/*InitSignalReady( 0x1, 7);*//* c_Property_Node_error_out */
					/*InitSignalReady( 0xE, 0);*//* b_Equal__x___y_ */
					/*InitSignalReady( 0x7, 3);*//* n_y */
					/*InitSignalReady( 0xD, 7);*//* b_Reset__T__Reset_ */
					/*InitSignalReady( 0xD, 6);*//* b_ID_Query__T__Check_ */
					InitSignalReady(2, 2);
					/*InitSignalReady( 0x2, 4);*//* c_Case_Structure_CT_2 */
					/*InitSignalReady( 0x5, 7);*//* s_Case_Structure_CT_2 */
				}
				else {
					{
						heap->dw_Tmo_Value = 250;
						/*SetSignalReady( 0x3, 4);*//* dw_Tmo_Value */
						SetSignalReady(17, 1);
						heap->n_y = 4;
						/*SetSignalReady( 0x7, 3);*//* n_y */
						SetSignalReady(16, 1);
						heap->b_Message_Based_Settings_Termin = true;
						/*SetSignalReady( 0xE, 1);*//* b_Message_Based_Settings_Termin */
						SetSignalReady(17, 1);
						heap->b_duplicate_session__F_ = true;
						/*SetSignalReady( 0xE, 2);*//* b_duplicate_session__F_ */
						SetSignalReady(18, 1);
						heap->dw_access_mode = 4;
						/*SetSignalReady( 0x3, 3);*//* dw_access_mode */
						SetSignalReady(18, 1);
						heap->by_Message_Based_Settings_Termi = 10;
						/*SetSignalReady( 0xB, 4);*//* by_Message_Based_Settings_Termi */
						SetSignalReady(17, 1);
					}
					heap->runStat1 = eFinished;
					continue;
				}
			}
/* start q el linear (2 struct) */
			if ((heap->runStat10B92D00 != eFinished)
			/*&& GetSignalReady( 0x3, 3)*//* dw_access_mode */
			/*&& GetSignalReady( 0xE, 2)*//* b_duplicate_session__F_ *//*) {*/
			&& GetSignalReady( 18 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					{
						MemMove( &heap->c_error_in__no_error_, ((ClusterControlData*)FPData(error_in__no_error___315119968_ctlid))->pVal, sizeof( cl_00000 ) );
						MemSet(((ClusterControlData*)FPData(error_in__no_error___315119968_ctlid))->pVal, sizeof( cl_00000 ), 0);
						/*SetSignalReady( 0x0, 6);*//* c_error_in__no_error_ */
						heap->s_VISA_resource_name = FPData(VISA_resource_name__315122080_ctlid);
						PDAStrIncRefCnt(heap->s_VISA_resource_name, (uInt16)1);
						/*SetSignalReady( 0x4, 5);*//* s_VISA_resource_name */
						/**/
						/* VISA Open */
						/**/
						if (!VisaOpen(heap->s_VISA_resource_name,  (VoidHand)NULL,  CharDataType,  &(heap->dw_access_mode),  uInt32DataType,  heap->b_duplicate_session__F_,  &(heap->c_error_in__no_error_),  &(heap->s_VISA_resource_name),  &(heap->c_VISA_Open_error_out) )) {
							CGenErr();
						}
						/*SetSignalReady( 0x0, 2);*//* c_VISA_Open_error_out */
						SetSignalReady(17, 1);
						/*SetSignalReady( 0x4, 1);*//* s_VISA_Open_VISA_resource_name_ */
						SetSignalReady(17, 1);
					}
					heap->runStat10B92D00 = eFinished;
					InitSignalReady(18, 2);
					continue;
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72FE44C != eFinished)
			/*&& GetSignalReady( 0x4, 1)*//* s_VISA_Open_VISA_resource_name_ */
			/*&& GetSignalReady( 0x0, 2)*//* c_VISA_Open_error_out */
			/*&& GetSignalReady( 0xE, 1)*//* b_Message_Based_Settings_Termin */
			/*&& GetSignalReady( 0xB, 4)*//* by_Message_Based_Settings_Termi */
			/*&& GetSignalReady( 0x3, 4)*//* dw_Tmo_Value *//*) {*/
			&& GetSignalReady( 17 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat72FE44C == eReady) {
					}
/* Property node */
					{
						PropInfo props[3] = {
							{kTermChar_En, &heap->b_Message_Based_Settings_Termin, BooleanDataType},
							{kTermChar, &heap->by_Message_Based_Settings_Termi, uCharDataType},
							{kGeneral_Settings_Timeout_Value, &heap->dw_Tmo_Value, uInt32DataType}
						};
						if (!VisaSetProperties( heap->s_VISA_resource_name, &heap->s_VISA_resource_name, &heap->c_VISA_Open_error_out, &heap->c_Property_Node_error_out, props, 3)) {
							CGenErr();
						}
						heap->runStat72FE44C = eFinished;
					}
					{
						PropInfo props[1] = {
							{kInterface_Information_Interface_Type, &heap->n_Property_Node_Interface_Infor, uInt16DataType}
						};
						if (!VisaGetProperties( heap->s_VISA_resource_name, &heap->s_VISA_resource_name, &heap->c_VISA_Open_error_out, &heap->c_Property_Node_error_out, props, 1)) {
							CGenErr();
						}
						heap->runStat72FE44C = eFinished;
					}
					/*SetSignalReady( 0x1, 7);*//* c_Property_Node_error_out */
					SetSignalReady(15, 1);
					/*SetSignalReady( 0x6, 3);*//* s_Property_Node_reference_out */
					SetSignalReady(15, 1);
					/*SetSignalReady( 0x7, 7);*//* n_Property_Node_Interface_Infor */
					SetSignalReady(16, 1);
					if (heap->runStat72FE44C == eFinished) {
						InitSignalReady(17, 5);
						continue;
					}
				}
			}
/* start q el linear (2 struct) */
			if ((heap->runStatE285820 != eFinished)
			/*&& GetSignalReady( 0x7, 3)*//* n_y */
			/*&& GetSignalReady( 0x7, 7)*//* n_Property_Node_Interface_Infor *//*) {*/
			&& GetSignalReady( 16 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					{
						/**/
						/* Equal? */
						/**/
						heap->b_Equal__x___y_ =  (heap->n_Property_Node_Interface_Infor == 4);
						/*SetSignalReady( 0xE, 0);*//* b_Equal__x___y_ */
						SetSignalReady(15, 1);
					}
					heap->runStatE285820 = eFinished;
					InitSignalReady(16, 2);
					continue;
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F4BCC != eFinished)
			/*&& GetSignalReady( 0xE, 0)*//* b_Equal__x___y_ */
			/*&& GetSignalReady( 0x6, 3)*//* s_Property_Node_reference_out */
			/*&& GetSignalReady( 0x1, 7)*//* c_Property_Node_error_out *//*) {*/
			&& GetSignalReady( 15 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					heap->runStat72F4BCC = TESynC_Initialize_RunFunc_72F4BCC( (Boolean)(bRunToFinish && (nReady < 2)) );
					if (heap->runStat72F4BCC == eNotFinished) {
						runStat = eNotFinished;
					}
					else if (heap->runStat72F4BCC == eFail) {
						CGenErr();
					}
					else {
						InitSignalReady(15, 3);
					}
					if (runStat == eFinished) {
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F234C != eFinished)
			/*&& GetSignalReady( 0x7, 1)*//* s_Case_Structure_CT_1 */
			/*&& GetSignalReady( 0x1, 6)*//* c_Case_Structure_CT_1 *//*) {*/
			&& GetSignalReady( 11 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					heap->runStat72F234C = TESynC_Initialize_RunFunc_72F234C( (Boolean)(bRunToFinish && (nReady < 2)) );
					if (heap->runStat72F234C == eNotFinished) {
						runStat = eNotFinished;
					}
					else if (heap->runStat72F234C == eFail) {
						CGenErr();
					}
					else {
						InitSignalReady(11, 2);
					}
					if (runStat == eFinished) {
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72FCA4C != eFinished)
			/*&& GetSignalReady( 0x2, 4)*//* c_Case_Structure_CT_2 */
			/*&& GetSignalReady( 0x5, 7)*//* s_Case_Structure_CT_2 *//*) {*/
			&& GetSignalReady( 2 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					heap->runStat72FCA4C = TESynC_Initialize_RunFunc_72FCA4C( (Boolean)(bRunToFinish && (nReady < 2)) );
					if (heap->runStat72FCA4C == eNotFinished) {
						runStat = eNotFinished;
					}
					else if (heap->runStat72FCA4C == eFail) {
						CGenErr();
					}
					else {
						InitSignalReady(2, 2);
					}
					if (runStat == eFinished) {
						continue;
					}
				}
			}
			if (pass == 1) bEndDiagram = true;
		}
		if (bEndDiagram &&runStat == eFinished) {
			heap->runStat1 = eReady;
			heap->runStat10B92D00 = eReady;
			heap->runStat72FE44C = eReady;
			heap->runStatE285820 = eReady;
			heap->runStat72F4BCC = eReady;
			heap->runStat72F234C = eReady;
			heap->runStat72FCA4C = eReady;
			break;
		}
		if (!bRunToFinish) {
			if (bEndDiagram) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		}
	}
	TESynC_Initialize_CleanupVIGlobalConstants();
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr TESynC_Initialize_VIName = "TESynC Initialize.vi";

static VIInfo _DATA_SECTION viInfo = {
	&TESynC_Initialize_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _TESynC_Initialize_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)76,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &TESynC_Initialize_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tTESynC_Initialize_viInstanceHeap),
	TESynC_Initialize_InitFPTerms,
	TESynC_Initialize_FrontPanelInit,
	TESynC_Initialize_BlockDiagram,
	TESynC_Initialize_DrawLabels,
	TESynC_Initialize_GetFPTerms,
	TESynC_Initialize_Cleanup,
	TESynC_Initialize_CleanupLSRs,
	TESynC_Initialize_AddSubVIInstanceData,
	TESynC_Initialize_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION TESynC_Initialize_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	return stat;
}


/****** End of generated code **********/


