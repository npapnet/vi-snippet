/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Initialize.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Public\Initialize.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 1;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snode72F6DCC = false;
static Boolean snode72FAD4C = false;
static Boolean snode72F704C = false;
struct _Watflow_F4_lvlib_Initialize_heap { 
	cl_00000 c_Select_s__t_f;
	cl_00000 c_Case_Structure_CT_5;
	cl_00000 c_Case_Structure_CT_6;
	cl_00000 c_Case_Structure_CT_7;
	cl_00000 c_Property_Node_error_out;
	cl_00000 c_error_in__no_error_;
	cl_00000 c_Constant;
	cl_00000 c_Utility_Read_From_Register_vi;
	cl_00000 c_Property_Node_error_out_CT_2;
	cl_00000 c_VISA_Open_error_out;
	cl_00000 c_Case_Structure_CT;
	cl_00000 c_Reset_vi_error_out;
	cl_00000 c_Close_vi_error_out;
	cl_00000 c_Case_Structure_CT_1;
	cl_00000 c_Case_Structure_CT_8;
	cl_00000 c_Property_Node_error_out_CT_1;
	cl_00000 c_Case_Structure_CT_11;
	cl_00000 c_Case_Structure_CT_2;
	cl_00000 c_Property_Node_error_out_CT;
	cl_00000 c_Case_Structure_CT_10;
	cl_00000 c_Case_Structure_CT_9;
	cl_00000 c_Case_Structure_CT_3;
	cl_00000 c_Case_Structure_CT_4;
	uInt32 dw_General_Settings_Timeout_Val;
	int32 l_index;
	VoidHand s_Case_Structure_CT_8;
	VoidHand s_Case_Structure_CT_3;
	VoidHand s_Case_Structure_CT_11;
	VoidHand s_Property_Node_reference_out_C_1;
	VoidHand s_Case_Structure_CT_2;
	VoidHand ArgsEC173B9;  
	VoidHand s_Utility_Read_From_Register_vi;
	VoidHand ArgsEC16C99;  
	VoidHand s_Case_Structure_CT;
	VoidHand s_Case_Structure_CT_1;
	VoidHand s_Reset_vi_VISA_resource_name_o;
	VoidHand s_Property_Node_reference_out__1;
	VoidHand s_VISA_Open_VISA_resource_name_;
	VoidHand s_Case_Structure_CT_10;
	VoidHand s_Property_Node_reference_out_C;
	VoidHand a_Utility_Read_From_Register_vi;
	VoidHand s_Case_Structure_CT_4;
	VoidHand s_VISA_resource_name;
	VoidHand s_Property_Node_reference_out;
	VoidHand s_Case_Structure_CT_7;
	VoidHand s_Case_Structure_CT_5;
	VoidHand ArgsEC17179;  
	VoidHand ArgsEC16699;  
	VoidHand s_Case_Structure_CT_6;
	VoidHand ArgsEC134A9;  
	VoidHand s_Case_Structure_CT_9;
	uInt16 n_x;
	uInt16 n_Register_Address;
	uInt16 n_Serial_Settings_Serial_End_Mo;
	int16 i_Index_Array_element;
	uInt8 runStat72FAD4C;  
	uInt8 runStatEC152B2;  
	uInt8 runStatEC152B1;  
	uInt8 runStatEC16578;  
	uInt8 runStatEC16698;  
	uInt8 runStatEC020F1;  
	uInt8 runStatEC020F2;  
	uInt8 runStatEC026B2;  
	uInt8 runStatEC026B1;  
	uInt8 by_Unit_Address__1__CT_1;
	uInt8 runStat72F704C;  
	uInt8 runStatEC16C98;  
	uInt8 by_Unit_Address__1_;
	uInt8 runStatEC020B1;  
	uInt8 runStatEC020B2;  
	uInt8 runStatEC173B8;  
	uInt8 runStatEC15332;  
	uInt8 runStat1;  
	uInt8 runStatEC17178;  
	uInt8 runStatEC15331;  
	uInt8 by_Unit_Address__1__CT;
	uInt8 runStatEC026F2;  
	uInt8 runStat72F6DCC;  
	uInt8 runStat72F2CCC;  
	uInt8 runStatEC17418;  
	uInt8 runStatEC026F1;  
	Boolean b_ID_Query__T__Check__CS;
	Boolean b_Reset__T__Reset__1;
	Boolean b_ID_Query__T__Check__1;
	Boolean b_Unbundle_By_Name_status;
	Boolean b_Unbundle_By_Name_status_CS;
	Boolean b_Equal__x___y_;
	Boolean b_Unbundle_By_Name_status_1;
	Boolean b_Or_x__or__y_;
	Boolean b_Reset__T__Reset__CS;
} _DATA_SECTION __Watflow_F4_lvlib_Initialize_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Initialize_signalsReadyTable[15];

static struct _Watflow_F4_lvlib_Initialize_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Initialize_heap; /* heap */

struct _tWatflow_F4_lvlib_Initialize_GlobalConstantsHeap {
	uInt8	refCnt;
	cl_00000	i0EC13DF8;
} _DATA_SECTION __Watflow_F4_lvlib_Initialize_GlobalConstantsHeap;
static struct _tWatflow_F4_lvlib_Initialize_GlobalConstantsHeap _DATA_SECTION *Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr = &__Watflow_F4_lvlib_Initialize_GlobalConstantsHeap;

struct _tWatflow_F4_lvlib_Initialize_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i0EC16698;
	subVIInstanceData	i0EC16C98;
	subVIInstanceData	i0EC17178;
} _DATA_SECTION __Watflow_F4_lvlib_Initialize_viInstanceHeap;
static struct _tWatflow_F4_lvlib_Initialize_viInstanceHeap _DATA_SECTION *Watflow_F4_lvlib_Initialize_viInstanceHeapPtr = &__Watflow_F4_lvlib_Initialize_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Initialize_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[15] = {2, 2, 2, 3, 1, 2, 2, 2, 2, 2, 2, 4, 2, 2, 4};
struct _g_string_3 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[327];
};
static struct _g_string_3 g_string_3 = { 
	0, 1, 325,
	_LVT("<ERR> WLF4 Initialize\012The ID Query failed.  This may mean that you selected the ")
	_LVT("wrong instrument or your instrument did not respond.  You may also be using a mo")
	_LVT("del that is not officially supported by this driver.  If you are sure that you h")
	_LVT("ave selected the correct instrument and it is responding, try disabling the ID Q")
	_LVT("uery.")
};

_DATA_SECTION static cl_00000 g_cluster_1 = { 
	1, -1074003951, &g_string_3.el_1
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

static ClusterControlData g_control_4 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_8 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static BooleanData g_control_9 = {
	true, false, false, true
};

static BooleanData g_control_10 = {
	true, false, false, true
};

static NumericData g_control_11 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2100UL
#define VISA_resource_name_out__236720192_ctlid 2100
#define error_in__no_error___275770672_ctlid 2101
#define error_out__275771824_ctlid 2102
#define VISA_resource_name__275772304_ctlid 2103
#define Reset__T__Reset___275772496_ctlid 2104
#define ID_Query__T__Check___275772688_ctlid 2105
#define Unit_Address__1___275773072_ctlid 2106
#define label275761368_ctlid 2107
#define N_CONTROLS 8L
#define gArrControlData Watflow_F4_lvlib_Initialize_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Initialize_gArrControlData[8] = {
	{ VISA_resource_name_out__236720192_ctlid, 0, NULL, StringDataType, nonui_control },
	{ error_in__no_error___275770672_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__275771824_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_resource_name__275772304_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Reset__T__Reset___275772496_ctlid, 0, NULL, VoidHandDataType, pushbutton_control },
	{ ID_Query__T__Check___275772688_ctlid, 0, NULL, VoidHandDataType, pushbutton_control },
	{ Unit_Address__1___275773072_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ label275761368_ctlid, 0, NULL, uCharDataType, nonui_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Initialize_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Initialize_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	FPData(VISA_resource_name_out__236720192_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb20);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__236720192_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,2,-18,157,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(error_in__no_error___275770672_ctlid) = ClusterControlDataCreateStatic(&g_control_4, GetControlDataPtr(), gFormID, error_in__no_error___275770672_ctlid, 1, 1, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 4 && argsIn->args[4].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___275770672_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[4].pValue, argsIn->args[4].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb21);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___275770672_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___275770672_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,1,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__275771824_ctlid) = ClusterControlDataCreateStatic(&g_control_8, GetControlDataPtr(), gFormID, error_out__275771824_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb23);
		}
		InitClusterControlFieldValue( FPData(error_out__275771824_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__275771824_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-2,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__275772304_ctlid);
			vhIn = *(VoidHand *)argsIn->args[0].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[0].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[0].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[0].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__275772304_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,2,-18,129,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(Reset__T__Reset___275772496_ctlid) = BooleanDataCreateStatic(&g_control_9, Reset__T__Reset___275772496_ctlid, (Boolean)0, (Boolean)1, (Boolean)true, (uInt8)1, (!version35)?std_button:std_button))){
		return false;
	}
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		{
			int32 lVal;
			nIdx = CalcControlOffset( gFormID, Reset__T__Reset___275772496_ctlid);
			lVal = LVPtrToLong( argsIn->args[3].pValue, argsIn->args[3].nType );
			if (!SetBooleanFieldValue( gArrControlData[nIdx].hValue, (Boolean)lVal )) {
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Reset__T__Reset___275772496_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Reset (T: Reset)"),16,-6,-18,105,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(ID_Query__T__Check___275772688_ctlid) = BooleanDataCreateStatic(&g_control_10, ID_Query__T__Check___275772688_ctlid, (Boolean)0, (Boolean)1, (Boolean)true, (uInt8)1, (!version35)?std_button:std_button))){
		return false;
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		{
			int32 lVal;
			nIdx = CalcControlOffset( gFormID, ID_Query__T__Check___275772688_ctlid);
			lVal = LVPtrToLong( argsIn->args[2].pValue, argsIn->args[2].nType );
			if (!SetBooleanFieldValue( gArrControlData[nIdx].hValue, (Boolean)lVal )) {
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	ID_Query__T__Check___275772688_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("ID Query (T: Check)"),19,-5,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	{uInt8 dVal = (uInt8)1 ;
		{
			static NumericInitialData numData = {
				Unit_Address__1___275773072_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Unit_Address__1___275773072_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_11, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Unit_Address__1___275773072_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[1].pValue, argsIn->args[1].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Unit_Address__1___275773072_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Unit Address (1)"),16,-13,-20,111,16,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	label275761368_ctlid,
	0,0,255,
	1,0,0,0,
	_LVT("\251 2005 National Instruments.  ALL RIGHTS RESERVED."),50,93,15,297,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Initialize_FrontPanelInit NULL
#define Watflow_F4_lvlib_Initialize_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Initialize_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Initialize_Cleanup(Boolean bShowFrontPanel){
PDAStrFree( FPData(VISA_resource_name_out__236720192_ctlid) );
	FPData(VISA_resource_name_out__236720192_ctlid) = NULL;
	if (FPData(error_in__no_error___275770672_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___275770672_ctlid), false );
	if (FPData(error_out__275771824_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__275771824_ctlid), false );
PDAStrFree( FPData(VISA_resource_name__275772304_ctlid) );
	FPData(VISA_resource_name__275772304_ctlid) = NULL;
	(void)BooleanFreeData( FPData(Reset__T__Reset___275772496_ctlid) );
	(void)BooleanFreeData( FPData(ID_Query__T__Check___275772688_ctlid) );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Initialize_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Initialize_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__236720192_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[0].pValue = GetControlHValue(nIdx);
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__275771824_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[1].pValue, argsOut->args[1].nType );
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Initialize_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Initialize_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Initialize_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Initialize_AddSubVIInstanceData(void) {
	if (Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->initialized) return;
	Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->initialized = TRUE;

	Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16698.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16698;
	Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16C98.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16C98;
	Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC17178.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC17178;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Initialize_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Initialize_AddVIGlobalConstants(void) {
	(Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->refCnt)++;
	if (Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->refCnt > 1) return;

	if ( !(((cl_00000*)&Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->i0EC13DF8)->el_2)) {
		{
			cl_00000* cl_002;
			cl_002 = (cl_00000*)&Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->i0EC13DF8;
			MemSet( cl_002, sizeof(cl_00000), 0 );
			cl_002->el_0 = true;
			cl_002->el_1 = -1074003951 ;
			cl_002->el_2 = PDAStrNewFromBufStatic(_LVT("<ERR> WLF4 Initialize\012The ID Query failed.  This may mean that you selected the wrong instrument or your instrument did not respond.  You may also be using a model that is not officially supported by this driver.  If you are sure that you have selected the correct instrument and it is responding, try disabling the ID Query."),(uInt32)325, g_staticArb27);
		}
	}
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Initialize_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Initialize_CleanupVIGlobalConstants(void) {
	if (Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->refCnt > 0) return;

	/* Free Cluster */
	{
		cl_00000* cl_003 = (cl_00000*)&Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->i0EC13DF8;
				if (cl_003->el_2 && --((PDAStrPtr)cl_003->el_2)->refcnt == 0 && !((PDAStrPtr)cl_003->el_2)->staticStr) {
			MemHandleFree( cl_003->el_2 );
		}
	}
	MemSet(Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr,sizeof(*(Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr)),0);
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Initialize_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Initialize_InitVIConstantList(void) {
	heap->c_Constant = Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->i0EC13DF8;
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_RunFunc_72F704C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_RunFunc_72F704C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F704C == eReady) {
			CCGDebugSynchSNode(&state, 6, 7, 1, &snode72F704C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatEC026B1 = eReady;
			heap->runStatEC17178 = eReady;
			heap->runStatEC026B2 = eReady;
			heap->runStatEC026F1 = eReady;
			heap->runStatEC026F2 = eReady;
			heap->b_Unbundle_By_Name_status_CS = heap->b_Unbundle_By_Name_status;
			/*SetSignalReady( 0xA, 5);*//* b_Unbundle_By_Name_status_CS */
			heap->s_Case_Structure_CT_8 = heap->s_Case_Structure_CT_1;
			/*SetSignalReady( 0x3, 1);*//* s_Case_Structure_CT_8 */
			MemMove( &heap->c_Case_Structure_CT_9, &heap->c_Case_Structure_CT, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x2, 4);*//* c_Case_Structure_CT_9 */
		}
		/* begin case */
		if ( heap->b_Unbundle_By_Name_status_CS ) {
			uInt32 diagramIdx = 20;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(1, 2);
					/*InitSignalReady( 0x2, 0);*//* c_Case_Structure_CT_11 */
					InitSignalReady(0, 2);
					/*InitSignalReady( 0x3, 3);*//* s_Case_Structure_CT_11 */
					/*InitSignalReady( 0x1, 4);*//* c_Close_vi_error_out */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->s_Case_Structure_CT_11 = heap->s_Case_Structure_CT_8;
					/*SetSignalReady( 0x3, 3);*//* s_Case_Structure_CT_11 */
					UpdateProbes(&state, debugOffset, 45 /*0xEC16FF8*/, (uChar*)&(heap->s_Case_Structure_CT_11)); /* assign */
					SetSignalReady(0, 1);
					SetSignalReady(1, 1);
					PDAStrIncRefCnt(heap->s_Case_Structure_CT_11, (uInt16)1); /* SelectTunnel */
					MemMove( &heap->c_Case_Structure_CT_11, &heap->c_Case_Structure_CT_9, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x2, 0);*//* c_Case_Structure_CT_11 */
					UpdateProbes(&state, debugOffset, 44 /*0xEC170B8*/, (uChar*)&(heap->c_Case_Structure_CT_11)); /* assign */
					SetSignalReady(1, 1);
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 1 : {
					if (heap->runStatEC17178 == eReady) {
					}
					CCGDebugSynchIUse(&state, 20, 21, 20, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Close.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStatEC17178 == eReady) {
							CreateArgListStatic(heap->ArgsEC17179, 2, 1 );
							argIn(heap->ArgsEC17179, 0).nType = StringDataType;
							argIn(heap->ArgsEC17179, 0).pValue = (void *)&heap->s_Case_Structure_CT_11;
							argIn(heap->ArgsEC17179, 1).nType = 0x0 | ClusterDataType;
							argIn(heap->ArgsEC17179, 1).pValue = (void *)&heap->c_Case_Structure_CT_11;
							argOut(heap->ArgsEC17179, 0).nType = 0x0 | ClusterDataType;
							argOut(heap->ArgsEC17179, 0).pValue = (void *)&heap->c_Close_vi_error_out;
						}
						if (!Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC17178.callerID) {
							Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC17178.callerID = ++gCallerID;
						}
						heap->runStatEC17178 = Watflow_F4_lvlib_Close_Run( &Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC17178, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsEC17179)[0], (ArgList *)((ArgList **)heap->ArgsEC17179)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 21, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStatEC17178 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStatEC17178 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStatEC17178 == eFinished)) {
							/*SetSignalReady( 0x1, 4);*//* c_Close_vi_error_out */
							UpdateProbes(&state, debugOffset, 46 /*0xEC16F98*/, (uChar*)&(heap->c_Close_vi_error_out)); /* assign */
							SetSignalReady(0, 1);
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (!bRunToFinish && (runStat == eNotFinished)) {
						return eNotFinished;
					}
					if (heap->runStatEC17178 == eFinished) {
						heap->runStatEC17178 = eReady;
					}
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 3 : {
					heap->s_Case_Structure_CT_9 = heap->s_Case_Structure_CT_11;
					/*SetSignalReady( 0x6, 2);*//* s_Case_Structure_CT_9 */
					MemMove( &heap->c_Case_Structure_CT_8, &heap->c_Close_vi_error_out, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 6);*//* c_Case_Structure_CT_8 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 21, 20, &snode72F704C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 19;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(2, 2);
					/*InitSignalReady( 0x2, 3);*//* c_Case_Structure_CT_10 */
					/*InitSignalReady( 0x4, 6);*//* s_Case_Structure_CT_10 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->s_Case_Structure_CT_10 = heap->s_Case_Structure_CT_8;
					/*SetSignalReady( 0x4, 6);*//* s_Case_Structure_CT_10 */
					UpdateProbes(&state, debugOffset, 43 /*0xEC17238*/, (uChar*)&(heap->s_Case_Structure_CT_10)); /* assign */
					SetSignalReady(2, 1);
					MemMove( &heap->c_Case_Structure_CT_10, &heap->c_Case_Structure_CT_9, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x2, 3);*//* c_Case_Structure_CT_10 */
					UpdateProbes(&state, debugOffset, 42 /*0xEC172F8*/, (uChar*)&(heap->c_Case_Structure_CT_10)); /* assign */
					SetSignalReady(2, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_8, &heap->c_Case_Structure_CT_10, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 6);*//* c_Case_Structure_CT_8 */
					heap->s_Case_Structure_CT_9 = heap->s_Case_Structure_CT_10;
					/*SetSignalReady( 0x6, 2);*//* s_Case_Structure_CT_9 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 19, 19, &snode72F704C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		MemMove( &heap->c_Case_Structure_CT_1, &heap->c_Case_Structure_CT_8, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x1, 5);*//* c_Case_Structure_CT_1 */
		UpdateProbes(&state, debugOffset, 14 /*0xEAF35A8*/, (uChar*)&(heap->c_Case_Structure_CT_1)); /* assign */
		heap->s_Case_Structure_CT_2 = heap->s_Case_Structure_CT_9;
		/*SetSignalReady( 0x3, 5);*//* s_Case_Structure_CT_2 */
		UpdateProbes(&state, debugOffset, 15 /*0xEB11320*/, (uChar*)&(heap->s_Case_Structure_CT_2)); /* assign */
		CCGDebugSynchAfterSNode(&state, &snode72F704C, 7, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	{
		if (!SetClusterControlFieldValue( FPData(error_out__275771824_ctlid), &heap->c_Case_Structure_CT_1, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, error_out__275771824_ctlid);
	if (FPData(VISA_resource_name_out__236720192_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__236720192_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__236720192_ctlid))->staticStr) {
		MemHandleFree( FPData(VISA_resource_name_out__236720192_ctlid) );
	}
	FPData(VISA_resource_name_out__236720192_ctlid)=PDAStrCopyOnModify(heap->s_Case_Structure_CT_2);
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__236720192_ctlid);
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_RunFunc_72FAD4C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_RunFunc_72FAD4C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72FAD4C == eReady) {
		if (!GetBooleanFieldValue( FPData(Reset__T__Reset___275772496_ctlid), &heap->b_Reset__T__Reset__1 )){
			CGenErr();
		}
		/*SetSignalReady( 0xA, 2);*//* b_Reset__T__Reset__1 */
		UpdateProbes(&state, debugOffset, 17 /*0xEB11200*/, (uChar*)&(heap->b_Reset__T__Reset__1)); /* assign */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72FAD4C == eReady) {
			CCGDebugSynchSNode(&state, 4, 5, 1, &snode72FAD4C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatEC020B1 = eReady;
			heap->runStatEC16C98 = eReady;
			heap->runStatEC020B2 = eReady;
			heap->runStatEC020F1 = eReady;
			heap->runStatEC020F2 = eReady;
			heap->b_Reset__T__Reset__CS = heap->b_Reset__T__Reset__1;
			/*SetSignalReady( 0xB, 1);*//* b_Reset__T__Reset__CS */
			MemMove( &heap->c_Case_Structure_CT_4, &heap->c_Case_Structure_CT_2, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x2, 6);*//* c_Case_Structure_CT_4 */
			heap->s_Case_Structure_CT_5 = heap->s_Case_Structure_CT;
			/*SetSignalReady( 0x5, 5);*//* s_Case_Structure_CT_5 */
		}
		/* begin case */
		if ( heap->b_Reset__T__Reset__CS ) {
			uInt32 diagramIdx = 17;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(6, 2);
					/*InitSignalReady( 0x5, 4);*//* s_Case_Structure_CT_7 */
					/*InitSignalReady( 0x0, 3);*//* c_Case_Structure_CT_7 */
					InitSignalReady(5, 2);
					/*InitSignalReady( 0x4, 3);*//* s_Reset_vi_VISA_resource_name_o */
					/*InitSignalReady( 0x1, 3);*//* c_Reset_vi_error_out */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					MemMove( &heap->c_Case_Structure_CT_7, &heap->c_Case_Structure_CT_4, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 3);*//* c_Case_Structure_CT_7 */
					UpdateProbes(&state, debugOffset, 39 /*0xEC16B18*/, (uChar*)&(heap->c_Case_Structure_CT_7)); /* assign */
					SetSignalReady(6, 1);
					heap->s_Case_Structure_CT_7 = heap->s_Case_Structure_CT_5;
					/*SetSignalReady( 0x5, 4);*//* s_Case_Structure_CT_7 */
					UpdateProbes(&state, debugOffset, 38 /*0xEC16BD8*/, (uChar*)&(heap->s_Case_Structure_CT_7)); /* assign */
					SetSignalReady(6, 1);
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 1 : {
					if (heap->runStatEC16C98 == eReady) {
					}
					CCGDebugSynchIUse(&state, 17, 18, 17, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Reset.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStatEC16C98 == eReady) {
							CreateArgListStatic(heap->ArgsEC16C99, 3, 2 );
							argIn(heap->ArgsEC16C99, 0).nType = StringDataType;
							argIn(heap->ArgsEC16C99, 0).pValue = (void *)&heap->s_Case_Structure_CT_7;
							argIn(heap->ArgsEC16C99, 1).nType = 0;
							argIn(heap->ArgsEC16C99, 1).pValue = NULL;
							argIn(heap->ArgsEC16C99, 2).nType = 0x0 | ClusterDataType;
							argIn(heap->ArgsEC16C99, 2).pValue = (void *)&heap->c_Case_Structure_CT_7;
							argOut(heap->ArgsEC16C99, 0).nType = StringDataType;
							argOut(heap->ArgsEC16C99, 0).pValue = (void *)&heap->s_Reset_vi_VISA_resource_name_o;
							argOut(heap->ArgsEC16C99, 1).nType = 0x0 | ClusterDataType;
							argOut(heap->ArgsEC16C99, 1).pValue = (void *)&heap->c_Reset_vi_error_out;
						}
						if (!Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16C98.callerID) {
							Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16C98.callerID = ++gCallerID;
						}
						heap->runStatEC16C98 = Watflow_F4_lvlib_Reset_Run( &Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16C98, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsEC16C99)[0], (ArgList *)((ArgList **)heap->ArgsEC16C99)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 18, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStatEC16C98 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStatEC16C98 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStatEC16C98 == eFinished)) {
							/*SetSignalReady( 0x4, 3);*//* s_Reset_vi_VISA_resource_name_o */
							UpdateProbes(&state, debugOffset, 40 /*0xEC16A58*/, (uChar*)&(heap->s_Reset_vi_VISA_resource_name_o)); /* assign */
							SetSignalReady(5, 1);
							/*SetSignalReady( 0x1, 3);*//* c_Reset_vi_error_out */
							UpdateProbes(&state, debugOffset, 41 /*0xEC16998*/, (uChar*)&(heap->c_Reset_vi_error_out)); /* assign */
							SetSignalReady(5, 1);
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (!bRunToFinish && (runStat == eNotFinished)) {
						return eNotFinished;
					}
					if (heap->runStatEC16C98 == eFinished) {
						heap->runStatEC16C98 = eReady;
					}
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 3 : {
					heap->s_Case_Structure_CT_4 = heap->s_Reset_vi_VISA_resource_name_o;
					/*SetSignalReady( 0x5, 1);*//* s_Case_Structure_CT_4 */
					MemMove( &heap->c_Case_Structure_CT_5, &heap->c_Reset_vi_error_out, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 1);*//* c_Case_Structure_CT_5 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 18, 17, &snode72FAD4C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 16;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(7, 2);
					/*InitSignalReady( 0x6, 0);*//* s_Case_Structure_CT_6 */
					/*InitSignalReady( 0x0, 2);*//* c_Case_Structure_CT_6 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					MemMove( &heap->c_Case_Structure_CT_6, &heap->c_Case_Structure_CT_4, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 2);*//* c_Case_Structure_CT_6 */
					UpdateProbes(&state, debugOffset, 37 /*0xEC16D58*/, (uChar*)&(heap->c_Case_Structure_CT_6)); /* assign */
					SetSignalReady(7, 1);
					heap->s_Case_Structure_CT_6 = heap->s_Case_Structure_CT_5;
					/*SetSignalReady( 0x6, 0);*//* s_Case_Structure_CT_6 */
					UpdateProbes(&state, debugOffset, 36 /*0xEC16E18*/, (uChar*)&(heap->s_Case_Structure_CT_6)); /* assign */
					SetSignalReady(7, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					heap->s_Case_Structure_CT_4 = heap->s_Case_Structure_CT_6;
					/*SetSignalReady( 0x5, 1);*//* s_Case_Structure_CT_4 */
					MemMove( &heap->c_Case_Structure_CT_5, &heap->c_Case_Structure_CT_6, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 1);*//* c_Case_Structure_CT_5 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 16, 16, &snode72FAD4C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		MemMove( &heap->c_Case_Structure_CT, &heap->c_Case_Structure_CT_5, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x1, 2);*//* c_Case_Structure_CT */
		UpdateProbes(&state, debugOffset, 11 /*0xEAF3728*/, (uChar*)&(heap->c_Case_Structure_CT)); /* assign */
		SetSignalReady(3, 1);
		SetSignalReady(4, 1);
		heap->s_Case_Structure_CT_1 = heap->s_Case_Structure_CT_4;
		/*SetSignalReady( 0x4, 2);*//* s_Case_Structure_CT_1 */
		UpdateProbes(&state, debugOffset, 12 /*0xEAF36C8*/, (uChar*)&(heap->s_Case_Structure_CT_1)); /* assign */
		SetSignalReady(3, 1);
		CCGDebugSynchAfterSNode(&state, &snode72FAD4C, 5, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	/* Cluster Inc Ref Count:  Select: sel tunnels*/
	{
		cl_00000* cl_004 = (cl_00000*)&heap->c_Case_Structure_CT;
		PDAStrIncRefCnt(cl_004->el_2, (uInt16)1); /* Select: sel tunnels */
	}
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_RunFunc_72F6DCC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_RunFunc_72F6DCC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72F6DCC == eReady) {
		if (!GetBooleanFieldValue( FPData(ID_Query__T__Check___275772688_ctlid), &heap->b_ID_Query__T__Check__1 )){
			CGenErr();
		}
		/*SetSignalReady( 0xA, 3);*//* b_ID_Query__T__Check__1 */
		UpdateProbes(&state, debugOffset, 16 /*0xEB11260*/, (uChar*)&(heap->b_ID_Query__T__Check__1)); /* assign */
		if (!GetNumericFieldValue( FPData(Unit_Address__1___275773072_ctlid), &heap->by_Unit_Address__1_, uCharDataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x8, 3);*//* by_Unit_Address__1_ */
		UpdateProbes(&state, debugOffset, 3 /*0xEAF3C08*/, (uChar*)&(heap->by_Unit_Address__1_)); /* assign */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F6DCC == eReady) {
			CCGDebugSynchSNode(&state, 3, 4, 1, &snode72F6DCC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatEC152B1 = eReady;
			heap->runStatEC16698 = eReady;
			heap->runStatEC16578 = eReady;
			heap->runStatEC152B2 = eReady;
			heap->runStatEC15331 = eReady;
			heap->runStatEC15332 = eReady;
			heap->b_ID_Query__T__Check__CS = heap->b_ID_Query__T__Check__1;
			/*SetSignalReady( 0xA, 1);*//* b_ID_Query__T__Check__CS */
			MemMove( &heap->c_Property_Node_error_out_CT, &heap->c_Property_Node_error_out, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x2, 2);*//* c_Property_Node_error_out_CT */
			heap->s_Property_Node_reference_out_C = heap->s_Property_Node_reference_out;
			/*SetSignalReady( 0x4, 7);*//* s_Property_Node_reference_out_C */
			heap->by_Unit_Address__1__CT = heap->by_Unit_Address__1_;
			/*SetSignalReady( 0x9, 3);*//* by_Unit_Address__1__CT */
		}
		/* begin case */
		if ( heap->b_ID_Query__T__Check__CS ) {
			uInt32 diagramIdx = 9;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(9, 2);
					/*InitSignalReady( 0x3, 7);*//* s_Utility_Read_From_Register_vi */
					/*InitSignalReady( 0xA, 6);*//* b_Equal__x___y_ */
					/*InitSignalReady( 0x6, 3);*//* n_x */
					/*InitSignalReady( 0x6, 6);*//* i_Index_Array_element */
					InitSignalReady(11, 4);
					/*InitSignalReady( 0x8, 0);*//* by_Unit_Address__1__CT_1 */
					/*InitSignalReady( 0x4, 4);*//* s_Property_Node_reference_out__1 */
					/*InitSignalReady( 0x1, 0);*//* c_Property_Node_error_out_CT_2 */
					/*InitSignalReady( 0x0, 7);*//* c_Utility_Read_From_Register_vi */
					InitSignalReady(10, 2);
					/*InitSignalReady( 0x3, 0);*//* l_index */
					/*InitSignalReady( 0x5, 0);*//* a_Utility_Read_From_Register_vi */
					/*InitSignalReady( 0x6, 4);*//* n_Register_Address */
					/*InitSignalReady( 0x0, 6);*//* c_Constant */
					/*InitSignalReady( 0xA, 7);*//* b_Unbundle_By_Name_status_1 */
					/*InitSignalReady( 0xB, 0);*//* b_Or_x__or__y_ */
					/*InitSignalReady( 0x0, 0);*//* c_Select_s__t_f */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->l_index = 0;
					/*SetSignalReady( 0x3, 0);*//* l_index */
					UpdateProbes(&state, debugOffset, 29 /*0xEC12608*/, (uChar*)&(heap->l_index)); /* assign */
					SetSignalReady(10, 1);
					/*SetSignalReady( 0x0, 6);*//* c_Constant */
					UpdateProbes(&state, debugOffset, 32 /*0xEAF4388*/, (uChar*)&(heap->c_Constant)); /* assign */
					/* Cluster Inc Ref Count:  BDConst - alloc type*/
					{
						cl_00000* cl_006 = (cl_00000*)&heap->c_Constant;
						PDAStrIncRefCnt(cl_006->el_2, (uInt16)1); /* BDConst - alloc type */
					}
					heap->n_Register_Address = 0;
					/*SetSignalReady( 0x6, 4);*//* n_Register_Address */
					UpdateProbes(&state, debugOffset, 31 /*0xEAF4448*/, (uChar*)&(heap->n_Register_Address)); /* assign */
					SetSignalReady(11, 1);
					MemMove( &heap->c_Property_Node_error_out_CT_2, &heap->c_Property_Node_error_out_CT, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 0);*//* c_Property_Node_error_out_CT_2 */
					UpdateProbes(&state, debugOffset, 27 /*0xEC126C8*/, (uChar*)&(heap->c_Property_Node_error_out_CT_2)); /* assign */
					SetSignalReady(11, 1);
					heap->s_Property_Node_reference_out__1 = heap->s_Property_Node_reference_out_C;
					/*SetSignalReady( 0x4, 4);*//* s_Property_Node_reference_out__1 */
					UpdateProbes(&state, debugOffset, 26 /*0xEC12788*/, (uChar*)&(heap->s_Property_Node_reference_out__1)); /* assign */
					SetSignalReady(11, 1);
					heap->by_Unit_Address__1__CT_1 = heap->by_Unit_Address__1__CT;
					/*SetSignalReady( 0x8, 0);*//* by_Unit_Address__1__CT_1 */
					UpdateProbes(&state, debugOffset, 25 /*0xEC127E8*/, (uChar*)&(heap->by_Unit_Address__1__CT_1)); /* assign */
					SetSignalReady(11, 1);
					heap->n_x = 5270;
					/*SetSignalReady( 0x6, 3);*//* n_x */
					UpdateProbes(&state, debugOffset, 23 /*0xEC128A8*/, (uChar*)&(heap->n_x)); /* assign */
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 1 : {
					if (heap->runStatEC16698 == eReady) {
					}
					CCGDebugSynchIUse(&state, 9, 10, 9, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility Read From Register.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStatEC16698 == eReady) {
							CreateArgListStatic(heap->ArgsEC16699, 5, 3 );
							argIn(heap->ArgsEC16699, 0).nType = uCharDataType;
							argIn(heap->ArgsEC16699, 0).pValue = (void *)&heap->by_Unit_Address__1__CT_1;
							argIn(heap->ArgsEC16699, 1).nType = 0x0 | ClusterDataType;
							argIn(heap->ArgsEC16699, 1).pValue = (void *)&heap->c_Property_Node_error_out_CT_2;
							argIn(heap->ArgsEC16699, 2).nType = 0;
							argIn(heap->ArgsEC16699, 2).pValue = NULL;
							argIn(heap->ArgsEC16699, 3).nType = uInt16DataType;
							argIn(heap->ArgsEC16699, 3).pValue = (void *)&heap->n_Register_Address;
							argIn(heap->ArgsEC16699, 4).nType = StringDataType;
							argIn(heap->ArgsEC16699, 4).pValue = (void *)&heap->s_Property_Node_reference_out__1;
							argOut(heap->ArgsEC16699, 0).nType = 0x0 | ClusterDataType;
							argOut(heap->ArgsEC16699, 0).pValue = (void *)&heap->c_Utility_Read_From_Register_vi;
							argOut(heap->ArgsEC16699, 1).nType = 0x20000 | ArrayDataType;
							argOut(heap->ArgsEC16699, 1).pValue = (void *)&heap->a_Utility_Read_From_Register_vi;
							argOut(heap->ArgsEC16699, 2).nType = StringDataType;
							argOut(heap->ArgsEC16699, 2).pValue = (void *)&heap->s_Utility_Read_From_Register_vi;
						}
						if (!Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16698.callerID) {
							Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16698.callerID = ++gCallerID;
						}
						heap->runStatEC16698 = Watflow_F4_lvlib_Utility_Read_From_Register_Run( &Watflow_F4_lvlib_Initialize_viInstanceHeapPtr->i0EC16698, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsEC16699)[0], (ArgList *)((ArgList **)heap->ArgsEC16699)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 10, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStatEC16698 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStatEC16698 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStatEC16698 == eFinished)) {
							/*SetSignalReady( 0x0, 7);*//* c_Utility_Read_From_Register_vi */
							UpdateProbes(&state, debugOffset, 28 /*0xEC12668*/, (uChar*)&(heap->c_Utility_Read_From_Register_vi)); /* assign */
							/*SetSignalReady( 0x5, 0);*//* a_Utility_Read_From_Register_vi */
							UpdateProbes(&state, debugOffset, 30 /*0xEAF44A8*/, (uChar*)&(heap->a_Utility_Read_From_Register_vi)); /* assign */
							SetSignalReady(10, 1);
							/*SetSignalReady( 0x3, 7);*//* s_Utility_Read_From_Register_vi */
							UpdateProbes(&state, debugOffset, 21 /*0xEC129C8*/, (uChar*)&(heap->s_Utility_Read_From_Register_vi)); /* assign */
							SetSignalReady(9, 1);
							/* Cluster Inc Ref Count:  Func call*/
							{
								cl_00000* cl_007 = (cl_00000*)&heap->c_Utility_Read_From_Register_vi;
								PDAStrIncRefCnt(cl_007->el_2, (uInt16)1); /* Func call */
							}
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (!bRunToFinish && (runStat == eNotFinished)) {
						return eNotFinished;
					}
					if (heap->runStatEC16698 == eFinished) {
						heap->runStatEC16698 = eReady;
					}
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 3 : {
					CCGDebugSynchNode(&state, 10, 11, 9, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{ /* Array Index 1D */
						heap->i_Index_Array_element = *(int16 *)NthElemFast(((PDAArrPtr)heap->a_Utility_Read_From_Register_vi), heap->l_index, 2);
						/*SetSignalReady( 0x6, 6);*//* i_Index_Array_element */
						UpdateProbes(&state, debugOffset, 24 /*0xEC12848*/, (uChar*)&(heap->i_Index_Array_element)); /* assign */
					}
	if (heap->a_Utility_Read_From_Register_vi){--((PDAArrPtr)heap->a_Utility_Read_From_Register_vi)->refcnt;}
					/**/
					/* Equal? */
					/**/
					CCGDebugSynchNode(&state, 11, 12, 9, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->b_Equal__x___y_ =  (heap->n_x == (uInt16)(heap->i_Index_Array_element));
					/*SetSignalReady( 0xA, 6);*//* b_Equal__x___y_ */
					UpdateProbes(&state, debugOffset, 22 /*0xEC12908*/, (uChar*)&(heap->b_Equal__x___y_)); /* assign */
					CCGDebugSynchNode(&state, 12, 13, 9, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
/* Unbundle by name */
					{
						cl_00000* cl_008 = (cl_00000*)&heap->c_Utility_Read_From_Register_vi;
						heap->b_Unbundle_By_Name_status_1 = cl_008->el_0;
						/*SetSignalReady( 0xA, 7);*//* b_Unbundle_By_Name_status_1 */
						UpdateProbes(&state, debugOffset, 33 /*0xEAF4328*/, (uChar*)&(heap->b_Unbundle_By_Name_status_1)); /* assign */
	/* Free Cluster */
						{
							cl_00000* cl_009 = (cl_00000*)&heap->c_Utility_Read_From_Register_vi;
				if (cl_009->el_2 && --((PDAStrPtr)cl_009->el_2)->refcnt == 0 && !((PDAStrPtr)cl_009->el_2)->staticStr) {
								MemHandleFree( cl_009->el_2 );
							}
						}
					}
					/**/
					/* Or */
					/**/
					CCGDebugSynchNode(&state, 13, 14, 9, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->b_Or_x__or__y_ =  (heap->b_Unbundle_By_Name_status_1 | heap->b_Equal__x___y_);
					/*SetSignalReady( 0xB, 0);*//* b_Or_x__or__y_ */
					UpdateProbes(&state, debugOffset, 34 /*0xEAF42C8*/, (uChar*)&(heap->b_Or_x__or__y_)); /* assign */
					/**/
					/* Select */
					/**/
					CCGDebugSynchNode(&state, 14, 15, 9, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (heap->b_Or_x__or__y_) {
						MemMove( &heap->c_Select_s__t_f, &heap->c_Utility_Read_From_Register_vi, sizeof( cl_00000 ) );
	/* Free Cluster */
						{
							cl_00000* cl_010 = (cl_00000*)&heap->c_Constant;
				if (cl_010->el_2 && --((PDAStrPtr)cl_010->el_2)->refcnt == 0 && !((PDAStrPtr)cl_010->el_2)->staticStr) {
								MemHandleFree( cl_010->el_2 );
							}
						}
					}
					else {
						MemMove( &heap->c_Select_s__t_f, &heap->c_Constant, sizeof( cl_00000 ) );
	/* Free Cluster */
						{
							cl_00000* cl_011 = (cl_00000*)&heap->c_Utility_Read_From_Register_vi;
				if (cl_011->el_2 && --((PDAStrPtr)cl_011->el_2)->refcnt == 0 && !((PDAStrPtr)cl_011->el_2)->staticStr) {
								MemHandleFree( cl_011->el_2 );
							}
						}
					}
					/*SetSignalReady( 0x0, 0);*//* c_Select_s__t_f */
					UpdateProbes(&state, debugOffset, 35 /*0xEAF4208*/, (uChar*)&(heap->c_Select_s__t_f)); /* assign */
					SetSignalReady(9, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 4 : {
					heap->s_Case_Structure_CT_3 = heap->s_Utility_Read_From_Register_vi;
					/*SetSignalReady( 0x3, 2);*//* s_Case_Structure_CT_3 */
					MemMove( &heap->c_Case_Structure_CT_3, &heap->c_Select_s__t_f, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x2, 5);*//* c_Case_Structure_CT_3 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 15, 9, &snode72F6DCC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 8;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(12, 2);
					/*InitSignalReady( 0x1, 7);*//* c_Property_Node_error_out_CT_1 */
					/*InitSignalReady( 0x3, 4);*//* s_Property_Node_reference_out_C_1 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					MemMove( &heap->c_Property_Node_error_out_CT_1, &heap->c_Property_Node_error_out_CT, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 7);*//* c_Property_Node_error_out_CT_1 */
					UpdateProbes(&state, debugOffset, 19 /*0xEC16818*/, (uChar*)&(heap->c_Property_Node_error_out_CT_1)); /* assign */
					SetSignalReady(12, 1);
					heap->s_Property_Node_reference_out_C_1 = heap->s_Property_Node_reference_out_C;
					/*SetSignalReady( 0x3, 4);*//* s_Property_Node_reference_out_C_1 */
					UpdateProbes(&state, debugOffset, 20 /*0xEC167B8*/, (uChar*)&(heap->s_Property_Node_reference_out_C_1)); /* assign */
					SetSignalReady(12, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					MemMove( &heap->c_Case_Structure_CT_3, &heap->c_Property_Node_error_out_CT_1, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x2, 5);*//* c_Case_Structure_CT_3 */
					heap->s_Case_Structure_CT_3 = heap->s_Property_Node_reference_out_C_1;
					/*SetSignalReady( 0x3, 2);*//* s_Case_Structure_CT_3 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 8, 8, &snode72F6DCC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		MemMove( &heap->c_Case_Structure_CT_2, &heap->c_Case_Structure_CT_3, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x2, 1);*//* c_Case_Structure_CT_2 */
		UpdateProbes(&state, debugOffset, 18 /*0xEB111A0*/, (uChar*)&(heap->c_Case_Structure_CT_2)); /* assign */
		SetSignalReady(8, 1);
		heap->s_Case_Structure_CT = heap->s_Case_Structure_CT_3;
		/*SetSignalReady( 0x4, 1);*//* s_Case_Structure_CT */
		UpdateProbes(&state, debugOffset, 2 /*0xEAF3CC8*/, (uChar*)&(heap->s_Case_Structure_CT)); /* assign */
		SetSignalReady(8, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F6DCC, 4, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}


/****** Block diagram main entry point **********/


/*********************************************************************************/
/* Close if Error */
/*********************************************************************************/
/*********************************************************************************/
/* Query ID and Device Type Registers */
/*********************************************************************************/
/*********************************************************************************/
/* Reset Instrument */
/*********************************************************************************/
/*********************************************************************************/
/* Open instrument */
/*********************************************************************************/
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	uInt32 id = LVGetTimerFlag();
	int16 pass, numStructs = 4;
	Boolean bEndDiagram = false;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {;
		heap->runStat1 = eReady;
		heap->runStatEC17418 = eReady;
		heap->runStat72F2CCC = eReady;
		heap->runStat72F6DCC = eReady;
		heap->runStat72FAD4C = eReady;
		heap->runStatEC173B8 = eReady;
		heap->runStat72F704C = eReady;
	}
	while (!gAppStop && !gLastError) {
		nReady = 0;
		runStat = eFinished;
		bEndDiagram = false;
		for (pass=0;pass<2;pass++) {
/* start q el linear (2 struct) */
			if ((heap->runStat1 != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					InitSignalReady(14, 4);
					/*InitSignalReady( 0x6, 5);*//* n_Serial_Settings_Serial_End_Mo */
					InitSignalReady(8, 2);
					/*InitSignalReady( 0x4, 1);*//* s_Case_Structure_CT */
					/*InitSignalReady( 0x8, 3);*//* by_Unit_Address__1_ */
					InitSignalReady(13, 2);
					/*InitSignalReady( 0x5, 3);*//* s_Property_Node_reference_out */
					/*InitSignalReady( 0x0, 4);*//* c_Property_Node_error_out */
					/*InitSignalReady( 0x0, 5);*//* c_error_in__no_error_ */
					/*InitSignalReady( 0x5, 2);*//* s_VISA_resource_name */
					/*InitSignalReady( 0x2, 7);*//* dw_General_Settings_Timeout_Val */
					/*InitSignalReady( 0x4, 5);*//* s_VISA_Open_VISA_resource_name_ */
					/*InitSignalReady( 0x1, 1);*//* c_VISA_Open_error_out */
					InitSignalReady(3, 3);
					InitSignalReady(4, 1);
					/*InitSignalReady( 0x1, 2);*//* c_Case_Structure_CT */
					/*InitSignalReady( 0x4, 2);*//* s_Case_Structure_CT_1 */
					/*InitSignalReady( 0xA, 4);*//* b_Unbundle_By_Name_status */
					/*InitSignalReady( 0x1, 5);*//* c_Case_Structure_CT_1 */
					/*InitSignalReady( 0x3, 5);*//* s_Case_Structure_CT_2 */
					/*InitSignalReady( 0xA, 3);*//* b_ID_Query__T__Check__1 */
					/*InitSignalReady( 0xA, 2);*//* b_Reset__T__Reset__1 */
					/*InitSignalReady( 0x2, 1);*//* c_Case_Structure_CT_2 */
				}
				else {
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					{
						heap->dw_General_Settings_Timeout_Val = 5000;
						/*SetSignalReady( 0x2, 7);*//* dw_General_Settings_Timeout_Val */
						UpdateProbes(&state, debugOffset, 8 /*0xEAF38A8*/, (uChar*)&(heap->dw_General_Settings_Timeout_Val)); /* assign */
						SetSignalReady(14, 1);
						heap->n_Serial_Settings_Serial_End_Mo = 0;
						/*SetSignalReady( 0x6, 5);*//* n_Serial_Settings_Serial_End_Mo */
						UpdateProbes(&state, debugOffset, 1 /*0xEAF3D28*/, (uChar*)&(heap->n_Serial_Settings_Serial_End_Mo)); /* assign */
						SetSignalReady(14, 1);
					}
					heap->runStat1 = eFinished;
					continue;
				}
			}
/* start q el linear (2 struct) */
			if ((heap->runStatEC17418 != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					nReady++;
				}
				else {
					{
						MemMove( &heap->c_error_in__no_error_, ((ClusterControlData*)FPData(error_in__no_error___275770672_ctlid))->pVal, sizeof( cl_00000 ) );
						MemSet(((ClusterControlData*)FPData(error_in__no_error___275770672_ctlid))->pVal, sizeof( cl_00000 ), 0);
						/*SetSignalReady( 0x0, 5);*//* c_error_in__no_error_ */
						UpdateProbes(&state, debugOffset, 6 /*0xEAF3A28*/, (uChar*)&(heap->c_error_in__no_error_)); /* assign */
						heap->s_VISA_resource_name = FPData(VISA_resource_name__275772304_ctlid);
						PDAStrIncRefCnt(heap->s_VISA_resource_name, (uInt16)1);
						/*SetSignalReady( 0x5, 2);*//* s_VISA_resource_name */
						UpdateProbes(&state, debugOffset, 7 /*0xEAF3968*/, (uChar*)&(heap->s_VISA_resource_name)); /* assign */
						/**/
						/* VISA Open */
						/**/
						CCGDebugSynchNode(&state, 1, 2, 1, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (!VisaOpen(heap->s_VISA_resource_name,  (VoidHand)NULL,  CharDataType,  (VoidHand)NULL,  CharDataType,  false,  &(heap->c_error_in__no_error_),  &(heap->s_VISA_Open_VISA_resource_name_),  &(heap->c_VISA_Open_error_out) )) {
							CGenErr();
						}
						/*SetSignalReady( 0x1, 1);*//* c_VISA_Open_error_out */
						UpdateProbes(&state, debugOffset, 10 /*0xEAF3788*/, (uChar*)&(heap->c_VISA_Open_error_out)); /* assign */
						SetSignalReady(14, 1);
						/*SetSignalReady( 0x4, 5);*//* s_VISA_Open_VISA_resource_name_ */
						UpdateProbes(&state, debugOffset, 9 /*0xEAF3848*/, (uChar*)&(heap->s_VISA_Open_VISA_resource_name_)); /* assign */
						SetSignalReady(14, 1);
					}
					heap->runStatEC17418 = eFinished;
					continue;
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F2CCC != eFinished)
			/*&& GetSignalReady( 0x4, 5)*//* s_VISA_Open_VISA_resource_name_ */
			/*&& GetSignalReady( 0x1, 1)*//* c_VISA_Open_error_out */
			/*&& GetSignalReady( 0x2, 7)*//* dw_General_Settings_Timeout_Val */
			/*&& GetSignalReady( 0x6, 5)*//* n_Serial_Settings_Serial_End_Mo *//*) {*/
			&& GetSignalReady( 14 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat72F2CCC == eReady) {
					}
					CCGDebugSynchNode(&state, 2, 3, 1, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
/* Property node */
					{
						PropInfo props[2] = {
							{kGeneral_Settings_Timeout_Value, &heap->dw_General_Settings_Timeout_Val, uInt32DataType},
							{kSerial_Settings_End_Mode_for_Reads, &heap->n_Serial_Settings_Serial_End_Mo, uInt16DataType}
						};
						if (!VisaSetProperties( heap->s_VISA_Open_VISA_resource_name_, &heap->s_Property_Node_reference_out, &heap->c_VISA_Open_error_out, &heap->c_Property_Node_error_out, props, 2)) {
							CGenErr();
						}
						heap->runStat72F2CCC = eFinished;
					}
					/*SetSignalReady( 0x0, 4);*//* c_Property_Node_error_out */
					UpdateProbes(&state, debugOffset, 5 /*0xEAF3AE8*/, (uChar*)&(heap->c_Property_Node_error_out)); /* assign */
					SetSignalReady(13, 1);
					/*SetSignalReady( 0x5, 3);*//* s_Property_Node_reference_out */
					UpdateProbes(&state, debugOffset, 4 /*0xEAF3B48*/, (uChar*)&(heap->s_Property_Node_reference_out)); /* assign */
					SetSignalReady(13, 1);
					if (heap->runStat72F2CCC == eFinished) {
						InitSignalReady(14, 4);
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F6DCC != eFinished)
			/*&& GetSignalReady( 0x0, 4)*//* c_Property_Node_error_out */
			/*&& GetSignalReady( 0x5, 3)*//* s_Property_Node_reference_out *//*) {*/
			&& GetSignalReady( 13 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					heap->runStat72F6DCC = Watflow_F4_lvlib_Initialize_RunFunc_72F6DCC( (Boolean)(bRunToFinish && (nReady < 2)) );
					if (heap->runStat72F6DCC == eNotFinished) {
						runStat = eNotFinished;
					}
					else if (heap->runStat72F6DCC == eFail) {
						CGenErr();
					}
					else {
						InitSignalReady(13, 2);
					}
					if (runStat == eFinished) {
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72FAD4C != eFinished)
			/*&& GetSignalReady( 0x2, 1)*//* c_Case_Structure_CT_2 */
			/*&& GetSignalReady( 0x4, 1)*//* s_Case_Structure_CT *//*) {*/
			&& GetSignalReady( 8 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					heap->runStat72FAD4C = Watflow_F4_lvlib_Initialize_RunFunc_72FAD4C( (Boolean)(bRunToFinish && (nReady < 2)) );
					if (heap->runStat72FAD4C == eNotFinished) {
						runStat = eNotFinished;
					}
					else if (heap->runStat72FAD4C == eFail) {
						CGenErr();
					}
					else {
						InitSignalReady(8, 2);
					}
					if (runStat == eFinished) {
						continue;
					}
				}
			}
/* start q el linear (2 struct) */
			if ((heap->runStatEC173B8 != eFinished)
			/*&& GetSignalReady( 0x1, 2)*//* c_Case_Structure_CT *//*) {*/
			&& GetSignalReady( 4 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					{
						CCGDebugSynchNode(&state, 5, 6, 1, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
/* Unbundle by name */
						{
							cl_00000* cl_012 = (cl_00000*)&heap->c_Case_Structure_CT;
							heap->b_Unbundle_By_Name_status = cl_012->el_0;
							/*SetSignalReady( 0xA, 4);*//* b_Unbundle_By_Name_status */
							UpdateProbes(&state, debugOffset, 13 /*0xEAF3608*/, (uChar*)&(heap->b_Unbundle_By_Name_status)); /* assign */
							SetSignalReady(3, 1);
	/* Free Cluster */
							{
								cl_00000* cl_013 = (cl_00000*)&heap->c_Case_Structure_CT;
				if (cl_013->el_2 && --((PDAStrPtr)cl_013->el_2)->refcnt == 0 && !((PDAStrPtr)cl_013->el_2)->staticStr) {
									MemHandleFree( cl_013->el_2 );
								}
							}
						}
					}
					heap->runStatEC173B8 = eFinished;
					InitSignalReady(4, 1);
					continue;
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F704C != eFinished)
			/*&& GetSignalReady( 0xA, 4)*//* b_Unbundle_By_Name_status */
			/*&& GetSignalReady( 0x4, 2)*//* s_Case_Structure_CT_1 */
			/*&& GetSignalReady( 0x1, 2)*//* c_Case_Structure_CT *//*) {*/
			&& GetSignalReady( 3 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					heap->runStat72F704C = Watflow_F4_lvlib_Initialize_RunFunc_72F704C( (Boolean)(bRunToFinish && (nReady < 2)) );
					if (heap->runStat72F704C == eNotFinished) {
						runStat = eNotFinished;
					}
					else if (heap->runStat72F704C == eFail) {
						CGenErr();
					}
					else {
						InitSignalReady(3, 3);
					}
					if (runStat == eFinished) {
						continue;
					}
				}
			}
			if (pass == 1) bEndDiagram = true;
		}
		if (bEndDiagram &&runStat == eFinished) {
			CCGDebugSynchSRN(&state, 7, 1, pauseCaller, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat1 = eReady;
			heap->runStatEC17418 = eReady;
			heap->runStat72F2CCC = eReady;
			heap->runStat72F6DCC = eReady;
			heap->runStat72FAD4C = eReady;
			heap->runStatEC173B8 = eReady;
			heap->runStat72F704C = eReady;
			break;
		}
		if (!bRunToFinish) {
			if (bEndDiagram) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		}
	}
	(Watflow_F4_lvlib_Initialize_GlobalConstantsHeapPtr->refCnt)--;
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Initialize_VIName = "Watflow F4.lvlib:Initialize.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Initialize_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Initialize_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)60,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &Watflow_F4_lvlib_Initialize_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tWatflow_F4_lvlib_Initialize_viInstanceHeap),
	Watflow_F4_lvlib_Initialize_InitFPTerms,
	Watflow_F4_lvlib_Initialize_FrontPanelInit,
	Watflow_F4_lvlib_Initialize_BlockDiagram,
	Watflow_F4_lvlib_Initialize_DrawLabels,
	Watflow_F4_lvlib_Initialize_GetFPTerms,
	Watflow_F4_lvlib_Initialize_Cleanup,
	Watflow_F4_lvlib_Initialize_CleanupLSRs,
	Watflow_F4_lvlib_Initialize_AddSubVIInstanceData,
	Watflow_F4_lvlib_Initialize_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Initialize_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


