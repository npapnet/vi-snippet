/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Utility MODBUS RTU CRC16.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Private\Utility MODBUS RTU CRC16.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 5;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snodeF851ADC = false;
static Boolean snodeF85015C = false;
static Boolean snode72F824C = false;
struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_heap { 
	cl_00000 c_error_in__no_error__4;
	int32 l_For_Loop_N_2;
	int32 l_For_Loop_N_3;
	int32 l_For_Loop_i_3;
	int32 l_Constant_5;
	int32 l_For_Loop_i_2;
	VoidHand a_Message__empty_array__LT;
	VoidHand s_VISA_resource_name_4;
	VoidHand a_Message__empty_array_;
	VoidHand a_Build_Array_appended_array_4;
	uInt16 n_Exclusive_Or_x__xor__y_;
	uInt16 n_16;
	uInt16 n_Case_Structure_SR;
	uInt16 n_Case_Structure_SR_2;
	uInt16 n_Join_Numbers__hi_lo__3;
	uInt16 n_Rotate_Right_With_Carry_valu_1;
	uInt16 n_Case_Structure_CT_1;
	uInt16 n_Rotate_Right_With_Carry_value_1;
	uInt16 n_16_SR;
	uInt16 n_y;
	uInt16 n_Join_Numbers__hi_lo__SR;
	uInt16 n_Rotate_Right_With_Carry_value;
	uInt16 n_Case_Structure_CT;
	uInt16 n_Rotate_Right_With_Carry_val_1;
	uInt16 n_Case_Structure_SR_1;
	uInt16 n_Case_Structure_SR_3;
	uInt8 runStatF85015C;  
	uInt8 runStat9B68EB8;  
	uInt8 runStat1;  
	uInt8 runStat9B68FD8;  
	uInt8 by_Message__empty_array__LT;
	uInt8 runStat9B68DF8;  
	uInt8 runStat72F824C;  
	uInt8 runStat9B6E002;  
	uInt8 by_Split_Number_lo_x__3;
	uInt8 by_Exclusive_Or_x__xor__y_;
	uInt8 by_Split_Number_hi_x__3;
	uInt8 runStat9B6DB81;  
	uInt8 runStat9B6DB82;  
	uInt8 runStatF851ADC;  
	uInt8 by_Split_Number_hi_x__2;
	uInt8 by_Split_Number_lo_x__2;
	uInt8 runStat9B68C78;  
	uInt8 runStat9B6DB41;  
	uInt8 runStat9B6DB42;  
	uInt8 runStat9B6DD81;  
	uInt8 runStat9B6DD82;  
	uInt8 runStat9B6E001;  
	uInt8 runStat2;  
	Boolean b_Rotate_Right_With_Carry_lsb_c;
	Boolean b_carry;
	Boolean b_Rotate_Right_With_Carry_lsb_c_1;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_signalsReadyTable[11];

static struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_heap; /* heap */

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[11] = {1, 1, 1, 1, 2, 1, 2, 2, 2, 1, 1};
struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_array_1 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_1 g_array_1 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_array_2 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_2 g_array_2 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

static NumericData g_control_1 = {
	0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ClusterControlData g_control_5 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_9 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_11 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_10 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ArrayControlData g_control_12 = {
	0, 0, true, 1, 0, 0
};

static NumericData g_control_14 = {
	0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_13 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ArrayControlData g_control_15 = {
	0, 0, true, 1, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2500UL
#define CRC__267727864_ctlid 2500
#define error_in__no_error___267729016_ctlid 2501
#define error_out__267734888_ctlid 2502
#define VISA_resource_name_out__267735368_ctlid 2503
#define VISA_resource_name__267735848_ctlid 2504
#define Message__empty_array___267736808_ctlid 2505
#define Message_with_CRC__267737864_ctlid 2506
#define N_CONTROLS 7L
#define gArrControlData Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_gArrControlData[7] = {
	{ CRC__267727864_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ error_in__no_error___267729016_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__267734888_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_resource_name_out__267735368_ctlid, 0, NULL, StringDataType, nonui_control },
	{ VISA_resource_name__267735848_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Message__empty_array___267736808_ctlid, 0, NULL, 0x100000 | ArrayDataType, array_control },
	{ Message_with_CRC__267737864_ctlid, 0, NULL, 0x100000 | ArrayDataType, array_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	{uInt16 dVal = (uInt16)0 ;
		{
			static NumericInitialData numData = {
				CRC__267727864_ctlid,
				0,
				0,
				66,
				uInt16DataType,
				0.0000000000000000000E+0,
				6.5535000000000000000E+4,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
			};
			if (!(FPData(CRC__267727864_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_1, &numData, &dVal))){
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	CRC__267727864_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("CRC"),3,-4,-20,24,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(error_in__no_error___267729016_ctlid) = ClusterControlDataCreateStatic(&g_control_5, GetControlDataPtr(), gFormID, error_in__no_error___267729016_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___267729016_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[0].pValue, argsIn->args[0].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb53);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___267729016_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___267729016_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,-1,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__267734888_ctlid) = ClusterControlDataCreateStatic(&g_control_9, GetControlDataPtr(), gFormID, error_out__267734888_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb55);
		}
		InitClusterControlFieldValue( FPData(error_out__267734888_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__267734888_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-2,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_resource_name_out__267735368_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb57);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__267735368_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-16,157,16,
	_LVT("0"),12,0,1000,0, false);
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__267735848_ctlid);
			vhIn = *(VoidHand *)argsIn->args[2].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[2].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[2].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[2].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__267735848_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,1,-16,129,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(Message__empty_array___267736808_ctlid) = NULL;
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		{
			VoidHand vhIn, vhOut;
			DataType dtIn, dtOut;
			nIdx = CalcControlOffset( gFormID, Message__empty_array___267736808_ctlid);
			FPDataType(Message__empty_array___267736808_ctlid) = 0x100000 | ArrayDataType;
			dtIn = argsIn->args[1].nType;
			vhIn = *(VoidHand *)argsIn->args[1].pValue;
			dtOut = gArrControlData[nIdx].dataType;
			vhOut = gArrControlData[nIdx].hValue;
			if (vhOut) {
				PDAArrFree(vhOut);
			}
			if (IsArray(dtIn)) {
				vhOut = PDAArrCopyOnModifyStatic( vhIn, &g_staticArray_18);
			}
			FPData(Message__empty_array___267736808_ctlid) = vhOut;
		}
	}
	else {
/* Declare array */
		{
			FPData(Message__empty_array___267736808_ctlid) = (void*)&g_array_1.el_1;
			NDims(((PDAArrPtr)&g_array_1.el_1)) = 1;
			((PDAArrPtr)&g_array_1.el_1)->datatype = uCharDataType;
			((PDAArrPtr)&g_array_1.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_1.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_1.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(Message__empty_array___267736808_ctlid) = ArrayControlDataCreateStatic(&g_control_12, FPData(Message__empty_array___267736808_ctlid), Message__empty_array___267736808_ctlid, 1, 0, 1, bShowFrontPanel, 1, 0x100000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Message__empty_array___267736808_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Message (empty array)"),21,-40,-18,136,16,
	_LVT("0"),12,0,0,0, false);
	FPData(Message_with_CRC__267737864_ctlid) = NULL;
	if(bShowFrontPanel) {
/* Declare array */
		{
			FPData(Message_with_CRC__267737864_ctlid) = (void*)&g_array_2.el_1;
			NDims(((PDAArrPtr)&g_array_2.el_1)) = 1;
			((PDAArrPtr)&g_array_2.el_1)->datatype = uCharDataType;
			((PDAArrPtr)&g_array_2.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_2.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_2.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(Message_with_CRC__267737864_ctlid) = ArrayControlDataCreateStatic(&g_control_15, FPData(Message_with_CRC__267737864_ctlid), Message_with_CRC__267737864_ctlid, 0, 0, 1, bShowFrontPanel, 1, 0x100000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Message_with_CRC__267737864_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Message with CRC"),16,-40,-18,115,16,
	_LVT("0"),12,0,1000,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_FrontPanelInit NULL
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_in__no_error___267729016_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___267729016_ctlid), false );
	if (FPData(error_out__267734888_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__267734888_ctlid), false );
PDAStrFree( FPData(VISA_resource_name_out__267735368_ctlid) );
	FPData(VISA_resource_name_out__267735368_ctlid) = NULL;
PDAStrFree( FPData(VISA_resource_name__267735848_ctlid) );
	FPData(VISA_resource_name__267735848_ctlid) = NULL;
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(Message__empty_array___267736808_ctlid), 1 );
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(Message_with_CRC__267737864_ctlid), 1 );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, CRC__267727864_ctlid);
		if (!GetNumericFieldValue(GetControlHValue(nIdx), argsOut->args[1].pValue, argsOut->args[1].nType )) {
			return false;
		}
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__267734888_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	if (argsOut->size > 3 && argsOut->args[3].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__267735368_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[3].pValue = GetControlHValue(nIdx);
	}
	if (argsOut->size > 2 && argsOut->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, Message_with_CRC__267737864_ctlid);
		GetArrayControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[2].pValue);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_AddSubVIInstanceData(void) {
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_InitVIConstantList(void) {
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_72F824C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_72F824C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F824C == eReady) {
			CCGDebugSynchSNode(&state, 11, 12, 10, &snode72F824C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat9B6DB41 = eReady;
			heap->runStat9B68C78 = eReady;
			heap->runStat9B6DB42 = eReady;
			heap->runStat9B6DB81 = eReady;
			heap->runStat9B6DB82 = eReady;
			heap->b_Rotate_Right_With_Carry_lsb_c_1 = heap->b_Rotate_Right_With_Carry_lsb_c;
			/*SetSignalReady( 0x6, 3);*//* b_Rotate_Right_With_Carry_lsb_c_1 */
			heap->n_Rotate_Right_With_Carry_value_1 = heap->n_Rotate_Right_With_Carry_value;
			/*SetSignalReady( 0x2, 1);*//* n_Rotate_Right_With_Carry_value_1 */
		}
		/* begin case */
		if ( heap->b_Rotate_Right_With_Carry_lsb_c_1 ) {
			uInt32 diagramIdx = 14;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(3, 1);
					/*InitSignalReady( 0x1, 2);*//* n_Exclusive_Or_x__xor__y_ */
					InitSignalReady(4, 2);
					/*InitSignalReady( 0x2, 3);*//* n_y */
					/*InitSignalReady( 0x2, 7);*//* n_Rotate_Right_With_Carry_val_1 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->n_Rotate_Right_With_Carry_val_1 = heap->n_Rotate_Right_With_Carry_value_1;
					/*SetSignalReady( 0x2, 7);*//* n_Rotate_Right_With_Carry_val_1 */
					UpdateProbes(&state, debugOffset, 25 /*0x9B68918*/, (uChar*)&(heap->n_Rotate_Right_With_Carry_val_1)); /* assign */
					SetSignalReady(4, 1);
					heap->n_y = 40961;
					/*SetSignalReady( 0x2, 3);*//* n_y */
					UpdateProbes(&state, debugOffset, 24 /*0x9B689D8*/, (uChar*)&(heap->n_y)); /* assign */
					SetSignalReady(4, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					/**/
					/* Exclusive Or */
					/**/
					CCGDebugSynchNode(&state, 14, 15, 14, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->n_Exclusive_Or_x__xor__y_ =  (heap->n_Rotate_Right_With_Carry_val_1 ^ heap->n_y);
					/*SetSignalReady( 0x1, 2);*//* n_Exclusive_Or_x__xor__y_ */
					UpdateProbes(&state, debugOffset, 23 /*0x9B68A38*/, (uChar*)&(heap->n_Exclusive_Or_x__xor__y_)); /* assign */
					SetSignalReady(3, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 2 : {
					heap->n_Case_Structure_CT_1 = heap->n_Exclusive_Or_x__xor__y_;
					/*SetSignalReady( 0x2, 0);*//* n_Case_Structure_CT_1 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 15, 14, &snode72F824C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 13;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(5, 1);
					/*InitSignalReady( 0x1, 7);*//* n_Rotate_Right_With_Carry_valu_1 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->n_Rotate_Right_With_Carry_valu_1 = heap->n_Rotate_Right_With_Carry_value_1;
					/*SetSignalReady( 0x1, 7);*//* n_Rotate_Right_With_Carry_valu_1 */
					UpdateProbes(&state, debugOffset, 22 /*0x9B68D38*/, (uChar*)&(heap->n_Rotate_Right_With_Carry_valu_1)); /* assign */
					SetSignalReady(5, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					heap->n_Case_Structure_CT_1 = heap->n_Rotate_Right_With_Carry_valu_1;
					/*SetSignalReady( 0x2, 0);*//* n_Case_Structure_CT_1 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 13, 13, &snode72F824C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		heap->n_Case_Structure_CT = heap->n_Case_Structure_CT_1;
		/*SetSignalReady( 0x2, 6);*//* n_Case_Structure_CT */
		UpdateProbes(&state, debugOffset, 17 /*0x9B68678*/, (uChar*)&(heap->n_Case_Structure_CT)); /* assign */
		SetSignalReady(2, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F824C, 12, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_F85015C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_F85015C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* for loop */
		uInt32 id = LVGetTimerFlag();
		static uInt16 nStep = 0;
		uInt32 diagramIdx = 10;
		if (heap->runStatF85015C == eReady) {
			CCGDebugSynchSNode(&state, 8, 9, 5, &snodeF85015C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->l_For_Loop_N_3 = heap->l_Constant_5;
			heap->n_Case_Structure_SR_3 = heap->n_Join_Numbers__hi_lo__3;
			/*SetSignalReady( 0x3, 1);*//* n_Case_Structure_SR_3 */
			heap->l_For_Loop_i_3 = 0;
		}
		while (!gAppStop && !gLastError) {
			if (heap->l_For_Loop_i_3 < heap->l_For_Loop_N_3) {
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(2, 1);
						/*InitSignalReady( 0x2, 6);*//* n_Case_Structure_CT */
						InitSignalReady(6, 2);
						/*InitSignalReady( 0x2, 5);*//* n_Rotate_Right_With_Carry_value */
						/*InitSignalReady( 0x6, 1);*//* b_Rotate_Right_With_Carry_lsb_c */
						InitSignalReady(7, 2);
						/*InitSignalReady( 0x6, 2);*//* b_carry */
						/*InitSignalReady( 0x2, 4);*//* n_Join_Numbers__hi_lo__SR */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->n_Join_Numbers__hi_lo__SR = heap->n_Case_Structure_SR_3;
						/*SetSignalReady( 0x2, 4);*//* n_Join_Numbers__hi_lo__SR */
						UpdateProbes(&state, debugOffset, 21 /*0x9B683D8*/, (uChar*)&(heap->n_Join_Numbers__hi_lo__SR)); /* assign */
						SetSignalReady(7, 1);
						heap->b_carry = false;
						/*SetSignalReady( 0x6, 2);*//* b_carry */
						UpdateProbes(&state, debugOffset, 20 /*0x9B68438*/, (uChar*)&(heap->b_carry)); /* assign */
						SetSignalReady(7, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						/**/
						/* Rotate Right With Carry */
						/**/
						CCGDebugSynchNode(&state, 10, 11, 10, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						PDARoxR( &(heap->n_Join_Numbers__hi_lo__SR), uInt16DataType, heap->b_carry, &(heap->n_Rotate_Right_With_Carry_value), &(heap->b_Rotate_Right_With_Carry_lsb_c) );
						/*SetSignalReady( 0x2, 5);*//* n_Rotate_Right_With_Carry_value */
						UpdateProbes(&state, debugOffset, 18 /*0x9B685B8*/, (uChar*)&(heap->n_Rotate_Right_With_Carry_value)); /* assign */
						SetSignalReady(6, 1);
						/*SetSignalReady( 0x6, 1);*//* b_Rotate_Right_With_Carry_lsb_c */
						UpdateProbes(&state, debugOffset, 19 /*0x9B684F8*/, (uChar*)&(heap->b_Rotate_Right_With_Carry_lsb_c)); /* assign */
						SetSignalReady(6, 1);
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 2 : {
						heap->runStat72F824C = Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_72F824C( bRunToFinish  );
						if (heap->runStat72F824C == eNotFinished) {
							return eNotFinished;
						}
						else if (heap->runStat72F824C == eFail) {
							CGenErr();
						}
						heap->runStat72F824C = eReady;
						nStep++; }
/* start q el linear (0 or 1 struct) */
					case 3 : {
						heap->n_Case_Structure_SR_3 = heap->n_Case_Structure_CT;
						/*SetSignalReady( 0x3, 1);*//* n_Case_Structure_SR_3 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 12, 10, &snodeF85015C, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep=0;
			}
			(heap->l_For_Loop_i_3)++;
			if (heap->l_For_Loop_i_3 >= heap->l_For_Loop_N_3) {
				heap->n_Case_Structure_SR_2 = heap->n_Case_Structure_SR_3;
				/*SetSignalReady( 0x1, 5);*//* n_Case_Structure_SR_2 */
				UpdateProbes(&state, debugOffset, 9 /*0x9391F50*/, (uChar*)&(heap->n_Case_Structure_SR_2)); /* assign */
				SetSignalReady(1, 1);
				break;
			}
			if (!bRunToFinish) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		} /* end while */
	} /* end for loop */
	CCGDebugSynchAfterSNode(&state, &snodeF85015C, 9, debugOffset);
	if(gAppStop) {
		gAppStop = true;
		return eFinished;
	}

	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_F851ADC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_F851ADC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStatF851ADC == eReady) {
		heap->a_Message__empty_array_ = ((ArrayControlData*)FPData(Message__empty_array___267736808_ctlid))->hValue;
		((ArrayControlData*)FPData(Message__empty_array___267736808_ctlid))->hValue = NULL;
		/*SetSignalReady( 0x1, 0);*//* a_Message__empty_array_ */
		UpdateProbes(&state, debugOffset, 1 /*0x9391890*/, (uChar*)&(heap->a_Message__empty_array_)); /* assign */
		PDAArrIncRefCnt(heap->a_Message__empty_array_, (uInt16)1); /* FPTerm */
	}
	{ /* for loop */
		uInt32 id = LVGetTimerFlag();
		static uInt16 nStep = 0;
		uInt32 diagramIdx = 5;
		if (heap->runStatF851ADC == eReady) {
			CCGDebugSynchSNode(&state, 1, 2, 1, &snodeF851ADC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->l_For_Loop_N_2 = MaxArrDimSize;
			heap->l_For_Loop_N_2 = LVMIN(heap->l_For_Loop_N_2, ( heap->a_Message__empty_array_ ? FirstDim( heap->a_Message__empty_array_ ) : 0 ));
			heap->a_Message__empty_array__LT = heap->a_Message__empty_array_;
			/*SetSignalReady( 0x0, 6);*//* a_Message__empty_array__LT */
			heap->n_Case_Structure_SR_1 = heap->n_16;
			/*SetSignalReady( 0x3, 0);*//* n_Case_Structure_SR_1 */
			heap->l_For_Loop_i_2 = 0;
		}
		while (!gAppStop && !gLastError) {
			if (heap->l_For_Loop_i_2 < heap->l_For_Loop_N_2) {
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(1, 1);
						/*InitSignalReady( 0x1, 5);*//* n_Case_Structure_SR_2 */
						InitSignalReady(8, 2);
						/*InitSignalReady( 0x1, 6);*//* n_Join_Numbers__hi_lo__3 */
						/*InitSignalReady( 0x4, 4);*//* by_Split_Number_hi_x__3 */
						/*InitSignalReady( 0x4, 3);*//* by_Exclusive_Or_x__xor__y_ */
						/*InitSignalReady( 0x4, 2);*//* by_Split_Number_lo_x__3 */
						InitSignalReady(9, 1);
						/*InitSignalReady( 0x2, 2);*//* n_16_SR */
						/*InitSignalReady( 0x0, 4);*//* l_Constant_5 */
						/*InitSignalReady( 0x3, 6);*//* by_Message__empty_array__LT */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						{ /* Array Index 1D */
							heap->by_Message__empty_array__LT = *(uChar *)NthElemFast(((PDAArrPtr)heap->a_Message__empty_array__LT), heap->l_For_Loop_i_2, 1);
							/*SetSignalReady( 0x3, 6);*//* by_Message__empty_array__LT */
							UpdateProbes(&state, debugOffset, 16 /*0x9391B90*/, (uChar*)&(heap->by_Message__empty_array__LT)); /* assign */
						}
						heap->l_Constant_5 = 8;
						/*SetSignalReady( 0x0, 4);*//* l_Constant_5 */
						UpdateProbes(&state, debugOffset, 15 /*0x9391C50*/, (uChar*)&(heap->l_Constant_5)); /* assign */
						SetSignalReady(8, 1);
						heap->n_16_SR = heap->n_Case_Structure_SR_1;
						/*SetSignalReady( 0x2, 2);*//* n_16_SR */
						UpdateProbes(&state, debugOffset, 14 /*0x9391D10*/, (uChar*)&(heap->n_16_SR)); /* assign */
						SetSignalReady(9, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						/**/
						/* Split Number */
						/**/
						CCGDebugSynchNode(&state, 5, 6, 5, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						PDASplit( &(heap->n_16_SR), uInt16DataType, &(heap->by_Split_Number_hi_x__3), &(heap->by_Split_Number_lo_x__3) );
						/*SetSignalReady( 0x4, 4);*//* by_Split_Number_hi_x__3 */
						UpdateProbes(&state, debugOffset, 11 /*0x9391E90*/, (uChar*)&(heap->by_Split_Number_hi_x__3)); /* assign */
						/*SetSignalReady( 0x4, 2);*//* by_Split_Number_lo_x__3 */
						UpdateProbes(&state, debugOffset, 13 /*0x9391D70*/, (uChar*)&(heap->by_Split_Number_lo_x__3)); /* assign */
						/**/
						/* Exclusive Or */
						/**/
						CCGDebugSynchNode(&state, 6, 7, 5, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						heap->by_Exclusive_Or_x__xor__y_ =  (heap->by_Message__empty_array__LT ^ heap->by_Split_Number_lo_x__3);
						/*SetSignalReady( 0x4, 3);*//* by_Exclusive_Or_x__xor__y_ */
						UpdateProbes(&state, debugOffset, 12 /*0x9391DD0*/, (uChar*)&(heap->by_Exclusive_Or_x__xor__y_)); /* assign */
						/**/
						/* Join Numbers */
						/**/
						CCGDebugSynchNode(&state, 7, 8, 5, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						PDAJoin( &(heap->by_Split_Number_hi_x__3), uCharDataType, &(heap->by_Exclusive_Or_x__xor__y_), uCharDataType, &(heap->n_Join_Numbers__hi_lo__3) );
						/*SetSignalReady( 0x1, 6);*//* n_Join_Numbers__hi_lo__3 */
						UpdateProbes(&state, debugOffset, 10 /*0x9391EF0*/, (uChar*)&(heap->n_Join_Numbers__hi_lo__3)); /* assign */
						SetSignalReady(8, 1);
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 2 : {
						heap->runStatF85015C = Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_F85015C( bRunToFinish  );
						if (heap->runStatF85015C == eNotFinished) {
							return eNotFinished;
						}
						else if (heap->runStatF85015C == eFail) {
							CGenErr();
						}
						heap->runStatF85015C = eReady;
						nStep++; }
/* start q el linear (0 or 1 struct) */
					case 3 : {
						heap->n_Case_Structure_SR_1 = heap->n_Case_Structure_SR_2;
						/*SetSignalReady( 0x3, 0);*//* n_Case_Structure_SR_1 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 9, 5, &snodeF851ADC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep=0;
			}
			(heap->l_For_Loop_i_2)++;
			if (heap->l_For_Loop_i_2 >= heap->l_For_Loop_N_2) {
				heap->n_Case_Structure_SR = heap->n_Case_Structure_SR_1;
				/*SetSignalReady( 0x1, 4);*//* n_Case_Structure_SR */
				UpdateProbes(&state, debugOffset, 6 /*0x9391650*/, (uChar*)&(heap->n_Case_Structure_SR)); /* assign */
				SetSignalReady(0, 1);
				/* FreeLoopInputs. */
	if (heap->a_Message__empty_array__LT){--((PDAArrPtr)heap->a_Message__empty_array__LT)->refcnt;}
				break;
			}
			if (!bRunToFinish) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		} /* end while */
	} /* end for loop */
	CCGDebugSynchAfterSNode(&state, &snodeF851ADC, 2, debugOffset);
	if(gAppStop) {
		gAppStop = true;
		return eFinished;
	}

	{
		if (!SetNumericFieldValue( FPData(CRC__267727864_ctlid), &heap->n_Case_Structure_SR, uInt16DataType )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, CRC__267727864_ctlid);
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			/*InitSignalReady( 0x1, 0);*//* a_Message__empty_array_ */
			/*InitSignalReady( 0x0, 7);*//* s_VISA_resource_name_4 */
			/*InitSignalReady( 0x1, 1);*//* a_Build_Array_appended_array_4 */
			/*InitSignalReady( 0x5, 1);*//* by_Split_Number_lo_x__2 */
			/*InitSignalReady( 0x5, 0);*//* by_Split_Number_hi_x__2 */
			InitSignalReady(0, 1);
			/*InitSignalReady( 0x1, 4);*//* n_Case_Structure_SR */
			/*InitSignalReady( 0x0, 0);*//* c_error_in__no_error__4 */
			InitSignalReady(10, 1);
			/*InitSignalReady( 0x1, 3);*//* n_16 */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			heap->n_16 = 65535;
			/*SetSignalReady( 0x1, 3);*//* n_16 */
			UpdateProbes(&state, debugOffset, 8 /*0x9391530*/, (uChar*)&(heap->n_16)); /* assign */
			SetSignalReady(10, 1);
			MemMove( &heap->c_error_in__no_error__4, ((ClusterControlData*)FPData(error_in__no_error___267729016_ctlid))->pVal, sizeof( cl_00000 ) );
			MemSet(((ClusterControlData*)FPData(error_in__no_error___267729016_ctlid))->pVal, sizeof( cl_00000 ), 0);
			/*SetSignalReady( 0x0, 0);*//* c_error_in__no_error__4 */
			UpdateProbes(&state, debugOffset, 7 /*0x93915F0*/, (uChar*)&(heap->c_error_in__no_error__4)); /* assign */
			heap->s_VISA_resource_name_4 = FPData(VISA_resource_name__267735848_ctlid);
			PDAStrIncRefCnt(heap->s_VISA_resource_name_4, (uInt16)1);
			/*SetSignalReady( 0x0, 7);*//* s_VISA_resource_name_4 */
			UpdateProbes(&state, debugOffset, 2 /*0x9391830*/, (uChar*)&(heap->s_VISA_resource_name_4)); /* assign */
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStatF851ADC = Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_RunFunc_F851ADC( bRunToFinish  );
			if (heap->runStatF851ADC == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStatF851ADC == eFail) {
				CGenErr();
			}
			heap->runStatF851ADC = eReady;
			nStep++; }
/* start q el linear (0 or 1 struct) */
		case 2 : {
			/**/
			/* Split Number */
			/**/
			CCGDebugSynchNode(&state, 2, 3, 1, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			PDASplit( &(heap->n_Case_Structure_SR), uInt16DataType, &(heap->by_Split_Number_hi_x__2), &(heap->by_Split_Number_lo_x__2) );
			/*SetSignalReady( 0x5, 0);*//* by_Split_Number_hi_x__2 */
			UpdateProbes(&state, debugOffset, 5 /*0x93916B0*/, (uChar*)&(heap->by_Split_Number_hi_x__2)); /* assign */
			/*SetSignalReady( 0x5, 1);*//* by_Split_Number_lo_x__2 */
			UpdateProbes(&state, debugOffset, 4 /*0x9391710*/, (uChar*)&(heap->by_Split_Number_lo_x__2)); /* assign */
/* Build array */
			CCGDebugSynchNode(&state, 3, 4, 1, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			{
				ArrDimSize i;
				ArrDimSize dimSize=0;
				heap->a_Build_Array_appended_array_4 = PDAArrNewEmptyWithNDimsStatic( uCharDataType, (ArrDimSize)1, &g_staticArray_19 );
				if (!heap->a_Build_Array_appended_array_4){
					CGenErr();
				}
				dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_Message__empty_array_), (ArrDimSize)0);
				dimSize += 1;
				dimSize += 1;
				PDAArrSetDim(((PDAArrPtr)heap->a_Build_Array_appended_array_4), (ArrDimSize)0, dimSize);
				if (!PDAArrAllocData(&heap->a_Build_Array_appended_array_4)){
					CGenErr();
				}
				i=0;
				if (!PDAArrAdd(heap->a_Build_Array_appended_array_4, i, heap->a_Message__empty_array_)) {
					CGenErr();
				}
				i += PDAArrNthDim(((PDAArrPtr)heap->a_Message__empty_array_), (ArrDimSize)0);
				PDAArrFree(heap->a_Message__empty_array_);
				if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_4), i, &heap->by_Split_Number_lo_x__2, uCharDataType)) {
					CGenErr();
				}
				i++;
				if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_4), i, &heap->by_Split_Number_hi_x__2, uCharDataType)) {
					CGenErr();
				}
				i++;
			}
			/*SetSignalReady( 0x1, 1);*//* a_Build_Array_appended_array_4 */
			UpdateProbes(&state, debugOffset, 3 /*0x9391770*/, (uChar*)&(heap->a_Build_Array_appended_array_4)); /* assign */
			if (!SetArrayControlFieldValueStatic( FPData(Message_with_CRC__267737864_ctlid), &heap->a_Build_Array_appended_array_4, false, &g_staticArray_20))
			CGenErr();
			/* Update front panel indicator */
			CCGDebugUpdateFPControl(&state, debugOffset, Message_with_CRC__267737864_ctlid);
			nStep++;}
/* start q el linear (0 or 1 struct) */
		case 3 : {
			{
				if (!SetClusterControlFieldValue( FPData(error_out__267734888_ctlid), &heap->c_error_in__no_error__4, 0x0 | ClusterDataType, false )){
					CGenErr();
				}
			}
			/* Update front panel indicator */
			CCGDebugUpdateFPControl(&state, debugOffset, error_out__267734888_ctlid);
	if (FPData(VISA_resource_name_out__267735368_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__267735368_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__267735368_ctlid))->staticStr) {
				MemHandleFree( FPData(VISA_resource_name_out__267735368_ctlid) );
			}
			FPData(VISA_resource_name_out__267735368_ctlid)=PDAStrCopyOnModify(heap->s_VISA_resource_name_4);
			/* Update front panel indicator */
			CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__267735368_ctlid);
			nStep++;}
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 4, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_VIName = "Watflow F4.lvlib:Utility MODBUS RTU CRC16.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)44,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	NULL,
	0,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_InitFPTerms,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_FrontPanelInit,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_BlockDiagram,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_DrawLabels,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_GetFPTerms,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Cleanup,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupLSRs,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_AddSubVIInstanceData,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


