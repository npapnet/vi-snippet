/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: subTimeDelay.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\vi.lib\express\express execution control\TimeDelayBlock.llb\subTimeDelay.vi
 *	Generated on: 2010-2-8 14:39
 *  Generated UI: false
 *  Generated Debug Info: false
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: true
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: dynamic
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
struct _subTimeDelay_heap { 
	double n_Multiply_x_y;
	double n_y_1;
	double n_Delay_Time__Seconds_;
	uInt32 extraF8864D9;  
	uInt8 runStatF8864D8;  
	uInt8 runStat1;  
	uInt8 runStatF886478;  
};
static struct _subTimeDelay_heap *heap = NULL; /* heap */

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) NULL; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[2] = {1, 1};


/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2300UL
#define Delay_Time__Seconds___184012728_ctlid 2300
#define N_CONTROLS 1L
#define gArrControlData subTimeDelay_gArrControlData
static ControlDataItem *subTimeDelay_gArrControlData=NULL;


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION subTimeDelay_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION subTimeDelay_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	{float64 dVal = (float64)0.0000000000000000000E+0 ;
		{
			static NumericInitialData numData = {
				Delay_Time__Seconds___184012728_ctlid,
				0,
				0,
				-2,
				doubleDataType,
				0,
				0,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				1,
				0,
				2,
				0,
				0,
				1,
				3,
				2,
			};
			if (!(FPData(Delay_Time__Seconds___184012728_ctlid) = NumericDataCreate(&numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, Delay_Time__Seconds___184012728_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[0].pValue, argsIn->args[0].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Delay_Time__Seconds___184012728_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Delay Time (Seconds)"),20,-4,-20,123,16,
	_LVT("0"),12,0,0,0, false);
	return true;
}
#define subTimeDelay_FrontPanelInit NULL
#define subTimeDelay_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION subTimeDelay_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION subTimeDelay_Cleanup(Boolean bShowFrontPanel){
	(void)NumericFreeData( FPData(Delay_Time__Seconds___184012728_ctlid) );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION subTimeDelay_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION subTimeDelay_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION subTimeDelay_CleanupLSRs(void);
void _TEXT_SECTION subTimeDelay_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION subTimeDelay_AddSubVIInstanceData(void);
void _TEXT_SECTION subTimeDelay_AddSubVIInstanceData(void) {
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION subTimeDelay_AddVIGlobalConstants(void);
void _TEXT_SECTION subTimeDelay_AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION subTimeDelay_CleanupVIGlobalConstants(void);
void _TEXT_SECTION subTimeDelay_CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION subTimeDelay_InitVIConstantList(void);
void _TEXT_SECTION subTimeDelay_InitVIConstantList(void) {
}


/****** Block diagram code **********/




/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION subTimeDelay_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION subTimeDelay_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	uInt16 *nStep = LVGetStepIndex( stepArr, -1 );
	if (gRunStatus == eReady) {
	}
	switch(*nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			heap->n_y_1 = 1.0000000000000000000E+3;
			(*nStep)++;}
/* start q el linear (0 or 1 struct) */
		case 1 : {
			if (!GetNumericFieldValue( FPData(Delay_Time__Seconds___184012728_ctlid), &heap->n_Delay_Time__Seconds_, doubleDataType )){
				CGenErr();
			}
			/**/
			/* Multiply */
			/**/
			PDAFltBinop( &heap->n_Delay_Time__Seconds_, doubleDataType, &heap->n_y_1, doubleDataType, opMult, &heap->n_Multiply_x_y, doubleDataType);
			(*nStep)++;}
/* start q el struct (0 or 1 struct)*/
		case 2 : {
			if (heap->runStatF8864D8 == eReady) {
				heap->extraF8864D9 = 0;
			}
			/**/
			/* Wait (ms) */
			/**/
			{
				eRunStatus runStatLocal=eFinished;
				runStatLocal = PrimWaitMS((Boolean)(bRunToFinish && (nReady  < 2)), (uInt32)heap->n_Multiply_x_y, (uInt32 *)&(heap->extraF8864D9));
				if (runStatLocal == eFail) {
					CGenErr();
				}
				if (runStatLocal == eFinished) {
					heap->extraF8864D9 = 0L;
				}
				heap->runStatF8864D8 = runStatLocal;
				runStat = runStatLocal;
			};
			if (runStat == eFinished) {
			}
			if (!bRunToFinish && (runStat == eNotFinished)) {
				return eNotFinished;
			}
			if (heap->runStatF8864D8 == eFinished) {
				heap->runStatF8864D8 = eReady;
			}
			(*nStep)++; }
		LVDelStepIndex( stepArr, -1 );
		default: {
			; /* do nothing */
		}
	}
	subTimeDelay_CleanupVIGlobalConstants();
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr subTimeDelay_VIName = "subTimeDelay.vi";

static VIInfo _DATA_SECTION viInfo = {
	&subTimeDelay_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _subTimeDelay_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)8,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	true,
	(uInt8**)&stepArr,
	NULL,
	0,
	subTimeDelay_InitFPTerms,
	subTimeDelay_FrontPanelInit,
	subTimeDelay_BlockDiagram,
	subTimeDelay_DrawLabels,
	subTimeDelay_GetFPTerms,
	subTimeDelay_Cleanup,
	subTimeDelay_CleanupLSRs,
	subTimeDelay_AddSubVIInstanceData,
	subTimeDelay_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION subTimeDelay_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (1) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	return stat;
}


/****** End of generated code **********/


