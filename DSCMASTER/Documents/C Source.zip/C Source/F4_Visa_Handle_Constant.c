/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: F4 Visa Handle Constant.vi
 *	Generated from: C:\Documents and Settings\pansino\����\Source Code(0925 check UI)\SubVIs\Controller Communication.llb\F4 Visa Handle Constant.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 12;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
struct _F4_Visa_Handle_Constant_heap { 
	cl_C0000 c_F4_Controller_handle_2;
	uInt8 runStat2;  
	uInt8 runStat1;  
} _DATA_SECTION __F4_Visa_Handle_Constant_heap; /* heap */

static uInt32 _DATA_SECTION _F4_Visa_Handle_Constant_signalsReadyTable[1];

static struct _F4_Visa_Handle_Constant_heap _DATA_SECTION *heap = &__F4_Visa_Handle_Constant_heap; /* heap */

struct _tF4_Visa_Handle_Constant_GlobalConstantsHeap {
	uInt8	refCnt;
	cl_C0000	i09B27EB8;
} _DATA_SECTION __F4_Visa_Handle_Constant_GlobalConstantsHeap;
static struct _tF4_Visa_Handle_Constant_GlobalConstantsHeap _DATA_SECTION *F4_Visa_Handle_Constant_GlobalConstantsHeapPtr = &__F4_Visa_Handle_Constant_GlobalConstantsHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _F4_Visa_Handle_Constant_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[1] = {1};
struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_3 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_3 g_string_3 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_C0000 g_cluster_1 = { 
	&g_string_2.el_1, 0, &g_string_3.el_1
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

static ClusterControlData g_control_3 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 3200UL
#define F4_Controller_Handle_Constant__267438168_ctlid 3200
#define N_CONTROLS 1L
#define gArrControlData F4_Visa_Handle_Constant_gArrControlData
ControlDataItem _DATA_SECTION F4_Visa_Handle_Constant_gArrControlData[1] = {
	{ F4_Controller_Handle_Constant__267438168_ctlid, 0, NULL, 0xC0000 | ClusterDataType, cluster_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION F4_Visa_Handle_Constant_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION F4_Visa_Handle_Constant_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(F4_Controller_Handle_Constant__267438168_ctlid) = ClusterControlDataCreateStatic(&g_control_3, GetControlDataPtr(), gFormID, F4_Controller_Handle_Constant__267438168_ctlid, 0, 0, 0xC0000 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0xC0000 | ClusterDataType );
		{
			cl_C0000* cl_000;
			cl_000 = (cl_C0000*)vpCls;
			cl_000->el_0 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb103);
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb104);
		}
		InitClusterControlFieldValue( FPData(F4_Controller_Handle_Constant__267438168_ctlid),  vpCls, 0xC0000 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	F4_Controller_Handle_Constant__267438168_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("F4 Controller Handle Constant"),29,0,-17,177,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define F4_Visa_Handle_Constant_FrontPanelInit NULL
#define F4_Visa_Handle_Constant_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION F4_Visa_Handle_Constant_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION F4_Visa_Handle_Constant_Cleanup(Boolean bShowFrontPanel){
	if (FPData(F4_Controller_Handle_Constant__267438168_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(F4_Controller_Handle_Constant__267438168_ctlid), false );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION F4_Visa_Handle_Constant_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION F4_Visa_Handle_Constant_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, F4_Controller_Handle_Constant__267438168_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION F4_Visa_Handle_Constant_CleanupLSRs(void);
void _TEXT_SECTION F4_Visa_Handle_Constant_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION F4_Visa_Handle_Constant_AddSubVIInstanceData(void);
void _TEXT_SECTION F4_Visa_Handle_Constant_AddSubVIInstanceData(void) {
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION F4_Visa_Handle_Constant_AddVIGlobalConstants(void);
void _TEXT_SECTION F4_Visa_Handle_Constant_AddVIGlobalConstants(void) {
	(F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->refCnt)++;
	if (F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->refCnt > 1) return;

	if ( !(((cl_C0000*)&F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->i09B27EB8)->el_0)) {
		{
			cl_C0000* cl_001;
			cl_001 = (cl_C0000*)&F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->i09B27EB8;
			MemSet( cl_001, sizeof(cl_C0000), 0 );
			cl_001->el_0 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb109);
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb110);
		}
	}
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION F4_Visa_Handle_Constant_CleanupVIGlobalConstants(void);
void _TEXT_SECTION F4_Visa_Handle_Constant_CleanupVIGlobalConstants(void) {
	if (F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->refCnt > 0) return;

	/* Free Cluster */
	{
		cl_C0000* cl_002 = (cl_C0000*)&F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->i09B27EB8;
		if (cl_002->el_0 && --((PDAStrPtr)cl_002->el_0)->refcnt == 0 && !((PDAStrPtr)cl_002->el_0)->staticStr) {
			MemHandleFree( cl_002->el_0 );
		}
		if (cl_002->el_2 && --((PDAStrPtr)cl_002->el_2)->refcnt == 0 && !((PDAStrPtr)cl_002->el_2)->staticStr) {
			MemHandleFree( cl_002->el_2 );
		}
	}
	MemSet(F4_Visa_Handle_Constant_GlobalConstantsHeapPtr,sizeof(*(F4_Visa_Handle_Constant_GlobalConstantsHeapPtr)),0);
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION F4_Visa_Handle_Constant_InitVIConstantList(void);
void _TEXT_SECTION F4_Visa_Handle_Constant_InitVIConstantList(void) {
	heap->c_F4_Controller_handle_2 = F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->i09B27EB8;
}


/****** Block diagram code **********/




/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION F4_Visa_Handle_Constant_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION F4_Visa_Handle_Constant_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			InitSignalReady(0, 1);
			/*InitSignalReady( 0x0, 0);*//* c_F4_Controller_handle_2 */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			/*SetSignalReady( 0x0, 0);*//* c_F4_Controller_handle_2 */
			UpdateProbes(&state, debugOffset, 1 /*0x9B25088*/, (uChar*)&(heap->c_F4_Controller_handle_2)); /* assign */
			SetSignalReady(0, 1);
			/* Cluster Inc Ref Count:  BDConst - alloc type*/
			{
				cl_C0000* cl_004 = (cl_C0000*)&heap->c_F4_Controller_handle_2;
				PDAStrIncRefCnt(cl_004->el_0, (uInt16)1); /* BDConst - alloc type */
				PDAStrIncRefCnt(cl_004->el_2, (uInt16)1); /* BDConst - alloc type */
			}
			nStep++;}
/* start q el linear (0 or 1 struct) */
		case 1 : {
			{
				if (!SetClusterControlFieldValue( FPData(F4_Controller_Handle_Constant__267438168_ctlid), &heap->c_F4_Controller_handle_2, 0xC0000 | ClusterDataType, false )){
					CGenErr();
				}
			}
			/* Update front panel indicator */
			CCGDebugUpdateFPControl(&state, debugOffset, F4_Controller_Handle_Constant__267438168_ctlid);
			nStep++;}
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 1, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	(F4_Visa_Handle_Constant_GlobalConstantsHeapPtr->refCnt)--;
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr F4_Visa_Handle_Constant_VIName = "F4 Visa Handle Constant.vi";

static VIInfo _DATA_SECTION viInfo = {
	&F4_Visa_Handle_Constant_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _F4_Visa_Handle_Constant_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)4,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	NULL,
	0,
	F4_Visa_Handle_Constant_InitFPTerms,
	F4_Visa_Handle_Constant_FrontPanelInit,
	F4_Visa_Handle_Constant_BlockDiagram,
	F4_Visa_Handle_Constant_DrawLabels,
	F4_Visa_Handle_Constant_GetFPTerms,
	F4_Visa_Handle_Constant_Cleanup,
	F4_Visa_Handle_Constant_CleanupLSRs,
	F4_Visa_Handle_Constant_AddSubVIInstanceData,
	F4_Visa_Handle_Constant_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION F4_Visa_Handle_Constant_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


