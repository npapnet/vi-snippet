/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: VISA Configure Serial Port (Instr).vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\vi.lib\Instr\_visa.llb\VISA Configure Serial Port (Instr).vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 10;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snode72F404C = false;
struct _VISA_Configure_Serial_Port__Instr__heap { 
	cl_00000 c_Property_Node_error_out_5;
	cl_00000 c_error_in__no_error__9;
	uInt32 dw_timeout__10sec_;
	uInt32 dw_baud_rate__9600_;
	VoidHand s_Property_Node_reference_out_8;
	VoidHand s_VISA_resource_name_9;
	uInt16 n_Case_Structure_CT_2;
	uInt16 n_Serial_Settings_Serial_End_M_1;
	uInt16 e_parity__0_none_;
	uInt16 n_data_bits__8_;
	uInt16 n_stop_bits__10__1_bit_;
	uInt16 n_Serial_Settings_Serial_End__1;
	uInt16 n_flow_control__0_none_;
	uInt16 n_Case_Structure_CT_3;
	uInt8 runStat1;  
	uInt8 runStat72F404C;  
	uInt8 by_termination_char__0xA_____n_;
	uInt8 runStat1013E559;  
	uInt8 runStat1013E55A;  
	uInt8 runStat1013E45A;  
	uInt8 runStat1013E459;  
	uInt8 runStat72F4CCC;  
	Boolean b_Enable_Termination_Char__T_;
	Boolean b_Enable_Termination_Char__T__C;
} _DATA_SECTION __VISA_Configure_Serial_Port__Instr__heap; /* heap */

static uInt32 _DATA_SECTION _VISA_Configure_Serial_Port__Instr__signalsReadyTable[3];

static struct _VISA_Configure_Serial_Port__Instr__heap _DATA_SECTION *heap = &__VISA_Configure_Serial_Port__Instr__heap; /* heap */

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _VISA_Configure_Serial_Port__Instr__signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[3] = {1, 1, 1};
struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

static NumericData g_control_1 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_2 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_3 = {
	0, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

struct {
	DataType	el_0;
	uInt32	el_1;
	uInt32	el_2;
	uInt32	el_3;
	uInt8	el_4;
	uInt8	el_5;
}
static g_control_4 = {
	0, 0, 0, 5, 1, 0
};

static NumericData g_control_5 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ClusterControlData g_control_9 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_13 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static float64 array_1[] = {
	10 , 15 , 20 
};
static RingData g_control_14 = {
	0, 0, 3, NULL, array_1, 0.0000000000000000000E+0, 0.0000000000000000000E+0, 1, 0, true, true
};

static BooleanData g_control_15 = {
	true, false, false, true
};

static float64 array_2[] = {
	0 , 1 , 2 , 3 , 4 , 5 
};
static RingData g_control_16 = {
	0, 0, 6, NULL, array_2, 0.0000000000000000000E+0, 0.0000000000000000000E+0, 1, 0, true, true
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 3000UL
#define VISA_resource_name__310397456_ctlid 3000
#define timeout__10sec___281325752_ctlid 3001
#define baud_rate__9600___281326424_ctlid 3002
#define data_bits__8___281327000_ctlid 3003
#define parity__0_none___281327576_ctlid 3004
#define termination_char__0xA_____n____LF___281328152_ctlid 3005
#define error_out__305729064_ctlid 3006
#define error_in__no_error___305730408_ctlid 3007
#define VISA_resource_name_out__305730888_ctlid 3008
#define stop_bits__10__1_bit___305731464_ctlid 3009
#define Enable_Termination_Char__T___305731752_ctlid 3010
#define flow_control__0_none___305732328_ctlid 3011
#define N_CONTROLS 12L
#define gArrControlData VISA_Configure_Serial_Port__Instr__gArrControlData
ControlDataItem _DATA_SECTION VISA_Configure_Serial_Port__Instr__gArrControlData[12] = {
	{ VISA_resource_name__310397456_ctlid, 0, NULL, StringDataType, nonui_control },
	{ timeout__10sec___281325752_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ baud_rate__9600___281326424_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ data_bits__8___281327000_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ parity__0_none___281327576_ctlid, 0, NULL, VoidHandDataType, enum_control },
	{ termination_char__0xA_____n____LF___281328152_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ error_out__305729064_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_in__no_error___305730408_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_resource_name_out__305730888_ctlid, 0, NULL, StringDataType, nonui_control },
	{ stop_bits__10__1_bit___305731464_ctlid, 0, NULL, VoidHandDataType, ring_control },
	{ Enable_Termination_Char__T___305731752_ctlid, 0, NULL, VoidHandDataType, pushbutton_control },
	{ flow_control__0_none___305732328_ctlid, 0, NULL, VoidHandDataType, ring_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION VISA_Configure_Serial_Port__Instr__InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION VISA_Configure_Serial_Port__Instr__InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__310397456_ctlid);
			vhIn = *(VoidHand *)argsIn->args[0].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[0].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[0].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[0].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__310397456_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,0,-21,111,16,
	_LVT("0"),12,0,0,0, false);
	{uInt32 dVal = (uInt32)10000 ;
		{
			static NumericInitialData numData = {
				timeout__10sec___281325752_ctlid,
				0,
				0,
				64,
				uInt32DataType,
				0.0000000000000000000E+0,
				4.2949672950000000000E+9,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(timeout__10sec___281325752_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_1, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, timeout__10sec___281325752_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[1].pValue, argsIn->args[1].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	timeout__10sec___281325752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("timeout (10sec)"),15,-8,-18,93,16,
	_LVT("0"),12,0,0,0, false);
	{uInt32 dVal = (uInt32)9600 ;
		{
			static NumericInitialData numData = {
				baud_rate__9600___281326424_ctlid,
				0,
				0,
				64,
				uInt32DataType,
				0.0000000000000000000E+0,
				4.2949672950000000000E+9,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(baud_rate__9600___281326424_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_2, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 4 && argsIn->args[4].pValue) {
		nIdx = CalcControlOffset( gFormID, baud_rate__9600___281326424_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[4].pValue, argsIn->args[4].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	baud_rate__9600___281326424_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("baud rate (9600)"),16,-7,-18,99,16,
	_LVT("0"),12,0,0,0, false);
	{uInt16 dVal = (uInt16)8 ;
		{
			static NumericInitialData numData = {
				data_bits__8___281327000_ctlid,
				0,
				0,
				64,
				uInt16DataType,
				5.0000000000000000000E+0,
				8.0000000000000000000E+0,
				1.0000000000000000000E+0,
				1,
				1,
				1,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(data_bits__8___281327000_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_3, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 5 && argsIn->args[5].pValue) {
		nIdx = CalcControlOffset( gFormID, data_bits__8___281327000_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[5].pValue, argsIn->args[5].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	data_bits__8___281327000_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("data bits (8)"),13,-7,-21,81,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(parity__0_none___281327576_ctlid) = EnumCtlDataCreateStatic((EnumCtlData*)&g_control_4, parity__0_none___281327576_ctlid, (ControlID)0, (ControlID)0, (int32)5, 0x120000 | Enum16DataType, 0 ))){
		return false;
	}
	if (argsIn && argsIn->size > 6 && argsIn->args[6].pValue) {
		nIdx = CalcControlOffset( gFormID, parity__0_none___281327576_ctlid);
		if (!SetEnumCtlFieldValue(GetControlHValue(nIdx), argsIn->args[6].pValue, argsIn->args[6].nType )) {
			return false;
		}
	}
	else {
		{			int16 lVal = 0 ;
			if (!SetEnumCtlFieldValue( FPData(parity__0_none___281327576_ctlid), &lVal, IntDataType )){
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	parity__0_none___281327576_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("parity (0:none)"),15,-9,-21,93,16,
	_LVT("0"),12,0,0,0, false);
	{uInt8 dVal = (uInt8)10 ;
		{
			static NumericInitialData numData = {
				termination_char__0xA_____n____LF___281328152_ctlid,
				0,
				0,
				66,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(termination_char__0xA_____n____LF___281328152_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_5, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, termination_char__0xA_____n____LF___281328152_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[2].pValue, argsIn->args[2].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	termination_char__0xA_____n____LF___281328152_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("termination char"),16,-13,-32,111,30,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	termination_char__0xA_____n____LF___281328152_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("(0xA = \'\\n\' = LF) "),18,-13,-20,111,30,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__305729064_ctlid) = ClusterControlDataCreateStatic(&g_control_9, GetControlDataPtr(), gFormID, error_out__305729064_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb83);
		}
		InitClusterControlFieldValue( FPData(error_out__305729064_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__305729064_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,0,-18,57,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_in__no_error___305730408_ctlid) = ClusterControlDataCreateStatic(&g_control_13, GetControlDataPtr(), gFormID, error_in__no_error___305730408_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 7 && argsIn->args[7].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___305730408_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[7].pValue, argsIn->args[7].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb85);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___305730408_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___305730408_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,0,-18,117,16,
	_LVT("0"),12,0,0,0, false);
	FPData(VISA_resource_name_out__305730888_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb87);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__305730888_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-21,135,16,
	_LVT("0"),12,0,0,0, false);
	FPData(stop_bits__10__1_bit___305731464_ctlid) = &g_control_14;
	if (argsIn && argsIn->size > 8 && argsIn->args[8].pValue) {
		nIdx = CalcControlOffset( gFormID, stop_bits__10__1_bit___305731464_ctlid);
		SetRingFieldValue( GetControlHValue(nIdx), argsIn->args[8].pValue, argsIn->args[8].nType );
	}
	else {
		uInt16 rValue = 10 ;
		if (!SetRingFieldValue( FPData(stop_bits__10__1_bit___305731464_ctlid), &rValue, uInt16DataType )){
			return false;
		}

	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	stop_bits__10__1_bit___305731464_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("stop bits (10: 1 bit)"),21,-6,-18,129,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(Enable_Termination_Char__T___305731752_ctlid) = BooleanDataCreateStatic(&g_control_15, Enable_Termination_Char__T___305731752_ctlid, (Boolean)0, (Boolean)1, (Boolean)true, (uInt8)1, (!version35)?std_button:std_button))){
		return false;
	}
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		{
			int32 lVal;
			nIdx = CalcControlOffset( gFormID, Enable_Termination_Char__T___305731752_ctlid);
			lVal = LVPtrToLong( argsIn->args[3].pValue, argsIn->args[3].nType );
			if (!SetBooleanFieldValue( gArrControlData[nIdx].hValue, (Boolean)lVal )) {
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Enable_Termination_Char__T___305731752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Enable Termination"),18,0,-30,111,30,
	_LVT("0"),12,0,0,0, false);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Enable_Termination_Char__T___305731752_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Char (T)"),8,0,-18,111,30,
	_LVT("0"),12,0,0,0, false);
	FPData(flow_control__0_none___305732328_ctlid) = &g_control_16;
	if (argsIn && argsIn->size > 9 && argsIn->args[9].pValue) {
		nIdx = CalcControlOffset( gFormID, flow_control__0_none___305732328_ctlid);
		SetRingFieldValue( GetControlHValue(nIdx), argsIn->args[9].pValue, argsIn->args[9].nType );
	}
	else {
		uInt16 rValue = 0 ;
		if (!SetRingFieldValue( FPData(flow_control__0_none___305732328_ctlid), &rValue, uInt16DataType )){
			return false;
		}

	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	flow_control__0_none___305732328_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("flow control (0:none)"),21,-2,-18,129,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define VISA_Configure_Serial_Port__Instr__FrontPanelInit NULL
#define VISA_Configure_Serial_Port__Instr__DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__Cleanup(Boolean bShowFrontPanel){
PDAStrFree( FPData(VISA_resource_name__310397456_ctlid) );
	FPData(VISA_resource_name__310397456_ctlid) = NULL;
	if (FPData(error_out__305729064_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__305729064_ctlid), false );
	if (FPData(error_in__no_error___305730408_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___305730408_ctlid), false );
PDAStrFree( FPData(VISA_resource_name_out__305730888_ctlid) );
	FPData(VISA_resource_name_out__305730888_ctlid) = NULL;
	(void)BooleanFreeData( FPData(Enable_Termination_Char__T___305731752_ctlid) );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION VISA_Configure_Serial_Port__Instr__GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION VISA_Configure_Serial_Port__Instr__GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__305729064_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[1].pValue, argsOut->args[1].nType );
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__305730888_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[0].pValue = GetControlHValue(nIdx);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__CleanupLSRs(void);
void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__AddSubVIInstanceData(void);
void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__AddSubVIInstanceData(void) {
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__AddVIGlobalConstants(void);
void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__CleanupVIGlobalConstants(void);
void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__InitVIConstantList(void);
void _TEXT_SECTION VISA_Configure_Serial_Port__Instr__InitVIConstantList(void) {
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION VISA_Configure_Serial_Port__Instr__RunFunc_72F404C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION VISA_Configure_Serial_Port__Instr__RunFunc_72F404C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72F404C == eReady) {
		if (!GetBooleanFieldValue( FPData(Enable_Termination_Char__T___305731752_ctlid), &heap->b_Enable_Termination_Char__T_ )){
			CGenErr();
		}
		/*SetSignalReady( 0x2, 6);*//* b_Enable_Termination_Char__T_ */
		UpdateProbes(&state, debugOffset, 2 /*0x10133E40*/, (uChar*)&(heap->b_Enable_Termination_Char__T_)); /* assign */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F404C == eReady) {
			CCGDebugSynchSNode(&state, 1, 2, 1, &snode72F404C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat1013E459 = eReady;
			heap->runStat1013E45A = eReady;
			heap->runStat1013E559 = eReady;
			heap->runStat1013E55A = eReady;
			heap->b_Enable_Termination_Char__T__C = heap->b_Enable_Termination_Char__T_;
			/*SetSignalReady( 0x2, 7);*//* b_Enable_Termination_Char__T__C */
		}
		/* begin case */
		if ( heap->b_Enable_Termination_Char__T__C ) {
			uInt32 diagramIdx = 5;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(1, 1);
					/*InitSignalReady( 0x1, 3);*//* n_Serial_Settings_Serial_End__1 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->n_Serial_Settings_Serial_End__1 = 2;
					/*SetSignalReady( 0x1, 3);*//* n_Serial_Settings_Serial_End__1 */
					UpdateProbes(&state, debugOffset, 15 /*0x10134500*/, (uChar*)&(heap->n_Serial_Settings_Serial_End__1)); /* assign */
					SetSignalReady(1, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					heap->n_Case_Structure_CT_3 = heap->n_Serial_Settings_Serial_End__1;
					/*SetSignalReady( 0x1, 5);*//* n_Case_Structure_CT_3 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 5, 5, &snode72F404C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 4;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(2, 1);
					/*InitSignalReady( 0x0, 7);*//* n_Serial_Settings_Serial_End_M_1 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->n_Serial_Settings_Serial_End_M_1 = 0;
					/*SetSignalReady( 0x0, 7);*//* n_Serial_Settings_Serial_End_M_1 */
					UpdateProbes(&state, debugOffset, 14 /*0x10134800*/, (uChar*)&(heap->n_Serial_Settings_Serial_End_M_1)); /* assign */
					SetSignalReady(2, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					heap->n_Case_Structure_CT_3 = heap->n_Serial_Settings_Serial_End_M_1;
					/*SetSignalReady( 0x1, 5);*//* n_Case_Structure_CT_3 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 4, 4, &snode72F404C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		heap->n_Case_Structure_CT_2 = heap->n_Case_Structure_CT_3;
		/*SetSignalReady( 0x0, 6);*//* n_Case_Structure_CT_2 */
		UpdateProbes(&state, debugOffset, 3 /*0x10133DE0*/, (uChar*)&(heap->n_Case_Structure_CT_2)); /* assign */
		SetSignalReady(0, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F404C, 2, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION VISA_Configure_Serial_Port__Instr__BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION VISA_Configure_Serial_Port__Instr__BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	uInt32 id = LVGetTimerFlag();
	int16 pass, numStructs = 2;
	Boolean bEndDiagram = false;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {;
		heap->runStat1 = eReady;
		heap->runStat72F404C = eReady;
		heap->runStat72F4CCC = eReady;
	}
	while (!gAppStop && !gLastError) {
		nReady = 0;
		runStat = eFinished;
		bEndDiagram = false;
		for (pass=0;pass<2;pass++) {
/* start q el linear (2 struct) */
			if ((heap->runStat1 != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					/*InitSignalReady( 0x1, 4);*//* n_flow_control__0_none_ */
					/*InitSignalReady( 0x2, 6);*//* b_Enable_Termination_Char__T_ */
					InitSignalReady(0, 1);
					/*InitSignalReady( 0x0, 6);*//* n_Case_Structure_CT_2 */
					/*InitSignalReady( 0x1, 2);*//* n_stop_bits__10__1_bit_ */
					/*InitSignalReady( 0x0, 4);*//* s_Property_Node_reference_out_8 */
					/*InitSignalReady( 0x0, 0);*//* c_Property_Node_error_out_5 */
					/*InitSignalReady( 0x0, 1);*//* c_error_in__no_error__9 */
					/*InitSignalReady( 0x0, 5);*//* s_VISA_resource_name_9 */
					/*InitSignalReady( 0x2, 0);*//* by_termination_char__0xA_____n_ */
					/*InitSignalReady( 0x1, 0);*//* e_parity__0_none_ */
					/*InitSignalReady( 0x1, 1);*//* n_data_bits__8_ */
					/*InitSignalReady( 0x0, 3);*//* dw_baud_rate__9600_ */
					/*InitSignalReady( 0x0, 2);*//* dw_timeout__10sec_ */
				}
				else {
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					{
					}
					heap->runStat1 = eFinished;
					continue;
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F404C != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					nReady++;
				}
				else {
					heap->runStat72F404C = VISA_Configure_Serial_Port__Instr__RunFunc_72F404C( (Boolean)(bRunToFinish && (nReady < 2)) );
					if (heap->runStat72F404C == eNotFinished) {
						runStat = eNotFinished;
					}
					else if (heap->runStat72F404C == eFail) {
						CGenErr();
					}
					else {
					}
					if (runStat == eFinished) {
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F4CCC != eFinished)
			/*&& GetSignalReady( 0x0, 6)*//* n_Case_Structure_CT_2 *//*) {*/
			&& GetSignalReady( 0 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat72F4CCC == eReady) {
						heap->s_VISA_resource_name_9 = FPData(VISA_resource_name__310397456_ctlid);
						PDAStrIncRefCnt(heap->s_VISA_resource_name_9, (uInt16)1);
						/*SetSignalReady( 0x0, 5);*//* s_VISA_resource_name_9 */
						UpdateProbes(&state, debugOffset, 8 /*0x10133BA0*/, (uChar*)&(heap->s_VISA_resource_name_9)); /* assign */
						MemMove( &heap->c_error_in__no_error__9, ((ClusterControlData*)FPData(error_in__no_error___305730408_ctlid))->pVal, sizeof( cl_00000 ) );
						MemSet(((ClusterControlData*)FPData(error_in__no_error___305730408_ctlid))->pVal, sizeof( cl_00000 ), 0);
						/*SetSignalReady( 0x0, 1);*//* c_error_in__no_error__9 */
						UpdateProbes(&state, debugOffset, 7 /*0x10133C00*/, (uChar*)&(heap->c_error_in__no_error__9)); /* assign */
						if (!GetNumericFieldValue( FPData(timeout__10sec___281325752_ctlid), &heap->dw_timeout__10sec_, uInt32DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x0, 2);*//* dw_timeout__10sec_ */
						UpdateProbes(&state, debugOffset, 13 /*0x101339B8*/, (uChar*)&(heap->dw_timeout__10sec_)); /* assign */
						if (!GetNumericFieldValue( FPData(baud_rate__9600___281326424_ctlid), &heap->dw_baud_rate__9600_, uInt32DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x0, 3);*//* dw_baud_rate__9600_ */
						UpdateProbes(&state, debugOffset, 12 /*0x10133A18*/, (uChar*)&(heap->dw_baud_rate__9600_)); /* assign */
						if (!GetNumericFieldValue( FPData(data_bits__8___281327000_ctlid), &heap->n_data_bits__8_, uInt16DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x1, 1);*//* n_data_bits__8_ */
						UpdateProbes(&state, debugOffset, 11 /*0x10133A78*/, (uChar*)&(heap->n_data_bits__8_)); /* assign */
						if (!GetRingFieldValue( FPData(stop_bits__10__1_bit___305731464_ctlid), &heap->n_stop_bits__10__1_bit_, uInt16DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x1, 2);*//* n_stop_bits__10__1_bit_ */
						UpdateProbes(&state, debugOffset, 4 /*0x10133D80*/, (uChar*)&(heap->n_stop_bits__10__1_bit_)); /* assign */
						if (!GetEnumCtlFieldValue( FPData(parity__0_none___281327576_ctlid), &heap->e_parity__0_none_ )){
							CGenErr();
						}
						/*SetSignalReady( 0x1, 0);*//* e_parity__0_none_ */
						UpdateProbes(&state, debugOffset, 10 /*0x10133AD8*/, (uChar*)&(heap->e_parity__0_none_)); /* assign */
						if (!GetNumericFieldValue( FPData(termination_char__0xA_____n____LF___281328152_ctlid), &heap->by_termination_char__0xA_____n_, uCharDataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x2, 0);*//* by_termination_char__0xA_____n_ */
						UpdateProbes(&state, debugOffset, 9 /*0x10133B40*/, (uChar*)&(heap->by_termination_char__0xA_____n_)); /* assign */
						if (!GetRingFieldValue( FPData(flow_control__0_none___305732328_ctlid), &heap->n_flow_control__0_none_, uInt16DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x1, 4);*//* n_flow_control__0_none_ */
						UpdateProbes(&state, debugOffset, 1 /*0x10133EA0*/, (uChar*)&(heap->n_flow_control__0_none_)); /* assign */
					}
					CCGDebugSynchNode(&state, 2, 3, 1, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
/* Property node */
					{
						PropInfo props[9] = {
							{kGeneral_Settings_Timeout_Value, &heap->dw_timeout__10sec_, uInt32DataType},
							{kSerial_Settings_Serial_Baud_Rate, &heap->dw_baud_rate__9600_, uInt32DataType},
							{kSerial_Settings_Serial_Data_Bits, &heap->n_data_bits__8_, uInt16DataType},
							{kSerial_Settings_Serial_Stop_Bits, &heap->n_stop_bits__10__1_bit_, uInt16DataType},
							{kSerial_Settings_Serial_Parity, &heap->e_parity__0_none_, 0x120000 | Enum16DataType},
							{kMessage_Based_Settings_Termination_Character_Enable, &heap->b_Enable_Termination_Char__T_, BooleanDataType},
							{kMessage_Based_Settings_Termination_Character, &heap->by_termination_char__0xA_____n_, uCharDataType},
							{kSerial_Settings_Serial_Flow_Control, &heap->n_flow_control__0_none_, uInt16DataType},
							{kSerial_Settings_Serial_End_Mode_for_Reads, &heap->n_Case_Structure_CT_2, uInt16DataType}
						};
						if (!VisaSetProperties( heap->s_VISA_resource_name_9, &heap->s_Property_Node_reference_out_8, &heap->c_error_in__no_error__9, &heap->c_Property_Node_error_out_5, props, 9)) {
							CGenErr();
						}
						heap->runStat72F4CCC = eFinished;
					}
					/*SetSignalReady( 0x0, 0);*//* c_Property_Node_error_out_5 */
					UpdateProbes(&state, debugOffset, 6 /*0x10133C60*/, (uChar*)&(heap->c_Property_Node_error_out_5)); /* assign */
					/*SetSignalReady( 0x0, 4);*//* s_Property_Node_reference_out_8 */
					UpdateProbes(&state, debugOffset, 5 /*0x10133CC0*/, (uChar*)&(heap->s_Property_Node_reference_out_8)); /* assign */
					if (heap->runStat72F4CCC == eFinished) {
	if (FPData(VISA_resource_name_out__305730888_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__305730888_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__305730888_ctlid))->staticStr) {
							MemHandleFree( FPData(VISA_resource_name_out__305730888_ctlid) );
						}
						FPData(VISA_resource_name_out__305730888_ctlid)=PDAStrCopyOnModify(heap->s_Property_Node_reference_out_8);
						/* Update front panel indicator */
						CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__305730888_ctlid);
						{
							if (!SetClusterControlFieldValue( FPData(error_out__305729064_ctlid), &heap->c_Property_Node_error_out_5, 0x0 | ClusterDataType, false )){
								CGenErr();
							}
						}
						/* Update front panel indicator */
						CCGDebugUpdateFPControl(&state, debugOffset, error_out__305729064_ctlid);
						InitSignalReady(0, 1);
						continue;
					}
				}
			}
			if (pass == 1) bEndDiagram = true;
		}
		if (bEndDiagram &&runStat == eFinished) {
			CCGDebugSynchSRN(&state, 3, 1, pauseCaller, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat1 = eReady;
			heap->runStat72F404C = eReady;
			heap->runStat72F4CCC = eReady;
			break;
		}
		if (!bRunToFinish) {
			if (bEndDiagram) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		}
	}
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr VISA_Configure_Serial_Port__Instr__VIName = "VISA Configure Serial Port (Instr).vi";

static VIInfo _DATA_SECTION viInfo = {
	&VISA_Configure_Serial_Port__Instr__VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _VISA_Configure_Serial_Port__Instr__heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)12,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	NULL,
	0,
	VISA_Configure_Serial_Port__Instr__InitFPTerms,
	VISA_Configure_Serial_Port__Instr__FrontPanelInit,
	VISA_Configure_Serial_Port__Instr__BlockDiagram,
	VISA_Configure_Serial_Port__Instr__DrawLabels,
	VISA_Configure_Serial_Port__Instr__GetFPTerms,
	VISA_Configure_Serial_Port__Instr__Cleanup,
	VISA_Configure_Serial_Port__Instr__CleanupLSRs,
	VISA_Configure_Serial_Port__Instr__AddSubVIInstanceData,
	VISA_Configure_Serial_Port__Instr__InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION VISA_Configure_Serial_Port__Instr__Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


