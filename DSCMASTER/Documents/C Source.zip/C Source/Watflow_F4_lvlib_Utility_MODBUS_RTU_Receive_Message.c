/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Utility MODBUS RTU Receive Message.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Private\Utility MODBUS RTU Receive Message.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 3;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snode72FA6CC = false;
static Boolean snode72F964C = false;
static Boolean snode72F97CC = false;
static Boolean snode72F344C = false;
static Boolean snode72F25CC = false;
static Boolean snode72F304C = false;
struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_heap { 
	cl_00000 c_Case_Structure_CT_12;
	cl_00000 c_error_in__no_error__CT_2;
	cl_00000 c_error_in__no_error__2;
	cl_00000 c_VISA_Read_error_out_CT_5;
	cl_00000 c_VISA_Read_error_out_7;
	cl_00000 c_VISA_Read_error_out_6;
	cl_00000 c_Utility_Generate_Instrument_1;
	cl_00000 c_VISA_Read_error_out_CT_4;
	cl_00000 c_Utility_Generate_Instrument__1;
	cl_00000 c_Case_Structure_CT_21;
	cl_00000 c_error_in__no_error__CT;
	cl_00000 c_VISA_Read_error_out_CT_3;
	cl_00000 c_VISA_Read_error_out_CT_2;
	cl_00000 c_Case_Structure_CT_20;
	cl_00000 c_VISA_Read_error_out_CT_1;
	cl_00000 c_VISA_Read_error_out_5;
	cl_00000 c_VISA_Read_error_out_4;
	cl_00000 c_Case_Structure_CT_13;
	cl_00000 c_Case_Structure_CT_19;
	cl_00000 c_Property_Node_error_out_1;
	cl_00000 c_error_in__no_error__CT_1;
	cl_00000 c_VISA_Read_error_out_CT;
	cl_00000 c_Property_Node_error_out_CT_5;
	cl_00000 c_Select_s__t_f_1;
	cl_00000 c_Utility_Generate_Instrument_E_1;
	cl_00000 c_Constant_1;
	cl_00000 c_Utility_MODBUS_RTU_CRC16_vi_e_1;
	cl_00000 c_VISA_Read_error_out_3;
	cl_00000 c_Case_Structure_CT_18;
	cl_00000 c_Case_Structure_CT_14;
	cl_00000 c_VISA_Read_error_out_CS_2;
	cl_00000 c_VISA_Read_error_out_CS_1;
	cl_00000 c_VISA_Read_error_out_2;
	cl_00000 c_VISA_Read_error_out_1;
	cl_00000 c_Utility_Generate_Instrument_E;
	cl_00000 c_Utility_MODBUS_RTU_CRC16_vi_e;
	cl_00000 c_Case_Structure_CT_17;
	cl_00000 c_Case_Structure_CT_15;
	cl_00000 c_Property_Node_error_out_CT_3;
	cl_00000 c_Property_Node_error_out_CT_4;
	cl_00000 c_VISA_Read_error_out;
	cl_00000 c_Case_Structure_CT_16;
	uInt32 dw_byte_count__0__1;
	uInt32 dw_byte_count__0__3;
	uInt32 dw_byte_count__0__5;
	uInt32 dw_byte_count__0__4;
	uInt32 dw_byte_count__0_;
	uInt32 dw_byte_count__0__2;
	uInt32 dw_To_Unsigned_Long_Integer_uns;
	int32 l_Constant_3;
	int32 l_Constant_4;
	int32 l_Unbundle_By_Name_code;
	int32 l_Constant_2;
	int32 l_index_2;
	int32 l_index_4;
	int32 l_Constant_1;
	int32 l_To_Long_Integer_32bit_integer;
	int32 l_Constant;
	int32 l_Add_x_y;
	int32 l_index_3;
	int32 l_index_5;
	cl_F0000 c_Array_To_Cluster_cluster_2;
	cl_F0000 c_Array_To_Cluster_cluster_1;
	VoidHand a_String_To_Byte_Array_unsig_3;
	VoidHand a_String_To_Byte_Array_unsigned;
	VoidHand s_VISA_Read_read_buffer_7;
	VoidHand s_Case_Structure_CT_17;
	VoidHand a_Case_Structure_CT_7;
	VoidHand s_VISA_Read_VISA_resource_name__1;
	VoidHand s_VISA_Read_read_buffer_CT;
	VoidHand s_Utility_Generate_Instrument_E;
	VoidHand s_Utility_MODBUS_RTU_CRC16_vi_V;
	VoidHand s_VISA_Read_VISA_resource_name_1;
	VoidHand a_Build_Array_appended_array_1;
	VoidHand a_String_To_Byte_Array_unsigned_1;
	VoidHand a_Case_Structure_CT_2;
	VoidHand a_String_To_Byte_Array_unsig_2;
	VoidHand a_unsigned_byte_array_2;
	VoidHand a_Build_Array_appended_array_3;
	VoidHand s_VISA_Read_VISA_resource_na_4;
	VoidHand s_VISA_Read_read_buffer_6;
	VoidHand Args10782159;  
	VoidHand a_String_To_Byte_Array_unsigne_1;
	VoidHand a_String_To_Byte_Array_unsig_1;
	VoidHand s_VISA_Read_read_buffer_1;
	VoidHand s_VISA_Read_VISA_resource_na_3;
	VoidHand s_VISA_Read_VISA_resource_nam_1;
	VoidHand s_Property_Node_reference_out_2;
	VoidHand s_VISA_Read_read_buffer_2;
	VoidHand s_VISA_Read_VISA_resource_nam_2;
	VoidHand s_VISA_Read_VISA_resource_na_2;
	VoidHand s_VISA_Read_read_buffer_CT_1;
	VoidHand s_Utility_Generate_Instrument_1;
	VoidHand s_Property_Node_reference_out_3;
	VoidHand s_Case_Structure_CT_12;
	VoidHand Args10782999;  
	VoidHand a_String_To_Byte_Array_unsign_1;
	VoidHand a_String_To_Byte_Array_unsign_2;
	VoidHand s_VISA_Read_read_buffer;
	VoidHand s_Case_Structure_CT_15;
	VoidHand ArgsE58A4A1;  
	VoidHand a_String_To_Byte_Array_unsign_10;
	VoidHand s_VISA_Read_VISA_resource_na_1;
	VoidHand s_Utility_Generate_Instrument__1;
	VoidHand a_Case_Structure_CT_17;
	VoidHand s_Case_Structure_CT_21;
	VoidHand a_Case_Structure_CT_16;
	VoidHand Args101D4429;  
	VoidHand a_String_To_Byte_Array_unsign_9;
	VoidHand Args101D4DE9;  
	VoidHand s_VISA_Read_VISA_resource_nam_10;
	VoidHand s_VISA_Read_VISA_resource_nam_9;
	VoidHand Args101D4EA9;  
	VoidHand s_VISA_resource_name_CT;
	VoidHand a_String_To_Byte_Array_unsign_8;
	VoidHand a_unsigned_byte_array;
	VoidHand s_VISA_Read_VISA_resource_nam_3;
	VoidHand a_Case_Structure_CT_4;
	VoidHand a_Case_Structure_CT_15;
	VoidHand s_Case_Structure_CT_20;
	VoidHand a_Case_Structure_CT_14;
	VoidHand a_unsigned_byte_array_1;
	VoidHand s_VISA_Read_VISA_resource_nam_8;
	VoidHand s_VISA_Read_read_buffer_3;
	VoidHand a_Case_Structure_CT_5;
	VoidHand a_String_To_Byte_Array_unsign_7;
	VoidHand s_VISA_Read_read_buffer_5;
	VoidHand s_Utility_MODBUS_RTU_CRC16_vi_V_1;
	VoidHand s_Case_Structure_CT_18;
	VoidHand a_Case_Structure_CT_8;
	VoidHand s_Utility_Generate_Instrument_E_1;
	VoidHand a_Case_Structure_CT_9;
	VoidHand a_String_To_Byte_Array_unsign_3;
	VoidHand s_VISA_Read_VISA_resource_name_;
	VoidHand a_Build_Array_appended_array_2;
	VoidHand a_Case_Structure_CT_3;
	VoidHand s_VISA_resource_name_CT_2;
	VoidHand s_Case_Structure_CT_16;
	VoidHand a_Case_Structure_CT_6;
	VoidHand s_VISA_Read_VISA_resource_nam_7;
	VoidHand ArgsE58A1A1;  
	VoidHand a_Case_Structure_CT_10;
	VoidHand s_Case_Structure_CT_13;
	VoidHand s_VISA_Read_read_buffer_4;
	VoidHand s_VISA_resource_name_2;
	VoidHand a_Case_Structure_CT_11;
	VoidHand s_Case_Structure_CT_14;
	VoidHand s_VISA_Read_VISA_resource_nam_4;
	VoidHand s_VISA_resource_name_CT_1;
	VoidHand s_Property_Node_reference_out_4;
	VoidHand a_String_To_Byte_Array_unsign_6;
	VoidHand s_VISA_Read_VISA_resource_nam_6;
	VoidHand Args101D4F69;  
	VoidHand s_VISA_Read_VISA_resource_nam_5;
	VoidHand a_String_To_Byte_Array_unsign_5;
	VoidHand a_Case_Structure_CT_12;
	VoidHand s_Property_Node_reference_out_1;
	VoidHand a_Case_Structure_CT_13;
	VoidHand s_Case_Structure_CT_19;
	VoidHand a_String_To_Byte_Array_unsign_4;
	VoidHand ArgsE58A3E1;  
	uInt16 n_Receive_Message_Type__0__By_1;
	uInt16 n_Utility_MODBUS_RTU_CRC16_vi_C;
	uInt16 n_Join_Numbers__hi_lo__1;
	uInt16 n_Receive_Message_Type__0__By__1;
	uInt16 n_Receive_Message_Type__0__By_T;
	uInt16 n_Serial_Settings_Serial_End_Mo_1;
	uInt16 n_Receive_Message_Type__0__By_T_1;
	uInt16 n_Join_Numbers__hi_lo__2;
	uInt16 n_Utility_MODBUS_RTU_CRC16_vi_C_1;
	uInt8 by_Unbundle_unsigned_byte_arr_1;
	uInt8 by_Unbundle_unsigned_byte_arra_1;
	uInt8 runStat105915A9;  
	uInt8 runStat105915AA;  
	uInt8 by_Index_Array_element_2;
	uInt8 by_Sent_Command__0__CT_3;
	uInt8 runStatE58A320;  
	uInt8 runStat72F25CC;  
	uInt8 by_Length_Of_Sent_MSG__0__CT_3;
	uInt8 by_Sent_Command__0__CT;
	uInt8 runStatE589F60;  
	uInt8 runStatE1F69C9;  
	uInt8 runStatE1F69CA;  
	uInt8 by_y_1;
	uInt8 by_Sent_Command__0__CT_5;
	uInt8 runStat10590FAA;  
	uInt8 runStat10590FA9;  
	uInt8 runStatE4783EA;  
	uInt8 runStatE4783E9;  
	uInt8 runStat10590DAA;  
	uInt8 by_Length_Of_Sent_MSG__0__CT;
	uInt8 runStat101D4F68;  
	uInt8 by_Add_x_y;
	uInt8 by_Index_Array_element_CT_1;
	uInt8 runStat10590DA9;  
	uInt8 runStat101D4EA8;  
	uInt8 runStatE1F5160;  
	uInt8 runStat72F304C;  
	uInt8 runStatE477EAA;  
	uInt8 runStat101D44E8;  
	uInt8 by_Length_Of_Sent_MSG__0__CT_2;
	uInt8 runStatE477EA9;  
	uInt8 runStat101D4DE8;  
	uInt8 runStat101D4548;  
	uInt8 runStat12E8781A;  
	uInt8 runStat12E87819;  
	uInt8 by_Length_Of_Sent_MSG__0__CT_5;
	uInt8 runStat12E8799A;  
	uInt8 runStat12E87999;  
	uInt8 runStat101D4D28;  
	uInt8 runStat72FA6CC;  
	uInt8 by_Subtract_x_y;
	uInt8 by_Index_Array_element_1;
	uInt8 runStat10782998;  
	uInt8 by_Case_Structure_CT_1;
	uInt8 runStatE1F88D9;  
	uInt8 runStatE1F88DA;  
	uInt8 runStat72F344C;  
	uInt8 runStat13316058;  
	uInt8 by_Sent_Command__0__CT_1;
	uInt8 by_Length_Of_Sent_MSG__0_;
	uInt8 by_Sent_Command__0_;
	uInt8 by_Length_Of_Sent_MSG__0__CT_1;
	uInt8 by_y;
	uInt8 by_Unbundle_unsigned_byte_array_1;
	uInt8 by_Unbundle_unsigned_byte_array;
	uInt8 runStat72FD14C;  
	uInt8 runStat72F964C;  
	uInt8 by_Length_Of_Sent_MSG__0__CT_4;
	uInt8 by_Decrement_x_1;
	uInt8 by_Index_Array_element_CT;
	uInt8 by_x;
	uInt8 by_Index_Array_element_3;
	uInt8 by_Index_Array_element;
	uInt8 runStat1078DA81;  
	uInt8 by_Case_Structure_CT;
	uInt8 runStatE58A4A0;  
	uInt8 by_Sent_Command__0__CT_4;
	uInt8 runStat1078DA82;  
	uInt8 runStat72F97CC;  
	uInt8 runStat10781CD8;  
	uInt8 runStat10782158;  
	uInt8 runStatE58AD40;  
	uInt8 runStat10782098;  
	uInt8 runStatE1F8459;  
	uInt8 runStatE1F845A;  
	uInt8 runStatE1F61C9;  
	uInt8 runStatE1F61CA;  
	uInt8 runStatE58A200;  
	uInt8 by_Sent_Command__0__CT_2;
	uInt8 runStatE58A3E0;  
	uInt8 by_Constant;
	uInt8 runStatE58A0E0;  
	uInt8 runStat1;  
	Boolean b_status;
	Boolean c_error_in__no_error__CS;
	Boolean b_Equal__x___y__CS_1;
	Boolean b_Equal__x___y__2;
	Boolean b_Not_Equal__x____y__CS;
	Boolean b_Not_Equal__x____y__3;
	Boolean b_Not_Equal__x____y_;
	Boolean b_Not_Equal__x____y__2;
	Boolean b_Equal__x___y__CS;
	Boolean b_Not_Equal__x____y__1;
	Boolean b_Equal__x___y__1;
	Boolean c_VISA_Read_error_out_CS;
	Boolean b_status_1;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_signalsReadyTable[37];

static struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_heap; /* heap */

struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeap {
	uInt8	refCnt;
	VoidHand	i0E587C38;
	VoidHand	i10780AA8;
	VoidHand	i12776318;
	cl_00000	i12776A50;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeap;
static struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeap _DATA_SECTION *Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr = &__Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeap;

struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i0E58A3E0;
	subVIInstanceData	i0E58A4A0;
	subVIInstanceData	i101D4DE8;
	subVIInstanceData	i101D4EA8;
	subVIInstanceData	i10782158;
	subVIInstanceData	i10782998;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeap;
static struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeap _DATA_SECTION *Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr = &__Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[37] = {3, 3, 1, 3, 4, 2, 3, 1, 5, 4, 1, 4, 3, 4, 4, 4, 2, 5, 2, 7, 3, 3, 3, 3, 4, 2, 3, 1, 1, 1, 2, 2, 1, 3, 3, 5, 3};
struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

struct _g_array_1 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_1 g_array_1 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_array_2 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_2 g_array_2 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_array_3 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_3 g_array_3 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_array_4 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_4 g_array_4 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_string_3 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_3 g_string_3 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_cluster_1 = { 
	0, 0, &g_string_3.el_1
};

static float64 array_1[] = {
	0 , 1 
};
static RingData g_control_1 = {
	0, 0, 2, NULL, array_1, 0.0000000000000000000E+0, 0.0000000000000000000E+0, 1, 0, true, true
};

static ClusterControlData g_control_5 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_9 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_10 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_11 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_13 = {
	0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_12 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ArrayControlData g_control_14 = {
	0, 0, true, 1, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2300UL
#define Receive_Message_Type__0__By_The_Number_Of_Bytes___162217272_ctlid 2300
#define error_in__no_error___162218424_ctlid 2301
#define error_out__163480472_ctlid 2302
#define Sent_Command__0___163480856_ctlid 2303
#define VISA_resource_name__163481336_ctlid 2304
#define VISA_resource_name_out__163481816_ctlid 2305
#define Length_Of_Sent_MSG__0___163482200_ctlid 2306
#define Read_Buffer__163483256_ctlid 2307
#define N_CONTROLS 8L
#define gArrControlData Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_gArrControlData[8] = {
	{ Receive_Message_Type__0__By_The_Number_Of_Bytes___162217272_ctlid, 0, NULL, VoidHandDataType, ring_control },
	{ error_in__no_error___162218424_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__163480472_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ Sent_Command__0___163480856_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ VISA_resource_name__163481336_ctlid, 0, NULL, StringDataType, nonui_control },
	{ VISA_resource_name_out__163481816_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Length_Of_Sent_MSG__0___163482200_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ Read_Buffer__163483256_ctlid, 0, NULL, 0x100000 | ArrayDataType, array_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	FPData(Receive_Message_Type__0__By_The_Number_Of_Bytes___162217272_ctlid) = &g_control_1;
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, Receive_Message_Type__0__By_The_Number_Of_Bytes___162217272_ctlid);
		SetRingFieldValue( GetControlHValue(nIdx), argsIn->args[0].pValue, argsIn->args[0].nType );
	}
	else {
		uInt16 rValue = 0 ;
		if (!SetRingFieldValue( FPData(Receive_Message_Type__0__By_The_Number_Of_Bytes___162217272_ctlid), &rValue, uInt16DataType )){
			return false;
		}

	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Receive_Message_Type__0__By_The_Number_Of_Bytes___162217272_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Receive Message Type (0: By The Number Of Bytes)"),48,-15,-19,311,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_in__no_error___162218424_ctlid) = ClusterControlDataCreateStatic(&g_control_5, GetControlDataPtr(), gFormID, error_in__no_error___162218424_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___162218424_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[1].pValue, argsIn->args[1].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb35);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___162218424_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___162218424_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,-1,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__163480472_ctlid) = ClusterControlDataCreateStatic(&g_control_9, GetControlDataPtr(), gFormID, error_out__163480472_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb37);
		}
		InitClusterControlFieldValue( FPData(error_out__163480472_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__163480472_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-2,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	{uInt8 dVal = (uInt8)0 ;
		{
			static NumericInitialData numData = {
				Sent_Command__0___163480856_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Sent_Command__0___163480856_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_10, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, Sent_Command__0___163480856_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[2].pValue, argsIn->args[2].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Sent_Command__0___163480856_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Sent Command (0)"),16,-15,-20,111,16,
	_LVT("0"),12,0,0,0, false);
	if (argsIn && argsIn->size > 4 && argsIn->args[4].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__163481336_ctlid);
			vhIn = *(VoidHand *)argsIn->args[4].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[4].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[4].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[4].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__163481336_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,0,-16,129,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_resource_name_out__163481816_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb40);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__163481816_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-16,157,16,
	_LVT("0"),12,0,1000,0, false);
	{uInt8 dVal = (uInt8)0 ;
		{
			static NumericInitialData numData = {
				Length_Of_Sent_MSG__0___163482200_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Length_Of_Sent_MSG__0___163482200_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_11, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		nIdx = CalcControlOffset( gFormID, Length_Of_Sent_MSG__0___163482200_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[3].pValue, argsIn->args[3].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Length_Of_Sent_MSG__0___163482200_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Length Of Sent MSG (0)"),22,-15,-20,153,16,
	_LVT("0"),12,0,0,0, false);
	FPData(Read_Buffer__163483256_ctlid) = NULL;
	if(bShowFrontPanel) {
/* Declare array */
		{
			FPData(Read_Buffer__163483256_ctlid) = (void*)&g_array_1.el_1;
			NDims(((PDAArrPtr)&g_array_1.el_1)) = 1;
			((PDAArrPtr)&g_array_1.el_1)->datatype = uCharDataType;
			((PDAArrPtr)&g_array_1.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_1.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_1.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(Read_Buffer__163483256_ctlid) = ArrayControlDataCreateStatic(&g_control_14, FPData(Read_Buffer__163483256_ctlid), Read_Buffer__163483256_ctlid, 0, 0, 1, bShowFrontPanel, 1, 0x100000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Read_Buffer__163483256_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Read Buffer"),11,0,-18,80,16,
	_LVT("0"),12,0,1000,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_FrontPanelInit NULL
#define Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_in__no_error___162218424_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___162218424_ctlid), false );
	if (FPData(error_out__163480472_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__163480472_ctlid), false );
PDAStrFree( FPData(VISA_resource_name__163481336_ctlid) );
	FPData(VISA_resource_name__163481336_ctlid) = NULL;
PDAStrFree( FPData(VISA_resource_name_out__163481816_ctlid) );
	FPData(VISA_resource_name_out__163481816_ctlid) = NULL;
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(Read_Buffer__163483256_ctlid), 1 );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__163480472_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	if (argsOut->size > 2 && argsOut->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__163481816_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[2].pValue = GetControlHValue(nIdx);
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Read_Buffer__163483256_ctlid);
		GetArrayControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[1].pValue);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_AddSubVIInstanceData(void) {
	if (Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->initialized) return;
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->initialized = TRUE;

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A3E0.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A3E0;
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A4A0.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A4A0;
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4DE8.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4DE8;
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4EA8.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4EA8;
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782158.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782158;
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782998.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782998;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_AddVIGlobalConstants(void) {
	(Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->refCnt)++;
	if (Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->refCnt > 1) return;

/* Declare array */
	{
		Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i0E587C38 = (void*)&g_array_2.el_1;
		NDims(((PDAArrPtr)&g_array_2.el_1)) = 1;
		((PDAArrPtr)&g_array_2.el_1)->datatype = uCharDataType;
		((PDAArrPtr)&g_array_2.el_1)->staticArray = 1;
		((PDAArrPtr)&g_array_2.el_1)->refcnt = 2;
		NthDim(((PDAArrPtr)&g_array_2.el_1), (ArrDimSize)0) = 0;
	}
/* Declare array */
	{
		Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i10780AA8 = (void*)&g_array_3.el_1;
		NDims(((PDAArrPtr)&g_array_3.el_1)) = 1;
		((PDAArrPtr)&g_array_3.el_1)->datatype = uCharDataType;
		((PDAArrPtr)&g_array_3.el_1)->staticArray = 1;
		((PDAArrPtr)&g_array_3.el_1)->refcnt = 2;
		NthDim(((PDAArrPtr)&g_array_3.el_1), (ArrDimSize)0) = 0;
	}
/* Declare array */
	{
		Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776318 = (void*)&g_array_4.el_1;
		NDims(((PDAArrPtr)&g_array_4.el_1)) = 1;
		((PDAArrPtr)&g_array_4.el_1)->datatype = uCharDataType;
		((PDAArrPtr)&g_array_4.el_1)->staticArray = 1;
		((PDAArrPtr)&g_array_4.el_1)->refcnt = 2;
		NthDim(((PDAArrPtr)&g_array_4.el_1), (ArrDimSize)0) = 0;
	}
	if ( !(((cl_00000*)&Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776A50)->el_2)) {
		{
			cl_00000* cl_002;
			cl_002 = (cl_00000*)&Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776A50;
			MemSet( cl_002, sizeof(cl_00000), 0 );
			cl_002->el_0 = false;
			cl_002->el_1 = 0 ;
			cl_002->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb42);
		}
	}
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupVIGlobalConstants(void) {
	if (Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->refCnt > 0) return;

	if (Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i0E587C38){--((PDAArrPtr)Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i0E587C38)->refcnt;}
		if (Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i10780AA8){--((PDAArrPtr)Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i10780AA8)->refcnt;}
		if (Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776318){--((PDAArrPtr)Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776318)->refcnt;}
		/* Free Cluster */
	{
		cl_00000* cl_003 = (cl_00000*)&Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776A50;
				if (cl_003->el_2 && --((PDAStrPtr)cl_003->el_2)->refcnt == 0 && !((PDAStrPtr)cl_003->el_2)->staticStr) {
			MemHandleFree( cl_003->el_2 );
		}
	}
	MemSet(Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr,sizeof(*(Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr)),0);
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_InitVIConstantList(void) {
	heap->c_Constant_1 = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776A50;
	heap->a_unsigned_byte_array = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i0E587C38;
	heap->a_unsigned_byte_array_1 = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i10780AA8;
	heap->a_unsigned_byte_array_2 = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->i12776318;
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F304C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F304C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F304C == eReady) {
			CCGDebugSynchSNode(&state, 54, 55, 52, &snode72F304C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatE1F8459 = eReady;
			heap->runStat10781CD8 = eReady;
			heap->runStat10782158 = eReady;
			heap->runStat10782098 = eReady;
			heap->runStatE1F845A = eReady;
			heap->runStatE1F88D9 = eReady;
			heap->runStat10782998 = eReady;
			heap->runStatE1F88DA = eReady;
			heap->b_Equal__x___y__CS_1 = heap->b_Equal__x___y__2;
			/*SetSignalReady( 0x20, 0);*//* b_Equal__x___y__CS_1 */
			heap->s_VISA_Read_VISA_resource_nam_10 = heap->s_VISA_Read_VISA_resource_nam_9;
			/*SetSignalReady( 0xD, 6);*//* s_VISA_Read_VISA_resource_nam_10 */
			MemMove( &heap->c_VISA_Read_error_out_CT_3, &heap->c_VISA_Read_error_out_CT_2, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x1, 3);*//* c_VISA_Read_error_out_CT_3 */
			heap->a_String_To_Byte_Array_unsign_9 = heap->a_String_To_Byte_Array_unsign_8;
			/*SetSignalReady( 0xD, 4);*//* a_String_To_Byte_Array_unsign_9 */
		}
		/* begin case */
		if ( heap->b_Equal__x___y__CS_1 ) {
			uInt32 diagramIdx = 58;
			static uInt16 nStep = 0;
			switch(nStep)
			/*********************************************************************************/
			/* Error Message */
			/*********************************************************************************/
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(9, 4);
					/*InitSignalReady( 0x0, 6);*//* c_Utility_Generate_Instrument_1 */
					/*InitSignalReady( 0xB, 4);*//* s_Utility_Generate_Instrument_1 */
					InitSignalReady(11, 4);
					/*InitSignalReady( 0xB, 2);*//* s_VISA_Read_VISA_resource_na_2 */
					/*InitSignalReady( 0x0, 5);*//* c_VISA_Read_error_out_6 */
					/*InitSignalReady( 0x0, 4);*//* c_VISA_Read_error_out_7 */
					/*InitSignalReady( 0xA, 5);*//* s_VISA_Read_VISA_resource_na_3 */
					/*InitSignalReady( 0xA, 3);*//* a_String_To_Byte_Array_unsig_1 */
					InitSignalReady(10, 1);
					/*InitSignalReady( 0xA, 0);*//* s_VISA_Read_read_buffer_6 */
					/*InitSignalReady( 0x5, 5);*//* dw_byte_count__0__4 */
					/*InitSignalReady( 0x9, 6);*//* a_Build_Array_appended_array_3 */
					/*InitSignalReady( 0x9, 4);*//* a_String_To_Byte_Array_unsig_2 */
					/*InitSignalReady( 0x7, 0);*//* l_To_Long_Integer_32bit_integer */
					/*InitSignalReady( 0x1C, 5);*//* by_Decrement_x_1 */
					/*InitSignalReady( 0x7, 2);*//* l_Add_x_y */
					/*InitSignalReady( 0x6, 2);*//* l_Constant_4 */
					/*InitSignalReady( 0x1D, 0);*//* by_Index_Array_element_3 */
					/*InitSignalReady( 0x7, 4);*//* l_index_5 */
					/*InitSignalReady( 0x7, 7);*//* a_String_To_Byte_Array_unsig_3 */
					/*InitSignalReady( 0x8, 1);*//* s_VISA_Read_read_buffer_7 */
					/*InitSignalReady( 0x21, 2);*//* b_status_1 */
					InitSignalReady(12, 3);
					/*InitSignalReady( 0x5, 4);*//* dw_byte_count__0__5 */
					/*InitSignalReady( 0x0, 3);*//* c_VISA_Read_error_out_CT_5 */
					/*InitSignalReady( 0x9, 7);*//* s_VISA_Read_VISA_resource_na_4 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->s_VISA_Read_VISA_resource_na_4 = heap->s_VISA_Read_VISA_resource_nam_10;
					/*SetSignalReady( 0x9, 7);*//* s_VISA_Read_VISA_resource_na_4 */
					UpdateProbes(&state, debugOffset, 158 /*0xE4A1620*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_na_4)); /* assign */
					SetSignalReady(12, 1);
					heap->l_Constant_4 = -1074001421;
					/*SetSignalReady( 0x6, 2);*//* l_Constant_4 */
					UpdateProbes(&state, debugOffset, 150 /*0xE4A99C0*/, (uChar*)&(heap->l_Constant_4)); /* assign */
					heap->dw_byte_count__0__5 = 1;
					/*SetSignalReady( 0x5, 4);*//* dw_byte_count__0__5 */
					UpdateProbes(&state, debugOffset, 156 /*0xE4A1740*/, (uChar*)&(heap->dw_byte_count__0__5)); /* assign */
					SetSignalReady(12, 1);
					heap->b_status_1 = true;
					/*SetSignalReady( 0x21, 2);*//* b_status_1 */
					UpdateProbes(&state, debugOffset, 155 /*0xE4A17A0*/, (uChar*)&(heap->b_status_1)); /* assign */
					SetSignalReady(11, 1);
					heap->l_index_5 = 0;
					/*SetSignalReady( 0x7, 4);*//* l_index_5 */
					UpdateProbes(&state, debugOffset, 152 /*0xE4A98A0*/, (uChar*)&(heap->l_index_5)); /* assign */
					heap->a_String_To_Byte_Array_unsig_2 = heap->a_String_To_Byte_Array_unsign_9;
					/*SetSignalReady( 0x9, 4);*//* a_String_To_Byte_Array_unsig_2 */
					UpdateProbes(&state, debugOffset, 146 /*0xE4A9C00*/, (uChar*)&(heap->a_String_To_Byte_Array_unsig_2)); /* assign */
					heap->dw_byte_count__0__4 = 2;
					/*SetSignalReady( 0x5, 5);*//* dw_byte_count__0__4 */
					UpdateProbes(&state, debugOffset, 144 /*0xE4A9D20*/, (uChar*)&(heap->dw_byte_count__0__4)); /* assign */
					MemMove( &heap->c_VISA_Read_error_out_CT_5, &heap->c_VISA_Read_error_out_CT_3, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 3);*//* c_VISA_Read_error_out_CT_5 */
					UpdateProbes(&state, debugOffset, 157 /*0xE4A16E0*/, (uChar*)&(heap->c_VISA_Read_error_out_CT_5)); /* assign */
					SetSignalReady(12, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					/**/
					/* VISA Read */
					/**/
					CCGDebugSynchNode(&state, 58, 59, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (VisaRead(heap->s_VISA_Read_VISA_resource_na_4,  &(heap->dw_byte_count__0__5),  uInt32DataType,  &(heap->c_VISA_Read_error_out_CT_5),  &(heap->s_VISA_Read_VISA_resource_na_3),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer_7),  &(heap->c_VISA_Read_error_out_7) ) == eFail) {
						CGenErr();
					}
					/*SetSignalReady( 0x0, 4);*//* c_VISA_Read_error_out_7 */
					UpdateProbes(&state, debugOffset, 140 /*0xE4A9F60*/, (uChar*)&(heap->c_VISA_Read_error_out_7)); /* assign */
					/*SetSignalReady( 0x8, 1);*//* s_VISA_Read_read_buffer_7 */
					UpdateProbes(&state, debugOffset, 154 /*0xE4A1800*/, (uChar*)&(heap->s_VISA_Read_read_buffer_7)); /* assign */
					/*SetSignalReady( 0xA, 5);*//* s_VISA_Read_VISA_resource_na_3 */
					UpdateProbes(&state, debugOffset, 141 /*0xE4A9EA0*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_na_3)); /* assign */
					/**/
					/* String To Byte Array */
					/**/
					CCGDebugSynchNode(&state, 59, 60, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_7, &(heap->a_String_To_Byte_Array_unsig_3))) {
						CGenErr();
					}
					/*SetSignalReady( 0x7, 7);*//* a_String_To_Byte_Array_unsig_3 */
					UpdateProbes(&state, debugOffset, 153 /*0xE4A1860*/, (uChar*)&(heap->a_String_To_Byte_Array_unsig_3)); /* assign */
					PDAArrIncRefCnt(heap->a_String_To_Byte_Array_unsig_3, (uInt16)1); /* Primitive */
/* Build array */
					CCGDebugSynchNode(&state, 60, 61, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ArrDimSize i;
						ArrDimSize dimSize=0;
						heap->a_Build_Array_appended_array_3 = PDAArrNewEmptyWithNDimsStatic( uCharDataType, (ArrDimSize)1, &g_staticArray_10 );
						if (!heap->a_Build_Array_appended_array_3){
							CGenErr();
						}
						dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsig_2), (ArrDimSize)0);
						dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsig_3), (ArrDimSize)0);
						PDAArrSetDim(((PDAArrPtr)heap->a_Build_Array_appended_array_3), (ArrDimSize)0, dimSize);
						if (!PDAArrAllocData(&heap->a_Build_Array_appended_array_3)){
							CGenErr();
						}
						i=0;
						if (!PDAArrAdd(heap->a_Build_Array_appended_array_3, i, heap->a_String_To_Byte_Array_unsig_2)) {
							CGenErr();
						}
						i += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsig_2), (ArrDimSize)0);
						PDAArrFree(heap->a_String_To_Byte_Array_unsig_2);
						if (!PDAArrAdd(heap->a_Build_Array_appended_array_3, i, heap->a_String_To_Byte_Array_unsig_3)) {
							CGenErr();
						}
						i += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsig_3), (ArrDimSize)0);
						PDAArrFree(heap->a_String_To_Byte_Array_unsig_3);
					}
					/*SetSignalReady( 0x9, 6);*//* a_Build_Array_appended_array_3 */
					UpdateProbes(&state, debugOffset, 145 /*0xE4A9CC0*/, (uChar*)&(heap->a_Build_Array_appended_array_3)); /* assign */
					SetSignalReady(9, 1);
					CCGDebugSynchNode(&state, 61, 62, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{ /* Array Index 1D */
						heap->by_Index_Array_element_3 = *(uChar *)NthElemFast(((PDAArrPtr)heap->a_String_To_Byte_Array_unsig_3), heap->l_index_5, 1);
						/*SetSignalReady( 0x1D, 0);*//* by_Index_Array_element_3 */
						UpdateProbes(&state, debugOffset, 151 /*0xE4A9960*/, (uChar*)&(heap->by_Index_Array_element_3)); /* assign */
					}
	if (heap->a_String_To_Byte_Array_unsig_3){--((PDAArrPtr)heap->a_String_To_Byte_Array_unsig_3)->refcnt;}
					/**/
					/* Decrement */
					/**/
					CCGDebugSynchNode(&state, 62, 63, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->by_Decrement_x_1 = (uChar)(heap->by_Index_Array_element_3 - 1);
					/*SetSignalReady( 0x1C, 5);*//* by_Decrement_x_1 */
					UpdateProbes(&state, debugOffset, 148 /*0xE4A9AE0*/, (uChar*)&(heap->by_Decrement_x_1)); /* assign */
					/**/
					/* To Long Integer */
					/**/
					CCGDebugSynchNode(&state, 63, 64, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->l_To_Long_Integer_32bit_integer = (int32)heap->by_Decrement_x_1;
					/*SetSignalReady( 0x7, 0);*//* l_To_Long_Integer_32bit_integer */
					UpdateProbes(&state, debugOffset, 147 /*0xE4A9BA0*/, (uChar*)&(heap->l_To_Long_Integer_32bit_integer)); /* assign */
					/**/
					/* Add */
					/**/
					CCGDebugSynchNode(&state, 64, 65, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->l_Add_x_y =  (heap->l_Constant_4 + heap->l_To_Long_Integer_32bit_integer);
					/*SetSignalReady( 0x7, 2);*//* l_Add_x_y */
					UpdateProbes(&state, debugOffset, 149 /*0xE4A9A20*/, (uChar*)&(heap->l_Add_x_y)); /* assign */
					SetSignalReady(11, 1);
					/**/
					/* VISA Read */
					/**/
					CCGDebugSynchNode(&state, 65, 66, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (VisaRead(heap->s_VISA_Read_VISA_resource_na_3,  &(heap->dw_byte_count__0__4),  uInt32DataType,  &(heap->c_VISA_Read_error_out_7),  &(heap->s_VISA_Read_VISA_resource_na_2),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer_6),  &(heap->c_VISA_Read_error_out_6) ) == eFail) {
						CGenErr();
					}
					/*SetSignalReady( 0x0, 5);*//* c_VISA_Read_error_out_6 */
					UpdateProbes(&state, debugOffset, 139 /*0xE4AA020*/, (uChar*)&(heap->c_VISA_Read_error_out_6)); /* assign */
					SetSignalReady(11, 1);
					/*SetSignalReady( 0xA, 0);*//* s_VISA_Read_read_buffer_6 */
					UpdateProbes(&state, debugOffset, 143 /*0xE4A9D80*/, (uChar*)&(heap->s_VISA_Read_read_buffer_6)); /* assign */
					SetSignalReady(10, 1);
					/*SetSignalReady( 0xB, 2);*//* s_VISA_Read_VISA_resource_na_2 */
					UpdateProbes(&state, debugOffset, 138 /*0xE4AA080*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_na_2)); /* assign */
					SetSignalReady(11, 1);
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 2 : {
					if (heap->runStat10782158 == eReady) {
					}
					CCGDebugSynchIUse(&state, 66, 67, 58, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility Generate Instrument Error.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStat10782158 == eReady) {
							CreateArgListStatic(heap->Args10782159, 4, 2 );
							argIn(heap->Args10782159, 0).nType = 0x0 | ClusterDataType;
							argIn(heap->Args10782159, 0).pValue = (void *)&heap->c_VISA_Read_error_out_6;
							argIn(heap->Args10782159, 1).nType = int32DataType;
							argIn(heap->Args10782159, 1).pValue = (void *)&heap->l_Add_x_y;
							argIn(heap->Args10782159, 2).nType = BooleanDataType;
							argIn(heap->Args10782159, 2).pValue = (void *)&heap->b_status_1;
							argIn(heap->Args10782159, 3).nType = StringDataType;
							argIn(heap->Args10782159, 3).pValue = (void *)&heap->s_VISA_Read_VISA_resource_na_2;
							argOut(heap->Args10782159, 0).nType = 0x0 | ClusterDataType;
							argOut(heap->Args10782159, 0).pValue = (void *)&heap->c_Utility_Generate_Instrument_1;
							argOut(heap->Args10782159, 1).nType = StringDataType;
							argOut(heap->Args10782159, 1).pValue = (void *)&heap->s_Utility_Generate_Instrument_1;
						}
						if (!Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782158.callerID) {
							Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782158.callerID = ++gCallerID;
						}
						heap->runStat10782158 = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Run( &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782158, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args10782159)[0], (ArgList *)((ArgList **)heap->Args10782159)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 67, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStat10782158 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStat10782158 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStat10782158 == eFinished)) {
							/*SetSignalReady( 0x0, 6);*//* c_Utility_Generate_Instrument_1 */
							UpdateProbes(&state, debugOffset, 136 /*0xE4AA200*/, (uChar*)&(heap->c_Utility_Generate_Instrument_1)); /* assign */
							SetSignalReady(9, 1);
							/*SetSignalReady( 0xB, 4);*//* s_Utility_Generate_Instrument_1 */
							UpdateProbes(&state, debugOffset, 137 /*0xE4AA140*/, (uChar*)&(heap->s_Utility_Generate_Instrument_1)); /* assign */
							SetSignalReady(9, 1);
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (!bRunToFinish && (runStat == eNotFinished)) {
						return eNotFinished;
					}
					if (heap->runStat10782158 == eFinished) {
						heap->runStat10782158 = eReady;
					}
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 4 : {
					/**/
					/* String To Byte Array */
					/**/
					CCGDebugSynchNode(&state, 67, 68, 58, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_6, &(heap->a_String_To_Byte_Array_unsig_1))) {
						CGenErr();
					}
					/*SetSignalReady( 0xA, 3);*//* a_String_To_Byte_Array_unsig_1 */
					UpdateProbes(&state, debugOffset, 142 /*0xE4A9DE0*/, (uChar*)&(heap->a_String_To_Byte_Array_unsig_1)); /* assign */
					SetSignalReady(9, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 5 : {
					heap->a_Case_Structure_CT_16 = heap->a_Build_Array_appended_array_3;
					/*SetSignalReady( 0xD, 2);*//* a_Case_Structure_CT_16 */
					heap->a_Case_Structure_CT_17 = heap->a_String_To_Byte_Array_unsig_1;
					/*SetSignalReady( 0xD, 0);*//* a_Case_Structure_CT_17 */
					MemMove( &heap->c_Case_Structure_CT_21, &heap->c_Utility_Generate_Instrument_1, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 1);*//* c_Case_Structure_CT_21 */
					heap->s_Case_Structure_CT_21 = heap->s_Utility_Generate_Instrument_1;
					/*SetSignalReady( 0xD, 1);*//* s_Case_Structure_CT_21 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 68, 58, &snode72F304C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 56;
			static uInt16 nStep = 0;
			switch(nStep)
			/*********************************************************************************/
			/* Transmit Error */
			/*********************************************************************************/
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(13, 4);
					/*InitSignalReady( 0xC, 7);*//* s_Utility_Generate_Instrument__1 */
					InitSignalReady(14, 4);
					/*InitSignalReady( 0xC, 6);*//* s_VISA_Read_VISA_resource_na_1 */
					/*InitSignalReady( 0xC, 5);*//* a_String_To_Byte_Array_unsign_10 */
					/*InitSignalReady( 0x1F, 6);*//* b_status */
					/*InitSignalReady( 0x1, 0);*//* c_Utility_Generate_Instrument__1 */
					/*InitSignalReady( 0x0, 7);*//* c_VISA_Read_error_out_CT_4 */
					/*InitSignalReady( 0x6, 1);*//* l_Constant_3 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->s_VISA_Read_VISA_resource_na_1 = heap->s_VISA_Read_VISA_resource_nam_10;
					/*SetSignalReady( 0xC, 6);*//* s_VISA_Read_VISA_resource_na_1 */
					UpdateProbes(&state, debugOffset, 130 /*0x107824B8*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_na_1)); /* assign */
					SetSignalReady(14, 1);
					heap->l_Constant_3 = -1074001423;
					/*SetSignalReady( 0x6, 1);*//* l_Constant_3 */
					UpdateProbes(&state, debugOffset, 135 /*0x107821B8*/, (uChar*)&(heap->l_Constant_3)); /* assign */
					SetSignalReady(14, 1);
					heap->b_status = true;
					/*SetSignalReady( 0x1F, 6);*//* b_status */
					UpdateProbes(&state, debugOffset, 132 /*0x10782398*/, (uChar*)&(heap->b_status)); /* assign */
					SetSignalReady(14, 1);
					heap->a_String_To_Byte_Array_unsign_10 = heap->a_String_To_Byte_Array_unsign_9;
					/*SetSignalReady( 0xC, 5);*//* a_String_To_Byte_Array_unsign_10 */
					UpdateProbes(&state, debugOffset, 131 /*0x107823F8*/, (uChar*)&(heap->a_String_To_Byte_Array_unsign_10)); /* assign */
					SetSignalReady(13, 2);
					PDAArrIncRefCnt(heap->a_String_To_Byte_Array_unsign_10, (uInt16)1); /* SelectTunnel */
					MemMove( &heap->c_VISA_Read_error_out_CT_4, &heap->c_VISA_Read_error_out_CT_3, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x0, 7);*//* c_VISA_Read_error_out_CT_4 */
					UpdateProbes(&state, debugOffset, 134 /*0x10782278*/, (uChar*)&(heap->c_VISA_Read_error_out_CT_4)); /* assign */
					SetSignalReady(14, 1);
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 1 : {
					if (heap->runStat10782998 == eReady) {
					}
					CCGDebugSynchIUse(&state, 56, 57, 56, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility Generate Instrument Error.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStat10782998 == eReady) {
							CreateArgListStatic(heap->Args10782999, 4, 2 );
							argIn(heap->Args10782999, 0).nType = 0x0 | ClusterDataType;
							argIn(heap->Args10782999, 0).pValue = (void *)&heap->c_VISA_Read_error_out_CT_4;
							argIn(heap->Args10782999, 1).nType = int32DataType;
							argIn(heap->Args10782999, 1).pValue = (void *)&heap->l_Constant_3;
							argIn(heap->Args10782999, 2).nType = BooleanDataType;
							argIn(heap->Args10782999, 2).pValue = (void *)&heap->b_status;
							argIn(heap->Args10782999, 3).nType = StringDataType;
							argIn(heap->Args10782999, 3).pValue = (void *)&heap->s_VISA_Read_VISA_resource_na_1;
							argOut(heap->Args10782999, 0).nType = 0x0 | ClusterDataType;
							argOut(heap->Args10782999, 0).pValue = (void *)&heap->c_Utility_Generate_Instrument__1;
							argOut(heap->Args10782999, 1).nType = StringDataType;
							argOut(heap->Args10782999, 1).pValue = (void *)&heap->s_Utility_Generate_Instrument__1;
						}
						if (!Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782998.callerID) {
							Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782998.callerID = ++gCallerID;
						}
						heap->runStat10782998 = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Run( &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i10782998, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args10782999)[0], (ArgList *)((ArgList **)heap->Args10782999)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 57, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStat10782998 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStat10782998 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStat10782998 == eFinished)) {
							/*SetSignalReady( 0x1, 0);*//* c_Utility_Generate_Instrument__1 */
							UpdateProbes(&state, debugOffset, 133 /*0x10782338*/, (uChar*)&(heap->c_Utility_Generate_Instrument__1)); /* assign */
							SetSignalReady(13, 1);
							/*SetSignalReady( 0xC, 7);*//* s_Utility_Generate_Instrument__1 */
							UpdateProbes(&state, debugOffset, 129 /*0x10782578*/, (uChar*)&(heap->s_Utility_Generate_Instrument__1)); /* assign */
							SetSignalReady(13, 1);
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (!bRunToFinish && (runStat == eNotFinished)) {
						return eNotFinished;
					}
					if (heap->runStat10782998 == eFinished) {
						heap->runStat10782998 = eReady;
					}
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 3 : {
					heap->a_Case_Structure_CT_16 = heap->a_String_To_Byte_Array_unsign_10;
					/*SetSignalReady( 0xD, 2);*//* a_Case_Structure_CT_16 */
					heap->a_Case_Structure_CT_17 = heap->a_String_To_Byte_Array_unsign_10;
					/*SetSignalReady( 0xD, 0);*//* a_Case_Structure_CT_17 */
					MemMove( &heap->c_Case_Structure_CT_21, &heap->c_Utility_Generate_Instrument__1, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 1);*//* c_Case_Structure_CT_21 */
					heap->s_Case_Structure_CT_21 = heap->s_Utility_Generate_Instrument__1;
					/*SetSignalReady( 0xD, 1);*//* s_Case_Structure_CT_21 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 57, 56, &snode72F304C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		MemMove( &heap->c_Case_Structure_CT_20, &heap->c_Case_Structure_CT_21, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x1, 5);*//* c_Case_Structure_CT_20 */
		UpdateProbes(&state, debugOffset, 123 /*0xE4A09C0*/, (uChar*)&(heap->c_Case_Structure_CT_20)); /* assign */
		SetSignalReady(8, 1);
		heap->a_Case_Structure_CT_15 = heap->a_Case_Structure_CT_16;
		/*SetSignalReady( 0xE, 6);*//* a_Case_Structure_CT_15 */
		UpdateProbes(&state, debugOffset, 121 /*0xE4A0AE0*/, (uChar*)&(heap->a_Case_Structure_CT_15)); /* assign */
		SetSignalReady(8, 1);
		heap->s_Case_Structure_CT_20 = heap->s_Case_Structure_CT_21;
		/*SetSignalReady( 0xE, 7);*//* s_Case_Structure_CT_20 */
		UpdateProbes(&state, debugOffset, 120 /*0xE4A0BA0*/, (uChar*)&(heap->s_Case_Structure_CT_20)); /* assign */
		SetSignalReady(8, 1);
		heap->a_Case_Structure_CT_14 = heap->a_Case_Structure_CT_17;
		/*SetSignalReady( 0xF, 0);*//* a_Case_Structure_CT_14 */
		UpdateProbes(&state, debugOffset, 119 /*0xE4A0C60*/, (uChar*)&(heap->a_Case_Structure_CT_14)); /* assign */
		SetSignalReady(8, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F304C, 55, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F25CC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F25CC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F25CC == eReady) {
			CCGDebugSynchSNode(&state, 37, 38, 33, &snode72F25CC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatE1F61C9 = eReady;
			heap->runStatE1F5160 = eReady;
			heap->runStat72F304C = eReady;
			heap->runStatE1F61CA = eReady;
			heap->runStatE1F69C9 = eReady;
			heap->runStatE589F60 = eReady;
			heap->runStatE1F69CA = eReady;
			heap->b_Not_Equal__x____y__CS = heap->b_Not_Equal__x____y__2;
			/*SetSignalReady( 0x20, 2);*//* b_Not_Equal__x____y__CS */
			heap->s_VISA_Read_VISA_resource_nam_5 = heap->s_VISA_Read_VISA_resource_nam_4;
			/*SetSignalReady( 0x13, 1);*//* s_VISA_Read_VISA_resource_nam_5 */
			MemMove( &heap->c_VISA_Read_error_out_CT, &heap->c_VISA_Read_error_out_3, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x2, 5);*//* c_VISA_Read_error_out_CT */
			heap->by_Index_Array_element_CT = heap->by_Index_Array_element_2;
			/*SetSignalReady( 0x1C, 6);*//* by_Index_Array_element_CT */
			heap->by_Sent_Command__0__CT_4 = heap->by_Sent_Command__0__CT_3;
			/*SetSignalReady( 0x1D, 5);*//* by_Sent_Command__0__CT_4 */
			heap->a_String_To_Byte_Array_unsign_4 = heap->a_String_To_Byte_Array_unsign_3;
			/*SetSignalReady( 0x13, 7);*//* a_String_To_Byte_Array_unsign_4 */
			heap->by_Length_Of_Sent_MSG__0__CT_4 = heap->by_Length_Of_Sent_MSG__0__CT_3;
			/*SetSignalReady( 0x1C, 4);*//* by_Length_Of_Sent_MSG__0__CT_4 */
		}
		/* begin case */
		if ( heap->b_Not_Equal__x____y__CS ) {
			uInt32 diagramIdx = 52;
			static uInt16 nStep = 0;
			switch(nStep)
			/*********************************************************************************/
			/* Error Message */
			/*********************************************************************************/
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(16, 2);
					/*InitSignalReady( 0x16, 7);*//* by_y_1 */
					/*InitSignalReady( 0x17, 0);*//* by_Sent_Command__0__CT_5 */
					InitSignalReady(8, 5);
					/*InitSignalReady( 0xF, 1);*//* a_unsigned_byte_array_1 */
					/*InitSignalReady( 0xF, 0);*//* a_Case_Structure_CT_14 */
					/*InitSignalReady( 0xE, 7);*//* s_Case_Structure_CT_20 */
					/*InitSignalReady( 0xE, 6);*//* a_Case_Structure_CT_15 */
					InitSignalReady(15, 4);
					/*InitSignalReady( 0xE, 2);*//* a_String_To_Byte_Array_unsign_8 */
					/*InitSignalReady( 0x1, 5);*//* c_Case_Structure_CT_20 */
					/*InitSignalReady( 0x20, 1);*//* b_Equal__x___y__2 */
					/*InitSignalReady( 0x18, 0);*//* by_Add_x_y */
					/*InitSignalReady( 0x18, 1);*//* by_Index_Array_element_CT_1 */
					/*InitSignalReady( 0x1, 4);*//* c_VISA_Read_error_out_CT_2 */
					/*InitSignalReady( 0xD, 7);*//* s_VISA_Read_VISA_resource_nam_9 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->s_VISA_Read_VISA_resource_nam_9 = heap->s_VISA_Read_VISA_resource_nam_5;
					/*SetSignalReady( 0xD, 7);*//* s_VISA_Read_VISA_resource_nam_9 */
					UpdateProbes(&state, debugOffset, 128 /*0x127778C8*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_9)); /* assign */
					SetSignalReady(15, 1);
					heap->a_String_To_Byte_Array_unsign_8 = heap->a_String_To_Byte_Array_unsign_4;
					/*SetSignalReady( 0xE, 2);*//* a_String_To_Byte_Array_unsign_8 */
					UpdateProbes(&state, debugOffset, 122 /*0xE4A0A80*/, (uChar*)&(heap->a_String_To_Byte_Array_unsign_8)); /* assign */
					SetSignalReady(15, 1);
					/*SetSignalReady( 0xF, 1);*//* a_unsigned_byte_array_1 */
					UpdateProbes(&state, debugOffset, 118 /*0xE4A0CC0*/, (uChar*)&(heap->a_unsigned_byte_array_1)); /* assign */
					SetSignalReady(8, 1);
					PDAArrIncRefCnt(heap->a_unsigned_byte_array_1, (uInt16)1); /* BDConst - alloc type */
					MemMove( &heap->c_VISA_Read_error_out_CT_2, &heap->c_VISA_Read_error_out_CT, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 4);*//* c_VISA_Read_error_out_CT_2 */
					UpdateProbes(&state, debugOffset, 127 /*0x12777988*/, (uChar*)&(heap->c_VISA_Read_error_out_CT_2)); /* assign */
					SetSignalReady(15, 1);
					heap->by_Index_Array_element_CT_1 = heap->by_Index_Array_element_CT;
					/*SetSignalReady( 0x18, 1);*//* by_Index_Array_element_CT_1 */
					UpdateProbes(&state, debugOffset, 126 /*0x127779E8*/, (uChar*)&(heap->by_Index_Array_element_CT_1)); /* assign */
					heap->by_Sent_Command__0__CT_5 = heap->by_Sent_Command__0__CT_4;
					/*SetSignalReady( 0x17, 0);*//* by_Sent_Command__0__CT_5 */
					UpdateProbes(&state, debugOffset, 117 /*0xE4A0D80*/, (uChar*)&(heap->by_Sent_Command__0__CT_5)); /* assign */
					SetSignalReady(16, 1);
					heap->by_y_1 = 128;
					/*SetSignalReady( 0x16, 7);*//* by_y_1 */
					UpdateProbes(&state, debugOffset, 116 /*0xE4A0DE0*/, (uChar*)&(heap->by_y_1)); /* assign */
					SetSignalReady(16, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					/**/
					/* Add */
					/**/
					CCGDebugSynchNode(&state, 52, 53, 52, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->by_Add_x_y =  (heap->by_y_1 + heap->by_Sent_Command__0__CT_5);
					/*SetSignalReady( 0x18, 0);*//* by_Add_x_y */
					UpdateProbes(&state, debugOffset, 125 /*0x12777AA8*/, (uChar*)&(heap->by_Add_x_y)); /* assign */
					/**/
					/* Equal? */
					/**/
					CCGDebugSynchNode(&state, 53, 54, 52, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->b_Equal__x___y__2 =  (heap->by_Add_x_y == heap->by_Index_Array_element_CT_1);
					/*SetSignalReady( 0x20, 1);*//* b_Equal__x___y__2 */
					UpdateProbes(&state, debugOffset, 124 /*0xE4A0900*/, (uChar*)&(heap->b_Equal__x___y__2)); /* assign */
					SetSignalReady(15, 1);
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 2 : {
					heap->runStat72F304C = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F304C( bRunToFinish  );
					if (heap->runStat72F304C == eNotFinished) {
						return eNotFinished;
					}
					else if (heap->runStat72F304C == eFail) {
						CGenErr();
					}
					heap->runStat72F304C = eReady;
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 3 : {
					heap->a_Case_Structure_CT_12 = heap->a_Case_Structure_CT_15;
					/*SetSignalReady( 0x13, 3);*//* a_Case_Structure_CT_12 */
					heap->a_Case_Structure_CT_11 = heap->a_Case_Structure_CT_14;
					/*SetSignalReady( 0x12, 1);*//* a_Case_Structure_CT_11 */
					heap->a_Case_Structure_CT_13 = heap->a_unsigned_byte_array_1;
					/*SetSignalReady( 0x13, 5);*//* a_Case_Structure_CT_13 */
					MemMove( &heap->c_Case_Structure_CT_19, &heap->c_Case_Structure_CT_20, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x2, 2);*//* c_Case_Structure_CT_19 */
					heap->s_Case_Structure_CT_19 = heap->s_Case_Structure_CT_20;
					/*SetSignalReady( 0x13, 6);*//* s_Case_Structure_CT_19 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 55, 52, &snode72F25CC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 45;
			static uInt16 nStep = 0;
			switch(nStep)
			/*********************************************************************************/
			/* GoodMessage */
			/*********************************************************************************/
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(18, 2);
					/*InitSignalReady( 0x1B, 7);*//* by_y */
					/*InitSignalReady( 0x1A, 3);*//* by_Subtract_x_y */
					/*InitSignalReady( 0x19, 6);*//* by_Length_Of_Sent_MSG__0__CT_5 */
					InitSignalReady(17, 5);
					/*InitSignalReady( 0x13, 2);*//* a_String_To_Byte_Array_unsign_5 */
					/*InitSignalReady( 0x12, 7);*//* s_VISA_Read_VISA_resource_nam_6 */
					/*InitSignalReady( 0x12, 6);*//* a_String_To_Byte_Array_unsign_6 */
					/*InitSignalReady( 0x11, 7);*//* s_VISA_Read_read_buffer_4 */
					/*InitSignalReady( 0x2, 0);*//* c_VISA_Read_error_out_4 */
					/*InitSignalReady( 0x5, 3);*//* dw_byte_count__0__3 */
					/*InitSignalReady( 0x11, 3);*//* s_VISA_Read_VISA_resource_nam_7 */
					/*InitSignalReady( 0x1, 7);*//* c_VISA_Read_error_out_5 */
					/*InitSignalReady( 0x10, 6);*//* a_Build_Array_appended_array_2 */
					/*InitSignalReady( 0xF, 6);*//* s_VISA_Read_read_buffer_5 */
					/*InitSignalReady( 0xF, 5);*//* a_String_To_Byte_Array_unsign_7 */
					/*InitSignalReady( 0xF, 2);*//* s_VISA_Read_VISA_resource_nam_8 */
					/*InitSignalReady( 0x1, 6);*//* c_VISA_Read_error_out_CT_1 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->s_VISA_Read_VISA_resource_nam_8 = heap->s_VISA_Read_VISA_resource_nam_5;
					/*SetSignalReady( 0xF, 2);*//* s_VISA_Read_VISA_resource_nam_8 */
					UpdateProbes(&state, debugOffset, 114 /*0xE1F52E0*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_8)); /* assign */
					heap->a_String_To_Byte_Array_unsign_7 = heap->a_String_To_Byte_Array_unsign_4;
					/*SetSignalReady( 0xF, 5);*//* a_String_To_Byte_Array_unsign_7 */
					UpdateProbes(&state, debugOffset, 113 /*0xE1F5340*/, (uChar*)&(heap->a_String_To_Byte_Array_unsign_7)); /* assign */
					heap->dw_byte_count__0__3 = 2;
					/*SetSignalReady( 0x5, 3);*//* dw_byte_count__0__3 */
					UpdateProbes(&state, debugOffset, 108 /*0xE1F5640*/, (uChar*)&(heap->dw_byte_count__0__3)); /* assign */
					MemMove( &heap->c_VISA_Read_error_out_CT_1, &heap->c_VISA_Read_error_out_CT, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x1, 6);*//* c_VISA_Read_error_out_CT_1 */
					UpdateProbes(&state, debugOffset, 115 /*0xE1F5220*/, (uChar*)&(heap->c_VISA_Read_error_out_CT_1)); /* assign */
					heap->by_Length_Of_Sent_MSG__0__CT_5 = heap->by_Length_Of_Sent_MSG__0__CT_4;
					/*SetSignalReady( 0x19, 6);*//* by_Length_Of_Sent_MSG__0__CT_5 */
					UpdateProbes(&state, debugOffset, 102 /*0xE1F59A0*/, (uChar*)&(heap->by_Length_Of_Sent_MSG__0__CT_5)); /* assign */
					SetSignalReady(18, 1);
					heap->by_y = 4;
					/*SetSignalReady( 0x1B, 7);*//* by_y */
					UpdateProbes(&state, debugOffset, 100 /*0xE1F5AC0*/, (uChar*)&(heap->by_y)); /* assign */
					SetSignalReady(18, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					/**/
					/* Subtract */
					/**/
					CCGDebugSynchNode(&state, 45, 46, 45, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					heap->by_Subtract_x_y =  (heap->by_Length_Of_Sent_MSG__0__CT_5 - heap->by_y);
					/*SetSignalReady( 0x1A, 3);*//* by_Subtract_x_y */
					UpdateProbes(&state, debugOffset, 101 /*0xE1F5A00*/, (uChar*)&(heap->by_Subtract_x_y)); /* assign */
					/**/
					/* VISA Read */
					/**/
					CCGDebugSynchNode(&state, 46, 47, 45, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (VisaRead(heap->s_VISA_Read_VISA_resource_nam_8,  &(heap->by_Subtract_x_y),  uCharDataType,  &(heap->c_VISA_Read_error_out_CT_1),  &(heap->s_VISA_Read_VISA_resource_nam_7),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer_5),  &(heap->c_VISA_Read_error_out_5) ) == eFail) {
						CGenErr();
					}
					/*SetSignalReady( 0x1, 7);*//* c_VISA_Read_error_out_5 */
					UpdateProbes(&state, debugOffset, 110 /*0xE1F5520*/, (uChar*)&(heap->c_VISA_Read_error_out_5)); /* assign */
					/*SetSignalReady( 0xF, 6);*//* s_VISA_Read_read_buffer_5 */
					UpdateProbes(&state, debugOffset, 112 /*0xE1F5400*/, (uChar*)&(heap->s_VISA_Read_read_buffer_5)); /* assign */
					/*SetSignalReady( 0x11, 3);*//* s_VISA_Read_VISA_resource_nam_7 */
					UpdateProbes(&state, debugOffset, 109 /*0xE1F55E0*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_7)); /* assign */
					/**/
					/* String To Byte Array */
					/**/
					CCGDebugSynchNode(&state, 47, 48, 45, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_5, &(heap->a_String_To_Byte_Array_unsign_5))) {
						CGenErr();
					}
					/*SetSignalReady( 0x13, 2);*//* a_String_To_Byte_Array_unsign_5 */
					UpdateProbes(&state, debugOffset, 103 /*0xE1F5940*/, (uChar*)&(heap->a_String_To_Byte_Array_unsign_5)); /* assign */
					SetSignalReady(17, 1);
					PDAArrIncRefCnt(heap->a_String_To_Byte_Array_unsign_5, (uInt16)1); /* Primitive */
/* Build array */
					CCGDebugSynchNode(&state, 48, 49, 45, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ArrDimSize i;
						ArrDimSize dimSize=0;
						heap->a_Build_Array_appended_array_2 = PDAArrNewEmptyWithNDimsStatic( uCharDataType, (ArrDimSize)1, &g_staticArray_14 );
						if (!heap->a_Build_Array_appended_array_2){
							CGenErr();
						}
						dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_7), (ArrDimSize)0);
						dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_5), (ArrDimSize)0);
						PDAArrSetDim(((PDAArrPtr)heap->a_Build_Array_appended_array_2), (ArrDimSize)0, dimSize);
						if (!PDAArrAllocData(&heap->a_Build_Array_appended_array_2)){
							CGenErr();
						}
						i=0;
						if (!PDAArrAdd(heap->a_Build_Array_appended_array_2, i, heap->a_String_To_Byte_Array_unsign_7)) {
							CGenErr();
						}
						i += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_7), (ArrDimSize)0);
						PDAArrFree(heap->a_String_To_Byte_Array_unsign_7);
						if (!PDAArrAdd(heap->a_Build_Array_appended_array_2, i, heap->a_String_To_Byte_Array_unsign_5)) {
							CGenErr();
						}
						i += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_5), (ArrDimSize)0);
						PDAArrFree(heap->a_String_To_Byte_Array_unsign_5);
					}
					/*SetSignalReady( 0x10, 6);*//* a_Build_Array_appended_array_2 */
					UpdateProbes(&state, debugOffset, 111 /*0xE1F5460*/, (uChar*)&(heap->a_Build_Array_appended_array_2)); /* assign */
					SetSignalReady(17, 1);
					/**/
					/* VISA Read */
					/**/
					CCGDebugSynchNode(&state, 49, 50, 45, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (VisaRead(heap->s_VISA_Read_VISA_resource_nam_7,  &(heap->dw_byte_count__0__3),  uInt32DataType,  &(heap->c_VISA_Read_error_out_5),  &(heap->s_VISA_Read_VISA_resource_nam_6),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer_4),  &(heap->c_VISA_Read_error_out_4) ) == eFail) {
						CGenErr();
					}
					/*SetSignalReady( 0x2, 0);*//* c_VISA_Read_error_out_4 */
					UpdateProbes(&state, debugOffset, 107 /*0xE1F5700*/, (uChar*)&(heap->c_VISA_Read_error_out_4)); /* assign */
					SetSignalReady(17, 1);
					/*SetSignalReady( 0x11, 7);*//* s_VISA_Read_read_buffer_4 */
					UpdateProbes(&state, debugOffset, 106 /*0xE1F57C0*/, (uChar*)&(heap->s_VISA_Read_read_buffer_4)); /* assign */
					/*SetSignalReady( 0x12, 7);*//* s_VISA_Read_VISA_resource_nam_6 */
					UpdateProbes(&state, debugOffset, 104 /*0xE1F58E0*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_6)); /* assign */
					SetSignalReady(17, 1);
					/**/
					/* String To Byte Array */
					/**/
					CCGDebugSynchNode(&state, 50, 51, 45, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_4, &(heap->a_String_To_Byte_Array_unsign_6))) {
						CGenErr();
					}
					/*SetSignalReady( 0x12, 6);*//* a_String_To_Byte_Array_unsign_6 */
					UpdateProbes(&state, debugOffset, 105 /*0xE1F5820*/, (uChar*)&(heap->a_String_To_Byte_Array_unsign_6)); /* assign */
					SetSignalReady(17, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 2 : {
					heap->a_Case_Structure_CT_12 = heap->a_Build_Array_appended_array_2;
					/*SetSignalReady( 0x13, 3);*//* a_Case_Structure_CT_12 */
					heap->a_Case_Structure_CT_11 = heap->a_String_To_Byte_Array_unsign_6;
					/*SetSignalReady( 0x12, 1);*//* a_Case_Structure_CT_11 */
					heap->a_Case_Structure_CT_13 = heap->a_String_To_Byte_Array_unsign_5;
					/*SetSignalReady( 0x13, 5);*//* a_Case_Structure_CT_13 */
					MemMove( &heap->c_Case_Structure_CT_19, &heap->c_VISA_Read_error_out_4, sizeof( cl_00000 ) );
					/*SetSignalReady( 0x2, 2);*//* c_Case_Structure_CT_19 */
					heap->s_Case_Structure_CT_19 = heap->s_VISA_Read_VISA_resource_nam_6;
					/*SetSignalReady( 0x13, 6);*//* s_Case_Structure_CT_19 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 51, 45, &snode72F25CC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		heap->a_Case_Structure_CT_10 = heap->a_Case_Structure_CT_11;
		/*SetSignalReady( 0x11, 5);*//* a_Case_Structure_CT_10 */
		UpdateProbes(&state, debugOffset, 91 /*0x1277CC70*/, (uChar*)&(heap->a_Case_Structure_CT_10)); /* assign */
		SetSignalReady(7, 1);
		heap->a_Case_Structure_CT_8 = heap->a_Case_Structure_CT_12;
		/*SetSignalReady( 0x10, 1);*//* a_Case_Structure_CT_8 */
		UpdateProbes(&state, debugOffset, 79 /*0x12776D88*/, (uChar*)&(heap->a_Case_Structure_CT_8)); /* assign */
		SetSignalReady(6, 1);
		MemMove( &heap->c_Case_Structure_CT_18, &heap->c_Case_Structure_CT_19, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x3, 4);*//* c_Case_Structure_CT_18 */
		UpdateProbes(&state, debugOffset, 83 /*0x1277D0F0*/, (uChar*)&(heap->c_Case_Structure_CT_18)); /* assign */
		SetSignalReady(6, 1);
		heap->s_Case_Structure_CT_18 = heap->s_Case_Structure_CT_19;
		/*SetSignalReady( 0x10, 0);*//* s_Case_Structure_CT_18 */
		UpdateProbes(&state, debugOffset, 78 /*0x12776E48*/, (uChar*)&(heap->s_Case_Structure_CT_18)); /* assign */
		SetSignalReady(6, 1);
		heap->a_Case_Structure_CT_9 = heap->a_Case_Structure_CT_13;
		/*SetSignalReady( 0x10, 3);*//* a_Case_Structure_CT_9 */
		UpdateProbes(&state, debugOffset, 81 /*0x12776C68*/, (uChar*)&(heap->a_Case_Structure_CT_9)); /* assign */
		SetSignalReady(3, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F25CC, 38, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F344C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F344C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F344C == eReady) {
			CCGDebugSynchSNode(&state, 15, 16, 12, &snode72F344C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat12E87819 = eReady;
			heap->runStat12E8781A = eReady;
			heap->runStat12E87999 = eReady;
			heap->runStat101D4D28 = eReady;
			heap->runStat12E8799A = eReady;
			heap->b_Equal__x___y__CS = heap->b_Equal__x___y__1;
			/*SetSignalReady( 0x20, 6);*//* b_Equal__x___y__CS */
			heap->a_String_To_Byte_Array_unsign_1 = heap->a_String_To_Byte_Array_unsigned;
			/*SetSignalReady( 0xC, 0);*//* a_String_To_Byte_Array_unsign_1 */
		}
		/* begin case */
		if ( heap->b_Equal__x___y__CS ) {
			uInt32 diagramIdx = 31;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(28, 1);
					/*InitSignalReady( 0x1F, 3);*//* by_Constant */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					/* Free unwired input select tunnel. */
	if (heap->a_String_To_Byte_Array_unsign_1){--((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_1)->refcnt;}
					heap->by_Constant = 3;
					/*SetSignalReady( 0x1F, 3);*//* by_Constant */
					UpdateProbes(&state, debugOffset, 68 /*0x101D4728*/, (uChar*)&(heap->by_Constant)); /* assign */
					SetSignalReady(28, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					heap->by_Case_Structure_CT_1 = heap->by_Constant;
					/*SetSignalReady( 0x1A, 6);*//* by_Case_Structure_CT_1 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 31, 31, &snode72F344C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		/* begin case */
		else {
			uInt32 diagramIdx = 29;
			static uInt16 nStep = 0;
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(30, 2);
					/*InitSignalReady( 0xC, 1);*//* a_String_To_Byte_Array_unsign_2 */
					InitSignalReady(29, 1);
					/*InitSignalReady( 0x1A, 4);*//* by_Index_Array_element_1 */
					/*InitSignalReady( 0x7, 3);*//* l_index_3 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					heap->l_index_3 = 2;
					/*SetSignalReady( 0x7, 3);*//* l_index_3 */
					UpdateProbes(&state, debugOffset, 67 /*0x101D49C8*/, (uChar*)&(heap->l_index_3)); /* assign */
					SetSignalReady(30, 1);
					heap->a_String_To_Byte_Array_unsign_2 = heap->a_String_To_Byte_Array_unsign_1;
					/*SetSignalReady( 0xC, 1);*//* a_String_To_Byte_Array_unsign_2 */
					UpdateProbes(&state, debugOffset, 65 /*0x101D4AE8*/, (uChar*)&(heap->a_String_To_Byte_Array_unsign_2)); /* assign */
					SetSignalReady(30, 1);
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 1 : {
					CCGDebugSynchNode(&state, 29, 30, 29, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{ /* Array Index 1D */
						heap->by_Index_Array_element_1 = *(uChar *)NthElemFast(((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_2), heap->l_index_3, 1);
						/*SetSignalReady( 0x1A, 4);*//* by_Index_Array_element_1 */
						UpdateProbes(&state, debugOffset, 66 /*0x101D4A88*/, (uChar*)&(heap->by_Index_Array_element_1)); /* assign */
						SetSignalReady(29, 1);
					}
	if (heap->a_String_To_Byte_Array_unsign_2){--((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_2)->refcnt;}
					nStep++;}
/* start q el linear (0 or 1 struct) */
				case 2 : {
					heap->by_Case_Structure_CT_1 = heap->by_Index_Array_element_1;
					/*SetSignalReady( 0x1A, 6);*//* by_Case_Structure_CT_1 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 30, 29, &snode72F344C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
		} /* end case */
		heap->by_Case_Structure_CT = heap->by_Case_Structure_CT_1;
		/*SetSignalReady( 0x1D, 3);*//* by_Case_Structure_CT */
		UpdateProbes(&state, debugOffset, 34 /*0x13315938*/, (uChar*)&(heap->by_Case_Structure_CT)); /* assign */
		SetSignalReady(27, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F344C, 16, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F97CC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F97CC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F97CC == eReady) {
			CCGDebugSynchSNode(&state, 10, 11, 9, &snode72F97CC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatE4783E9 = eReady;
			heap->runStatE4783EA = eReady;
			heap->runStat10590DA9 = eReady;
			heap->runStat13316058 = eReady;
			heap->runStat72F344C = eReady;
			heap->runStat101D4548 = eReady;
			heap->runStat101D4DE8 = eReady;
			heap->runStat101D44E8 = eReady;
			heap->runStat101D4EA8 = eReady;
			heap->runStat10590DAA = eReady;
			if (!PDAClusterGetElemByPosStatic( &heap->c_VISA_Read_error_out, 0x0 | ClusterDataType, 0, &heap->c_VISA_Read_error_out_CS, BooleanDataType, NULL )) {
				CGenErr();
			}
			/*SetSignalReady( 0x21, 1);*//* c_VISA_Read_error_out_CS */
			heap->s_VISA_Read_read_buffer_CT = heap->s_VISA_Read_read_buffer;
			/*SetSignalReady( 0x8, 5);*//* s_VISA_Read_read_buffer_CT */
			heap->s_VISA_Read_VISA_resource_name__1 = heap->s_VISA_Read_VISA_resource_name_;
			/*SetSignalReady( 0x8, 4);*//* s_VISA_Read_VISA_resource_name__1 */
		}
		switch ( heap->c_VISA_Read_error_out_CS ) {
			/* begin case */
			case 1 : {
				uInt32 diagramIdx = 32;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(22, 3);
						/*InitSignalReady( 0xE, 3);*//* a_unsigned_byte_array */
						/*InitSignalReady( 0xE, 4);*//* s_VISA_Read_VISA_resource_nam_3 */
						/*InitSignalReady( 0x3, 6);*//* c_VISA_Read_error_out_CS_2 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						/* Free unwired input select tunnel. */
	if (heap->s_VISA_Read_read_buffer_CT && --((PDAStrPtr)heap->s_VISA_Read_read_buffer_CT)->refcnt == 0 && !((PDAStrPtr)heap->s_VISA_Read_read_buffer_CT)->staticStr) {
							MemHandleFree( heap->s_VISA_Read_read_buffer_CT );
						}
						/*SetSignalReady( 0xE, 3);*//* a_unsigned_byte_array */
						UpdateProbes(&state, debugOffset, 69 /*0xE38AE88*/, (uChar*)&(heap->a_unsigned_byte_array)); /* assign */
						SetSignalReady(22, 1);
						PDAArrIncRefCnt(heap->a_unsigned_byte_array, (uInt16)1); /* BDConst - alloc type */
						MemMove( &heap->c_VISA_Read_error_out_CS_2, &heap->c_VISA_Read_error_out, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x3, 6);*//* c_VISA_Read_error_out_CS_2 */
						UpdateProbes(&state, debugOffset, 71 /*0xE38AD68*/, (uChar*)&(heap->c_VISA_Read_error_out_CS_2)); /* assign */
						SetSignalReady(22, 1);
						heap->s_VISA_Read_VISA_resource_nam_3 = heap->s_VISA_Read_VISA_resource_name__1;
						/*SetSignalReady( 0xE, 4);*//* s_VISA_Read_VISA_resource_nam_3 */
						UpdateProbes(&state, debugOffset, 70 /*0xE38ADC8*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_3)); /* assign */
						SetSignalReady(22, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						heap->a_Case_Structure_CT_7 = heap->a_unsigned_byte_array;
						/*SetSignalReady( 0x8, 3);*//* a_Case_Structure_CT_7 */
						heap->s_Case_Structure_CT_17 = heap->s_VISA_Read_VISA_resource_nam_3;
						/*SetSignalReady( 0x8, 2);*//* s_Case_Structure_CT_17 */
						MemMove( &heap->c_Case_Structure_CT_17, &heap->c_VISA_Read_error_out_CS_2, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x4, 4);*//* c_Case_Structure_CT_17 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 32, 32, &snode72F97CC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				int16 pass;
				Boolean bEndDiagram = false;
				uInt32 diagramIdx = 12;
				uInt32 id = LVGetTimerFlag();
				while (!gAppStop && !gLastError) {
					nReady = 0;
					bEndDiagram = false;
					runStat = eFinished;
					for (pass=0;pass<2;pass++) {
						{
/* start q el linear (2 struct) */
							if ((heap->runStat10590DA9 != eFinished)
							/*) {*/
							) {
								if (pass == 0) {
									InitSignalReady(27, 1);
									/*InitSignalReady( 0x1D, 3);*//* by_Case_Structure_CT */
									InitSignalReady(31, 2);
									/*InitSignalReady( 0x8, 0);*//* a_String_To_Byte_Array_unsigned */
									/*InitSignalReady( 0x21, 0);*//* b_Equal__x___y__1 */
									/*InitSignalReady( 0x1D, 1);*//* by_Index_Array_element */
									/*InitSignalReady( 0x1C, 7);*//* by_x */
									/*InitSignalReady( 0x6, 5);*//* l_index_2 */
									/*InitSignalReady( 0x6, 0);*//* dw_To_Unsigned_Long_Integer_uns */
									InitSignalReady(25, 2);
									/*InitSignalReady( 0x14, 2);*//* n_Utility_MODBUS_RTU_CRC16_vi_C */
									/*InitSignalReady( 0x14, 3);*//* n_Join_Numbers__hi_lo__1 */
									InitSignalReady(23, 3);
									/*InitSignalReady( 0x8, 6);*//* s_Utility_Generate_Instrument_E */
									InitSignalReady(24, 4);
									/*InitSignalReady( 0x8, 7);*//* s_Utility_MODBUS_RTU_CRC16_vi_V */
									InitSignalReady(26, 3);
									/*InitSignalReady( 0x9, 0);*//* s_VISA_Read_VISA_resource_name_1 */
									/*InitSignalReady( 0x9, 1);*//* a_Build_Array_appended_array_1 */
									/*InitSignalReady( 0x9, 2);*//* a_String_To_Byte_Array_unsigned_1 */
									/*InitSignalReady( 0x6, 7);*//* l_Constant_1 */
									/*InitSignalReady( 0x4, 3);*//* c_Utility_MODBUS_RTU_CRC16_vi_e */
									/*InitSignalReady( 0x20, 7);*//* b_Not_Equal__x____y__1 */
									/*InitSignalReady( 0x4, 2);*//* c_Utility_Generate_Instrument_E */
									/*InitSignalReady( 0x1C, 1);*//* by_Unbundle_unsigned_byte_array */
									/*InitSignalReady( 0x1C, 0);*//* by_Unbundle_unsigned_byte_array_1 */
									/*InitSignalReady( 0x7, 6);*//* c_Array_To_Cluster_cluster_1 */
									/*InitSignalReady( 0xA, 2);*//* a_String_To_Byte_Array_unsigne_1 */
									/*InitSignalReady( 0x4, 1);*//* c_VISA_Read_error_out_1 */
									/*InitSignalReady( 0xA, 4);*//* s_VISA_Read_read_buffer_1 */
									/*InitSignalReady( 0x4, 0);*//* c_VISA_Read_error_out_2 */
									/*InitSignalReady( 0xA, 6);*//* s_VISA_Read_VISA_resource_nam_1 */
									/*InitSignalReady( 0x5, 2);*//* dw_byte_count__0__1 */
									/*InitSignalReady( 0xB, 0);*//* s_VISA_Read_read_buffer_2 */
									/*InitSignalReady( 0xB, 1);*//* s_VISA_Read_VISA_resource_nam_2 */
									/*InitSignalReady( 0x3, 7);*//* c_VISA_Read_error_out_CS_1 */
									InitSignalReady(32, 1);
									/*InitSignalReady( 0xB, 3);*//* s_VISA_Read_read_buffer_CT_1 */
								}
								else {
									HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
									{
										heap->s_VISA_Read_read_buffer_CT_1 = heap->s_VISA_Read_read_buffer_CT;
										/*SetSignalReady( 0xB, 3);*//* s_VISA_Read_read_buffer_CT_1 */
										UpdateProbes(&state, debugOffset, 64 /*0xE38B428*/, (uChar*)&(heap->s_VISA_Read_read_buffer_CT_1)); /* assign */
										SetSignalReady(32, 1);
										heap->dw_byte_count__0__1 = 2;
										/*SetSignalReady( 0x5, 2);*//* dw_byte_count__0__1 */
										UpdateProbes(&state, debugOffset, 60 /*0xE38B668*/, (uChar*)&(heap->dw_byte_count__0__1)); /* assign */
										heap->l_Constant_1 = -1074001422;
										/*SetSignalReady( 0x6, 7);*//* l_Constant_1 */
										UpdateProbes(&state, debugOffset, 48 /*0x13315218*/, (uChar*)&(heap->l_Constant_1)); /* assign */
										SetSignalReady(24, 1);
										heap->l_index_2 = 1;
										/*SetSignalReady( 0x6, 5);*//* l_index_2 */
										UpdateProbes(&state, debugOffset, 39 /*0x133156F8*/, (uChar*)&(heap->l_index_2)); /* assign */
										MemMove( &heap->c_VISA_Read_error_out_CS_1, &heap->c_VISA_Read_error_out, sizeof( cl_00000 ) );
										/*SetSignalReady( 0x3, 7);*//* c_VISA_Read_error_out_CS_1 */
										UpdateProbes(&state, debugOffset, 63 /*0xE38B4E8*/, (uChar*)&(heap->c_VISA_Read_error_out_CS_1)); /* assign */
										heap->s_VISA_Read_VISA_resource_nam_2 = heap->s_VISA_Read_VISA_resource_name__1;
										/*SetSignalReady( 0xB, 1);*//* s_VISA_Read_VISA_resource_nam_2 */
										UpdateProbes(&state, debugOffset, 62 /*0xE38B5A8*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_2)); /* assign */
										heap->by_x = 16;
										/*SetSignalReady( 0x1C, 7);*//* by_x */
										UpdateProbes(&state, debugOffset, 38 /*0x13315758*/, (uChar*)&(heap->by_x)); /* assign */
									}
									heap->runStat10590DA9 = eFinished;
									continue;
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStat13316058 != eFinished)
							/*&& GetSignalReady( 0xB, 3)*//* s_VISA_Read_read_buffer_CT_1 *//*) {*/
							&& GetSignalReady( 32 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										/**/
										/* String To Byte Array */
										/**/
										CCGDebugSynchNode(&state, 12, 13, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_CT_1, &(heap->a_String_To_Byte_Array_unsigned))) {
											CGenErr();
										}
										/*SetSignalReady( 0x8, 0);*//* a_String_To_Byte_Array_unsigned */
										UpdateProbes(&state, debugOffset, 35 /*0x13315878*/, (uChar*)&(heap->a_String_To_Byte_Array_unsigned)); /* assign */
										SetSignalReady(31, 1);
										PDAArrIncRefCnt(heap->a_String_To_Byte_Array_unsigned, (uInt16)2); /* Primitive */
										CCGDebugSynchNode(&state, 13, 14, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										{ /* Array Index 1D */
											heap->by_Index_Array_element = *(uChar *)NthElemFast(((PDAArrPtr)heap->a_String_To_Byte_Array_unsigned), heap->l_index_2, 1);
											/*SetSignalReady( 0x1D, 1);*//* by_Index_Array_element */
											UpdateProbes(&state, debugOffset, 37 /*0x133157B8*/, (uChar*)&(heap->by_Index_Array_element)); /* assign */
										}
	if (heap->a_String_To_Byte_Array_unsigned){--((PDAArrPtr)heap->a_String_To_Byte_Array_unsigned)->refcnt;}
										/**/
										/* Equal? */
										/**/
										CCGDebugSynchNode(&state, 14, 15, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										heap->b_Equal__x___y__1 =  (heap->by_Index_Array_element == heap->by_x);
										/*SetSignalReady( 0x21, 0);*//* b_Equal__x___y__1 */
										UpdateProbes(&state, debugOffset, 36 /*0x13315818*/, (uChar*)&(heap->b_Equal__x___y__1)); /* assign */
										SetSignalReady(31, 1);
									}
									heap->runStat13316058 = eFinished;
									InitSignalReady(32, 1);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat72F344C != eFinished)
							/*&& GetSignalReady( 0x21, 0)*//* b_Equal__x___y__1 */
							/*&& GetSignalReady( 0x8, 0)*//* a_String_To_Byte_Array_unsigned *//*) {*/
							&& GetSignalReady( 31 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									heap->runStat72F344C = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F344C( (Boolean)(bRunToFinish && (nReady < 2)) );
									if (heap->runStat72F344C == eNotFinished) {
										runStat = eNotFinished;
									}
									else if (heap->runStat72F344C == eFail) {
										CGenErr();
									}
									else {
										InitSignalReady(31, 2);
									}
									if (runStat == eFinished) {
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStat101D4548 != eFinished)
							/*&& GetSignalReady( 0x1D, 3)*//* by_Case_Structure_CT *//*) {*/
							&& GetSignalReady( 27 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										/**/
										/* To Unsigned Long Integer */
										/**/
										CCGDebugSynchNode(&state, 16, 17, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										heap->dw_To_Unsigned_Long_Integer_uns = (uInt32)heap->by_Case_Structure_CT;
										/*SetSignalReady( 0x6, 0);*//* dw_To_Unsigned_Long_Integer_uns */
										UpdateProbes(&state, debugOffset, 40 /*0x13315698*/, (uChar*)&(heap->dw_To_Unsigned_Long_Integer_uns)); /* assign */
										/**/
										/* VISA Read */
										/**/
										CCGDebugSynchNode(&state, 17, 18, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (VisaRead(heap->s_VISA_Read_VISA_resource_nam_2,  &(heap->dw_To_Unsigned_Long_Integer_uns),  uInt32DataType,  &(heap->c_VISA_Read_error_out_CS_1),  &(heap->s_VISA_Read_VISA_resource_nam_1),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer_1),  &(heap->c_VISA_Read_error_out_2) ) == eFail) {
											CGenErr();
										}
										/*SetSignalReady( 0x4, 0);*//* c_VISA_Read_error_out_2 */
										UpdateProbes(&state, debugOffset, 58 /*0xE38B7E8*/, (uChar*)&(heap->c_VISA_Read_error_out_2)); /* assign */
										/*SetSignalReady( 0xA, 4);*//* s_VISA_Read_read_buffer_1 */
										UpdateProbes(&state, debugOffset, 57 /*0xE38B848*/, (uChar*)&(heap->s_VISA_Read_read_buffer_1)); /* assign */
										/*SetSignalReady( 0xA, 6);*//* s_VISA_Read_VISA_resource_nam_1 */
										UpdateProbes(&state, debugOffset, 59 /*0xE38B728*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_1)); /* assign */
										/**/
										/* String To Byte Array */
										/**/
										CCGDebugSynchNode(&state, 18, 19, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_1, &(heap->a_String_To_Byte_Array_unsigned_1))) {
											CGenErr();
										}
										/*SetSignalReady( 0x9, 2);*//* a_String_To_Byte_Array_unsigned_1 */
										UpdateProbes(&state, debugOffset, 47 /*0x13315278*/, (uChar*)&(heap->a_String_To_Byte_Array_unsigned_1)); /* assign */
										SetSignalReady(23, 1);
										PDAArrIncRefCnt(heap->a_String_To_Byte_Array_unsigned_1, (uInt16)1); /* Primitive */
/* Build array */
										CCGDebugSynchNode(&state, 19, 20, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										{
											ArrDimSize i;
											ArrDimSize dimSize=0;
											heap->a_Build_Array_appended_array_1 = PDAArrNewEmptyWithNDimsStatic( uCharDataType, (ArrDimSize)1, &g_staticArray_15 );
											if (!heap->a_Build_Array_appended_array_1){
												CGenErr();
											}
											dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsigned), (ArrDimSize)0);
											dimSize += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsigned_1), (ArrDimSize)0);
											PDAArrSetDim(((PDAArrPtr)heap->a_Build_Array_appended_array_1), (ArrDimSize)0, dimSize);
											if (!PDAArrAllocData(&heap->a_Build_Array_appended_array_1)){
												CGenErr();
											}
											i=0;
											if (!PDAArrAdd(heap->a_Build_Array_appended_array_1, i, heap->a_String_To_Byte_Array_unsigned)) {
												CGenErr();
											}
											i += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsigned), (ArrDimSize)0);
											PDAArrFree(heap->a_String_To_Byte_Array_unsigned);
											if (!PDAArrAdd(heap->a_Build_Array_appended_array_1, i, heap->a_String_To_Byte_Array_unsigned_1)) {
												CGenErr();
											}
											i += PDAArrNthDim(((PDAArrPtr)heap->a_String_To_Byte_Array_unsigned_1), (ArrDimSize)0);
											PDAArrFree(heap->a_String_To_Byte_Array_unsigned_1);
										}
										/*SetSignalReady( 0x9, 1);*//* a_Build_Array_appended_array_1 */
										UpdateProbes(&state, debugOffset, 46 /*0x133152D8*/, (uChar*)&(heap->a_Build_Array_appended_array_1)); /* assign */
										SetSignalReady(26, 1);
										/**/
										/* VISA Read */
										/**/
										CCGDebugSynchNode(&state, 20, 21, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (VisaRead(heap->s_VISA_Read_VISA_resource_nam_1,  &(heap->dw_byte_count__0__1),  uInt32DataType,  &(heap->c_VISA_Read_error_out_2),  &(heap->s_VISA_Read_VISA_resource_name_1),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer_2),  &(heap->c_VISA_Read_error_out_1) ) == eFail) {
											CGenErr();
										}
										/*SetSignalReady( 0x4, 1);*//* c_VISA_Read_error_out_1 */
										UpdateProbes(&state, debugOffset, 56 /*0xE38B8A8*/, (uChar*)&(heap->c_VISA_Read_error_out_1)); /* assign */
										SetSignalReady(26, 1);
										/*SetSignalReady( 0xB, 0);*//* s_VISA_Read_read_buffer_2 */
										UpdateProbes(&state, debugOffset, 61 /*0xE38B608*/, (uChar*)&(heap->s_VISA_Read_read_buffer_2)); /* assign */
										/*SetSignalReady( 0x9, 0);*//* s_VISA_Read_VISA_resource_name_1 */
										UpdateProbes(&state, debugOffset, 45 /*0x13315338*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_name_1)); /* assign */
										SetSignalReady(26, 1);
										/**/
										/* String To Byte Array */
										/**/
										CCGDebugSynchNode(&state, 21, 22, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_2, &(heap->a_String_To_Byte_Array_unsigne_1))) {
											CGenErr();
										}
										/*SetSignalReady( 0xA, 2);*//* a_String_To_Byte_Array_unsigne_1 */
										UpdateProbes(&state, debugOffset, 55 /*0xE38B968*/, (uChar*)&(heap->a_String_To_Byte_Array_unsigne_1)); /* assign */
										/**/
										/* Array To Cluster */
										/**/
										CCGDebugSynchNode(&state, 22, 23, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (!PDAArrToClust(heap->a_String_To_Byte_Array_unsigne_1, 0x100000 | ArrayDataType, (int32)2, &(heap->c_Array_To_Cluster_cluster_1), 0xF0000 | ClusterDataType)) {
											CGenErr();
										}
;
										/*SetSignalReady( 0x7, 6);*//* c_Array_To_Cluster_cluster_1 */
										UpdateProbes(&state, debugOffset, 54 /*0xE38BA28*/, (uChar*)&(heap->c_Array_To_Cluster_cluster_1)); /* assign */
										CCGDebugSynchNode(&state, 23, 24, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
/* Unbundle */
										{
											cl_F0000* cl_004 = (cl_F0000*)&heap->c_Array_To_Cluster_cluster_1;
											heap->by_Unbundle_unsigned_byte_array_1 = cl_004->el_0;
											/*SetSignalReady( 0x1C, 0);*//* by_Unbundle_unsigned_byte_array_1 */
											UpdateProbes(&state, debugOffset, 53 /*0xE38BA88*/, (uChar*)&(heap->by_Unbundle_unsigned_byte_array_1)); /* assign */
											heap->by_Unbundle_unsigned_byte_array = cl_004->el_1;
											/*SetSignalReady( 0x1C, 1);*//* by_Unbundle_unsigned_byte_array */
											UpdateProbes(&state, debugOffset, 52 /*0xE38BB48*/, (uChar*)&(heap->by_Unbundle_unsigned_byte_array)); /* assign */
										}
										/**/
										/* Join Numbers */
										/**/
										CCGDebugSynchNode(&state, 24, 25, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										PDAJoin( &(heap->by_Unbundle_unsigned_byte_array), uCharDataType, &(heap->by_Unbundle_unsigned_byte_array_1), uCharDataType, &(heap->n_Join_Numbers__hi_lo__1) );
										/*SetSignalReady( 0x14, 3);*//* n_Join_Numbers__hi_lo__1 */
										UpdateProbes(&state, debugOffset, 42 /*0x13315578*/, (uChar*)&(heap->n_Join_Numbers__hi_lo__1)); /* assign */
										SetSignalReady(25, 1);
									}
									heap->runStat101D4548 = eFinished;
									InitSignalReady(27, 1);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat101D4DE8 != eFinished)
							/*&& GetSignalReady( 0x4, 1)*//* c_VISA_Read_error_out_1 */
							/*&& GetSignalReady( 0x9, 1)*//* a_Build_Array_appended_array_1 */
							/*&& GetSignalReady( 0x9, 0)*//* s_VISA_Read_VISA_resource_name_1 *//*) {*/
							&& GetSignalReady( 26 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStat101D4DE8 == eReady) {
									}
									CCGDebugSynchIUse(&state, 25, 26, 12, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility MODBUS RTU CRC16.vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStat101D4DE8 == eReady) {
											CreateArgListStatic(heap->Args101D4DE9, 3, 4 );
											argIn(heap->Args101D4DE9, 0).nType = 0x0 | ClusterDataType;
											argIn(heap->Args101D4DE9, 0).pValue = (void *)&heap->c_VISA_Read_error_out_1;
											argIn(heap->Args101D4DE9, 1).nType = 0x100000 | ArrayDataType;
											argIn(heap->Args101D4DE9, 1).pValue = (void *)&heap->a_Build_Array_appended_array_1;
											argIn(heap->Args101D4DE9, 2).nType = StringDataType;
											argIn(heap->Args101D4DE9, 2).pValue = (void *)&heap->s_VISA_Read_VISA_resource_name_1;
											argOut(heap->Args101D4DE9, 0).nType = 0x0 | ClusterDataType;
											argOut(heap->Args101D4DE9, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_CRC16_vi_e;
											argOut(heap->Args101D4DE9, 1).nType = uInt16DataType;
											argOut(heap->Args101D4DE9, 1).pValue = (void *)&heap->n_Utility_MODBUS_RTU_CRC16_vi_C;
											argOut(heap->Args101D4DE9, 2).nType = 0;
											argOut(heap->Args101D4DE9, 2).pValue = NULL;
											argOut(heap->Args101D4DE9, 3).nType = StringDataType;
											argOut(heap->Args101D4DE9, 3).pValue = (void *)&heap->s_Utility_MODBUS_RTU_CRC16_vi_V;
										}
										if (!Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4DE8.callerID) {
											Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4DE8.callerID = ++gCallerID;
										}
										heap->runStat101D4DE8 = Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Run( &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4DE8, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args101D4DE9)[0], (ArgList *)((ArgList **)heap->Args101D4DE9)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 26, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStat101D4DE8 == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStat101D4DE8 == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStat101D4DE8 == eFinished)) {
											/*SetSignalReady( 0x4, 3);*//* c_Utility_MODBUS_RTU_CRC16_vi_e */
											UpdateProbes(&state, debugOffset, 49 /*0x133151B8*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_CRC16_vi_e)); /* assign */
											SetSignalReady(24, 1);
											/*SetSignalReady( 0x14, 2);*//* n_Utility_MODBUS_RTU_CRC16_vi_C */
											UpdateProbes(&state, debugOffset, 41 /*0x133155D8*/, (uChar*)&(heap->n_Utility_MODBUS_RTU_CRC16_vi_C)); /* assign */
											SetSignalReady(25, 1);
											/*SetSignalReady( 0x8, 7);*//* s_Utility_MODBUS_RTU_CRC16_vi_V */
											UpdateProbes(&state, debugOffset, 44 /*0x133153F8*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_CRC16_vi_V)); /* assign */
											SetSignalReady(24, 1);
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStat101D4DE8 == eFinished) {
										InitSignalReady(26, 3);
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStat101D44E8 != eFinished)
							/*&& GetSignalReady( 0x14, 2)*//* n_Utility_MODBUS_RTU_CRC16_vi_C */
							/*&& GetSignalReady( 0x14, 3)*//* n_Join_Numbers__hi_lo__1 *//*) {*/
							&& GetSignalReady( 25 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										/**/
										/* Not Equal? */
										/**/
										CCGDebugSynchNode(&state, 26, 27, 12, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										heap->b_Not_Equal__x____y__1 =  (heap->n_Join_Numbers__hi_lo__1 != heap->n_Utility_MODBUS_RTU_CRC16_vi_C);
										/*SetSignalReady( 0x20, 7);*//* b_Not_Equal__x____y__1 */
										UpdateProbes(&state, debugOffset, 50 /*0xE38BC08*/, (uChar*)&(heap->b_Not_Equal__x____y__1)); /* assign */
										SetSignalReady(24, 1);
									}
									heap->runStat101D44E8 = eFinished;
									InitSignalReady(25, 2);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat101D4EA8 != eFinished)
							/*&& GetSignalReady( 0x4, 3)*//* c_Utility_MODBUS_RTU_CRC16_vi_e */
							/*&& GetSignalReady( 0x6, 7)*//* l_Constant_1 */
							/*&& GetSignalReady( 0x20, 7)*//* b_Not_Equal__x____y__1 */
							/*&& GetSignalReady( 0x8, 7)*//* s_Utility_MODBUS_RTU_CRC16_vi_V *//*) {*/
							&& GetSignalReady( 24 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStat101D4EA8 == eReady) {
									}
									CCGDebugSynchIUse(&state, 27, 28, 12, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility Generate Instrument Error.vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStat101D4EA8 == eReady) {
											CreateArgListStatic(heap->Args101D4EA9, 4, 2 );
											argIn(heap->Args101D4EA9, 0).nType = 0x0 | ClusterDataType;
											argIn(heap->Args101D4EA9, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_CRC16_vi_e;
											argIn(heap->Args101D4EA9, 1).nType = int32DataType;
											argIn(heap->Args101D4EA9, 1).pValue = (void *)&heap->l_Constant_1;
											argIn(heap->Args101D4EA9, 2).nType = BooleanDataType;
											argIn(heap->Args101D4EA9, 2).pValue = (void *)&heap->b_Not_Equal__x____y__1;
											argIn(heap->Args101D4EA9, 3).nType = StringDataType;
											argIn(heap->Args101D4EA9, 3).pValue = (void *)&heap->s_Utility_MODBUS_RTU_CRC16_vi_V;
											argOut(heap->Args101D4EA9, 0).nType = 0x0 | ClusterDataType;
											argOut(heap->Args101D4EA9, 0).pValue = (void *)&heap->c_Utility_Generate_Instrument_E;
											argOut(heap->Args101D4EA9, 1).nType = StringDataType;
											argOut(heap->Args101D4EA9, 1).pValue = (void *)&heap->s_Utility_Generate_Instrument_E;
										}
										if (!Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4EA8.callerID) {
											Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4EA8.callerID = ++gCallerID;
										}
										heap->runStat101D4EA8 = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Run( &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i101D4EA8, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args101D4EA9)[0], (ArgList *)((ArgList **)heap->Args101D4EA9)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 28, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStat101D4EA8 == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStat101D4EA8 == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStat101D4EA8 == eFinished)) {
											/*SetSignalReady( 0x4, 2);*//* c_Utility_Generate_Instrument_E */
											UpdateProbes(&state, debugOffset, 51 /*0xE38BBA8*/, (uChar*)&(heap->c_Utility_Generate_Instrument_E)); /* assign */
											SetSignalReady(23, 1);
											/*SetSignalReady( 0x8, 6);*//* s_Utility_Generate_Instrument_E */
											UpdateProbes(&state, debugOffset, 43 /*0x133154B8*/, (uChar*)&(heap->s_Utility_Generate_Instrument_E)); /* assign */
											SetSignalReady(23, 1);
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStat101D4EA8 == eFinished) {
										InitSignalReady(24, 4);
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStat10590DAA != eFinished)
							/*&& GetSignalReady( 0x9, 2)*//* a_String_To_Byte_Array_unsigned_1 */
							/*&& GetSignalReady( 0x8, 6)*//* s_Utility_Generate_Instrument_E */
							/*&& GetSignalReady( 0x4, 2)*//* c_Utility_Generate_Instrument_E *//*) {*/
							&& GetSignalReady( 23 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										heap->a_Case_Structure_CT_7 = heap->a_String_To_Byte_Array_unsigned_1;
										/*SetSignalReady( 0x8, 3);*//* a_Case_Structure_CT_7 */
										heap->s_Case_Structure_CT_17 = heap->s_Utility_Generate_Instrument_E;
										/*SetSignalReady( 0x8, 2);*//* s_Case_Structure_CT_17 */
										MemMove( &heap->c_Case_Structure_CT_17, &heap->c_Utility_Generate_Instrument_E, sizeof( cl_00000 ) );
										/*SetSignalReady( 0x4, 4);*//* c_Case_Structure_CT_17 */
									}
									heap->runStat10590DAA = eFinished;
									InitSignalReady(23, 3);
									continue;
								}
							}
						}
						if( runStat == eFinished && pass )
						{
							volatile int dummy;
							CCGDebugSynchSRN(&state, 28, 12, &snode72F97CC, debugOffset);
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}

							dummy=1;
						}
						if (pass) {
							if (runStat == eFinished) {
								bEndDiagram = true;
							}
							if (!bRunToFinish) {
								if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
									if (gAppStop) {
										return eFinished;
									}
									if (gLastError) {
										CGenErr();
									}
									if (!gAppStop && !gLastError) {
										return eNotFinished;
									}
								}
							}
						}
					} /* end for */
					if (bEndDiagram) break;
				} /* end while */
			} /* end case */
			break;
		}
		heap->runStat10590DA9 = eReady;
		heap->runStat13316058 = eReady;
		heap->runStat72F344C = eReady;
		heap->runStat101D4548 = eReady;
		heap->runStat101D4DE8 = eReady;
		heap->runStat101D44E8 = eReady;
		heap->runStat101D4EA8 = eReady;
		heap->runStat10590DAA = eReady;
		MemMove( &heap->c_Case_Structure_CT_16, &heap->c_Case_Structure_CT_17, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x5, 1);*//* c_Case_Structure_CT_16 */
		UpdateProbes(&state, debugOffset, 28 /*0xE58A860*/, (uChar*)&(heap->c_Case_Structure_CT_16)); /* assign */
		SetSignalReady(21, 1);
		heap->a_Case_Structure_CT_6 = heap->a_Case_Structure_CT_7;
		/*SetSignalReady( 0x11, 2);*//* a_Case_Structure_CT_6 */
		UpdateProbes(&state, debugOffset, 25 /*0xE58AA40*/, (uChar*)&(heap->a_Case_Structure_CT_6)); /* assign */
		SetSignalReady(21, 1);
		heap->s_Case_Structure_CT_16 = heap->s_Case_Structure_CT_17;
		/*SetSignalReady( 0x11, 1);*//* s_Case_Structure_CT_16 */
		UpdateProbes(&state, debugOffset, 26 /*0xE58A980*/, (uChar*)&(heap->s_Case_Structure_CT_16)); /* assign */
		SetSignalReady(21, 1);
		/* FreeCaseSelDCO. */
	/* Free Cluster */
		{
			cl_00000* cl_005 = (cl_00000*)&heap->c_VISA_Read_error_out;
				if (cl_005->el_2 && --((PDAStrPtr)cl_005->el_2)->refcnt == 0 && !((PDAStrPtr)cl_005->el_2)->staticStr) {
				MemHandleFree( cl_005->el_2 );
			}
		}
		CCGDebugSynchAfterSNode(&state, &snode72F97CC, 11, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F964C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F964C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F964C == eReady) {
			CCGDebugSynchSNode(&state, 4, 5, 3, &snode72F964C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatE477EA9 = eReady;
			heap->runStatE58A320 = eReady;
			heap->runStat72F25CC = eReady;
			heap->runStatE58A200 = eReady;
			heap->runStatE58A3E0 = eReady;
			heap->runStatE58A0E0 = eReady;
			heap->runStatE58A4A0 = eReady;
			heap->runStatE477EAA = eReady;
			heap->runStat10590FA9 = eReady;
			heap->runStatE58AD40 = eReady;
			heap->runStat72F97CC = eReady;
			heap->runStat10590FAA = eReady;
			heap->n_Receive_Message_Type__0__By_1 = heap->n_Receive_Message_Type__0__By__1;
			/*SetSignalReady( 0x14, 1);*//* n_Receive_Message_Type__0__By_1 */
			MemMove( &heap->c_Property_Node_error_out_CT_3, &heap->c_Property_Node_error_out_1, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x4, 6);*//* c_Property_Node_error_out_CT_3 */
			heap->s_Property_Node_reference_out_2 = heap->s_Property_Node_reference_out_1;
			/*SetSignalReady( 0xA, 7);*//* s_Property_Node_reference_out_2 */
			heap->by_Length_Of_Sent_MSG__0__CT_2 = heap->by_Length_Of_Sent_MSG__0__CT_1;
			/*SetSignalReady( 0x19, 0);*//* by_Length_Of_Sent_MSG__0__CT_2 */
			heap->by_Sent_Command__0__CT_2 = heap->by_Sent_Command__0__CT_1;
			/*SetSignalReady( 0x1F, 1);*//* by_Sent_Command__0__CT_2 */
		}
		switch ( heap->n_Receive_Message_Type__0__By_1 ) {
			/* begin case */
			case 1 : {
				int16 pass;
				Boolean bEndDiagram = false;
				uInt32 diagramIdx = 33;
				uInt32 id = LVGetTimerFlag();
				while (!gAppStop && !gLastError) {
					nReady = 0;
					bEndDiagram = false;
					runStat = eFinished;
					for (pass=0;pass<2;pass++) {
						{
/* start q el linear (2 struct) */
							if ((heap->runStatE477EA9 != eFinished)
							/*) {*/
							) {
								if (pass == 0) {
									InitSignalReady(19, 7);
									/*InitSignalReady( 0x16, 2);*//* by_Length_Of_Sent_MSG__0__CT_3 */
									/*InitSignalReady( 0xF, 3);*//* s_VISA_Read_read_buffer_3 */
									InitSignalReady(20, 3);
									/*InitSignalReady( 0x5, 7);*//* dw_byte_count__0__2 */
									InitSignalReady(5, 2);
									/*InitSignalReady( 0x15, 0);*//* n_Join_Numbers__hi_lo__2 */
									/*InitSignalReady( 0x15, 1);*//* n_Utility_MODBUS_RTU_CRC16_vi_C_1 */
									InitSignalReady(4, 4);
									/*InitSignalReady( 0xF, 7);*//* s_Utility_MODBUS_RTU_CRC16_vi_V_1 */
									InitSignalReady(6, 3);
									/*InitSignalReady( 0x10, 0);*//* s_Case_Structure_CT_18 */
									/*InitSignalReady( 0x10, 1);*//* a_Case_Structure_CT_8 */
									InitSignalReady(3, 3);
									/*InitSignalReady( 0x10, 2);*//* s_Utility_Generate_Instrument_E_1 */
									/*InitSignalReady( 0x10, 3);*//* a_Case_Structure_CT_9 */
									/*InitSignalReady( 0x10, 4);*//* a_String_To_Byte_Array_unsign_3 */
									/*InitSignalReady( 0x3, 4);*//* c_Case_Structure_CT_18 */
									/*InitSignalReady( 0x15, 7);*//* by_Sent_Command__0__CT_3 */
									/*InitSignalReady( 0x15, 6);*//* by_Index_Array_element_2 */
									/*InitSignalReady( 0x20, 5);*//* b_Not_Equal__x____y__2 */
									/*InitSignalReady( 0x6, 6);*//* l_index_4 */
									/*InitSignalReady( 0x3, 3);*//* c_VISA_Read_error_out_3 */
									/*InitSignalReady( 0x3, 2);*//* c_Utility_MODBUS_RTU_CRC16_vi_e_1 */
									/*InitSignalReady( 0x20, 3);*//* b_Not_Equal__x____y__3 */
									InitSignalReady(7, 1);
									/*InitSignalReady( 0x11, 5);*//* a_Case_Structure_CT_10 */
									/*InitSignalReady( 0x15, 3);*//* by_Unbundle_unsigned_byte_arra_1 */
									/*InitSignalReady( 0x15, 2);*//* by_Unbundle_unsigned_byte_arr_1 */
									/*InitSignalReady( 0x7, 5);*//* c_Array_To_Cluster_cluster_2 */
									/*InitSignalReady( 0x6, 4);*//* l_Constant_2 */
									/*InitSignalReady( 0x3, 0);*//* c_Utility_Generate_Instrument_E_1 */
									/*InitSignalReady( 0x12, 3);*//* s_VISA_Read_VISA_resource_nam_4 */
									/*InitSignalReady( 0x2, 6);*//* c_Property_Node_error_out_CT_5 */
									/*InitSignalReady( 0x12, 5);*//* s_Property_Node_reference_out_4 */
								}
								else {
									HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
									{
										heap->l_Constant_2 = -1074001422;
										/*SetSignalReady( 0x6, 4);*//* l_Constant_2 */
										UpdateProbes(&state, debugOffset, 95 /*0x1277CA30*/, (uChar*)&(heap->l_Constant_2)); /* assign */
										SetSignalReady(4, 1);
										heap->l_index_4 = 1;
										/*SetSignalReady( 0x6, 6);*//* l_index_4 */
										UpdateProbes(&state, debugOffset, 87 /*0x1277CEB0*/, (uChar*)&(heap->l_index_4)); /* assign */
										heap->dw_byte_count__0__2 = 2;
										/*SetSignalReady( 0x5, 7);*//* dw_byte_count__0__2 */
										UpdateProbes(&state, debugOffset, 74 /*0x12777028*/, (uChar*)&(heap->dw_byte_count__0__2)); /* assign */
										SetSignalReady(20, 1);
										MemMove( &heap->c_Property_Node_error_out_CT_5, &heap->c_Property_Node_error_out_CT_3, sizeof( cl_00000 ) );
										/*SetSignalReady( 0x2, 6);*//* c_Property_Node_error_out_CT_5 */
										UpdateProbes(&state, debugOffset, 98 /*0x1277C8B0*/, (uChar*)&(heap->c_Property_Node_error_out_CT_5)); /* assign */
										SetSignalReady(20, 1);
										heap->s_Property_Node_reference_out_4 = heap->s_Property_Node_reference_out_2;
										/*SetSignalReady( 0x12, 5);*//* s_Property_Node_reference_out_4 */
										UpdateProbes(&state, debugOffset, 99 /*0x1277C7F0*/, (uChar*)&(heap->s_Property_Node_reference_out_4)); /* assign */
										SetSignalReady(20, 1);
										heap->by_Length_Of_Sent_MSG__0__CT_3 = heap->by_Length_Of_Sent_MSG__0__CT_2;
										/*SetSignalReady( 0x16, 2);*//* by_Length_Of_Sent_MSG__0__CT_3 */
										UpdateProbes(&state, debugOffset, 72 /*0x127771A8*/, (uChar*)&(heap->by_Length_Of_Sent_MSG__0__CT_3)); /* assign */
										SetSignalReady(19, 1);
										heap->by_Sent_Command__0__CT_3 = heap->by_Sent_Command__0__CT_2;
										/*SetSignalReady( 0x15, 7);*//* by_Sent_Command__0__CT_3 */
										UpdateProbes(&state, debugOffset, 84 /*0x1277D030*/, (uChar*)&(heap->by_Sent_Command__0__CT_3)); /* assign */
										SetSignalReady(19, 1);
									}
									heap->runStatE477EA9 = eFinished;
									continue;
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStatE58A320 != eFinished)
							/*&& GetSignalReady( 0x2, 6)*//* c_Property_Node_error_out_CT_5 */
							/*&& GetSignalReady( 0x5, 7)*//* dw_byte_count__0__2 */
							/*&& GetSignalReady( 0x12, 5)*//* s_Property_Node_reference_out_4 *//*) {*/
							&& GetSignalReady( 20 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										/**/
										/* VISA Read */
										/**/
										CCGDebugSynchNode(&state, 33, 34, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (VisaRead(heap->s_Property_Node_reference_out_4,  &(heap->dw_byte_count__0__2),  uInt32DataType,  &(heap->c_Property_Node_error_out_CT_5),  &(heap->s_VISA_Read_VISA_resource_nam_4),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer_3),  &(heap->c_VISA_Read_error_out_3) ) == eFail) {
											CGenErr();
										}
										/*SetSignalReady( 0x3, 3);*//* c_VISA_Read_error_out_3 */
										UpdateProbes(&state, debugOffset, 88 /*0x1277CE50*/, (uChar*)&(heap->c_VISA_Read_error_out_3)); /* assign */
										SetSignalReady(19, 1);
										/*SetSignalReady( 0xF, 3);*//* s_VISA_Read_read_buffer_3 */
										UpdateProbes(&state, debugOffset, 73 /*0x127770E8*/, (uChar*)&(heap->s_VISA_Read_read_buffer_3)); /* assign */
										/*SetSignalReady( 0x12, 3);*//* s_VISA_Read_VISA_resource_nam_4 */
										UpdateProbes(&state, debugOffset, 97 /*0x1277C970*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_nam_4)); /* assign */
										SetSignalReady(19, 1);
										/**/
										/* String To Byte Array */
										/**/
										CCGDebugSynchNode(&state, 34, 35, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (!PDAStrToArray(heap->s_VISA_Read_read_buffer_3, &(heap->a_String_To_Byte_Array_unsign_3))) {
											CGenErr();
										}
										/*SetSignalReady( 0x10, 4);*//* a_String_To_Byte_Array_unsign_3 */
										UpdateProbes(&state, debugOffset, 82 /*0x12776BA8*/, (uChar*)&(heap->a_String_To_Byte_Array_unsign_3)); /* assign */
										SetSignalReady(19, 1);
										PDAArrIncRefCnt(heap->a_String_To_Byte_Array_unsign_3, (uInt16)1); /* Primitive */
										CCGDebugSynchNode(&state, 35, 36, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										{ /* Array Index 1D */
											heap->by_Index_Array_element_2 = *(uChar *)NthElemFast(((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_3), heap->l_index_4, 1);
											/*SetSignalReady( 0x15, 6);*//* by_Index_Array_element_2 */
											UpdateProbes(&state, debugOffset, 85 /*0x1277CFD0*/, (uChar*)&(heap->by_Index_Array_element_2)); /* assign */
											SetSignalReady(19, 1);
										}
	if (heap->a_String_To_Byte_Array_unsign_3){--((PDAArrPtr)heap->a_String_To_Byte_Array_unsign_3)->refcnt;}
										/**/
										/* Not Equal? */
										/**/
										CCGDebugSynchNode(&state, 36, 37, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										heap->b_Not_Equal__x____y__2 =  (heap->by_Sent_Command__0__CT_3 != heap->by_Index_Array_element_2);
										/*SetSignalReady( 0x20, 5);*//* b_Not_Equal__x____y__2 */
										UpdateProbes(&state, debugOffset, 86 /*0x1277CF70*/, (uChar*)&(heap->b_Not_Equal__x____y__2)); /* assign */
										SetSignalReady(19, 1);
									}
									heap->runStatE58A320 = eFinished;
									InitSignalReady(20, 3);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat72F25CC != eFinished)
							/*&& GetSignalReady( 0x20, 5)*//* b_Not_Equal__x____y__2 */
							/*&& GetSignalReady( 0x12, 3)*//* s_VISA_Read_VISA_resource_nam_4 */
							/*&& GetSignalReady( 0x3, 3)*//* c_VISA_Read_error_out_3 */
							/*&& GetSignalReady( 0x15, 6)*//* by_Index_Array_element_2 */
							/*&& GetSignalReady( 0x15, 7)*//* by_Sent_Command__0__CT_3 */
							/*&& GetSignalReady( 0x10, 4)*//* a_String_To_Byte_Array_unsign_3 */
							/*&& GetSignalReady( 0x16, 2)*//* by_Length_Of_Sent_MSG__0__CT_3 *//*) {*/
							&& GetSignalReady( 19 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									heap->runStat72F25CC = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F25CC( (Boolean)(bRunToFinish && (nReady < 2)) );
									if (heap->runStat72F25CC == eNotFinished) {
										runStat = eNotFinished;
									}
									else if (heap->runStat72F25CC == eFail) {
										CGenErr();
									}
									else {
										InitSignalReady(19, 7);
									}
									if (runStat == eFinished) {
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStatE58A200 != eFinished)
							/*&& GetSignalReady( 0x11, 5)*//* a_Case_Structure_CT_10 *//*) {*/
							&& GetSignalReady( 7 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										/**/
										/* Array To Cluster */
										/**/
										CCGDebugSynchNode(&state, 38, 39, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (!PDAArrToClust(heap->a_Case_Structure_CT_10, 0x100000 | ArrayDataType, (int32)2, &(heap->c_Array_To_Cluster_cluster_2), 0xF0000 | ClusterDataType)) {
											CGenErr();
										}
;
										/*SetSignalReady( 0x7, 5);*//* c_Array_To_Cluster_cluster_2 */
										UpdateProbes(&state, debugOffset, 94 /*0x1277CAF0*/, (uChar*)&(heap->c_Array_To_Cluster_cluster_2)); /* assign */
										CCGDebugSynchNode(&state, 39, 40, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
/* Unbundle */
										{
											cl_F0000* cl_006 = (cl_F0000*)&heap->c_Array_To_Cluster_cluster_2;
											heap->by_Unbundle_unsigned_byte_arr_1 = cl_006->el_0;
											/*SetSignalReady( 0x15, 2);*//* by_Unbundle_unsigned_byte_arr_1 */
											UpdateProbes(&state, debugOffset, 93 /*0x1277CB50*/, (uChar*)&(heap->by_Unbundle_unsigned_byte_arr_1)); /* assign */
											heap->by_Unbundle_unsigned_byte_arra_1 = cl_006->el_1;
											/*SetSignalReady( 0x15, 3);*//* by_Unbundle_unsigned_byte_arra_1 */
											UpdateProbes(&state, debugOffset, 92 /*0x1277CBB0*/, (uChar*)&(heap->by_Unbundle_unsigned_byte_arra_1)); /* assign */
										}
										/**/
										/* Join Numbers */
										/**/
										CCGDebugSynchNode(&state, 40, 41, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										PDAJoin( &(heap->by_Unbundle_unsigned_byte_arra_1), uCharDataType, &(heap->by_Unbundle_unsigned_byte_arr_1), uCharDataType, &(heap->n_Join_Numbers__hi_lo__2) );
										/*SetSignalReady( 0x15, 0);*//* n_Join_Numbers__hi_lo__2 */
										UpdateProbes(&state, debugOffset, 75 /*0x12776FC8*/, (uChar*)&(heap->n_Join_Numbers__hi_lo__2)); /* assign */
										SetSignalReady(5, 1);
									}
									heap->runStatE58A200 = eFinished;
									InitSignalReady(7, 1);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStatE58A3E0 != eFinished)
							/*&& GetSignalReady( 0x3, 4)*//* c_Case_Structure_CT_18 */
							/*&& GetSignalReady( 0x10, 1)*//* a_Case_Structure_CT_8 */
							/*&& GetSignalReady( 0x10, 0)*//* s_Case_Structure_CT_18 *//*) {*/
							&& GetSignalReady( 6 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStatE58A3E0 == eReady) {
									}
									CCGDebugSynchIUse(&state, 41, 42, 33, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility MODBUS RTU CRC16.vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStatE58A3E0 == eReady) {
											CreateArgListStatic(heap->ArgsE58A3E1, 3, 4 );
											argIn(heap->ArgsE58A3E1, 0).nType = 0x0 | ClusterDataType;
											argIn(heap->ArgsE58A3E1, 0).pValue = (void *)&heap->c_Case_Structure_CT_18;
											argIn(heap->ArgsE58A3E1, 1).nType = 0x100000 | ArrayDataType;
											argIn(heap->ArgsE58A3E1, 1).pValue = (void *)&heap->a_Case_Structure_CT_8;
											argIn(heap->ArgsE58A3E1, 2).nType = StringDataType;
											argIn(heap->ArgsE58A3E1, 2).pValue = (void *)&heap->s_Case_Structure_CT_18;
											argOut(heap->ArgsE58A3E1, 0).nType = 0x0 | ClusterDataType;
											argOut(heap->ArgsE58A3E1, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_CRC16_vi_e_1;
											argOut(heap->ArgsE58A3E1, 1).nType = uInt16DataType;
											argOut(heap->ArgsE58A3E1, 1).pValue = (void *)&heap->n_Utility_MODBUS_RTU_CRC16_vi_C_1;
											argOut(heap->ArgsE58A3E1, 2).nType = 0;
											argOut(heap->ArgsE58A3E1, 2).pValue = NULL;
											argOut(heap->ArgsE58A3E1, 3).nType = StringDataType;
											argOut(heap->ArgsE58A3E1, 3).pValue = (void *)&heap->s_Utility_MODBUS_RTU_CRC16_vi_V_1;
										}
										if (!Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A3E0.callerID) {
											Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A3E0.callerID = ++gCallerID;
										}
										heap->runStatE58A3E0 = Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_Run( &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A3E0, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsE58A3E1)[0], (ArgList *)((ArgList **)heap->ArgsE58A3E1)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 42, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStatE58A3E0 == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStatE58A3E0 == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStatE58A3E0 == eFinished)) {
											/*SetSignalReady( 0x3, 2);*//* c_Utility_MODBUS_RTU_CRC16_vi_e_1 */
											UpdateProbes(&state, debugOffset, 89 /*0x1277CD90*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_CRC16_vi_e_1)); /* assign */
											SetSignalReady(4, 1);
											/*SetSignalReady( 0x15, 1);*//* n_Utility_MODBUS_RTU_CRC16_vi_C_1 */
											UpdateProbes(&state, debugOffset, 76 /*0x12776F68*/, (uChar*)&(heap->n_Utility_MODBUS_RTU_CRC16_vi_C_1)); /* assign */
											SetSignalReady(5, 1);
											/*SetSignalReady( 0xF, 7);*//* s_Utility_MODBUS_RTU_CRC16_vi_V_1 */
											UpdateProbes(&state, debugOffset, 77 /*0x12776F08*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_CRC16_vi_V_1)); /* assign */
											SetSignalReady(4, 1);
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStatE58A3E0 == eFinished) {
										InitSignalReady(6, 3);
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStatE58A0E0 != eFinished)
							/*&& GetSignalReady( 0x15, 1)*//* n_Utility_MODBUS_RTU_CRC16_vi_C_1 */
							/*&& GetSignalReady( 0x15, 0)*//* n_Join_Numbers__hi_lo__2 *//*) {*/
							&& GetSignalReady( 5 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										/**/
										/* Not Equal? */
										/**/
										CCGDebugSynchNode(&state, 42, 43, 33, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										heap->b_Not_Equal__x____y__3 =  (heap->n_Join_Numbers__hi_lo__2 != heap->n_Utility_MODBUS_RTU_CRC16_vi_C_1);
										/*SetSignalReady( 0x20, 3);*//* b_Not_Equal__x____y__3 */
										UpdateProbes(&state, debugOffset, 90 /*0x1277CCD0*/, (uChar*)&(heap->b_Not_Equal__x____y__3)); /* assign */
										SetSignalReady(4, 1);
									}
									heap->runStatE58A0E0 = eFinished;
									InitSignalReady(5, 2);
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStatE58A4A0 != eFinished)
							/*&& GetSignalReady( 0x3, 2)*//* c_Utility_MODBUS_RTU_CRC16_vi_e_1 */
							/*&& GetSignalReady( 0x6, 4)*//* l_Constant_2 */
							/*&& GetSignalReady( 0x20, 3)*//* b_Not_Equal__x____y__3 */
							/*&& GetSignalReady( 0xF, 7)*//* s_Utility_MODBUS_RTU_CRC16_vi_V_1 *//*) {*/
							&& GetSignalReady( 4 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStatE58A4A0 == eReady) {
									}
									CCGDebugSynchIUse(&state, 43, 44, 33, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility Generate Instrument Error.vi");
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
									{
										ControlDataItemPtr cdPtr = LVGetCurrentControlData();
										if (heap->runStatE58A4A0 == eReady) {
											CreateArgListStatic(heap->ArgsE58A4A1, 4, 2 );
											argIn(heap->ArgsE58A4A1, 0).nType = 0x0 | ClusterDataType;
											argIn(heap->ArgsE58A4A1, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_CRC16_vi_e_1;
											argIn(heap->ArgsE58A4A1, 1).nType = int32DataType;
											argIn(heap->ArgsE58A4A1, 1).pValue = (void *)&heap->l_Constant_2;
											argIn(heap->ArgsE58A4A1, 2).nType = BooleanDataType;
											argIn(heap->ArgsE58A4A1, 2).pValue = (void *)&heap->b_Not_Equal__x____y__3;
											argIn(heap->ArgsE58A4A1, 3).nType = StringDataType;
											argIn(heap->ArgsE58A4A1, 3).pValue = (void *)&heap->s_Utility_MODBUS_RTU_CRC16_vi_V_1;
											argOut(heap->ArgsE58A4A1, 0).nType = 0x0 | ClusterDataType;
											argOut(heap->ArgsE58A4A1, 0).pValue = (void *)&heap->c_Utility_Generate_Instrument_E_1;
											argOut(heap->ArgsE58A4A1, 1).nType = StringDataType;
											argOut(heap->ArgsE58A4A1, 1).pValue = (void *)&heap->s_Utility_Generate_Instrument_E_1;
										}
										if (!Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A4A0.callerID) {
											Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A4A0.callerID = ++gCallerID;
										}
										heap->runStatE58A4A0 = Watflow_F4_lvlib_Utility_Generate_Instrument_Error_Run( &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr->i0E58A4A0, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsE58A4A1)[0], (ArgList *)((ArgList **)heap->ArgsE58A4A1)[1], &gPauseThisVI );
										LVSetCurrentControlData(cdPtr);
										CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 44, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}

										if (heap->runStatE58A4A0 == eNotFinished) {
											runStat = eNotFinished;
										}
										if (heap->runStatE58A4A0 == eFail || gLastError) {
											CGenErr();
										}
										if (gAppStop || (heap->runStatE58A4A0 == eFinished)) {
											/*SetSignalReady( 0x3, 0);*//* c_Utility_Generate_Instrument_E_1 */
											UpdateProbes(&state, debugOffset, 96 /*0x1277C9D0*/, (uChar*)&(heap->c_Utility_Generate_Instrument_E_1)); /* assign */
											SetSignalReady(3, 1);
											/*SetSignalReady( 0x10, 2);*//* s_Utility_Generate_Instrument_E_1 */
											UpdateProbes(&state, debugOffset, 80 /*0x12776CC8*/, (uChar*)&(heap->s_Utility_Generate_Instrument_E_1)); /* assign */
											SetSignalReady(3, 1);
										}
										if (gAppStop) {
											gAppStop=true;/* opt bug fix*/
											return eFinished;
										}
									}
									if (heap->runStatE58A4A0 == eFinished) {
										InitSignalReady(4, 4);
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStatE477EAA != eFinished)
							/*&& GetSignalReady( 0x10, 3)*//* a_Case_Structure_CT_9 */
							/*&& GetSignalReady( 0x10, 2)*//* s_Utility_Generate_Instrument_E_1 */
							/*&& GetSignalReady( 0x3, 0)*//* c_Utility_Generate_Instrument_E_1 *//*) {*/
							&& GetSignalReady( 3 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										heap->a_Case_Structure_CT_5 = heap->a_Case_Structure_CT_9;
										/*SetSignalReady( 0xF, 4);*//* a_Case_Structure_CT_5 */
										heap->s_Case_Structure_CT_15 = heap->s_Utility_Generate_Instrument_E_1;
										/*SetSignalReady( 0xC, 3);*//* s_Case_Structure_CT_15 */
										MemMove( &heap->c_Case_Structure_CT_15, &heap->c_Utility_Generate_Instrument_E_1, sizeof( cl_00000 ) );
										/*SetSignalReady( 0x4, 5);*//* c_Case_Structure_CT_15 */
									}
									heap->runStatE477EAA = eFinished;
									InitSignalReady(3, 3);
									continue;
								}
							}
						}
						if( runStat == eFinished && pass )
						{
							volatile int dummy;
							CCGDebugSynchSRN(&state, 44, 33, &snode72F964C, debugOffset);
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}

							dummy=1;
						}
						if (pass) {
							if (runStat == eFinished) {
								bEndDiagram = true;
							}
							if (!bRunToFinish) {
								if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
									if (gAppStop) {
										return eFinished;
									}
									if (gLastError) {
										CGenErr();
									}
									if (!gAppStop && !gLastError) {
										return eNotFinished;
									}
								}
							}
						}
					} /* end for */
					if (bEndDiagram) break;
				} /* end while */
			} /* end case */
			break;
			/* begin case */
			default : {
				uInt32 diagramIdx = 9;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(21, 3);
						/*InitSignalReady( 0x11, 2);*//* a_Case_Structure_CT_6 */
						/*InitSignalReady( 0x11, 1);*//* s_Case_Structure_CT_16 */
						InitSignalReady(33, 3);
						/*InitSignalReady( 0x10, 5);*//* s_VISA_Read_VISA_resource_name_ */
						/*InitSignalReady( 0x5, 1);*//* c_Case_Structure_CT_16 */
						/*InitSignalReady( 0x5, 0);*//* c_VISA_Read_error_out */
						/*InitSignalReady( 0xC, 2);*//* s_VISA_Read_read_buffer */
						InitSignalReady(34, 3);
						/*InitSignalReady( 0xB, 5);*//* s_Property_Node_reference_out_3 */
						/*InitSignalReady( 0x5, 6);*//* dw_byte_count__0_ */
						/*InitSignalReady( 0x4, 7);*//* c_Property_Node_error_out_CT_4 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->dw_byte_count__0_ = 3;
						/*SetSignalReady( 0x5, 6);*//* dw_byte_count__0_ */
						UpdateProbes(&state, debugOffset, 32 /*0xE58A620*/, (uChar*)&(heap->dw_byte_count__0_)); /* assign */
						SetSignalReady(34, 1);
						MemMove( &heap->c_Property_Node_error_out_CT_4, &heap->c_Property_Node_error_out_CT_3, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x4, 7);*//* c_Property_Node_error_out_CT_4 */
						UpdateProbes(&state, debugOffset, 33 /*0xE58A5C0*/, (uChar*)&(heap->c_Property_Node_error_out_CT_4)); /* assign */
						SetSignalReady(34, 1);
						heap->s_Property_Node_reference_out_3 = heap->s_Property_Node_reference_out_2;
						/*SetSignalReady( 0xB, 5);*//* s_Property_Node_reference_out_3 */
						UpdateProbes(&state, debugOffset, 31 /*0xE58A6E0*/, (uChar*)&(heap->s_Property_Node_reference_out_3)); /* assign */
						SetSignalReady(34, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						/**/
						/* VISA Read */
						/**/
						CCGDebugSynchNode(&state, 9, 10, 9, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (VisaRead(heap->s_Property_Node_reference_out_3,  &(heap->dw_byte_count__0_),  uInt32DataType,  &(heap->c_Property_Node_error_out_CT_4),  &(heap->s_VISA_Read_VISA_resource_name_),  (VoidHand)NULL,  &(heap->s_VISA_Read_read_buffer),  &(heap->c_VISA_Read_error_out) ) == eFail) {
							CGenErr();
						}
						/*SetSignalReady( 0x5, 0);*//* c_VISA_Read_error_out */
						UpdateProbes(&state, debugOffset, 29 /*0xE58A7A0*/, (uChar*)&(heap->c_VISA_Read_error_out)); /* assign */
						SetSignalReady(33, 1);
						/*SetSignalReady( 0xC, 2);*//* s_VISA_Read_read_buffer */
						UpdateProbes(&state, debugOffset, 30 /*0xE58A740*/, (uChar*)&(heap->s_VISA_Read_read_buffer)); /* assign */
						SetSignalReady(33, 1);
						/*SetSignalReady( 0x10, 5);*//* s_VISA_Read_VISA_resource_name_ */
						UpdateProbes(&state, debugOffset, 27 /*0xE58A8C0*/, (uChar*)&(heap->s_VISA_Read_VISA_resource_name_)); /* assign */
						SetSignalReady(33, 1);
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 2 : {
						heap->runStat72F97CC = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F97CC( bRunToFinish  );
						if (heap->runStat72F97CC == eNotFinished) {
							return eNotFinished;
						}
						else if (heap->runStat72F97CC == eFail) {
							CGenErr();
						}
						heap->runStat72F97CC = eReady;
						nStep++; }
/* start q el linear (0 or 1 struct) */
					case 3 : {
						heap->a_Case_Structure_CT_5 = heap->a_Case_Structure_CT_6;
						/*SetSignalReady( 0xF, 4);*//* a_Case_Structure_CT_5 */
						heap->s_Case_Structure_CT_15 = heap->s_Case_Structure_CT_16;
						/*SetSignalReady( 0xC, 3);*//* s_Case_Structure_CT_15 */
						MemMove( &heap->c_Case_Structure_CT_15, &heap->c_Case_Structure_CT_16, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x4, 5);*//* c_Case_Structure_CT_15 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 11, 9, &snode72F964C, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
		}
		heap->runStatE477EA9 = eReady;
		heap->runStatE58A320 = eReady;
		heap->runStat72F25CC = eReady;
		heap->runStatE58A200 = eReady;
		heap->runStatE58A3E0 = eReady;
		heap->runStatE58A0E0 = eReady;
		heap->runStatE58A4A0 = eReady;
		heap->runStatE477EAA = eReady;
		MemMove( &heap->c_Case_Structure_CT_14, &heap->c_Case_Structure_CT_15, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x3, 5);*//* c_Case_Structure_CT_14 */
		UpdateProbes(&state, debugOffset, 20 /*0x1277B888*/, (uChar*)&(heap->c_Case_Structure_CT_14)); /* assign */
		SetSignalReady(2, 1);
		heap->s_Case_Structure_CT_14 = heap->s_Case_Structure_CT_15;
		/*SetSignalReady( 0x12, 2);*//* s_Case_Structure_CT_14 */
		UpdateProbes(&state, debugOffset, 15 /*0x1277BB28*/, (uChar*)&(heap->s_Case_Structure_CT_14)); /* assign */
		SetSignalReady(1, 1);
		heap->a_Case_Structure_CT_4 = heap->a_Case_Structure_CT_5;
		/*SetSignalReady( 0xE, 5);*//* a_Case_Structure_CT_4 */
		UpdateProbes(&state, debugOffset, 21 /*0x1277B828*/, (uChar*)&(heap->a_Case_Structure_CT_4)); /* assign */
		SetSignalReady(1, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F964C, 5, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	/* Cluster Inc Ref Count:  Select: sel tunnels*/
	{
		cl_00000* cl_007 = (cl_00000*)&heap->c_Case_Structure_CT_14;
		PDAStrIncRefCnt(cl_007->el_2, (uInt16)1); /* Select: sel tunnels */
	}
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72FA6CC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72FA6CC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72FA6CC == eReady) {
		MemMove( &heap->c_error_in__no_error__2, ((ClusterControlData*)FPData(error_in__no_error___162218424_ctlid))->pVal, sizeof( cl_00000 ) );
		MemSet(((ClusterControlData*)FPData(error_in__no_error___162218424_ctlid))->pVal, sizeof( cl_00000 ), 0);
		/*SetSignalReady( 0x0, 2);*//* c_error_in__no_error__2 */
		UpdateProbes(&state, debugOffset, 3 /*0x127755A0*/, (uChar*)&(heap->c_error_in__no_error__2)); /* assign */
		/* Cluster Inc Ref Count:  FPTerm*/
		{
			cl_00000* cl_008 = (cl_00000*)&heap->c_error_in__no_error__2;
			PDAStrIncRefCnt(cl_008->el_2, (uInt16)1); /* FPTerm */
		}
		if (!GetRingFieldValue( FPData(Receive_Message_Type__0__By_The_Number_Of_Bytes___162217272_ctlid), &heap->n_Receive_Message_Type__0__By_T, uInt16DataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x14, 5);*//* n_Receive_Message_Type__0__By_T */
		UpdateProbes(&state, debugOffset, 8 /*0x12775240*/, (uChar*)&(heap->n_Receive_Message_Type__0__By_T)); /* assign */
		heap->s_VISA_resource_name_2 = FPData(VISA_resource_name__163481336_ctlid);
		PDAStrIncRefCnt(heap->s_VISA_resource_name_2, (uInt16)1);
		/*SetSignalReady( 0x12, 0);*//* s_VISA_resource_name_2 */
		UpdateProbes(&state, debugOffset, 7 /*0x12775300*/, (uChar*)&(heap->s_VISA_resource_name_2)); /* assign */
		if (!GetNumericFieldValue( FPData(Length_Of_Sent_MSG__0___163482200_ctlid), &heap->by_Length_Of_Sent_MSG__0_, uCharDataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x1B, 4);*//* by_Length_Of_Sent_MSG__0_ */
		UpdateProbes(&state, debugOffset, 6 /*0x127753C0*/, (uChar*)&(heap->by_Length_Of_Sent_MSG__0_)); /* assign */
		if (!GetNumericFieldValue( FPData(Sent_Command__0___163480856_ctlid), &heap->by_Sent_Command__0_, uCharDataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x1B, 5);*//* by_Sent_Command__0_ */
		UpdateProbes(&state, debugOffset, 5 /*0x12775480*/, (uChar*)&(heap->by_Sent_Command__0_)); /* assign */
	}
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72FA6CC == eReady) {
			CCGDebugSynchSNode(&state, 1, 2, 1, &snode72FA6CC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat1078DA81 = eReady;
			heap->runStat1078DA82 = eReady;
			heap->runStat105915A9 = eReady;
			heap->runStat72FD14C = eReady;
			heap->runStat72F964C = eReady;
			heap->runStat101D4F68 = eReady;
			heap->runStat105915AA = eReady;
			if (!PDAClusterGetElemByPosStatic( &heap->c_error_in__no_error__2, 0x0 | ClusterDataType, 0, &heap->c_error_in__no_error__CS, BooleanDataType, NULL )) {
				CGenErr();
			}
			/*SetSignalReady( 0x1F, 7);*//* c_error_in__no_error__CS */
			MemMove( &heap->c_error_in__no_error__CT, &heap->c_error_in__no_error__2, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x1, 2);*//* c_error_in__no_error__CT */
			heap->n_Receive_Message_Type__0__By_T_1 = heap->n_Receive_Message_Type__0__By_T;
			/*SetSignalReady( 0x14, 7);*//* n_Receive_Message_Type__0__By_T_1 */
			heap->s_VISA_resource_name_CT = heap->s_VISA_resource_name_2;
			/*SetSignalReady( 0xE, 1);*//* s_VISA_resource_name_CT */
			heap->by_Length_Of_Sent_MSG__0__CT = heap->by_Length_Of_Sent_MSG__0_;
			/*SetSignalReady( 0x17, 6);*//* by_Length_Of_Sent_MSG__0__CT */
			heap->by_Sent_Command__0__CT = heap->by_Sent_Command__0_;
			/*SetSignalReady( 0x16, 3);*//* by_Sent_Command__0__CT */
		}
		switch ( heap->c_error_in__no_error__CS ) {
			/* begin case */
			case 1 : {
				uInt32 diagramIdx = 69;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(0, 3);
						/*InitSignalReady( 0x11, 0);*//* s_VISA_resource_name_CT_2 */
						/*InitSignalReady( 0x0, 1);*//* c_error_in__no_error__CT_2 */
						/*InitSignalReady( 0x9, 5);*//* a_unsigned_byte_array_2 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						/*SetSignalReady( 0x9, 5);*//* a_unsigned_byte_array_2 */
						UpdateProbes(&state, debugOffset, 161 /*0x12775960*/, (uChar*)&(heap->a_unsigned_byte_array_2)); /* assign */
						SetSignalReady(0, 1);
						PDAArrIncRefCnt(heap->a_unsigned_byte_array_2, (uInt16)1); /* BDConst - alloc type */
						MemMove( &heap->c_error_in__no_error__CT_2, &heap->c_error_in__no_error__CT, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x0, 1);*//* c_error_in__no_error__CT_2 */
						UpdateProbes(&state, debugOffset, 160 /*0x127759C0*/, (uChar*)&(heap->c_error_in__no_error__CT_2)); /* assign */
						SetSignalReady(0, 1);
						heap->s_VISA_resource_name_CT_2 = heap->s_VISA_resource_name_CT;
						/*SetSignalReady( 0x11, 0);*//* s_VISA_resource_name_CT_2 */
						UpdateProbes(&state, debugOffset, 159 /*0x12775A20*/, (uChar*)&(heap->s_VISA_resource_name_CT_2)); /* assign */
						SetSignalReady(0, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						heap->a_Case_Structure_CT_3 = heap->a_unsigned_byte_array_2;
						/*SetSignalReady( 0x10, 7);*//* a_Case_Structure_CT_3 */
						heap->s_Case_Structure_CT_13 = heap->s_VISA_resource_name_CT_2;
						/*SetSignalReady( 0x11, 6);*//* s_Case_Structure_CT_13 */
						MemMove( &heap->c_Case_Structure_CT_13, &heap->c_error_in__no_error__CT_2, sizeof( cl_00000 ) );
						/*SetSignalReady( 0x2, 1);*//* c_Case_Structure_CT_13 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 69, 69, &snode72FA6CC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				int16 pass;
				Boolean bEndDiagram = false;
				uInt32 diagramIdx = 3;
				uInt32 id = LVGetTimerFlag();
				while (!gAppStop && !gLastError) {
					nReady = 0;
					bEndDiagram = false;
					runStat = eFinished;
					for (pass=0;pass<2;pass++) {
						/*********************************************************************************/
						/* To make sure the */
						/* communication  */
						/* works even if */
						/* driver is not  */
						/* initialized */
						/*********************************************************************************/
						{
/* start q el linear (2 struct) */
							if ((heap->runStat105915A9 != eFinished)
							/*) {*/
							) {
								if (pass == 0) {
									InitSignalReady(36, 3);
									/*InitSignalReady( 0x14, 6);*//* n_Serial_Settings_Serial_End_Mo_1 */
									InitSignalReady(35, 5);
									/*InitSignalReady( 0x2, 3);*//* c_Property_Node_error_out_1 */
									/*InitSignalReady( 0x2, 4);*//* c_error_in__no_error__CT_1 */
									/*InitSignalReady( 0x13, 4);*//* s_Property_Node_reference_out_1 */
									/*InitSignalReady( 0x12, 4);*//* s_VISA_resource_name_CT_1 */
									InitSignalReady(1, 3);
									/*InitSignalReady( 0x2, 7);*//* c_Select_s__t_f_1 */
									/*InitSignalReady( 0x12, 2);*//* s_Case_Structure_CT_14 */
									/*InitSignalReady( 0x3, 1);*//* c_Constant_1 */
									/*InitSignalReady( 0x20, 4);*//* b_Not_Equal__x____y_ */
									/*InitSignalReady( 0x7, 1);*//* l_Constant */
									/*InitSignalReady( 0x6, 3);*//* l_Unbundle_By_Name_code */
									InitSignalReady(2, 1);
									/*InitSignalReady( 0x3, 5);*//* c_Case_Structure_CT_14 */
									/*InitSignalReady( 0xE, 5);*//* a_Case_Structure_CT_4 */
									/*InitSignalReady( 0x1B, 3);*//* by_Sent_Command__0__CT_1 */
									/*InitSignalReady( 0x1B, 6);*//* by_Length_Of_Sent_MSG__0__CT_1 */
									/*InitSignalReady( 0x14, 4);*//* n_Receive_Message_Type__0__By__1 */
								}
								else {
									HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
									{
										heap->l_Constant = 1073676294;
										/*SetSignalReady( 0x7, 1);*//* l_Constant */
										UpdateProbes(&state, debugOffset, 18 /*0x1277B948*/, (uChar*)&(heap->l_Constant)); /* assign */
										/*SetSignalReady( 0x3, 1);*//* c_Constant_1 */
										UpdateProbes(&state, debugOffset, 16 /*0x1277BA68*/, (uChar*)&(heap->c_Constant_1)); /* assign */
										/* Cluster Inc Ref Count:  BDConst - alloc type*/
										{
											cl_00000* cl_010 = (cl_00000*)&heap->c_Constant_1;
											PDAStrIncRefCnt(cl_010->el_2, (uInt16)1); /* BDConst - alloc type */
										}
										MemMove( &heap->c_error_in__no_error__CT_1, &heap->c_error_in__no_error__CT, sizeof( cl_00000 ) );
										/*SetSignalReady( 0x2, 4);*//* c_error_in__no_error__CT_1 */
										UpdateProbes(&state, debugOffset, 11 /*0x1277BD68*/, (uChar*)&(heap->c_error_in__no_error__CT_1)); /* assign */
										SetSignalReady(36, 1);
										heap->n_Receive_Message_Type__0__By__1 = heap->n_Receive_Message_Type__0__By_T_1;
										/*SetSignalReady( 0x14, 4);*//* n_Receive_Message_Type__0__By__1 */
										UpdateProbes(&state, debugOffset, 24 /*0x1277B648*/, (uChar*)&(heap->n_Receive_Message_Type__0__By__1)); /* assign */
										SetSignalReady(35, 1);
										heap->s_VISA_resource_name_CT_1 = heap->s_VISA_resource_name_CT;
										/*SetSignalReady( 0x12, 4);*//* s_VISA_resource_name_CT_1 */
										UpdateProbes(&state, debugOffset, 13 /*0x1277BC48*/, (uChar*)&(heap->s_VISA_resource_name_CT_1)); /* assign */
										SetSignalReady(36, 1);
										heap->by_Length_Of_Sent_MSG__0__CT_1 = heap->by_Length_Of_Sent_MSG__0__CT;
										/*SetSignalReady( 0x1B, 6);*//* by_Length_Of_Sent_MSG__0__CT_1 */
										UpdateProbes(&state, debugOffset, 23 /*0x1277B708*/, (uChar*)&(heap->by_Length_Of_Sent_MSG__0__CT_1)); /* assign */
										SetSignalReady(35, 1);
										heap->by_Sent_Command__0__CT_1 = heap->by_Sent_Command__0__CT;
										/*SetSignalReady( 0x1B, 3);*//* by_Sent_Command__0__CT_1 */
										UpdateProbes(&state, debugOffset, 22 /*0x1277B7C8*/, (uChar*)&(heap->by_Sent_Command__0__CT_1)); /* assign */
										SetSignalReady(35, 1);
										heap->n_Serial_Settings_Serial_End_Mo_1 = 0;
										/*SetSignalReady( 0x14, 6);*//* n_Serial_Settings_Serial_End_Mo_1 */
										UpdateProbes(&state, debugOffset, 9 /*0x1277BE28*/, (uChar*)&(heap->n_Serial_Settings_Serial_End_Mo_1)); /* assign */
										SetSignalReady(36, 1);
									}
									heap->runStat105915A9 = eFinished;
									continue;
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat72FD14C != eFinished)
							/*&& GetSignalReady( 0x12, 4)*//* s_VISA_resource_name_CT_1 */
							/*&& GetSignalReady( 0x2, 4)*//* c_error_in__no_error__CT_1 */
							/*&& GetSignalReady( 0x14, 6)*//* n_Serial_Settings_Serial_End_Mo_1 *//*) {*/
							&& GetSignalReady( 36 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									if (heap->runStat72FD14C == eReady) {
									}
									CCGDebugSynchNode(&state, 3, 4, 3, debugOffset);
									if(gAppStop) {
										gAppStop = true;
										return eFinished;
									}
/* Property node */
									{
										PropInfo props[1] = {
											{kSerial_Settings_End_Mode_for_Reads, &heap->n_Serial_Settings_Serial_End_Mo_1, uInt16DataType}
										};
										if (!VisaSetProperties( heap->s_VISA_resource_name_CT_1, &heap->s_Property_Node_reference_out_1, &heap->c_error_in__no_error__CT_1, &heap->c_Property_Node_error_out_1, props, 1)) {
											CGenErr();
										}
										heap->runStat72FD14C = eFinished;
									}
									/*SetSignalReady( 0x2, 3);*//* c_Property_Node_error_out_1 */
									UpdateProbes(&state, debugOffset, 10 /*0x1277BDC8*/, (uChar*)&(heap->c_Property_Node_error_out_1)); /* assign */
									SetSignalReady(35, 1);
									/*SetSignalReady( 0x13, 4);*//* s_Property_Node_reference_out_1 */
									UpdateProbes(&state, debugOffset, 12 /*0x1277BD08*/, (uChar*)&(heap->s_Property_Node_reference_out_1)); /* assign */
									SetSignalReady(35, 1);
									if (heap->runStat72FD14C == eFinished) {
										InitSignalReady(36, 3);
										continue;
									}
								}
							}
/* start q el struct (2 struct) */
							if ((heap->runStat72F964C != eFinished)
							/*&& GetSignalReady( 0x14, 4)*//* n_Receive_Message_Type__0__By__1 */
							/*&& GetSignalReady( 0x2, 3)*//* c_Property_Node_error_out_1 */
							/*&& GetSignalReady( 0x13, 4)*//* s_Property_Node_reference_out_1 */
							/*&& GetSignalReady( 0x1B, 6)*//* by_Length_Of_Sent_MSG__0__CT_1 */
							/*&& GetSignalReady( 0x1B, 3)*//* by_Sent_Command__0__CT_1 *//*) {*/
							&& GetSignalReady( 35 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									heap->runStat72F964C = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72F964C( (Boolean)(bRunToFinish && (nReady < 2)) );
									if (heap->runStat72F964C == eNotFinished) {
										runStat = eNotFinished;
									}
									else if (heap->runStat72F964C == eFail) {
										CGenErr();
									}
									else {
										InitSignalReady(35, 5);
									}
									if (runStat == eFinished) {
										continue;
									}
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStat101D4F68 != eFinished)
							/*&& GetSignalReady( 0x3, 5)*//* c_Case_Structure_CT_14 *//*) {*/
							&& GetSignalReady( 2 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										CCGDebugSynchNode(&state, 5, 6, 3, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
/* Unbundle by name */
										{
											cl_00000* cl_011 = (cl_00000*)&heap->c_Case_Structure_CT_14;
											heap->l_Unbundle_By_Name_code = cl_011->el_1;
											/*SetSignalReady( 0x6, 3);*//* l_Unbundle_By_Name_code */
											UpdateProbes(&state, debugOffset, 19 /*0x1277B8E8*/, (uChar*)&(heap->l_Unbundle_By_Name_code)); /* assign */
	/* Free Cluster */
											{
												cl_00000* cl_012 = (cl_00000*)&heap->c_Case_Structure_CT_14;
				if (cl_012->el_2 && --((PDAStrPtr)cl_012->el_2)->refcnt == 0 && !((PDAStrPtr)cl_012->el_2)->staticStr) {
													MemHandleFree( cl_012->el_2 );
												}
											}
										}
										/**/
										/* Not Equal? */
										/**/
										CCGDebugSynchNode(&state, 6, 7, 3, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										heap->b_Not_Equal__x____y_ =  (heap->l_Unbundle_By_Name_code != heap->l_Constant);
										/*SetSignalReady( 0x20, 4);*//* b_Not_Equal__x____y_ */
										UpdateProbes(&state, debugOffset, 17 /*0x1277B9A8*/, (uChar*)&(heap->b_Not_Equal__x____y_)); /* assign */
										/**/
										/* Select */
										/**/
										CCGDebugSynchNode(&state, 7, 8, 3, debugOffset);
										if(gAppStop) {
											gAppStop = true;
											return eFinished;
										}
										if (heap->b_Not_Equal__x____y_) {
											MemMove( &heap->c_Select_s__t_f_1, &heap->c_Case_Structure_CT_14, sizeof( cl_00000 ) );
	/* Free Cluster */
											{
												cl_00000* cl_013 = (cl_00000*)&heap->c_Constant_1;
				if (cl_013->el_2 && --((PDAStrPtr)cl_013->el_2)->refcnt == 0 && !((PDAStrPtr)cl_013->el_2)->staticStr) {
													MemHandleFree( cl_013->el_2 );
												}
											}
										}
										else {
											MemMove( &heap->c_Select_s__t_f_1, &heap->c_Constant_1, sizeof( cl_00000 ) );
	/* Free Cluster */
											{
												cl_00000* cl_014 = (cl_00000*)&heap->c_Case_Structure_CT_14;
				if (cl_014->el_2 && --((PDAStrPtr)cl_014->el_2)->refcnt == 0 && !((PDAStrPtr)cl_014->el_2)->staticStr) {
													MemHandleFree( cl_014->el_2 );
												}
											}
										}
										/*SetSignalReady( 0x2, 7);*//* c_Select_s__t_f_1 */
										UpdateProbes(&state, debugOffset, 14 /*0x1277BB88*/, (uChar*)&(heap->c_Select_s__t_f_1)); /* assign */
										SetSignalReady(1, 1);
									}
									heap->runStat101D4F68 = eFinished;
									InitSignalReady(2, 1);
									continue;
								}
							}
/* start q el linear (2 struct) */
							if ((heap->runStat105915AA != eFinished)
							/*&& GetSignalReady( 0xE, 5)*//* a_Case_Structure_CT_4 */
							/*&& GetSignalReady( 0x12, 2)*//* s_Case_Structure_CT_14 */
							/*&& GetSignalReady( 0x2, 7)*//* c_Select_s__t_f_1 *//*) {*/
							&& GetSignalReady( 1 )) {
								if (pass == 0) {
									nReady++;
								}
								else {
									{
										heap->a_Case_Structure_CT_3 = heap->a_Case_Structure_CT_4;
										/*SetSignalReady( 0x10, 7);*//* a_Case_Structure_CT_3 */
										heap->s_Case_Structure_CT_13 = heap->s_Case_Structure_CT_14;
										/*SetSignalReady( 0x11, 6);*//* s_Case_Structure_CT_13 */
										MemMove( &heap->c_Case_Structure_CT_13, &heap->c_Select_s__t_f_1, sizeof( cl_00000 ) );
										/*SetSignalReady( 0x2, 1);*//* c_Case_Structure_CT_13 */
									}
									heap->runStat105915AA = eFinished;
									InitSignalReady(1, 3);
									continue;
								}
							}
						}
						if( runStat == eFinished && pass )
						{
							volatile int dummy;
							CCGDebugSynchSRN(&state, 8, 3, &snode72FA6CC, debugOffset);
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}

							dummy=1;
						}
						if (pass) {
							if (runStat == eFinished) {
								bEndDiagram = true;
							}
							if (!bRunToFinish) {
								if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
									if (gAppStop) {
										return eFinished;
									}
									if (gLastError) {
										CGenErr();
									}
									if (!gAppStop && !gLastError) {
										return eNotFinished;
									}
								}
							}
						}
					} /* end for */
					if (bEndDiagram) break;
				} /* end while */
			} /* end case */
			break;
		}
		heap->runStat105915A9 = eReady;
		heap->runStat72FD14C = eReady;
		heap->runStat72F964C = eReady;
		heap->runStat101D4F68 = eReady;
		heap->runStat105915AA = eReady;
		heap->a_Case_Structure_CT_2 = heap->a_Case_Structure_CT_3;
		/*SetSignalReady( 0x9, 3);*//* a_Case_Structure_CT_2 */
		UpdateProbes(&state, debugOffset, 4 /*0x12775540*/, (uChar*)&(heap->a_Case_Structure_CT_2)); /* assign */
		heap->s_Case_Structure_CT_12 = heap->s_Case_Structure_CT_13;
		/*SetSignalReady( 0xB, 6);*//* s_Case_Structure_CT_12 */
		UpdateProbes(&state, debugOffset, 2 /*0x12775660*/, (uChar*)&(heap->s_Case_Structure_CT_12)); /* assign */
		MemMove( &heap->c_Case_Structure_CT_12, &heap->c_Case_Structure_CT_13, sizeof( cl_00000 ) );
		/*SetSignalReady( 0x0, 0);*//* c_Case_Structure_CT_12 */
		UpdateProbes(&state, debugOffset, 1 /*0x12775720*/, (uChar*)&(heap->c_Case_Structure_CT_12)); /* assign */
		/* FreeCaseSelDCO. */
	/* Free Cluster */
		{
			cl_00000* cl_015 = (cl_00000*)&heap->c_error_in__no_error__2;
				if (cl_015->el_2 && --((PDAStrPtr)cl_015->el_2)->refcnt == 0 && !((PDAStrPtr)cl_015->el_2)->staticStr) {
				MemHandleFree( cl_015->el_2 );
			}
		}
		CCGDebugSynchAfterSNode(&state, &snode72FA6CC, 2, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	if (!SetArrayControlFieldValueStatic( FPData(Read_Buffer__163483256_ctlid), &heap->a_Case_Structure_CT_2, false, &g_staticArray_16))
	CGenErr();
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, Read_Buffer__163483256_ctlid);
	if (FPData(VISA_resource_name_out__163481816_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__163481816_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__163481816_ctlid))->staticStr) {
		MemHandleFree( FPData(VISA_resource_name_out__163481816_ctlid) );
	}
	FPData(VISA_resource_name_out__163481816_ctlid)=PDAStrCopyOnModify(heap->s_Case_Structure_CT_12);
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__163481816_ctlid);
	{
		if (!SetClusterControlFieldValue( FPData(error_out__163480472_ctlid), &heap->c_Case_Structure_CT_12, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, error_out__163480472_ctlid);
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			/*InitSignalReady( 0x0, 0);*//* c_Case_Structure_CT_12 */
			/*InitSignalReady( 0xB, 6);*//* s_Case_Structure_CT_12 */
			/*InitSignalReady( 0x0, 2);*//* c_error_in__no_error__2 */
			/*InitSignalReady( 0x9, 3);*//* a_Case_Structure_CT_2 */
			/*InitSignalReady( 0x1B, 5);*//* by_Sent_Command__0_ */
			/*InitSignalReady( 0x1B, 4);*//* by_Length_Of_Sent_MSG__0_ */
			/*InitSignalReady( 0x12, 0);*//* s_VISA_resource_name_2 */
			/*InitSignalReady( 0x14, 5);*//* n_Receive_Message_Type__0__By_T */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStat72FA6CC = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_RunFunc_72FA6CC( bRunToFinish  );
			if (heap->runStat72FA6CC == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStat72FA6CC == eFail) {
				CGenErr();
			}
			heap->runStat72FA6CC = eReady;
			nStep++; }
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 2, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	(Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GlobalConstantsHeapPtr->refCnt)--;
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_VIName = "Watflow F4.lvlib:Utility MODBUS RTU Receive Message.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)148,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tWatflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_viInstanceHeap),
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_InitFPTerms,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_FrontPanelInit,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_BlockDiagram,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_DrawLabels,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_GetFPTerms,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_Cleanup,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupLSRs,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_AddSubVIInstanceData,
	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


