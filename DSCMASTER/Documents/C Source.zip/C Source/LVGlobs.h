#ifndef _LVGlobs_h
#define _LVGlobs_h
#define	HOST_IP_ADDRESS	"192.168.130.19"
#define	BUILD_SPECIFICATION_ID	"LocalHost localhost"
#include "LVCGenIncludes.h"
#ifdef LV_MAIN
int32 nBigClusterSize = 136;
void GlobFiller(Boolean bShowFrontPanel);
void GlobFiller(Boolean bShowFrontPanel) {}
void Filler(void);
void Filler(void) {}
Boolean InitFPTermsFiller(ArgList* argsIn, Boolean bShowFrontPanel);
Boolean InitFPTermsFiller(ArgList* argsIn, Boolean bShowFrontPanel) { return true; }
InitFPTermsFunc globTable[] = {
	InitFPTermsFiller,
};

extern void Open_Controller_handle_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Initialize_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_Read_From_Register_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_Generate_Instrument_Error_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Reset_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_Write_To_Register_AddVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Close_AddVIGlobalConstants(void);

extern void VISA_Configure_Serial_Port__Instr__AddVIGlobalConstants(void);

extern void F4_Controller_handle_Global_Function_Variable_AddVIGlobalConstants(void);

extern void F4_Visa_Handle_Constant_AddVIGlobalConstants(void);
VoidFn globConstInitTable[] = {
	Filler,

	Open_Controller_handle_AddVIGlobalConstants,

	Watflow_F4_lvlib_Initialize_AddVIGlobalConstants,

	Watflow_F4_lvlib_Utility_Read_From_Register_AddVIGlobalConstants,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_AddVIGlobalConstants,

	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_AddVIGlobalConstants,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_AddVIGlobalConstants,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_AddVIGlobalConstants,

	Watflow_F4_lvlib_Reset_AddVIGlobalConstants,

	Watflow_F4_lvlib_Utility_Write_To_Register_AddVIGlobalConstants,

	Watflow_F4_lvlib_Close_AddVIGlobalConstants,

	VISA_Configure_Serial_Port__Instr__AddVIGlobalConstants,

	F4_Controller_handle_Global_Function_Variable_AddVIGlobalConstants,

	F4_Visa_Handle_Constant_AddVIGlobalConstants,
};

extern void Open_Controller_handle_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Initialize_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_Read_From_Register_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Reset_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Utility_Write_To_Register_CleanupVIGlobalConstants(void);

extern void Watflow_F4_lvlib_Close_CleanupVIGlobalConstants(void);

extern void VISA_Configure_Serial_Port__Instr__CleanupVIGlobalConstants(void);

extern void F4_Controller_handle_Global_Function_Variable_CleanupVIGlobalConstants(void);

extern void F4_Visa_Handle_Constant_CleanupVIGlobalConstants(void);
VoidFn globConstCleanupTable[] = {
	Filler,

	Open_Controller_handle_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Initialize_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Utility_Read_From_Register_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Reset_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Utility_Write_To_Register_CleanupVIGlobalConstants,

	Watflow_F4_lvlib_Close_CleanupVIGlobalConstants,

	VISA_Configure_Serial_Port__Instr__CleanupVIGlobalConstants,

	F4_Controller_handle_Global_Function_Variable_CleanupVIGlobalConstants,

	F4_Visa_Handle_Constant_CleanupVIGlobalConstants,
};
CleanUpFunc globCleanupTable[] = {
	GlobFiller,
};

extern void Open_Controller_handle_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Initialize_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Utility_Read_From_Register_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Reset_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Utility_Write_To_Register_CleanupLSRs(void);

extern void Watflow_F4_lvlib_Close_CleanupLSRs(void);

extern void VISA_Configure_Serial_Port__Instr__CleanupLSRs(void);

extern void F4_Controller_handle_Global_Function_Variable_CleanupLSRs(void);

extern void F4_Visa_Handle_Constant_CleanupLSRs(void);
VoidFn lsrCleanupTable[] = {
	Filler,

	Open_Controller_handle_CleanupLSRs,

	Watflow_F4_lvlib_Initialize_CleanupLSRs,

	Watflow_F4_lvlib_Utility_Read_From_Register_CleanupLSRs,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_CleanupLSRs,

	Watflow_F4_lvlib_Utility_Generate_Instrument_Error_CleanupLSRs,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_CRC16_CleanupLSRs,

	Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_CleanupLSRs,

	Watflow_F4_lvlib_Reset_CleanupLSRs,

	Watflow_F4_lvlib_Utility_Write_To_Register_CleanupLSRs,

	Watflow_F4_lvlib_Close_CleanupLSRs,

	VISA_Configure_Serial_Port__Instr__CleanupLSRs,

	F4_Controller_handle_Global_Function_Variable_CleanupLSRs,

	F4_Visa_Handle_Constant_CleanupLSRs,
};
#else
extern InitFPTermsFunc globTable[];
extern VoidFn globCleanupTable[];
extern int32 nBigClusterSize;
#endif /*LV_MAIN*/
#ifdef LV_MAIN
const uInt8 nArrTypeData[] = {
	/* Cluster */
	ClusterDataType, 	0, 	0, 	0, 	3, 	0, 	0, 	0, 	0, 	0, 	0, 	0, 		BooleanDataType, 	0, 	0, 	0, 		int32DataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 	2, 0, 0, 0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		int16DataType, 	0, 	0, 	0, 	1, 0, 0, 0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 	1, 0, 0, 0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		doubleDataType, 	0, 	0, 	0, 	1, 0, 0, 0, 
	/* Cluster */
	ClusterDataType, 	0, 	0, 	0, 	5, 	0, 	0, 	0, 	1, 	0, 	0, 	0, 		Timestamp128DataType, 	0, 	0, 	0, 		doubleDataType, 	0, 	0, 	0, 		ArrayDataType, 	0, 	4, 	0, 		ClusterDataType, 	0, 	0, 	0, 		VariantDataType, 	0, 	0, 	0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		uInt32DataType, 	0, 	0, 	0, 	1, 0, 0, 0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		uCharDataType, 	0, 	0, 	0, 	2, 0, 0, 0, 
	/* Cluster */
	ClusterDataType, 	0, 	0, 	0, 	2, 	0, 	0, 	0, 	2, 	0, 	0, 	0, 		ArrayDataType, 	0, 	6, 	0, 		ArrayDataType, 	0, 	7, 	0, 
	/* Cluster */
	ClusterDataType, 	0, 	0, 	0, 	5, 	0, 	0, 	0, 	3, 	0, 	0, 	0, 		Timestamp128DataType, 	0, 	0, 	0, 		doubleDataType, 	0, 	0, 	0, 		ClusterDataType, 	0, 	8, 	0, 		ClusterDataType, 	0, 	0, 	0, 		VariantDataType, 	0, 	0, 	0, 
	/* Enum */
	Enum16DataType, 	0, 	0, 	0, 	2, 	0, 	5, 
	'F', 	'4', 	'S', 	'/', 	'D', 	7, 
	'S', 	'y', 	'n', 	'e', 	'r', 	'g', 	'y', 
	/* Cluster */
	ClusterDataType, 	0, 	0, 	0, 	7, 	0, 	0, 	0, 	4, 	0, 	0, 	0, 		Enum16DataType, 	0, 	10, 	0, 		StringDataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 		doubleDataType, 	0, 	0, 	0, 
	/* Cluster */
	ClusterDataType, 	0, 	0, 	0, 	3, 	0, 	0, 	0, 	5, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 		int32DataType, 	0, 	0, 	0, 		StringDataType, 	0, 	0, 	0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		ClusterDataType, 	0, 	11, 	0, 	1, 0, 0, 0, 
	/* Enum */
	Enum16DataType, 	0, 	0, 	0, 	5, 	0, 	8, 
	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	8, 
	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	14, 
	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	10, 
	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 	6, 
	'�', 	'�', 	'�', 	'�', 	'�', 	'�', 0, 0, 0, 
	/* Cluster */
	ClusterDataType, 	0, 	0, 	0, 	2, 	0, 	0, 	0, 	6, 	0, 	0, 	0, 		uCharDataType, 	0, 	0, 	0, 		uCharDataType, 	0, 	0, 	0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		uCharDataType, 	0, 	0, 	0, 	1, 0, 0, 0, 
	/* Enum */
	Enum16DataType, 	0, 	0, 	0, 	2, 	0, 	22, 
	'B', 	'y', 	' ', 	'T', 	'h', 	'e', 	' ', 	'N', 	'u', 	'm', 	'b', 	'e', 	'r', 	' ', 	'o', 	'f', 	' ', 	'B', 	'y', 	't', 	'e', 	's', 	24, 
	'C', 	'o', 	'p', 	'y', 	' ', 	'O', 	'f', 	' ', 	't', 	'h', 	'e', 	' ', 	'S', 	'e', 	'n', 	't', 	' ', 	'M', 	'e', 	's', 	's', 	'a', 	'g', 	'e', 0, 0, 
	/* Enum */
	Enum16DataType, 	0, 	0, 	0, 	5, 	0, 	4, 
	'N', 	'o', 	'n', 	'e', 	3, 
	'O', 	'd', 	'd', 	4, 
	'E', 	'v', 	'e', 	'n', 	4, 
	'M', 	'a', 	'r', 	'k', 	5, 
	'S', 	'p', 	'a', 	'c', 	'e', 0, 
	/* Array */
	ArrayDataType, 	0, 	0, 	0, 		ClusterDataType, 	0, 	12, 	0, 	1, 0, 0, 0, 
	0
};
uInt32 nArrClusterDataSizes[] = {
0,	0,	0,	0,	0,	0,	0
};
const uInt32 nArrTypeDataOffsets[] = {
	0, 	24, 	36, 	48, 	60, 	72, 	104, 	116, 	128, 	148, 	180, 	200, 	240, 	264, 	276, 	336, 	356, 	368, 	424, 	456, 	0
};
const uInt32 nArrTypeDataSize = 20;
#else
extern const uInt8 nArrTypeData[];
extern uInt32 nArrClusterDataSizes[];
extern const uInt32 nArrTypeDataOffsets[];
extern const uInt32 nArrTypeDataSize;
#endif
typedef struct cl_00000 {
	Boolean	el_0;
	int32	el_1;
	String	el_2;
} cl_00000;
typedef struct cl_50000 {
	Timestamp128	el_0;
	float64	el_1;
	PDAArrPtr	el_2;
	cl_00000	el_3;
	Variant	el_4;
} cl_50000;
typedef struct cl_80000 {
	PDAArrPtr	el_0;
	PDAArrPtr	el_1;
} cl_80000;
typedef struct cl_90000 {
	Timestamp128	el_0;
	float64	el_1;
	cl_80000	el_2;
	cl_00000	el_3;
	Variant	el_4;
} cl_90000;
typedef struct cl_B0000 {
	Enum16	el_0;
	String	el_1;
	String	el_2;
	String	el_3;
	String	el_4;
	String	el_5;
	float64	el_6;
} cl_B0000;
typedef struct cl_C0000 {
	String	el_0;
	int32	el_1;
	String	el_2;
} cl_C0000;
typedef struct cl_F0000 {
	uChar	el_0;
	uChar	el_1;
} cl_F0000;

/***************************
  Memory reuse system report
 ***************************
                             
Memory Item 0 (g_staticString_21)
- 0x0F503778 (s: Unbundle By Name: Ctrller Name: CT 2)

Memory Item 1 (g_staticString_22)
- 0x0F501B10 (s: Unbundle By Name: Ctrller Addr: CT)

Memory Item 2 (g_staticString_23)
- 0x0F501E70 (s: Unbundle By Name: Port: CT 1)

Memory Item 3 (g_staticString_24)
- 0x0F502FF8 (s: Unbundle By Name: Ctrller Name: CT)

Memory Item 4 (g_staticCluster_1)
- 0x0F501630 (c: Ctrllers: LT)

Memory Item 5 (g_staticCluster_2)
- 0x0EC170B8 (c: Case Structure: CT 11)

Memory Item 6 (g_staticCluster_3)
- 0x0EC172F8 (c: Case Structure: CT 10)

Memory Item 7 (g_staticCluster_4)
- 0x0EC16B18 (c: Case Structure: CT 7)

Memory Item 8 (g_staticCluster_5)
- 0x0EC16D58 (c: Case Structure: CT 6)

Memory Item 9 (g_staticCluster_6)
- 0x0EC126C8 (c: Property Node: error out: CT 2)

Memory Item 10 (g_staticCluster_7)
- 0x0EC16818 (c: Property Node: error out: CT 1)

Memory Item 11 (g_staticArb34)

Memory Item 12 (g_staticArray_3)
- 0x0F8DCBD0 (a: Join Numbers: (hi.lo): LT)

Memory Item 13 (g_staticArray_4)
- 0x0E4059B8 (a: Array Subset: subarray)

Memory Item 14 (g_staticArray_5)
- 0x0F8DCAB0 (a: Constant: CT 1)

Memory Item 15 (g_staticArray_6)
- 0x0F8DCB70 (a: Utility MODBUS RTU Receive Message.vi: Read Buffer: CT)

Memory Item 16 (g_staticArray_7)
- 0x09A32660 (a: Build Array: appended array)

Memory Item 17 (g_staticArray_9)
- 0x0E4A9C00 (a: String To Byte Array: unsigned byte array: CT 2)

Memory Item 18 (g_staticCluster_8)
- 0x0E4A16E0 (c: VISA Read: error out: CT 5)

Memory Item 19 (g_staticArray_10)
- 0x0E4A9CC0 (a: Build Array: appended array 3)

Memory Item 20 (g_staticArray_11)
- 0x107823F8 (a: String To Byte Array: unsigned byte array: CT)

Memory Item 21 (g_staticCluster_9)
- 0x10782278 (c: VISA Read: error out: CT 4)

Memory Item 22 (g_staticArray_12)
- 0x0E4A0A80 (a: String To Byte Array: unsigned byte array: CT 8)

Memory Item 23 (g_staticCluster_10)
- 0x12777988 (c: VISA Read: error out: CT 2)

Memory Item 24 (g_staticArray_13)
- 0x0E1F5340 (a: String To Byte Array: unsigned byte array: CT 7)

Memory Item 25 (g_staticCluster_11)
- 0x0E1F5220 (c: VISA Read: error out: CT 1)

Memory Item 26 (g_staticArray_14)
- 0x0E1F5460 (a: Build Array: appended array 2)

Memory Item 27 (g_staticString_48)
- 0x0E38B428 (s: VISA Read: read buffer: CT 1)

Memory Item 28 (g_staticArray_15)
- 0x133152D8 (a: Build Array: appended array 1)

Memory Item 29 (g_staticCluster_12)
- 0x1277C8B0 (c: Property Node: error out: CT 5)

Memory Item 30 (g_staticCluster_13)
- 0x0E58A5C0 (c: Property Node: error out: CT 4)

Memory Item 31 (g_staticArray_17)
- 0x0EB115B0 (a: Array Subset: subarray 1)

Memory Item 32 (g_staticCluster_14)
- 0x0EB12150 (c: error in (no error): CT 4)

Memory Item 33 (g_staticArray_19)
- 0x09391770 (a: Build Array: appended array 4)

Memory Item 34 (g_staticArray_22)
- 0x0F88A5E0 (a: Message (empty array): CT 1)

Memory Item 35 (g_staticArray_23)
- 0x0F88A340 (a: Build Array: appended array 5)

Memory Item 36 (g_staticArray_24)
- 0x125DF1B0 (a: Build Array: appended array 6)

Memory Item 37 (g_staticArb101)

Memory Item 38 (g_staticArray_25)
- 0x09BC7EE8 (a: Unbundle By Name: F4Ctrller Name: LT)

Memory Item 39 (g_staticCluster_15)
- 0x09BC8068 (c: While Loop: LT)

Memory Item 40 (g_staticArray_27)
- 0x09BCBFC8 (a: While Loop: CT 2)

Memory Item 41 (g_staticCluster_16)
- 0x09BCC088 (c: Index Array: element)

Memory Item 42 (g_staticArray_28)
- 0x09BC7E28 (a: While Loop: CT 3)

Memory Item 43 (g_staticArray_29)
- 0x09BC7D68 (a: While Loop: CT 4)

Memory Item 44 (g_staticArray_30)
- 0x09BCC328 (a: While Loop: CT 1)

***************************/


/**/
/* Begin static memory declarations for diagram */
/**/

LVCriticalSectionRec gCriticalSectionList[1];

static TextChar* g_staticArb0 = NULL;

static TextChar* g_staticArb1 = NULL;

static TextChar* g_staticArb2 = NULL;

static TextChar* g_staticArb3 = NULL;

static TextChar* g_staticArb4 = NULL;

static TextChar* g_staticArb5 = NULL;

static TextChar* g_staticArb6 = NULL;

static TextChar* g_staticArb7 = NULL;

static TextChar* g_staticArb8 = NULL;

static TextChar* g_staticArb9 = NULL;

static TextChar* g_staticArb10 = NULL;

static TextChar* g_staticArb11 = NULL;

static TextChar* g_staticArb12 = NULL;

static TextChar* g_staticArb13 = NULL;

static TextChar* g_staticArb14 = NULL;

static TextChar* g_staticArb15 = NULL;

static TextChar* g_staticArb16 = NULL;

static TextChar* g_staticArb17 = NULL;

static TextChar* g_staticArb18 = NULL;

static TextChar* g_staticArb19 = NULL;

struct _g_staticArray_1 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_1 g_staticArray_1 = { 
	0xB0000 | ClusterDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_1 g_staticArray_1;
#endif

struct _g_staticString_21 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_21 g_staticString_21 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_22 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_22 g_staticString_22 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_23 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_23 g_staticString_23 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_24 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_24 g_staticString_24 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_117 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_117 g_staticString_117 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_118 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_118 g_staticString_118 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_119 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_119 g_staticString_119 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_120 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_120 g_staticString_120 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_121 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_121 g_staticString_121 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_B0000 g_staticCluster_1 = { 
	0, &g_staticString_117.el_1, &g_staticString_118.el_1, &g_staticString_119.el_1,
	&g_staticString_120.el_1, &g_staticString_121.el_1, 0.0000000000000000000E+0
};

struct _g_staticArray_2 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_2 g_staticArray_2 = { 
	0xB0000 | ClusterDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_2 g_staticArray_2;
#endif

static TextChar* g_staticArb20 = NULL;

static TextChar* g_staticArb21 = NULL;

static TextChar* g_staticArb22 = NULL;

static TextChar* g_staticArb23 = NULL;

static TextChar* g_staticArb24 = NULL;

static TextChar* g_staticArb25 = NULL;

static TextChar g_staticArb26[sizeof(PDAStr) + 325];

static TextChar g_staticArb27[sizeof(PDAStr) + 325];

struct _g_staticString_122 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_122 g_staticString_122 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_2 = { 
	0, 0, &g_staticString_122.el_1
};

struct _g_staticString_123 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_123 g_staticString_123 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_3 = { 
	0, 0, &g_staticString_123.el_1
};

struct _g_staticString_124 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_124 g_staticString_124 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_4 = { 
	0, 0, &g_staticString_124.el_1
};

struct _g_staticString_125 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_125 g_staticString_125 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_5 = { 
	0, 0, &g_staticString_125.el_1
};

struct _g_staticString_126 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_126 g_staticString_126 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_6 = { 
	0, 0, &g_staticString_126.el_1
};

struct _g_staticString_127 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_127 g_staticString_127 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_7 = { 
	0, 0, &g_staticString_127.el_1
};

static TextChar* g_staticArb28 = NULL;

static TextChar* g_staticArb29 = NULL;

static TextChar* g_staticArb30 = NULL;

static TextChar* g_staticArb31 = NULL;

static TextChar* g_staticArb32 = NULL;

static TextChar* g_staticArb33 = NULL;

/* Memory References
Open_Controller_handle, line 3208
*/
static LpTunArray g_staticArb34[1];

/* Memory References
Open_Controller_handle, line 3208
*/
struct _g_staticArray_3 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_3 g_staticArray_3 = { 
	uInt16DataType, 0, 1, 0, 1, 0
};

/* Memory References
Open_Controller_handle, line 3253
*/
struct _g_staticArray_4 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_4 g_staticArray_4 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_5 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_5 g_staticArray_5 = { 
	uInt16DataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_6 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_6 g_staticArray_6 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

/* Memory References
Open_Controller_handle, line 3603
*/
struct _g_staticArray_7 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_7 g_staticArray_7 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_8 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_8 g_staticArray_8 = { 
	int16DataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_8 g_staticArray_8;
#endif

static TextChar* g_staticArb35 = NULL;

static TextChar* g_staticArb36 = NULL;

static TextChar* g_staticArb37 = NULL;

static TextChar* g_staticArb38 = NULL;

static TextChar* g_staticArb39 = NULL;

static TextChar* g_staticArb40 = NULL;

static TextChar* g_staticArb41 = NULL;

static TextChar* g_staticArb42 = NULL;

struct _g_staticArray_9 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_9 g_staticArray_9 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_128 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_128 g_staticString_128 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_8 = { 
	0, 0, &g_staticString_128.el_1
};

/* Memory References
Open_Controller_handle, line 4977
*/
struct _g_staticArray_10 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_10 g_staticArray_10 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_11 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_11 g_staticArray_11 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_129 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_129 g_staticString_129 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_9 = { 
	0, 0, &g_staticString_129.el_1
};

struct _g_staticArray_12 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_12 g_staticArray_12 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_130 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_130 g_staticString_130 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_10 = { 
	0, 0, &g_staticString_130.el_1
};

struct _g_staticArray_13 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_13 g_staticArray_13 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_131 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_131 g_staticString_131 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_11 = { 
	0, 0, &g_staticString_131.el_1
};

/* Memory References
Open_Controller_handle, line 5394
*/
struct _g_staticArray_14 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_14 g_staticArray_14 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_48 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_48 g_staticString_48 = { 
	0, 1, 0, _LVT("")
};

/* Memory References
Open_Controller_handle, line 5778
*/
struct _g_staticArray_15 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_15 g_staticArray_15 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_132 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_132 g_staticString_132 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_12 = { 
	0, 0, &g_staticString_132.el_1
};

struct _g_staticString_133 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_133 g_staticString_133 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_13 = { 
	0, 0, &g_staticString_133.el_1
};

struct _g_staticArray_16 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_16 g_staticArray_16 = { 
	uCharDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_16 g_staticArray_16;
#endif

static TextChar* g_staticArb43 = NULL;

static TextChar* g_staticArb44 = NULL;

static TextChar* g_staticArb45 = NULL;

static TextChar* g_staticArb46 = NULL;

static TextChar* g_staticArb47 = NULL;

static TextChar* g_staticArb48 = NULL;

static TextChar g_staticArb49[sizeof(PDAStr) + 2];

static TextChar g_staticArb50[sizeof(PDAStr) + 2];

static TextChar* g_staticArb51 = NULL;

static TextChar* g_staticArb52 = NULL;

/* Memory References
Open_Controller_handle, line 7572
*/
struct _g_staticArray_17 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_17 g_staticArray_17 = { 
	StringDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_134 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_134 g_staticString_134 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_00000 g_staticCluster_14 = { 
	0, 0, &g_staticString_134.el_1
};

static TextChar* g_staticArb53 = NULL;

static TextChar* g_staticArb54 = NULL;

static TextChar* g_staticArb55 = NULL;

static TextChar* g_staticArb56 = NULL;

static TextChar* g_staticArb57 = NULL;

static TextChar* g_staticArb58 = NULL;

struct _g_staticArray_18 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_18 g_staticArray_18 = { 
	uCharDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_18 g_staticArray_18;
#endif

/* Memory References
Open_Controller_handle, line 8678
*/
struct _g_staticArray_19 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_19 g_staticArray_19 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_20 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_20 g_staticArray_20 = { 
	uCharDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_20 g_staticArray_20;
#endif

static TextChar* g_staticArb59 = NULL;

static TextChar* g_staticArb60 = NULL;

static TextChar* g_staticArb61 = NULL;

static TextChar* g_staticArb62 = NULL;

static TextChar* g_staticArb63 = NULL;

static TextChar* g_staticArb64 = NULL;

struct _g_staticArray_21 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_21 g_staticArray_21 = { 
	uCharDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_21 g_staticArray_21;
#endif

struct _g_staticArray_22 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_22 g_staticArray_22 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

/* Memory References
Open_Controller_handle, line 9437
*/
struct _g_staticArray_23 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_23 g_staticArray_23 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

static TextChar* g_staticArb65 = NULL;

static TextChar* g_staticArb66 = NULL;

static TextChar* g_staticArb67 = NULL;

static TextChar* g_staticArb68 = NULL;

static TextChar* g_staticArb69 = NULL;

static TextChar* g_staticArb70 = NULL;

static TextChar* g_staticArb71 = NULL;

static TextChar* g_staticArb72 = NULL;

static TextChar* g_staticArb73 = NULL;

static TextChar* g_staticArb74 = NULL;

static TextChar* g_staticArb75 = NULL;

static TextChar* g_staticArb76 = NULL;

/* Memory References
Open_Controller_handle, line 10893
*/
struct _g_staticArray_24 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_24 g_staticArray_24 = { 
	uCharDataType, 0, 1, 0, 1, 0
};

static TextChar* g_staticArb77 = NULL;

static TextChar* g_staticArb78 = NULL;

static TextChar* g_staticArb79 = NULL;

static TextChar* g_staticArb80 = NULL;

static TextChar* g_staticArb81 = NULL;

static TextChar* g_staticArb82 = NULL;

static TextChar* g_staticArb83 = NULL;

static TextChar* g_staticArb84 = NULL;

static TextChar* g_staticArb85 = NULL;

static TextChar* g_staticArb86 = NULL;

static TextChar* g_staticArb87 = NULL;

static TextChar* g_staticArb88 = NULL;

static TextChar* g_staticArb89 = NULL;

static TextChar* g_staticArb90 = NULL;

static TextChar* g_staticArb91 = NULL;

static TextChar* g_staticArb92 = NULL;

static TextChar* g_staticArb93 = NULL;

static TextChar* g_staticArb94 = NULL;

static TextChar* g_staticArb95 = NULL;

static TextChar* g_staticArb96 = NULL;

static TextChar* g_staticArb97 = NULL;

static TextChar* g_staticArb98 = NULL;

static TextChar* g_staticArb99 = NULL;

static TextChar* g_staticArb100 = NULL;

/* Memory References
Open_Controller_handle, line 12120
*/
static LpTunArray g_staticArb101[1];

/* Memory References
Open_Controller_handle, line 12120
*/
struct _g_staticArray_25 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_25 g_staticArray_25 = { 
	StringDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_135 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_135 g_staticString_135 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_136 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_136 g_staticString_136 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_C0000 g_staticCluster_15 = { 
	&g_staticString_135.el_1, 0, &g_staticString_136.el_1
};

struct _g_staticArray_26 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_26 g_staticArray_26 = { 
	StringDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_26 g_staticArray_26;
#endif

struct _g_staticArray_27 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_27 g_staticArray_27 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_staticString_137 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_137 g_staticString_137 = { 
	0, 1, 0, _LVT("")
};

struct _g_staticString_138 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_staticString_138 g_staticString_138 = { 
	0, 1, 0, _LVT("")
};

_DATA_SECTION static cl_C0000 g_staticCluster_16 = { 
	&g_staticString_137.el_1, 0, &g_staticString_138.el_1
};

struct _g_staticArray_28 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_28 g_staticArray_28 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_29 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_29 g_staticArray_29 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_30 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_staticArray_30 g_staticArray_30 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_staticArray_31 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_31 g_staticArray_31 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_31 g_staticArray_31;
#endif

static ArrDimSize g_staticArb102[1];

struct _g_staticArray_32 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_32 g_staticArray_32 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_32 g_staticArray_32;
#endif

struct _g_staticArray_33 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_33 g_staticArray_33 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_33 g_staticArray_33;
#endif

struct _g_staticArray_34 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
#ifdef LV_MAIN
_DATA_SECTION struct _g_staticArray_34 g_staticArray_34 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};
#else
extern struct _g_staticArray_34 g_staticArray_34;
#endif

static TextChar* g_staticArb103 = NULL;

static TextChar* g_staticArb104 = NULL;

static TextChar* g_staticArb105 = NULL;

static TextChar* g_staticArb106 = NULL;

static TextChar* g_staticArb107 = NULL;

static TextChar* g_staticArb108 = NULL;

static TextChar* g_staticArb109 = NULL;

static TextChar* g_staticArb110 = NULL;


/**/
/* End static memory declarations for diagram */
/**/

#ifdef LV_MAIN
uInt32 gCallerID = 0;
#else
extern uInt32 gCallerID;
#endif /* LV_MAIN */


/**
* Profiling defines and global data
*/
#ifdef LV_MAIN
uInt32 gProfilingInfoSize = 0;
#else
extern uInt32 gProfilingInfoSize;
#endif /* LV_MAIN */

#ifdef LV_MAIN
ProfilingInfo* gProfilingInfo=NULL;
#else
extern ProfilingInfo* gProfilingInfo;
#endif /* LV_MAIN */


/**
* Reentrant call library node data structures
*/

/**
* Call library node callback structures
*/
#ifdef LV_MAIN
CLNInstanceData *gArrCLNInstanceData = NULL;
int32 gnArrCLNInstanceDataItems = 0;
#endif
#endif
