/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Reset.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Public\Utility\Reset.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 7;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
struct _Watflow_F4_lvlib_Reset_heap { 
	cl_00000 c_Utility_Write_To_Register_vi_;
	cl_00000 c_Property_Node_error_out_2;
	cl_00000 c_Property_Node_error_out_3;
	cl_00000 c_error_in__no_error__6;
	cl_00000 c_Property_Node_error_out_4;
	uInt32 dw_Property_Node_General_Settin;
	uInt32 dw_General_Settings_Timeout_Val_1;
	VoidHand s_Property_Node_reference_out_6;
	VoidHand s_Property_Node_reference_out_7;
	VoidHand s_Property_Node_reference_out_5;
	VoidHand s_VISA_resource_name_6;
	VoidHand Args10943D09;  
	VoidHand s_Utility_Write_To_Register_vi_;
	uInt16 n_Register_Address_1;
	int16 i_Data__0_;
	uInt8 runStat72F1DCC;  
	uInt8 runStat10943D08;  
	uInt8 by_Unit_Address__1__3;
	uInt8 runStat72F904C;  
	uInt8 runStat1;  
	uInt8 runStat72F51CC;  
} _DATA_SECTION __Watflow_F4_lvlib_Reset_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Reset_signalsReadyTable[3];

static struct _Watflow_F4_lvlib_Reset_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Reset_heap; /* heap */

struct _tWatflow_F4_lvlib_Reset_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i10943D08;
} _DATA_SECTION __Watflow_F4_lvlib_Reset_viInstanceHeap;
static struct _tWatflow_F4_lvlib_Reset_viInstanceHeap _DATA_SECTION *Watflow_F4_lvlib_Reset_viInstanceHeapPtr = &__Watflow_F4_lvlib_Reset_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Reset_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[3] = {3, 4, 3};
struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

static ClusterControlData g_control_4 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_8 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_9 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2700UL
#define VISA_resource_name__159461776_ctlid 2700
#define error_in__no_error___159462928_ctlid 2701
#define error_out__159464080_ctlid 2702
#define VISA_resource_name_out__159464560_ctlid 2703
#define Unit_Address__1___159464944_ctlid 2704
#define N_CONTROLS 5L
#define gArrControlData Watflow_F4_lvlib_Reset_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Reset_gArrControlData[5] = {
	{ VISA_resource_name__159461776_ctlid, 0, NULL, StringDataType, nonui_control },
	{ error_in__no_error___159462928_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__159464080_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_resource_name_out__159464560_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Unit_Address__1___159464944_ctlid, 0, NULL, VoidHandDataType, numeric_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Reset_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Reset_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__159461776_ctlid);
			vhIn = *(VoidHand *)argsIn->args[0].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[0].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[0].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[0].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__159461776_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,2,-18,129,16,
	_LVT("0"),12,0,1000,0, false);
	if (!(FPData(error_in__no_error___159462928_ctlid) = ClusterControlDataCreateStatic(&g_control_4, GetControlDataPtr(), gFormID, error_in__no_error___159462928_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___159462928_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[2].pValue, argsIn->args[2].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb66);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___159462928_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___159462928_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,0,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__159464080_ctlid) = ClusterControlDataCreateStatic(&g_control_8, GetControlDataPtr(), gFormID, error_out__159464080_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb68);
		}
		InitClusterControlFieldValue( FPData(error_out__159464080_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__159464080_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-1,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_resource_name_out__159464560_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb70);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__159464560_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-18,157,16,
	_LVT("0"),12,0,1000,0, false);
	{uInt8 dVal = (uInt8)1 ;
		{
			static NumericInitialData numData = {
				Unit_Address__1___159464944_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Unit_Address__1___159464944_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_9, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Unit_Address__1___159464944_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[1].pValue, argsIn->args[1].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Unit_Address__1___159464944_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Unit Address (1)"),16,-15,-22,111,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Reset_FrontPanelInit NULL
#define Watflow_F4_lvlib_Reset_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Reset_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Reset_Cleanup(Boolean bShowFrontPanel){
PDAStrFree( FPData(VISA_resource_name__159461776_ctlid) );
	FPData(VISA_resource_name__159461776_ctlid) = NULL;
	if (FPData(error_in__no_error___159462928_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___159462928_ctlid), false );
	if (FPData(error_out__159464080_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__159464080_ctlid), false );
PDAStrFree( FPData(VISA_resource_name_out__159464560_ctlid) );
	FPData(VISA_resource_name_out__159464560_ctlid) = NULL;
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Reset_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Reset_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__159464080_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[1].pValue, argsOut->args[1].nType );
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__159464560_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[0].pValue = GetControlHValue(nIdx);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Reset_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Reset_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Reset_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Reset_AddSubVIInstanceData(void) {
	if (Watflow_F4_lvlib_Reset_viInstanceHeapPtr->initialized) return;
	Watflow_F4_lvlib_Reset_viInstanceHeapPtr->initialized = TRUE;

	Watflow_F4_lvlib_Reset_viInstanceHeapPtr->i10943D08.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Reset_viInstanceHeapPtr->i10943D08;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Reset_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Reset_AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Reset_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Reset_CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Reset_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Reset_InitVIConstantList(void) {
}


/****** Block diagram code **********/




/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Reset_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Reset_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	uInt32 id = LVGetTimerFlag();
	int16 pass, numStructs = 4;
	Boolean bEndDiagram = false;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {;
		heap->runStat1 = eReady;
		heap->runStat72F51CC = eReady;
		heap->runStat72F1DCC = eReady;
		heap->runStat10943D08 = eReady;
		heap->runStat72F904C = eReady;
	}
	while (!gAppStop && !gLastError) {
		nReady = 0;
		runStat = eFinished;
		bEndDiagram = false;
		for (pass=0;pass<2;pass++) {
/* start q el linear (2 struct) */
			if ((heap->runStat1 != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					InitSignalReady(0, 3);
					/*InitSignalReady( 0x0, 0);*//* c_Utility_Write_To_Register_vi_ */
					InitSignalReady(1, 4);
					/*InitSignalReady( 0x0, 1);*//* c_Property_Node_error_out_2 */
					InitSignalReady(2, 3);
					/*InitSignalReady( 0x0, 2);*//* c_Property_Node_error_out_3 */
					/*InitSignalReady( 0x0, 6);*//* dw_General_Settings_Timeout_Val_1 */
					/*InitSignalReady( 0x0, 5);*//* dw_Property_Node_General_Settin */
					/*InitSignalReady( 0x0, 4);*//* c_Property_Node_error_out_4 */
					/*InitSignalReady( 0x1, 1);*//* s_Property_Node_reference_out_5 */
					/*InitSignalReady( 0x1, 4);*//* s_Utility_Write_To_Register_vi_ */
					/*InitSignalReady( 0x0, 7);*//* s_Property_Node_reference_out_6 */
					/*InitSignalReady( 0x1, 0);*//* s_Property_Node_reference_out_7 */
					/*InitSignalReady( 0x0, 3);*//* c_error_in__no_error__6 */
					/*InitSignalReady( 0x1, 2);*//* s_VISA_resource_name_6 */
					/*InitSignalReady( 0x2, 1);*//* by_Unit_Address__1__3 */
					/*InitSignalReady( 0x1, 6);*//* i_Data__0_ */
					/*InitSignalReady( 0x1, 5);*//* n_Register_Address_1 */
				}
				else {
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					{
						heap->n_Register_Address_1 = 1602;
						/*SetSignalReady( 0x1, 5);*//* n_Register_Address_1 */
						UpdateProbes(&state, debugOffset, 15 /*0x10942F88*/, (uChar*)&(heap->n_Register_Address_1)); /* assign */
						SetSignalReady(1, 1);
						heap->i_Data__0_ = 800;
						/*SetSignalReady( 0x1, 6);*//* i_Data__0_ */
						UpdateProbes(&state, debugOffset, 14 /*0x10942FE8*/, (uChar*)&(heap->i_Data__0_)); /* assign */
						SetSignalReady(1, 1);
						heap->dw_General_Settings_Timeout_Val_1 = 20000;
						/*SetSignalReady( 0x0, 6);*//* dw_General_Settings_Timeout_Val_1 */
						UpdateProbes(&state, debugOffset, 4 /*0x10943408*/, (uChar*)&(heap->dw_General_Settings_Timeout_Val_1)); /* assign */
						SetSignalReady(2, 1);
					}
					heap->runStat1 = eFinished;
					continue;
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F51CC != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat72F51CC == eReady) {
						heap->s_VISA_resource_name_6 = FPData(VISA_resource_name__159461776_ctlid);
						PDAStrIncRefCnt(heap->s_VISA_resource_name_6, (uInt16)1);
						/*SetSignalReady( 0x1, 2);*//* s_VISA_resource_name_6 */
						UpdateProbes(&state, debugOffset, 12 /*0x109430A8*/, (uChar*)&(heap->s_VISA_resource_name_6)); /* assign */
						MemMove( &heap->c_error_in__no_error__6, ((ClusterControlData*)FPData(error_in__no_error___159462928_ctlid))->pVal, sizeof( cl_00000 ) );
						MemSet(((ClusterControlData*)FPData(error_in__no_error___159462928_ctlid))->pVal, sizeof( cl_00000 ), 0);
						/*SetSignalReady( 0x0, 3);*//* c_error_in__no_error__6 */
						UpdateProbes(&state, debugOffset, 11 /*0x10943108*/, (uChar*)&(heap->c_error_in__no_error__6)); /* assign */
					}
					CCGDebugSynchNode(&state, 1, 2, 1, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
/* Property node */
					{
						PropInfo props[1] = {
							{kGeneral_Settings_Timeout_Value, &heap->dw_Property_Node_General_Settin, uInt32DataType}
						};
						if (!VisaGetProperties( heap->s_VISA_resource_name_6, &heap->s_Property_Node_reference_out_7, &heap->c_error_in__no_error__6, &heap->c_Property_Node_error_out_3, props, 1)) {
							CGenErr();
						}
						heap->runStat72F51CC = eFinished;
					}
					/*SetSignalReady( 0x0, 2);*//* c_Property_Node_error_out_3 */
					UpdateProbes(&state, debugOffset, 3 /*0x109434C8*/, (uChar*)&(heap->c_Property_Node_error_out_3)); /* assign */
					SetSignalReady(2, 1);
					/*SetSignalReady( 0x1, 0);*//* s_Property_Node_reference_out_7 */
					UpdateProbes(&state, debugOffset, 10 /*0x109431C8*/, (uChar*)&(heap->s_Property_Node_reference_out_7)); /* assign */
					SetSignalReady(2, 1);
					/*SetSignalReady( 0x0, 5);*//* dw_Property_Node_General_Settin */
					UpdateProbes(&state, debugOffset, 5 /*0x109433A8*/, (uChar*)&(heap->dw_Property_Node_General_Settin)); /* assign */
					SetSignalReady(0, 1);
					if (heap->runStat72F51CC == eFinished) {
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F1DCC != eFinished)
			/*&& GetSignalReady( 0x1, 0)*//* s_Property_Node_reference_out_7 */
			/*&& GetSignalReady( 0x0, 2)*//* c_Property_Node_error_out_3 */
			/*&& GetSignalReady( 0x0, 6)*//* dw_General_Settings_Timeout_Val_1 *//*) {*/
			&& GetSignalReady( 2 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat72F1DCC == eReady) {
					}
					CCGDebugSynchNode(&state, 2, 3, 1, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
/* Property node */
					{
						PropInfo props[1] = {
							{kGeneral_Settings_Timeout_Value, &heap->dw_General_Settings_Timeout_Val_1, uInt32DataType}
						};
						if (!VisaSetProperties( heap->s_Property_Node_reference_out_7, &heap->s_Property_Node_reference_out_6, &heap->c_Property_Node_error_out_3, &heap->c_Property_Node_error_out_2, props, 1)) {
							CGenErr();
						}
						heap->runStat72F1DCC = eFinished;
					}
					/*SetSignalReady( 0x0, 1);*//* c_Property_Node_error_out_2 */
					UpdateProbes(&state, debugOffset, 2 /*0x10943528*/, (uChar*)&(heap->c_Property_Node_error_out_2)); /* assign */
					SetSignalReady(1, 1);
					/*SetSignalReady( 0x0, 7);*//* s_Property_Node_reference_out_6 */
					UpdateProbes(&state, debugOffset, 9 /*0x10943228*/, (uChar*)&(heap->s_Property_Node_reference_out_6)); /* assign */
					SetSignalReady(1, 1);
					if (heap->runStat72F1DCC == eFinished) {
						InitSignalReady(2, 3);
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat10943D08 != eFinished)
			/*&& GetSignalReady( 0x0, 1)*//* c_Property_Node_error_out_2 */
			/*&& GetSignalReady( 0x1, 6)*//* i_Data__0_ */
			/*&& GetSignalReady( 0x1, 5)*//* n_Register_Address_1 */
			/*&& GetSignalReady( 0x0, 7)*//* s_Property_Node_reference_out_6 *//*) {*/
			&& GetSignalReady( 1 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat10943D08 == eReady) {
						if (!GetNumericFieldValue( FPData(Unit_Address__1___159464944_ctlid), &heap->by_Unit_Address__1__3, uCharDataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x2, 1);*//* by_Unit_Address__1__3 */
						UpdateProbes(&state, debugOffset, 13 /*0x10943048*/, (uChar*)&(heap->by_Unit_Address__1__3)); /* assign */
					}
					CCGDebugSynchIUse(&state, 3, 4, 1, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility Write To Register.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStat10943D08 == eReady) {
							CreateArgListStatic(heap->Args10943D09, 5, 2 );
							argIn(heap->Args10943D09, 0).nType = uCharDataType;
							argIn(heap->Args10943D09, 0).pValue = (void *)&heap->by_Unit_Address__1__3;
							argIn(heap->Args10943D09, 1).nType = 0x0 | ClusterDataType;
							argIn(heap->Args10943D09, 1).pValue = (void *)&heap->c_Property_Node_error_out_2;
							argIn(heap->Args10943D09, 2).nType = int16DataType;
							argIn(heap->Args10943D09, 2).pValue = (void *)&heap->i_Data__0_;
							argIn(heap->Args10943D09, 3).nType = uInt16DataType;
							argIn(heap->Args10943D09, 3).pValue = (void *)&heap->n_Register_Address_1;
							argIn(heap->Args10943D09, 4).nType = StringDataType;
							argIn(heap->Args10943D09, 4).pValue = (void *)&heap->s_Property_Node_reference_out_6;
							argOut(heap->Args10943D09, 0).nType = 0x0 | ClusterDataType;
							argOut(heap->Args10943D09, 0).pValue = (void *)&heap->c_Utility_Write_To_Register_vi_;
							argOut(heap->Args10943D09, 1).nType = StringDataType;
							argOut(heap->Args10943D09, 1).pValue = (void *)&heap->s_Utility_Write_To_Register_vi_;
						}
						if (!Watflow_F4_lvlib_Reset_viInstanceHeapPtr->i10943D08.callerID) {
							Watflow_F4_lvlib_Reset_viInstanceHeapPtr->i10943D08.callerID = ++gCallerID;
						}
						heap->runStat10943D08 = Watflow_F4_lvlib_Utility_Write_To_Register_Run( &Watflow_F4_lvlib_Reset_viInstanceHeapPtr->i10943D08, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args10943D09)[0], (ArgList *)((ArgList **)heap->Args10943D09)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 4, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStat10943D08 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStat10943D08 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStat10943D08 == eFinished)) {
							/*SetSignalReady( 0x0, 0);*//* c_Utility_Write_To_Register_vi_ */
							UpdateProbes(&state, debugOffset, 1 /*0x10943588*/, (uChar*)&(heap->c_Utility_Write_To_Register_vi_)); /* assign */
							SetSignalReady(0, 1);
							/*SetSignalReady( 0x1, 4);*//* s_Utility_Write_To_Register_vi_ */
							UpdateProbes(&state, debugOffset, 8 /*0x10943288*/, (uChar*)&(heap->s_Utility_Write_To_Register_vi_)); /* assign */
							SetSignalReady(0, 1);
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (heap->runStat10943D08 == eFinished) {
						InitSignalReady(1, 4);
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat72F904C != eFinished)
			/*&& GetSignalReady( 0x1, 4)*//* s_Utility_Write_To_Register_vi_ */
			/*&& GetSignalReady( 0x0, 0)*//* c_Utility_Write_To_Register_vi_ */
			/*&& GetSignalReady( 0x0, 5)*//* dw_Property_Node_General_Settin *//*) {*/
			&& GetSignalReady( 0 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat72F904C == eReady) {
					}
					CCGDebugSynchNode(&state, 4, 5, 1, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
/* Property node */
					{
						PropInfo props[1] = {
							{kGeneral_Settings_Timeout_Value, &heap->dw_Property_Node_General_Settin, uInt32DataType}
						};
						if (!VisaSetProperties( heap->s_Utility_Write_To_Register_vi_, &heap->s_Property_Node_reference_out_5, &heap->c_Utility_Write_To_Register_vi_, &heap->c_Property_Node_error_out_4, props, 1)) {
							CGenErr();
						}
						heap->runStat72F904C = eFinished;
					}
					/*SetSignalReady( 0x0, 4);*//* c_Property_Node_error_out_4 */
					UpdateProbes(&state, debugOffset, 6 /*0x10943348*/, (uChar*)&(heap->c_Property_Node_error_out_4)); /* assign */
					/*SetSignalReady( 0x1, 1);*//* s_Property_Node_reference_out_5 */
					UpdateProbes(&state, debugOffset, 7 /*0x109432E8*/, (uChar*)&(heap->s_Property_Node_reference_out_5)); /* assign */
					if (heap->runStat72F904C == eFinished) {
	if (FPData(VISA_resource_name_out__159464560_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__159464560_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__159464560_ctlid))->staticStr) {
							MemHandleFree( FPData(VISA_resource_name_out__159464560_ctlid) );
						}
						FPData(VISA_resource_name_out__159464560_ctlid)=PDAStrCopyOnModify(heap->s_Property_Node_reference_out_5);
						/* Update front panel indicator */
						CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__159464560_ctlid);
						{
							if (!SetClusterControlFieldValue( FPData(error_out__159464080_ctlid), &heap->c_Property_Node_error_out_4, 0x0 | ClusterDataType, false )){
								CGenErr();
							}
						}
						/* Update front panel indicator */
						CCGDebugUpdateFPControl(&state, debugOffset, error_out__159464080_ctlid);
						InitSignalReady(0, 3);
						continue;
					}
				}
			}
			if (pass == 1) bEndDiagram = true;
		}
		if (bEndDiagram &&runStat == eFinished) {
			CCGDebugSynchSRN(&state, 5, 1, pauseCaller, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat1 = eReady;
			heap->runStat72F51CC = eReady;
			heap->runStat72F1DCC = eReady;
			heap->runStat10943D08 = eReady;
			heap->runStat72F904C = eReady;
			break;
		}
		if (!bRunToFinish) {
			if (bEndDiagram) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		}
	}
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Reset_VIName = "Watflow F4.lvlib:Reset.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Reset_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Reset_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)12,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &Watflow_F4_lvlib_Reset_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tWatflow_F4_lvlib_Reset_viInstanceHeap),
	Watflow_F4_lvlib_Reset_InitFPTerms,
	Watflow_F4_lvlib_Reset_FrontPanelInit,
	Watflow_F4_lvlib_Reset_BlockDiagram,
	Watflow_F4_lvlib_Reset_DrawLabels,
	Watflow_F4_lvlib_Reset_GetFPTerms,
	Watflow_F4_lvlib_Reset_Cleanup,
	Watflow_F4_lvlib_Reset_CleanupLSRs,
	Watflow_F4_lvlib_Reset_AddSubVIInstanceData,
	Watflow_F4_lvlib_Reset_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Reset_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


