/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Utility Read From Register.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Private\Utility Read From Register.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 2;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snode72F494C = false;
static Boolean snode72F6C4C = false;
static Boolean snodeF851724 = false;
struct _Watflow_F4_lvlib_Utility_Read_From_Register_heap { 
	cl_00000 c_Utility_MODBUS_RTU_Send_Messa;
	cl_00000 c_Utility_MODBUS_RTU_Receive_M_1;
	cl_00000 c_Utility_MODBUS_RTU_Receive_Me;
	cl_00000 c_error_in__no_error__1;
	cl_00000 c_error_in__no_error__SR;
	cl_00000 c_Utility_MODBUS_RTU_Receive_Me_1;
	int32 l_While_Loop_i_1;
	int32 l_Quotient___Remainder_floor_x_;
	int32 l_y_1;
	int32 l_Array_Size_size_s_;
	int32 l_While_Loop_i;
	int32 l_index_1;
	int32 l_y;
	int32 l_For_Loop_N_1;
	int32 l_For_Loop_i_1;
	cl_F0000 c_Array_To_Cluster_cluster;
	VoidHand a_Case_Structure_SR;
	VoidHand a_Constant;
	VoidHand a_Case_Structure_SR_1;
	VoidHand s_Utility_MODBUS_RTU_Receive_Me_1;
	VoidHand a_Array_Subset_subarray_SR;
	VoidHand a_Join_Numbers__hi_lo__LT;
	VoidHand a_Array_Subset_subarray;
	VoidHand s_VISA_resource_name_1;
	VoidHand s_Utility_MODBUS_RTU_Receive_Me;
	VoidHand a_Constant_CT;
	VoidHand a_Constant_SR;
	VoidHand a_Case_Structure_CT;
	VoidHand a_Utility_MODBUS_RTU_Receive_Me;
	VoidHand a_Case_Structure_CT_1;
	VoidHand a_Utility_MODBUS_RTU_Receive_Me_1;
	VoidHand a_Constant_CT_1;
	VoidHand a_Build_Array_appended_array;
	VoidHand a_Utility_MODBUS_RTU_Receive_M_1;
	VoidHand ArgsF8DC871;  
	VoidHand a_Utility_MODBUS_RTU_Receive__1;
	VoidHand ArgsE405FB9;  
	VoidHand ArgsE405D19;  
	VoidHand ArgsE406079;  
	VoidHand s_Utility_MODBUS_RTU_Receive_M_1;
	VoidHand s_VISA_resource_name_SR;
	VoidHand s_Utility_MODBUS_RTU_Send_Messa;
	uInt16 n_Register_Address__0_;
	uInt16 n_Num_Of_Reg__1_;
	uInt16 n_Register_Address__0__LT;
	uInt16 n_Num_Of_Reg__1__LT;
	uInt16 e_Receive_Message_Type;
	uInt16 n_Join_Numbers__hi_lo_;
	uInt16 n_Num_Of_Reg__1__LT_1;
	uInt16 n_Register_Address__0__LT_1;
	uInt8 runStat72F6C4C;  
	uInt8 by_Split_Number_hi_x__1;
	uInt8 by_Split_Number_lo_x__1;
	uInt8 runStatF82CDD9;  
	uInt8 runStatF8DC870;  
	uInt8 by_Command;
	uInt8 by_Split_Number_lo_x_;
	uInt8 by_Utility_MODBUS_RTU_Send_Mess;
	uInt8 by_Unit_Address__1__LT_1;
	uInt8 runStatE405FB8;  
	uInt8 runStatE405E38;  
	uInt8 runStatF851724;  
	uInt8 runStatF8D44B9;  
	uInt8 runStatE406078;  
	uInt8 by_Unit_Address__1__LT;
	uInt8 runStatF82CDDA;  
	uInt8 runStat72F494C;  
	uInt8 runStatE405EF8;  
	uInt8 by_Split_Number_hi_x_;
	uInt8 by_Unbundle_Read_Buffer_0_;
	uInt8 by_Unbundle_Read_Buffer_1_;
	uInt8 by_Unit_Address__1__1;
	uInt8 runStatE405D78;  
	uInt8 runStatF8D44BA;  
	uInt8 runStatF82C2D9;  
	uInt8 runStatF82C2DA;  
	uInt8 runStatF82C559;  
	uInt8 runStatF82C55A;  
	uInt8 runStat1;  
	Boolean b_And_x__and__y_;
	Boolean b_Less__x___y_;
	Boolean b_While_Loop_End;
	Boolean b_Unbundle_By_Name_status_2;
	Boolean c_Utility_MODBUS_RTU_Receive__1;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_Read_From_Register_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Utility_Read_From_Register_signalsReadyTable[13];

static struct _Watflow_F4_lvlib_Utility_Read_From_Register_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Utility_Read_From_Register_heap; /* heap */

struct _tWatflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeap {
	uInt8	refCnt;
	VoidHand	i0F8D2AB0;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeap;
static struct _tWatflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeap _DATA_SECTION *Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr = &__Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeap;

struct _tWatflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i0E405FB8;
	subVIInstanceData	i0E406078;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeap;
static struct _tWatflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeap _DATA_SECTION *Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr = &__Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Utility_Read_From_Register_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[13] = {4, 1, 1, 2, 2, 2, 1, 3, 1, 5, 5, 1, 1};
struct _g_array_2 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_2 g_array_2 = { 
	uInt16DataType, 0, 1, 0, 1, 0
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_array_1 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_1 g_array_1 = { 
	int16DataType, 0, 1, 0, 1, 0
};

static ClusterControlData g_control_4 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_8 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_9 = {
	0, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_10 = {
	0, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_11 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_13 = {
	0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_12 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ArrayControlData g_control_14 = {
	0, 0, true, 1, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2200UL
#define error_in__no_error___274521432_ctlid 2200
#define error_out__322980768_ctlid 2201
#define VISA_resource_name__322981248_ctlid 2202
#define VISA_resource_name_out__322981728_ctlid 2203
#define Num_Of_Reg__1___322982112_ctlid 2204
#define Register_Address__0___322982496_ctlid 2205
#define Unit_Address__1___322982880_ctlid 2206
#define Data__322983840_ctlid 2207
#define N_CONTROLS 8L
#define gArrControlData Watflow_F4_lvlib_Utility_Read_From_Register_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_gArrControlData[8] = {
	{ error_in__no_error___274521432_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__322980768_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ VISA_resource_name__322981248_ctlid, 0, NULL, StringDataType, nonui_control },
	{ VISA_resource_name_out__322981728_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Num_Of_Reg__1___322982112_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ Register_Address__0___322982496_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ Unit_Address__1___322982880_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ Data__322983840_ctlid, 0, NULL, 0x20000 | ArrayDataType, array_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(error_in__no_error___274521432_ctlid) = ClusterControlDataCreateStatic(&g_control_4, GetControlDataPtr(), gFormID, error_in__no_error___274521432_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___274521432_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[1].pValue, argsIn->args[1].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb28);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___274521432_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___274521432_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,-1,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__322980768_ctlid) = ClusterControlDataCreateStatic(&g_control_8, GetControlDataPtr(), gFormID, error_out__322980768_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb30);
		}
		InitClusterControlFieldValue( FPData(error_out__322980768_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__322980768_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-2,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	if (argsIn && argsIn->size > 4 && argsIn->args[4].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__322981248_ctlid);
			vhIn = *(VoidHand *)argsIn->args[4].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[4].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[4].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[4].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__322981248_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,1,-16,129,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_resource_name_out__322981728_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb33);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__322981728_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-16,157,16,
	_LVT("0"),12,0,1000,0, false);
	{uInt16 dVal = (uInt16)1 ;
		{
			static NumericInitialData numData = {
				Num_Of_Reg__1___322982112_ctlid,
				0,
				0,
				0,
				uInt16DataType,
				1.0000000000000000000E+0,
				6.5535000000000000000E+4,
				1.0000000000000000000E+0,
				1,
				1,
				1,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Num_Of_Reg__1___322982112_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_9, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, Num_Of_Reg__1___322982112_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[2].pValue, argsIn->args[2].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Num_Of_Reg__1___322982112_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Num Of Reg (1)"),14,-13,-20,97,16,
	_LVT("0"),12,0,0,0, false);
	{uInt16 dVal = (uInt16)0 ;
		{
			static NumericInitialData numData = {
				Register_Address__0___322982496_ctlid,
				0,
				0,
				0,
				uInt16DataType,
				0.0000000000000000000E+0,
				6.5535000000000000000E+4,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Register_Address__0___322982496_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_10, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		nIdx = CalcControlOffset( gFormID, Register_Address__0___322982496_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[3].pValue, argsIn->args[3].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Register_Address__0___322982496_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Register Address (0)"),20,-21,-20,139,16,
	_LVT("0"),12,0,0,0, false);
	{uInt8 dVal = (uInt8)1 ;
		{
			static NumericInitialData numData = {
				Unit_Address__1___322982880_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Unit_Address__1___322982880_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_11, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, Unit_Address__1___322982880_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[0].pValue, argsIn->args[0].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Unit_Address__1___322982880_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Unit Address (1)"),16,-15,-20,111,16,
	_LVT("0"),12,0,0,0, false);
	FPData(Data__322983840_ctlid) = NULL;
	if(bShowFrontPanel) {
/* Declare array */
		{
			FPData(Data__322983840_ctlid) = (void*)&g_array_1.el_1;
			NDims(((PDAArrPtr)&g_array_1.el_1)) = 1;
			((PDAArrPtr)&g_array_1.el_1)->datatype = int16DataType;
			((PDAArrPtr)&g_array_1.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_1.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_1.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(Data__322983840_ctlid) = ArrayControlDataCreateStatic(&g_control_14, FPData(Data__322983840_ctlid), Data__322983840_ctlid, 0, 0, 1, bShowFrontPanel, 1, 0x20000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Data__322983840_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Data"),4,-40,-16,31,16,
	_LVT("0"),12,0,1000,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Utility_Read_From_Register_FrontPanelInit NULL
#define Watflow_F4_lvlib_Utility_Read_From_Register_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_in__no_error___274521432_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___274521432_ctlid), false );
	if (FPData(error_out__322980768_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__322980768_ctlid), false );
PDAStrFree( FPData(VISA_resource_name__322981248_ctlid) );
	FPData(VISA_resource_name__322981248_ctlid) = NULL;
PDAStrFree( FPData(VISA_resource_name_out__322981728_ctlid) );
	FPData(VISA_resource_name_out__322981728_ctlid) = NULL;
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(Data__322983840_ctlid), 1 );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__322980768_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	if (argsOut->size > 2 && argsOut->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__322981728_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[2].pValue = GetControlHValue(nIdx);
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, Data__322983840_ctlid);
		GetArrayControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[1].pValue);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_AddSubVIInstanceData(void) {
	if (Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->initialized) return;
	Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->initialized = TRUE;

	Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E405FB8.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E405FB8;
	Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E406078.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E406078;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_AddVIGlobalConstants(void) {
	(Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->refCnt)++;
	if (Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->refCnt > 1) return;

/* Declare array */
	{
		Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->i0F8D2AB0 = (void*)&g_array_2.el_1;
		NDims(((PDAArrPtr)&g_array_2.el_1)) = 1;
		((PDAArrPtr)&g_array_2.el_1)->datatype = uInt16DataType;
		((PDAArrPtr)&g_array_2.el_1)->staticArray = 1;
		((PDAArrPtr)&g_array_2.el_1)->refcnt = 2;
		NthDim(((PDAArrPtr)&g_array_2.el_1), (ArrDimSize)0) = 0;
	}
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_CleanupVIGlobalConstants(void) {
	if (Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->refCnt > 0) return;

	if (Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->i0F8D2AB0){--((PDAArrPtr)Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->i0F8D2AB0)->refcnt;}
	MemSet(Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr,sizeof(*(Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr)),0);
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_InitVIConstantList(void) {
	heap->a_Constant = Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->i0F8D2AB0;
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_F851724(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_F851724(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* for loop */
		uInt32 id = LVGetTimerFlag();
		static uInt16 nStep = 0;
		uInt32 diagramIdx = 17;
		if (heap->runStatF851724 == eReady) {
			CCGDebugSynchSNode(&state, 15, 16, 13, &snodeF851724, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->l_For_Loop_N_1 = heap->l_Quotient___Remainder_floor_x_;
			if (!(heap->a_Join_Numbers__hi_lo__LT = PDAArrCreateLpTunArrStatic( (ArrDimSize)heap->l_For_Loop_N_1, uInt16DataType, uCharDataType, (ArrDimSize)0, &g_staticArray_3, &g_staticArb34))){
				CGenErr();
			}
			heap->a_Array_Subset_subarray_SR = heap->a_Utility_MODBUS_RTU_Receive_M_1;
			/*SetSignalReady( 0x2, 4);*//* a_Array_Subset_subarray_SR */
			heap->l_For_Loop_i_1 = 0;
		}
		while (!gAppStop && !gLastError) {
			if (heap->l_For_Loop_i_1 < heap->l_For_Loop_N_1) {
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(4, 2);
						/*InitSignalReady( 0x1, 3);*//* l_index_1 */
						InitSignalReady(3, 2);
						/*InitSignalReady( 0x2, 6);*//* a_Array_Subset_subarray */
						/*InitSignalReady( 0x4, 3);*//* a_Utility_MODBUS_RTU_Receive__1 */
						/*InitSignalReady( 0x5, 7);*//* n_Join_Numbers__hi_lo_ */
						/*InitSignalReady( 0x8, 5);*//* by_Unbundle_Read_Buffer_0_ */
						/*InitSignalReady( 0x8, 6);*//* by_Unbundle_Read_Buffer_1_ */
						/*InitSignalReady( 0x1, 7);*//* c_Array_To_Cluster_cluster */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->a_Utility_MODBUS_RTU_Receive__1 = heap->a_Array_Subset_subarray_SR;
						/*SetSignalReady( 0x4, 3);*//* a_Utility_MODBUS_RTU_Receive__1 */
						UpdateProbes(&state, debugOffset, 42 /*0xE405958*/, (uChar*)&(heap->a_Utility_MODBUS_RTU_Receive__1)); /* assign */
						SetSignalReady(4, 1);
						PDAArrIncRefCnt(heap->a_Utility_MODBUS_RTU_Receive__1, (uInt16)1); /* RDCO:lsrs */
						heap->l_index_1 = 2;
						/*SetSignalReady( 0x1, 3);*//* l_index_1 */
						UpdateProbes(&state, debugOffset, 40 /*0xE405A18*/, (uChar*)&(heap->l_index_1)); /* assign */
						SetSignalReady(4, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						CCGDebugSynchNode(&state, 17, 18, 17, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						/* Array Subset */
						{
							Boolean bEmpty = false;
							Boolean bNullInput=false;
							ArrDimSize start0;
							{
								ArrDimSize nDimSize0=0;
								start0 = (ArrDimSize)heap->l_index_1;
								if (start0 < 0) {
									start0 = 0;
								}

								if (start0 >= PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0)) {
									start0 = PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0);
								}
								nDimSize0 = (ArrDimSize)PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0);
								if (nDimSize0 <= 0) {
									nDimSize0 = 0;
								}
								if ((start0 + nDimSize0) > PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0)) {
									nDimSize0 = PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0) - start0;
								}
								if (!(heap->a_Array_Subset_subarray = PDAArrNew1DStatic((ArrDimSize)nDimSize0, uCharDataType, &g_staticArray_4))){
									CGenErr();
								}
							}
							{
								ArrDimSize end0;
								if (start0 >= PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0)) {
									bEmpty = true;
								}
								end0 = PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0);
								if ((end0 < 0) || (end0 <= start0)) {
									bEmpty = true;;	}
								if (end0 > PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0)) {
									end0 = PDAArrNthDim(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), (ArrDimSize)0);
									PDAArrSetDim(((PDAArrPtr)heap->a_Array_Subset_subarray), (ArrDimSize)0, (end0 - start0) );
								}
								if (!bEmpty) {
									MemMove(NthElem(((PDAArrPtr)heap->a_Array_Subset_subarray), 0), NthElem(((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1), start0), (end0-start0)*DataSize(uCharDataType));
								}
								else {
									MemHandleFree( heap->a_Array_Subset_subarray ); //  Uninitialized
								}
	if (heap->a_Utility_MODBUS_RTU_Receive__1){--((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive__1)->refcnt;}
							}
							if (bNullInput) heap->a_Utility_MODBUS_RTU_Receive__1 = NULL;
						}
						/*SetSignalReady( 0x2, 6);*//* a_Array_Subset_subarray */
						UpdateProbes(&state, debugOffset, 41 /*0xE4059B8*/, (uChar*)&(heap->a_Array_Subset_subarray)); /* assign */
						SetSignalReady(3, 1);
						/**/
						/* Array To Cluster */
						/**/
						CCGDebugSynchNode(&state, 18, 19, 17, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (!PDAArrToClust(heap->a_Utility_MODBUS_RTU_Receive__1, 0x100000 | ArrayDataType, (int32)2, &(heap->c_Array_To_Cluster_cluster), 0xF0000 | ClusterDataType)) {
							CGenErr();
						}
;
						/*SetSignalReady( 0x1, 7);*//* c_Array_To_Cluster_cluster */
						UpdateProbes(&state, debugOffset, 46 /*0xE405718*/, (uChar*)&(heap->c_Array_To_Cluster_cluster)); /* assign */
						CCGDebugSynchNode(&state, 19, 20, 17, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
/* Unbundle */
						{
							cl_F0000* cl_002 = (cl_F0000*)&heap->c_Array_To_Cluster_cluster;
							heap->by_Unbundle_Read_Buffer_0_ = cl_002->el_0;
							/*SetSignalReady( 0x8, 5);*//* by_Unbundle_Read_Buffer_0_ */
							UpdateProbes(&state, debugOffset, 44 /*0xE405838*/, (uChar*)&(heap->by_Unbundle_Read_Buffer_0_)); /* assign */
							heap->by_Unbundle_Read_Buffer_1_ = cl_002->el_1;
							/*SetSignalReady( 0x8, 6);*//* by_Unbundle_Read_Buffer_1_ */
							UpdateProbes(&state, debugOffset, 45 /*0xE4057D8*/, (uChar*)&(heap->by_Unbundle_Read_Buffer_1_)); /* assign */
						}
						/**/
						/* Join Numbers */
						/**/
						CCGDebugSynchNode(&state, 20, 21, 17, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						PDAJoin( &(heap->by_Unbundle_Read_Buffer_0_), uCharDataType, &(heap->by_Unbundle_Read_Buffer_1_), uCharDataType, &(heap->n_Join_Numbers__hi_lo_) );
						/*SetSignalReady( 0x5, 7);*//* n_Join_Numbers__hi_lo_ */
						UpdateProbes(&state, debugOffset, 43 /*0xE4058F8*/, (uChar*)&(heap->n_Join_Numbers__hi_lo_)); /* assign */
						SetSignalReady(3, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 2 : {
						heap->a_Array_Subset_subarray_SR = heap->a_Array_Subset_subarray;
						/*SetSignalReady( 0x2, 4);*//* a_Array_Subset_subarray_SR */
						*(uInt16 *)LptunNthElem(heap->a_Join_Numbers__hi_lo__LT) = heap->n_Join_Numbers__hi_lo_; 
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 21, 17, &snodeF851724, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep=0;
			}
			(heap->l_For_Loop_i_1)++;
			if (heap->l_For_Loop_i_1 >= heap->l_For_Loop_N_1) {
				/* Free Unwired RSRs. */
	if (heap->a_Array_Subset_subarray_SR){--((PDAArrPtr)heap->a_Array_Subset_subarray_SR)->refcnt;}
				heap->a_Join_Numbers__hi_lo__LT = PDAArrCreate1DArrFromLpTunArr( heap->a_Join_Numbers__hi_lo__LT );
				/*SetSignalReady( 0x2, 5);*//* a_Join_Numbers__hi_lo__LT */
				UpdateProbes(&state, debugOffset, 38 /*0xF8DCBD0*/, (uChar*)&(heap->a_Join_Numbers__hi_lo__LT)); /* assign */
				SetSignalReady(2, 1);
				break;
			}
			if (!bRunToFinish) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		} /* end while */
	} /* end for loop */
	CCGDebugSynchAfterSNode(&state, &snodeF851724, 16, debugOffset);
	if(gAppStop) {
		gAppStop = true;
		return eFinished;
	}

	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_72F6C4C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_72F6C4C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F6C4C == eReady) {
			CCGDebugSynchSNode(&state, 11, 12, 3, &snode72F6C4C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatF8D44B9 = eReady;
			heap->runStatF8D44BA = eReady;
			heap->runStatF82C559 = eReady;
			heap->runStatE405E38 = eReady;
			heap->runStatF851724 = eReady;
			heap->runStatF82C55A = eReady;
			if (!PDAClusterGetElemByPosStatic( &heap->c_Utility_MODBUS_RTU_Receive_M_1, 0x0 | ClusterDataType, 0, &heap->c_Utility_MODBUS_RTU_Receive__1, BooleanDataType, NULL )) {
				CGenErr();
			}
			/*SetSignalReady( 0xA, 3);*//* c_Utility_MODBUS_RTU_Receive__1 */
			heap->a_Utility_MODBUS_RTU_Receive_Me_1 = heap->a_Utility_MODBUS_RTU_Receive_Me;
			/*SetSignalReady( 0x3, 6);*//* a_Utility_MODBUS_RTU_Receive_Me_1 */
			heap->a_Constant_CT = heap->a_Constant_SR;
			/*SetSignalReady( 0x3, 1);*//* a_Constant_CT */
		}
		switch ( heap->c_Utility_MODBUS_RTU_Receive__1 ) {
			/* begin case */
			case 1 : {
				uInt32 diagramIdx = 22;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(1, 1);
						/*InitSignalReady( 0x3, 7);*//* a_Constant_CT_1 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						/* Free unwired input select tunnel. */
	if (heap->a_Utility_MODBUS_RTU_Receive_Me_1){--((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive_Me_1)->refcnt;}
						heap->a_Constant_CT_1 = heap->a_Constant_CT;
						/*SetSignalReady( 0x3, 7);*//* a_Constant_CT_1 */
						UpdateProbes(&state, debugOffset, 47 /*0xF8DCAB0*/, (uChar*)&(heap->a_Constant_CT_1)); /* assign */
						SetSignalReady(1, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						heap->a_Case_Structure_CT_1 = heap->a_Constant_CT_1;
						/*SetSignalReady( 0x3, 5);*//* a_Case_Structure_CT_1 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 22, 22, &snode72F6C4C, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				uInt32 diagramIdx = 13;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(5, 2);
						/*InitSignalReady( 0x0, 7);*//* l_Quotient___Remainder_floor_x_ */
						/*InitSignalReady( 0x1, 0);*//* l_y_1 */
						/*InitSignalReady( 0x1, 1);*//* l_Array_Size_size_s_ */
						InitSignalReady(2, 1);
						/*InitSignalReady( 0x2, 5);*//* a_Join_Numbers__hi_lo__LT */
						InitSignalReady(6, 1);
						/*InitSignalReady( 0x4, 1);*//* a_Utility_MODBUS_RTU_Receive_M_1 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->a_Utility_MODBUS_RTU_Receive_M_1 = heap->a_Utility_MODBUS_RTU_Receive_Me_1;
						/*SetSignalReady( 0x4, 1);*//* a_Utility_MODBUS_RTU_Receive_M_1 */
						UpdateProbes(&state, debugOffset, 39 /*0xF8DCB70*/, (uChar*)&(heap->a_Utility_MODBUS_RTU_Receive_M_1)); /* assign */
						SetSignalReady(5, 1);
						SetSignalReady(6, 1);
						PDAArrIncRefCnt(heap->a_Utility_MODBUS_RTU_Receive_M_1, (uInt16)1); /* SelectTunnel */
						heap->l_y_1 = 2;
						/*SetSignalReady( 0x1, 0);*//* l_y_1 */
						UpdateProbes(&state, debugOffset, 36 /*0xE4053B8*/, (uChar*)&(heap->l_y_1)); /* assign */
						/* Free unwired input select tunnel. */
	if (heap->a_Constant_CT){--((PDAArrPtr)heap->a_Constant_CT)->refcnt;}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						/**/
						/* Array Size */
						/**/
						CCGDebugSynchNode(&state, 13, 14, 13, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						if (heap->a_Utility_MODBUS_RTU_Receive_M_1) {
							heap->l_Array_Size_size_s_ = NthDim( ((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive_M_1), 0 );
						}
						else {
							heap->l_Array_Size_size_s_ = 0;
						}
	if (heap->a_Utility_MODBUS_RTU_Receive_M_1){--((PDAArrPtr)heap->a_Utility_MODBUS_RTU_Receive_M_1)->refcnt;}
						/*SetSignalReady( 0x1, 1);*//* l_Array_Size_size_s_ */
						UpdateProbes(&state, debugOffset, 37 /*0xF8DCC90*/, (uChar*)&(heap->l_Array_Size_size_s_)); /* assign */
						/**/
						/* Quotient & Remainder */
						/**/
						CCGDebugSynchNode(&state, 14, 15, 13, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						heap->l_Quotient___Remainder_floor_x_ = (int32)(heap->l_Array_Size_size_s_/heap->l_y_1);
		/*SetSignalReady( 0x0, 7);*//* l_Quotient___Remainder_floor_x_ */
						UpdateProbes(&state, debugOffset, 35 /*0xE405478*/, (uChar*)&(heap->l_Quotient___Remainder_floor_x_)); /* assign */
						SetSignalReady(5, 1);
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 2 : {
						heap->runStatF851724 = Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_F851724( bRunToFinish  );
						if (heap->runStatF851724 == eNotFinished) {
							return eNotFinished;
						}
						else if (heap->runStatF851724 == eFail) {
							CGenErr();
						}
						heap->runStatF851724 = eReady;
						nStep++; }
/* start q el linear (0 or 1 struct) */
					case 3 : {
						heap->a_Case_Structure_CT_1 = heap->a_Join_Numbers__hi_lo__LT;
						/*SetSignalReady( 0x3, 5);*//* a_Case_Structure_CT_1 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 16, 13, &snode72F6C4C, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
		}
		heap->a_Case_Structure_CT = heap->a_Case_Structure_CT_1;
		/*SetSignalReady( 0x3, 3);*//* a_Case_Structure_CT */
		UpdateProbes(&state, debugOffset, 19 /*0xF8DBD30*/, (uChar*)&(heap->a_Case_Structure_CT)); /* assign */
		SetSignalReady(0, 1);
		/* FreeCaseSelDCO. */
	/* Free Cluster */
		{
			cl_00000* cl_003 = (cl_00000*)&heap->c_Utility_MODBUS_RTU_Receive_M_1;
				if (cl_003->el_2 && --((PDAStrPtr)cl_003->el_2)->refcnt == 0 && !((PDAStrPtr)cl_003->el_2)->staticStr) {
				MemHandleFree( cl_003->el_2 );
			}
		}
		CCGDebugSynchAfterSNode(&state, &snode72F6C4C, 12, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	return eFinished;
}
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_72F494C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_72F494C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72F494C == eReady) {
		if (!GetNumericFieldValue( FPData(Unit_Address__1___322982880_ctlid), &heap->by_Unit_Address__1__1, uCharDataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x8, 7);*//* by_Unit_Address__1__1 */
		UpdateProbes(&state, debugOffset, 1 /*0x9A31AC0*/, (uChar*)&(heap->by_Unit_Address__1__1)); /* assign */
		heap->s_VISA_resource_name_1 = FPData(VISA_resource_name__322981248_ctlid);
		PDAStrIncRefCnt(heap->s_VISA_resource_name_1, (uInt16)1);
		/*SetSignalReady( 0x2, 7);*//* s_VISA_resource_name_1 */
		UpdateProbes(&state, debugOffset, 9 /*0x9A315D8*/, (uChar*)&(heap->s_VISA_resource_name_1)); /* assign */
		if (!GetNumericFieldValue( FPData(Register_Address__0___322982496_ctlid), &heap->n_Register_Address__0_, uInt16DataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x5, 2);*//* n_Register_Address__0_ */
		UpdateProbes(&state, debugOffset, 2 /*0x9A31A00*/, (uChar*)&(heap->n_Register_Address__0_)); /* assign */
		if (!GetNumericFieldValue( FPData(Num_Of_Reg__1___322982112_ctlid), &heap->n_Num_Of_Reg__1_, uInt16DataType )){
			CGenErr();
		}
		/*SetSignalReady( 0x5, 3);*//* n_Num_Of_Reg__1_ */
		UpdateProbes(&state, debugOffset, 7 /*0x9A316F8*/, (uChar*)&(heap->n_Num_Of_Reg__1_)); /* assign */
		MemMove( &heap->c_error_in__no_error__1, ((ClusterControlData*)FPData(error_in__no_error___274521432_ctlid))->pVal, sizeof( cl_00000 ) );
		MemSet(((ClusterControlData*)FPData(error_in__no_error___274521432_ctlid))->pVal, sizeof( cl_00000 ), 0);
		/*SetSignalReady( 0x0, 3);*//* c_error_in__no_error__1 */
		UpdateProbes(&state, debugOffset, 4 /*0x9A318D8*/, (uChar*)&(heap->c_error_in__no_error__1)); /* assign */
	}
	{ /* while loop */
		uInt32 id = LVGetTimerFlag();
		int16 pass;
		Boolean bEndDiagram = false;
		static Boolean bInit = true;
		uInt32 diagramIdx = 3;
		if (heap->runStat72F494C == eReady) {
			CCGDebugSynchSNode(&state, 1, 2, 1, &snode72F494C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStatF82CDD9 = eReady;
			heap->runStatE405EF8 = eReady;
			heap->runStatE406078 = eReady;
			heap->runStatE405FB8 = eReady;
			heap->runStatF8DC870 = eReady;
			heap->runStat72F6C4C = eReady;
			heap->runStatF82CDDA = eReady;
			heap->by_Unit_Address__1__LT = heap->by_Unit_Address__1__1;
			/*SetSignalReady( 0x8, 0);*//* by_Unit_Address__1__LT */
			heap->n_Register_Address__0__LT = heap->n_Register_Address__0_;
			/*SetSignalReady( 0x5, 4);*//* n_Register_Address__0__LT */
			heap->n_Num_Of_Reg__1__LT = heap->n_Num_Of_Reg__1_;
			/*SetSignalReady( 0x5, 5);*//* n_Num_Of_Reg__1__LT */
			heap->s_Utility_MODBUS_RTU_Receive_Me_1 = heap->s_VISA_resource_name_1;
			/*SetSignalReady( 0x2, 3);*//* s_Utility_MODBUS_RTU_Receive_Me_1 */
			heap->a_Case_Structure_SR_1 = heap->a_Constant;
			/*SetSignalReady( 0x2, 2);*//* a_Case_Structure_SR_1 */
			MemMove( &heap->c_Utility_MODBUS_RTU_Receive_Me_1, &heap->c_error_in__no_error__1, sizeof( cl_00000 ) );
			/*SetSignalReady( 0x0, 5);*//* c_Utility_MODBUS_RTU_Receive_Me_1 */
			heap->l_While_Loop_i = 0;
		}
		while (!gAppStop && !gLastError) {
			nReady = 0;
			runStat = eFinished;
			bEndDiagram = false;
			for (pass=0;pass<2;pass++) {
				{
/* start q el linear (2 struct) */
					if ((heap->runStatF82CDD9 != eFinished)
					/*) {*/
					) {
						if (pass == 0) {
							InitSignalReady(10, 5);
							/*InitSignalReady( 0x0, 4);*//* c_error_in__no_error__SR */
							InitSignalReady(0, 4);
							InitSignalReady(7, 3);
							InitSignalReady(8, 1);
							/*InitSignalReady( 0x0, 1);*//* c_Utility_MODBUS_RTU_Receive_M_1 */
							InitSignalReady(9, 5);
							/*InitSignalReady( 0x5, 6);*//* e_Receive_Message_Type */
							/*InitSignalReady( 0x7, 2);*//* by_Unit_Address__1__LT_1 */
							/*InitSignalReady( 0x7, 1);*//* by_Utility_MODBUS_RTU_Send_Mess */
							/*InitSignalReady( 0x7, 0);*//* by_Split_Number_lo_x_ */
							/*InitSignalReady( 0x8, 4);*//* by_Split_Number_hi_x_ */
							InitSignalReady(11, 1);
							/*InitSignalReady( 0x6, 0);*//* n_Num_Of_Reg__1__LT_1 */
							/*InitSignalReady( 0x3, 2);*//* a_Constant_SR */
							/*InitSignalReady( 0x3, 3);*//* a_Case_Structure_CT */
							/*InitSignalReady( 0x3, 4);*//* a_Utility_MODBUS_RTU_Receive_Me */
							/*InitSignalReady( 0x6, 1);*//* n_Register_Address__0__LT_1 */
							/*InitSignalReady( 0x6, 4);*//* by_Split_Number_lo_x__1 */
							/*InitSignalReady( 0x6, 3);*//* by_Split_Number_hi_x__1 */
							/*InitSignalReady( 0x4, 0);*//* a_Build_Array_appended_array */
							/*InitSignalReady( 0x1, 4);*//* l_y */
							/*InitSignalReady( 0xA, 0);*//* b_Less__x___y_ */
							/*InitSignalReady( 0x0, 6);*//* l_While_Loop_i_1 */
							/*InitSignalReady( 0x6, 7);*//* by_Command */
							/*InitSignalReady( 0x9, 7);*//* b_And_x__and__y_ */
							/*InitSignalReady( 0xA, 2);*//* b_Unbundle_By_Name_status_2 */
							/*InitSignalReady( 0x4, 7);*//* s_Utility_MODBUS_RTU_Receive_M_1 */
							/*InitSignalReady( 0x5, 0);*//* s_VISA_resource_name_SR */
							/*InitSignalReady( 0x5, 1);*//* s_Utility_MODBUS_RTU_Send_Messa */
							/*InitSignalReady( 0x0, 0);*//* c_Utility_MODBUS_RTU_Send_Messa */
						}
						else {
							HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
							{
								heap->l_While_Loop_i_1 = heap->l_While_Loop_i;
								/*SetSignalReady( 0x0, 6);*//* l_While_Loop_i_1 */
								UpdateProbes(&state, debugOffset, 27 /*0x9A324E0*/, (uChar*)&(heap->l_While_Loop_i_1)); /* assign */
								heap->by_Unit_Address__1__LT_1 = heap->by_Unit_Address__1__1;
								/*SetSignalReady( 0x7, 2);*//* by_Unit_Address__1__LT_1 */
								UpdateProbes(&state, debugOffset, 13 /*0xF8DC090*/, (uChar*)&(heap->by_Unit_Address__1__LT_1)); /* assign */
								SetSignalReady(10, 1);
								heap->by_Command = 3;
								/*SetSignalReady( 0x6, 7);*//* by_Command */
								UpdateProbes(&state, debugOffset, 28 /*0x9A32420*/, (uChar*)&(heap->by_Command)); /* assign */
								SetSignalReady(9, 1);
								SetSignalReady(10, 1);
								heap->s_VISA_resource_name_SR = heap->s_Utility_MODBUS_RTU_Receive_Me_1;
								/*SetSignalReady( 0x5, 0);*//* s_VISA_resource_name_SR */
								UpdateProbes(&state, debugOffset, 32 /*0x9A32240*/, (uChar*)&(heap->s_VISA_resource_name_SR)); /* assign */
								SetSignalReady(10, 1);
								heap->l_y = 2;
								/*SetSignalReady( 0x1, 4);*//* l_y */
								UpdateProbes(&state, debugOffset, 25 /*0x9A32600*/, (uChar*)&(heap->l_y)); /* assign */
								heap->n_Register_Address__0__LT_1 = heap->n_Register_Address__0_;
								/*SetSignalReady( 0x6, 1);*//* n_Register_Address__0__LT_1 */
								UpdateProbes(&state, debugOffset, 21 /*0x9A327E0*/, (uChar*)&(heap->n_Register_Address__0__LT_1)); /* assign */
								heap->n_Num_Of_Reg__1__LT_1 = heap->n_Num_Of_Reg__1_;
								/*SetSignalReady( 0x6, 0);*//* n_Num_Of_Reg__1__LT_1 */
								UpdateProbes(&state, debugOffset, 17 /*0xF8DBEB0*/, (uChar*)&(heap->n_Num_Of_Reg__1__LT_1)); /* assign */
								SetSignalReady(11, 1);
								heap->a_Constant_SR = heap->a_Case_Structure_SR_1;
								/*SetSignalReady( 0x3, 2);*//* a_Constant_SR */
								UpdateProbes(&state, debugOffset, 18 /*0xF8DBDF0*/, (uChar*)&(heap->a_Constant_SR)); /* assign */
								SetSignalReady(7, 1);
								heap->e_Receive_Message_Type = 0;
								/*SetSignalReady( 0x5, 6);*//* e_Receive_Message_Type */
								UpdateProbes(&state, debugOffset, 12 /*0xF8DC0F0*/, (uChar*)&(heap->e_Receive_Message_Type)); /* assign */
								SetSignalReady(9, 1);
								MemMove( &heap->c_error_in__no_error__SR, &heap->c_Utility_MODBUS_RTU_Receive_Me_1, sizeof( cl_00000 ) );
								/*SetSignalReady( 0x0, 4);*//* c_error_in__no_error__SR */
								UpdateProbes(&state, debugOffset, 10 /*0xF8DC1B0*/, (uChar*)&(heap->c_error_in__no_error__SR)); /* assign */
								SetSignalReady(10, 1);
							}
							heap->runStatF82CDD9 = eFinished;
							continue;
						}
					}
/* start q el linear (2 struct) */
					if ((heap->runStatE405EF8 != eFinished)
					/*&& GetSignalReady( 0x6, 0)*//* n_Num_Of_Reg__1__LT_1 *//*) {*/
					&& GetSignalReady( 11 )) {
						if (pass == 0) {
							nReady++;
						}
						else {
							{
								/**/
								/* Split Number */
								/**/
								CCGDebugSynchNode(&state, 3, 4, 3, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}
								PDASplit( &(heap->n_Num_Of_Reg__1__LT_1), uInt16DataType, &(heap->by_Split_Number_hi_x_), &(heap->by_Split_Number_lo_x_) );
								/*SetSignalReady( 0x8, 4);*//* by_Split_Number_hi_x_ */
								UpdateProbes(&state, debugOffset, 16 /*0xF8DBF10*/, (uChar*)&(heap->by_Split_Number_hi_x_)); /* assign */
								/*SetSignalReady( 0x7, 0);*//* by_Split_Number_lo_x_ */
								UpdateProbes(&state, debugOffset, 15 /*0xF8DBF70*/, (uChar*)&(heap->by_Split_Number_lo_x_)); /* assign */
								/**/
								/* Split Number */
								/**/
								CCGDebugSynchNode(&state, 4, 5, 3, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}
								PDASplit( &(heap->n_Register_Address__0__LT_1), uInt16DataType, &(heap->by_Split_Number_hi_x__1), &(heap->by_Split_Number_lo_x__1) );
								/*SetSignalReady( 0x6, 3);*//* by_Split_Number_hi_x__1 */
								UpdateProbes(&state, debugOffset, 23 /*0x9A32720*/, (uChar*)&(heap->by_Split_Number_hi_x__1)); /* assign */
								/*SetSignalReady( 0x6, 4);*//* by_Split_Number_lo_x__1 */
								UpdateProbes(&state, debugOffset, 22 /*0x9A32780*/, (uChar*)&(heap->by_Split_Number_lo_x__1)); /* assign */
/* Build array */
								CCGDebugSynchNode(&state, 5, 6, 3, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}
								{
									ArrDimSize i;
									ArrDimSize dimSize=0;
									heap->a_Build_Array_appended_array = PDAArrNewEmptyWithNDimsStatic( uCharDataType, (ArrDimSize)1, &g_staticArray_7 );
									if (!heap->a_Build_Array_appended_array){
										CGenErr();
									}
									dimSize += 1;
									dimSize += 1;
									dimSize += 1;
									dimSize += 1;
									PDAArrSetDim(((PDAArrPtr)heap->a_Build_Array_appended_array), (ArrDimSize)0, dimSize);
									if (!PDAArrAllocData(&heap->a_Build_Array_appended_array)){
										CGenErr();
									}
									i=0;
									if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array), i, &heap->by_Split_Number_hi_x__1, uCharDataType)) {
										CGenErr();
									}
									i++;
									if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array), i, &heap->by_Split_Number_lo_x__1, uCharDataType)) {
										CGenErr();
									}
									i++;
									if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array), i, &heap->by_Split_Number_hi_x_, uCharDataType)) {
										CGenErr();
									}
									i++;
									if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array), i, &heap->by_Split_Number_lo_x_, uCharDataType)) {
										CGenErr();
									}
									i++;
								}
								/*SetSignalReady( 0x4, 0);*//* a_Build_Array_appended_array */
								UpdateProbes(&state, debugOffset, 24 /*0x9A32660*/, (uChar*)&(heap->a_Build_Array_appended_array)); /* assign */
								SetSignalReady(10, 1);
								/**/
								/* Less? */
								/**/
								CCGDebugSynchNode(&state, 6, 7, 3, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}
								heap->b_Less__x___y_ =  (heap->l_While_Loop_i_1 < heap->l_y);
								/*SetSignalReady( 0xA, 0);*//* b_Less__x___y_ */
								UpdateProbes(&state, debugOffset, 26 /*0x9A32540*/, (uChar*)&(heap->b_Less__x___y_)); /* assign */
							}
							heap->runStatE405EF8 = eFinished;
							InitSignalReady(11, 1);
							continue;
						}
					}
/* start q el struct (2 struct) */
					if ((heap->runStatE406078 != eFinished)
					/*&& GetSignalReady( 0x6, 7)*//* by_Command */
					/*&& GetSignalReady( 0x7, 2)*//* by_Unit_Address__1__LT_1 */
					/*&& GetSignalReady( 0x0, 4)*//* c_error_in__no_error__SR */
					/*&& GetSignalReady( 0x4, 0)*//* a_Build_Array_appended_array */
					/*&& GetSignalReady( 0x5, 0)*//* s_VISA_resource_name_SR *//*) {*/
					&& GetSignalReady( 10 )) {
						if (pass == 0) {
							nReady++;
						}
						else {
							if (heap->runStatE406078 == eReady) {
							}
							CCGDebugSynchIUse(&state, 7, 8, 3, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility MODBUS RTU Send Message.vi");
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}
							{
								ControlDataItemPtr cdPtr = LVGetCurrentControlData();
								if (heap->runStatE406078 == eReady) {
									CreateArgListStatic(heap->ArgsE406079, 5, 3 );
									argIn(heap->ArgsE406079, 0).nType = uCharDataType;
									argIn(heap->ArgsE406079, 0).pValue = (void *)&heap->by_Command;
									argIn(heap->ArgsE406079, 1).nType = uCharDataType;
									argIn(heap->ArgsE406079, 1).pValue = (void *)&heap->by_Unit_Address__1__LT_1;
									argIn(heap->ArgsE406079, 2).nType = 0x0 | ClusterDataType;
									argIn(heap->ArgsE406079, 2).pValue = (void *)&heap->c_error_in__no_error__SR;
									argIn(heap->ArgsE406079, 3).nType = 0x100000 | ArrayDataType;
									argIn(heap->ArgsE406079, 3).pValue = (void *)&heap->a_Build_Array_appended_array;
									argIn(heap->ArgsE406079, 4).nType = StringDataType;
									argIn(heap->ArgsE406079, 4).pValue = (void *)&heap->s_VISA_resource_name_SR;
									argOut(heap->ArgsE406079, 0).nType = 0x0 | ClusterDataType;
									argOut(heap->ArgsE406079, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_Send_Messa;
									argOut(heap->ArgsE406079, 1).nType = uCharDataType;
									argOut(heap->ArgsE406079, 1).pValue = (void *)&heap->by_Utility_MODBUS_RTU_Send_Mess;
									argOut(heap->ArgsE406079, 2).nType = StringDataType;
									argOut(heap->ArgsE406079, 2).pValue = (void *)&heap->s_Utility_MODBUS_RTU_Send_Messa;
								}
								if (!Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E406078.callerID) {
									Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E406078.callerID = ++gCallerID;
								}
								heap->runStatE406078 = Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_Run( &Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E406078, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsE406079)[0], (ArgList *)((ArgList **)heap->ArgsE406079)[1], &gPauseThisVI );
								LVSetCurrentControlData(cdPtr);
								CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 8, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}

								if (heap->runStatE406078 == eNotFinished) {
									runStat = eNotFinished;
								}
								if (heap->runStatE406078 == eFail || gLastError) {
									CGenErr();
								}
								if (gAppStop || (heap->runStatE406078 == eFinished)) {
									/*SetSignalReady( 0x0, 0);*//* c_Utility_MODBUS_RTU_Send_Messa */
									UpdateProbes(&state, debugOffset, 34 /*0x9A32120*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_Send_Messa)); /* assign */
									SetSignalReady(9, 1);
									/*SetSignalReady( 0x7, 1);*//* by_Utility_MODBUS_RTU_Send_Mess */
									UpdateProbes(&state, debugOffset, 14 /*0xF8DC030*/, (uChar*)&(heap->by_Utility_MODBUS_RTU_Send_Mess)); /* assign */
									SetSignalReady(9, 1);
									/*SetSignalReady( 0x5, 1);*//* s_Utility_MODBUS_RTU_Send_Messa */
									UpdateProbes(&state, debugOffset, 33 /*0x9A321E0*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_Send_Messa)); /* assign */
									SetSignalReady(9, 1);
								}
								if (gAppStop) {
									gAppStop=true;/* opt bug fix*/
									return eFinished;
								}
							}
							if (heap->runStatE406078 == eFinished) {
								InitSignalReady(10, 5);
								continue;
							}
						}
					}
/* start q el struct (2 struct) */
					if ((heap->runStatE405FB8 != eFinished)
					/*&& GetSignalReady( 0x5, 6)*//* e_Receive_Message_Type */
					/*&& GetSignalReady( 0x0, 0)*//* c_Utility_MODBUS_RTU_Send_Messa */
					/*&& GetSignalReady( 0x6, 7)*//* by_Command */
					/*&& GetSignalReady( 0x7, 1)*//* by_Utility_MODBUS_RTU_Send_Mess */
					/*&& GetSignalReady( 0x5, 1)*//* s_Utility_MODBUS_RTU_Send_Messa *//*) {*/
					&& GetSignalReady( 9 )) {
						if (pass == 0) {
							nReady++;
						}
						else {
							if (heap->runStatE405FB8 == eReady) {
							}
							CCGDebugSynchIUse(&state, 8, 9, 3, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility MODBUS RTU Receive Message.vi");
							if(gAppStop) {
								gAppStop = true;
								return eFinished;
							}
							{
								ControlDataItemPtr cdPtr = LVGetCurrentControlData();
								if (heap->runStatE405FB8 == eReady) {
									CreateArgListStatic(heap->ArgsE405FB9, 5, 3 );
									argIn(heap->ArgsE405FB9, 0).nType = 0x110000 | Enum16DataType;
									argIn(heap->ArgsE405FB9, 0).pValue = (void *)&heap->e_Receive_Message_Type;
									argIn(heap->ArgsE405FB9, 1).nType = 0x0 | ClusterDataType;
									argIn(heap->ArgsE405FB9, 1).pValue = (void *)&heap->c_Utility_MODBUS_RTU_Send_Messa;
									argIn(heap->ArgsE405FB9, 2).nType = uCharDataType;
									argIn(heap->ArgsE405FB9, 2).pValue = (void *)&heap->by_Command;
									argIn(heap->ArgsE405FB9, 3).nType = uCharDataType;
									argIn(heap->ArgsE405FB9, 3).pValue = (void *)&heap->by_Utility_MODBUS_RTU_Send_Mess;
									argIn(heap->ArgsE405FB9, 4).nType = StringDataType;
									argIn(heap->ArgsE405FB9, 4).pValue = (void *)&heap->s_Utility_MODBUS_RTU_Send_Messa;
									argOut(heap->ArgsE405FB9, 0).nType = 0x0 | ClusterDataType;
									argOut(heap->ArgsE405FB9, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_Receive_M_1;
									argOut(heap->ArgsE405FB9, 1).nType = 0x100000 | ArrayDataType;
									argOut(heap->ArgsE405FB9, 1).pValue = (void *)&heap->a_Utility_MODBUS_RTU_Receive_Me;
									argOut(heap->ArgsE405FB9, 2).nType = StringDataType;
									argOut(heap->ArgsE405FB9, 2).pValue = (void *)&heap->s_Utility_MODBUS_RTU_Receive_M_1;
								}
								if (!Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E405FB8.callerID) {
									Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E405FB8.callerID = ++gCallerID;
								}
								heap->runStatE405FB8 = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_Run( &Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr->i0E405FB8, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->ArgsE405FB9)[0], (ArgList *)((ArgList **)heap->ArgsE405FB9)[1], &gPauseThisVI );
								LVSetCurrentControlData(cdPtr);
								CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 9, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}

								if (heap->runStatE405FB8 == eNotFinished) {
									runStat = eNotFinished;
								}
								if (heap->runStatE405FB8 == eFail || gLastError) {
									CGenErr();
								}
								if (gAppStop || (heap->runStatE405FB8 == eFinished)) {
									/*SetSignalReady( 0x0, 1);*//* c_Utility_MODBUS_RTU_Receive_M_1 */
									UpdateProbes(&state, debugOffset, 11 /*0xF8DC150*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_Receive_M_1)); /* assign */
									SetSignalReady(0, 1);
									SetSignalReady(7, 1);
									SetSignalReady(8, 1);
									/*SetSignalReady( 0x3, 4);*//* a_Utility_MODBUS_RTU_Receive_Me */
									UpdateProbes(&state, debugOffset, 20 /*0x9A32840*/, (uChar*)&(heap->a_Utility_MODBUS_RTU_Receive_Me)); /* assign */
									SetSignalReady(7, 1);
									/*SetSignalReady( 0x4, 7);*//* s_Utility_MODBUS_RTU_Receive_M_1 */
									UpdateProbes(&state, debugOffset, 31 /*0x9A322A0*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_Receive_M_1)); /* assign */
									SetSignalReady(0, 1);
									/* Cluster Inc Ref Count:  Func call*/
									{
										cl_00000* cl_004 = (cl_00000*)&heap->c_Utility_MODBUS_RTU_Receive_M_1;
										PDAStrIncRefCnt(cl_004->el_2, (uInt16)2); /* Func call */
									}
								}
								if (gAppStop) {
									gAppStop=true;/* opt bug fix*/
									return eFinished;
								}
							}
							if (heap->runStatE405FB8 == eFinished) {
								InitSignalReady(9, 5);
								continue;
							}
						}
					}
/* start q el linear (2 struct) */
					if ((heap->runStatF8DC870 != eFinished)
					/*&& GetSignalReady( 0x0, 1)*//* c_Utility_MODBUS_RTU_Receive_M_1 *//*) {*/
					&& GetSignalReady( 8 )) {
						if (pass == 0) {
							nReady++;
						}
						else {
							{
								CCGDebugSynchNode(&state, 9, 10, 3, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}
/* Unbundle by name */
								{
									cl_00000* cl_005 = (cl_00000*)&heap->c_Utility_MODBUS_RTU_Receive_M_1;
									heap->b_Unbundle_By_Name_status_2 = cl_005->el_0;
									/*SetSignalReady( 0xA, 2);*//* b_Unbundle_By_Name_status_2 */
									UpdateProbes(&state, debugOffset, 30 /*0x9A32300*/, (uChar*)&(heap->b_Unbundle_By_Name_status_2)); /* assign */
	/* Free Cluster */
									{
										cl_00000* cl_006 = (cl_00000*)&heap->c_Utility_MODBUS_RTU_Receive_M_1;
				if (cl_006->el_2 && --((PDAStrPtr)cl_006->el_2)->refcnt == 0 && !((PDAStrPtr)cl_006->el_2)->staticStr) {
											MemHandleFree( cl_006->el_2 );
										}
									}
								}
								/**/
								/* And */
								/**/
								CCGDebugSynchNode(&state, 10, 11, 3, debugOffset);
								if(gAppStop) {
									gAppStop = true;
									return eFinished;
								}
								heap->b_And_x__and__y_ =  (heap->b_Unbundle_By_Name_status_2 & heap->b_Less__x___y_);
								/*SetSignalReady( 0x9, 7);*//* b_And_x__and__y_ */
								UpdateProbes(&state, debugOffset, 29 /*0x9A323C0*/, (uChar*)&(heap->b_And_x__and__y_)); /* assign */
								SetSignalReady(0, 1);
							}
							heap->runStatF8DC870 = eFinished;
							InitSignalReady(8, 1);
							continue;
						}
					}
/* start q el struct (2 struct) */
					if ((heap->runStat72F6C4C != eFinished)
					/*&& GetSignalReady( 0x0, 1)*//* c_Utility_MODBUS_RTU_Receive_M_1 */
					/*&& GetSignalReady( 0x3, 4)*//* a_Utility_MODBUS_RTU_Receive_Me */
					/*&& GetSignalReady( 0x3, 2)*//* a_Constant_SR *//*) {*/
					&& GetSignalReady( 7 )) {
						if (pass == 0) {
							nReady++;
						}
						else {
							heap->runStat72F6C4C = Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_72F6C4C( (Boolean)(bRunToFinish && (nReady < 2)) );
							if (heap->runStat72F6C4C == eNotFinished) {
								runStat = eNotFinished;
							}
							else if (heap->runStat72F6C4C == eFail) {
								CGenErr();
							}
							else {
								InitSignalReady(7, 3);
							}
							if (runStat == eFinished) {
								continue;
							}
						}
					}
/* start q el linear (2 struct) */
					if ((heap->runStatF82CDDA != eFinished)
					/*&& GetSignalReady( 0x9, 7)*//* b_And_x__and__y_ */
					/*&& GetSignalReady( 0x4, 7)*//* s_Utility_MODBUS_RTU_Receive_M_1 */
					/*&& GetSignalReady( 0x3, 3)*//* a_Case_Structure_CT */
					/*&& GetSignalReady( 0x0, 1)*//* c_Utility_MODBUS_RTU_Receive_M_1 *//*) {*/
					&& GetSignalReady( 0 )) {
						if (pass == 0) {
							nReady++;
						}
						else {
							{
								if (!PDAClusterGetElemByPosStatic( &heap->b_And_x__and__y_, BooleanDataType, 0, &heap->b_While_Loop_End, BooleanDataType, NULL )) {
									CGenErr();
								}
								heap->s_Utility_MODBUS_RTU_Receive_Me_1 = heap->s_Utility_MODBUS_RTU_Receive_M_1;
								/*SetSignalReady( 0x2, 3);*//* s_Utility_MODBUS_RTU_Receive_Me_1 */
								heap->a_Case_Structure_SR_1 = heap->a_Case_Structure_CT;
								/*SetSignalReady( 0x2, 2);*//* a_Case_Structure_SR_1 */
								MemMove( &heap->c_Utility_MODBUS_RTU_Receive_Me_1, &heap->c_Utility_MODBUS_RTU_Receive_M_1, sizeof( cl_00000 ) );
								/*SetSignalReady( 0x0, 5);*//* c_Utility_MODBUS_RTU_Receive_Me_1 */
							}
							heap->runStatF82CDDA = eFinished;
							InitSignalReady(0, 4);
							continue;
						}
					}
				}
				if( runStat == eFinished && pass )
				{
					volatile int dummy;
					CCGDebugSynchSRN(&state, 12, 3, &snode72F494C, debugOffset);
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}

					dummy=1;
				}
				if (pass == 1) {
					bEndDiagram = true;
				}
			}
			if (bEndDiagram &&runStat == eFinished) {
				(heap->l_While_Loop_i)++;
				heap->runStatF82CDD9 = eReady;
				heap->runStatE405EF8 = eReady;
				heap->runStatE406078 = eReady;
				heap->runStatE405FB8 = eReady;
				heap->runStatF8DC870 = eReady;
				heap->runStat72F6C4C = eReady;
				heap->runStatF82CDDA = eReady;
				if (!heap->b_While_Loop_End) {
					heap->s_Utility_MODBUS_RTU_Receive_Me = heap->s_Utility_MODBUS_RTU_Receive_Me_1;
					/*SetSignalReady( 0x3, 0);*//* s_Utility_MODBUS_RTU_Receive_Me */
					UpdateProbes(&state, debugOffset, 8 /*0x9A31698*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_Receive_Me)); /* assign */
					heap->a_Case_Structure_SR = heap->a_Case_Structure_SR_1;
					/*SetSignalReady( 0x2, 0);*//* a_Case_Structure_SR */
					UpdateProbes(&state, debugOffset, 6 /*0x9A317B8*/, (uChar*)&(heap->a_Case_Structure_SR)); /* assign */
					MemMove(&heap->c_Utility_MODBUS_RTU_Receive_Me, &heap->c_Utility_MODBUS_RTU_Receive_Me_1, sizeof(cl_00000));
					/*SetSignalReady( 0x0, 2);*//* c_Utility_MODBUS_RTU_Receive_Me */
					UpdateProbes(&state, debugOffset, 3 /*0x9A31940*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_Receive_Me)); /* assign */
					break;
				}
			}
			if (bEndDiagram) {
				if (!bRunToFinish && runStat == eNotFinished) return eNotFinished;
				if (!bRunToFinish) {
					if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
						if (!gAppStop && !gLastError) {
							return eNotFinished;
						}
						if (gAppStop) {
							return eFinished;
						}
						if (gLastError) {
							CGenErr();
						}
					}
				}
				bEndDiagram = false;
			}
		}
	}
	CCGDebugSynchAfterSNode(&state, &snode72F494C, 2, debugOffset);
	if(gAppStop) {
		gAppStop = true;
		return eFinished;
	}

	if (FPData(VISA_resource_name_out__322981728_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__322981728_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__322981728_ctlid))->staticStr) {
		MemHandleFree( FPData(VISA_resource_name_out__322981728_ctlid) );
	}
	FPData(VISA_resource_name_out__322981728_ctlid)=PDAStrCopyOnModify(heap->s_Utility_MODBUS_RTU_Receive_Me);
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__322981728_ctlid);
	if (!SetArrayControlFieldValueStatic( FPData(Data__322983840_ctlid), &heap->a_Case_Structure_SR, false, &g_staticArray_8))
	CGenErr();
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, Data__322983840_ctlid);
	{
		if (!SetClusterControlFieldValue( FPData(error_out__322980768_ctlid), &heap->c_Utility_MODBUS_RTU_Receive_Me, 0x0 | ClusterDataType, false )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, error_out__322980768_ctlid);
	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			/*InitSignalReady( 0x8, 7);*//* by_Unit_Address__1__1 */
			/*InitSignalReady( 0x5, 2);*//* n_Register_Address__0_ */
			/*InitSignalReady( 0x0, 2);*//* c_Utility_MODBUS_RTU_Receive_Me */
			/*InitSignalReady( 0x0, 3);*//* c_error_in__no_error__1 */
			InitSignalReady(12, 1);
			/*InitSignalReady( 0x2, 1);*//* a_Constant */
			/*InitSignalReady( 0x2, 0);*//* a_Case_Structure_SR */
			/*InitSignalReady( 0x5, 3);*//* n_Num_Of_Reg__1_ */
			/*InitSignalReady( 0x3, 0);*//* s_Utility_MODBUS_RTU_Receive_Me */
			/*InitSignalReady( 0x2, 7);*//* s_VISA_resource_name_1 */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			/*SetSignalReady( 0x2, 1);*//* a_Constant */
			UpdateProbes(&state, debugOffset, 5 /*0x9A31878*/, (uChar*)&(heap->a_Constant)); /* assign */
			SetSignalReady(12, 1);
			PDAArrIncRefCnt(heap->a_Constant, (uInt16)1); /* BDConst - alloc type */
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStat72F494C = Watflow_F4_lvlib_Utility_Read_From_Register_RunFunc_72F494C( bRunToFinish  );
			if (heap->runStat72F494C == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStat72F494C == eFail) {
				CGenErr();
			}
			heap->runStat72F494C = eReady;
			nStep++; }
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 2, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	(Watflow_F4_lvlib_Utility_Read_From_Register_GlobalConstantsHeapPtr->refCnt)--;
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Utility_Read_From_Register_VIName = "Watflow F4.lvlib:Utility Read From Register.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Utility_Read_From_Register_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Utility_Read_From_Register_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)52,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &Watflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tWatflow_F4_lvlib_Utility_Read_From_Register_viInstanceHeap),
	Watflow_F4_lvlib_Utility_Read_From_Register_InitFPTerms,
	Watflow_F4_lvlib_Utility_Read_From_Register_FrontPanelInit,
	Watflow_F4_lvlib_Utility_Read_From_Register_BlockDiagram,
	Watflow_F4_lvlib_Utility_Read_From_Register_DrawLabels,
	Watflow_F4_lvlib_Utility_Read_From_Register_GetFPTerms,
	Watflow_F4_lvlib_Utility_Read_From_Register_Cleanup,
	Watflow_F4_lvlib_Utility_Read_From_Register_CleanupLSRs,
	Watflow_F4_lvlib_Utility_Read_From_Register_AddSubVIInstanceData,
	Watflow_F4_lvlib_Utility_Read_From_Register_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Read_From_Register_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


