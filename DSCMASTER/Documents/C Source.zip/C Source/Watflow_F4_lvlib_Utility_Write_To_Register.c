/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: Watflow F4.lvlib:Utility Write To Register.vi
 *	Generated from: C:\Program Files\National Instruments\LabVIEW 2009\instr.lib\Watflow F4\Private\Utility Write To Register.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 8;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
struct _Watflow_F4_lvlib_Utility_Write_To_Register_heap { 
	cl_00000 c_Utility_MODBUS_RTU_Send_Messa_1;
	cl_00000 c_Utility_MODBUS_RTU_Receive__2;
	cl_00000 c_error_in__no_error__7;
	VoidHand Args125DFCF1;  
	VoidHand s_VISA_resource_name_7;
	VoidHand s_Utility_MODBUS_RTU_Receive__1;
	VoidHand Args125DFC31;  
	VoidHand s_Utility_MODBUS_RTU_Send_Messa_1;
	VoidHand a_Build_Array_appended_array_6;
	uInt16 e_Receive_Message_Type_1;
	uInt16 n_Register_Address__0__1;
	int16 i_Data__0__1;
	uInt8 by_Split_Number_lo_x__5;
	uInt8 by_Split_Number_hi_x__5;
	uInt8 by_Command_1;
	uInt8 by_Split_Number_hi_x__4;
	uInt8 by_Split_Number_lo_x__4;
	uInt8 runStat125DFB70;  
	uInt8 runStat125DFCF0;  
	uInt8 by_Utility_MODBUS_RTU_Send_Mess_1;
	uInt8 runStat125DFC30;  
	uInt8 by_Unit_Address__1__4;
	uInt8 runStat1;  
} _DATA_SECTION __Watflow_F4_lvlib_Utility_Write_To_Register_heap; /* heap */

static uInt32 _DATA_SECTION _Watflow_F4_lvlib_Utility_Write_To_Register_signalsReadyTable[2];

static struct _Watflow_F4_lvlib_Utility_Write_To_Register_heap _DATA_SECTION *heap = &__Watflow_F4_lvlib_Utility_Write_To_Register_heap; /* heap */

struct _tWatflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeap {
	Boolean initialized;
	subVIInstanceData	i125DFC30;
	subVIInstanceData	i125DFCF0;
} _DATA_SECTION __Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeap;
static struct _tWatflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeap _DATA_SECTION *Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr = &__Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _Watflow_F4_lvlib_Utility_Write_To_Register_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[2] = {5, 2};
struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

static ClusterControlData g_control_4 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static ClusterControlData g_control_8 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_9 = {
	0, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_10 = {
	0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static NumericData g_control_11 = {
	0, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 2800UL
#define error_in__no_error___269183208_ctlid 2800
#define error_out__269184360_ctlid 2801
#define Register_Address__0___269184744_ctlid 2802
#define Unit_Address__1___269185128_ctlid 2803
#define VISA_resource_name__269185608_ctlid 2804
#define VISA_resource_name_out__269186088_ctlid 2805
#define Data__0___269186472_ctlid 2806
#define N_CONTROLS 7L
#define gArrControlData Watflow_F4_lvlib_Utility_Write_To_Register_gArrControlData
ControlDataItem _DATA_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_gArrControlData[7] = {
	{ error_in__no_error___269183208_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ error_out__269184360_ctlid, 0, NULL, 0x0 | ClusterDataType, cluster_control },
	{ Register_Address__0___269184744_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ Unit_Address__1___269185128_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ VISA_resource_name__269185608_ctlid, 0, NULL, StringDataType, nonui_control },
	{ VISA_resource_name_out__269186088_ctlid, 0, NULL, StringDataType, nonui_control },
	{ Data__0___269186472_ctlid, 0, NULL, VoidHandDataType, numeric_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(error_in__no_error___269183208_ctlid) = ClusterControlDataCreateStatic(&g_control_4, GetControlDataPtr(), gFormID, error_in__no_error___269183208_ctlid, 1, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, error_in__no_error___269183208_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[1].pValue, argsIn->args[1].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_000;
			cl_000 = (cl_00000*)vpCls;
			cl_000->el_0 = false;
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb71);
		}
		InitClusterControlFieldValue( FPData(error_in__no_error___269183208_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_in__no_error___269183208_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error in (no error)"),19,-1,-18,126,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(error_out__269184360_ctlid) = ClusterControlDataCreateStatic(&g_control_8, GetControlDataPtr(), gFormID, error_out__269184360_ctlid, 0, 0, 0x0 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0x0 | ClusterDataType );
		{
			cl_00000* cl_001;
			cl_001 = (cl_00000*)vpCls;
			cl_001->el_0 = false;
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb73);
		}
		InitClusterControlFieldValue( FPData(error_out__269184360_ctlid),  vpCls, 0x0 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	error_out__269184360_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("error out"),9,-2,-18,66,16,
	_LVT("0"),12,0,1000,0, false);
	{uInt16 dVal = (uInt16)0 ;
		{
			static NumericInitialData numData = {
				Register_Address__0___269184744_ctlid,
				0,
				0,
				0,
				uInt16DataType,
				0.0000000000000000000E+0,
				6.5535000000000000000E+4,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Register_Address__0___269184744_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_9, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 3 && argsIn->args[3].pValue) {
		nIdx = CalcControlOffset( gFormID, Register_Address__0___269184744_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[3].pValue, argsIn->args[3].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Register_Address__0___269184744_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Register Address (0)"),20,-21,-20,139,16,
	_LVT("0"),12,0,0,0, false);
	{uInt8 dVal = (uInt8)1 ;
		{
			static NumericInitialData numData = {
				Unit_Address__1___269185128_ctlid,
				0,
				0,
				0,
				uCharDataType,
				0.0000000000000000000E+0,
				2.5500000000000000000E+2,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Unit_Address__1___269185128_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_10, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, Unit_Address__1___269185128_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[0].pValue, argsIn->args[0].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Unit_Address__1___269185128_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Unit Address (1)"),16,-15,-20,111,16,
	_LVT("0"),12,0,0,0, false);
	if (argsIn && argsIn->size > 4 && argsIn->args[4].pValue) {
		{
			VoidHand vhIn, vhOut;
			nIdx = CalcControlOffset( gFormID, VISA_resource_name__269185608_ctlid);
			vhIn = *(VoidHand *)argsIn->args[4].pValue;
			vhOut = GetControlHValue(nIdx);
			if (vhOut) {
				PDAVHFree( vhOut, argsIn->args[4].nType );
			}
			if (!vhIn) {
				vhOut = PDAVHNewEmpty( argsIn->args[4].nType );
			}
			else {
				vhOut = PDAVHCopyOnModify( vhIn, argsIn->args[4].nType );
			}
			if (!vhOut) return false;
			GetControlHValue(nIdx) = vhOut;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name__269185608_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name"),18,0,-16,129,16,
	_LVT("0"),12,0,1000,0, false);
	FPData(VISA_resource_name_out__269186088_ctlid) = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb76);
	LVInitLabel( GetControlDataPtr(),  gFormID,
	VISA_resource_name_out__269186088_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("VISA resource name out"),22,1,-16,157,16,
	_LVT("0"),12,0,1000,0, false);
	{int16 dVal = (int16)0 ;
		{
			static NumericInitialData numData = {
				Data__0___269186472_ctlid,
				0,
				0,
				0,
				int16DataType,
				-3.2768000000000000000E+4,
				3.2767000000000000000E+4,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(Data__0___269186472_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_11, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, Data__0___269186472_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[2].pValue, argsIn->args[2].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	Data__0___269186472_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("Data (0)"),8,-13,-20,55,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define Watflow_F4_lvlib_Utility_Write_To_Register_FrontPanelInit NULL
#define Watflow_F4_lvlib_Utility_Write_To_Register_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_Cleanup(Boolean bShowFrontPanel){
	if (FPData(error_in__no_error___269183208_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_in__no_error___269183208_ctlid), false );
	if (FPData(error_out__269184360_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(error_out__269184360_ctlid), false );
PDAStrFree( FPData(VISA_resource_name__269185608_ctlid) );
	FPData(VISA_resource_name__269185608_ctlid) = NULL;
PDAStrFree( FPData(VISA_resource_name_out__269186088_ctlid) );
	FPData(VISA_resource_name_out__269186088_ctlid) = NULL;
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, error_out__269184360_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue, argsOut->args[0].nType );
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, VISA_resource_name_out__269186088_ctlid);
		PDAVHIncRefCnt(gArrControlData[nIdx].hValue, gArrControlData[nIdx].dataType, 1) ;
		*(VoidHand *)argsOut->args[1].pValue = GetControlHValue(nIdx);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_CleanupLSRs(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_CleanupLSRs(void) {
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_AddSubVIInstanceData(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_AddSubVIInstanceData(void) {
	if (Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->initialized) return;
	Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->initialized = TRUE;

	Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFC30.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFC30;
	Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFCF0.next = gVIInstanceListHead;
	gVIInstanceListHead = &Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFCF0;
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_AddVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_AddVIGlobalConstants(void) {
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_CleanupVIGlobalConstants(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_CleanupVIGlobalConstants(void) {
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_InitVIConstantList(void);
void _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_InitVIConstantList(void) {
}


/****** Block diagram code **********/




/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	uInt32 id = LVGetTimerFlag();
	int16 pass, numStructs = 2;
	Boolean bEndDiagram = false;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {;
		heap->runStat1 = eReady;
		heap->runStat125DFB70 = eReady;
		heap->runStat125DFCF0 = eReady;
		heap->runStat125DFC30 = eReady;
	}
	while (!gAppStop && !gLastError) {
		nReady = 0;
		runStat = eFinished;
		bEndDiagram = false;
		for (pass=0;pass<2;pass++) {
/* start q el linear (2 struct) */
			if ((heap->runStat1 != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					/*InitSignalReady( 0x1, 2);*//* n_Register_Address__0__1 */
					/*InitSignalReady( 0x2, 5);*//* by_Unit_Address__1__4 */
					/*InitSignalReady( 0x0, 1);*//* c_Utility_MODBUS_RTU_Receive__2 */
					InitSignalReady(0, 5);
					/*InitSignalReady( 0x1, 1);*//* e_Receive_Message_Type_1 */
					/*InitSignalReady( 0x2, 3);*//* by_Utility_MODBUS_RTU_Send_Mess_1 */
					/*InitSignalReady( 0x2, 0);*//* by_Split_Number_lo_x__4 */
					/*InitSignalReady( 0x1, 7);*//* by_Split_Number_hi_x__4 */
					/*InitSignalReady( 0x1, 4);*//* by_Split_Number_lo_x__5 */
					/*InitSignalReady( 0x1, 5);*//* by_Split_Number_hi_x__5 */
					InitSignalReady(1, 2);
					/*InitSignalReady( 0x1, 0);*//* a_Build_Array_appended_array_6 */
					/*InitSignalReady( 0x1, 6);*//* by_Command_1 */
					/*InitSignalReady( 0x0, 7);*//* s_Utility_MODBUS_RTU_Send_Messa_1 */
					/*InitSignalReady( 0x0, 0);*//* c_Utility_MODBUS_RTU_Send_Messa_1 */
					/*InitSignalReady( 0x0, 2);*//* c_error_in__no_error__7 */
					/*InitSignalReady( 0x1, 3);*//* i_Data__0__1 */
					/*InitSignalReady( 0x0, 5);*//* s_Utility_MODBUS_RTU_Receive__1 */
					/*InitSignalReady( 0x0, 4);*//* s_VISA_resource_name_7 */
				}
				else {
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					{
						heap->by_Command_1 = 6;
						/*SetSignalReady( 0x1, 6);*//* by_Command_1 */
						UpdateProbes(&state, debugOffset, 11 /*0x125DF150*/, (uChar*)&(heap->by_Command_1)); /* assign */
						SetSignalReady(0, 1);
						SetSignalReady(1, 1);
						heap->e_Receive_Message_Type_1 = 1;
						/*SetSignalReady( 0x1, 1);*//* e_Receive_Message_Type_1 */
						UpdateProbes(&state, debugOffset, 4 /*0x125DF4B0*/, (uChar*)&(heap->e_Receive_Message_Type_1)); /* assign */
						SetSignalReady(0, 1);
					}
					heap->runStat1 = eFinished;
					continue;
				}
			}
/* start q el linear (2 struct) */
			if ((heap->runStat125DFB70 != eFinished)
			/*) {*/
			) {
				if (pass == 0) {
					nReady++;
				}
				else {
					{
						if (!GetNumericFieldValue( FPData(Data__0___269186472_ctlid), &heap->i_Data__0__1, int16DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x1, 3);*//* i_Data__0__1 */
						UpdateProbes(&state, debugOffset, 15 /*0x125DEEB0*/, (uChar*)&(heap->i_Data__0__1)); /* assign */
						/**/
						/* Split Number */
						/**/
						CCGDebugSynchNode(&state, 1, 2, 1, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						PDASplit( &(heap->i_Data__0__1), int16DataType, &(heap->by_Split_Number_hi_x__4), &(heap->by_Split_Number_lo_x__4) );
						/*SetSignalReady( 0x1, 7);*//* by_Split_Number_hi_x__4 */
						UpdateProbes(&state, debugOffset, 7 /*0x125DF330*/, (uChar*)&(heap->by_Split_Number_hi_x__4)); /* assign */
						/*SetSignalReady( 0x2, 0);*//* by_Split_Number_lo_x__4 */
						UpdateProbes(&state, debugOffset, 6 /*0x125DF390*/, (uChar*)&(heap->by_Split_Number_lo_x__4)); /* assign */
						if (!GetNumericFieldValue( FPData(Register_Address__0___269184744_ctlid), &heap->n_Register_Address__0__1, uInt16DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x1, 2);*//* n_Register_Address__0__1 */
						UpdateProbes(&state, debugOffset, 1 /*0x125DF630*/, (uChar*)&(heap->n_Register_Address__0__1)); /* assign */
						/**/
						/* Split Number */
						/**/
						CCGDebugSynchNode(&state, 2, 3, 1, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						PDASplit( &(heap->n_Register_Address__0__1), uInt16DataType, &(heap->by_Split_Number_hi_x__5), &(heap->by_Split_Number_lo_x__5) );
						/*SetSignalReady( 0x1, 5);*//* by_Split_Number_hi_x__5 */
						UpdateProbes(&state, debugOffset, 9 /*0x125DF270*/, (uChar*)&(heap->by_Split_Number_hi_x__5)); /* assign */
						/*SetSignalReady( 0x1, 4);*//* by_Split_Number_lo_x__5 */
						UpdateProbes(&state, debugOffset, 8 /*0x125DF2D0*/, (uChar*)&(heap->by_Split_Number_lo_x__5)); /* assign */
/* Build array */
						CCGDebugSynchNode(&state, 3, 4, 1, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						{
							ArrDimSize i;
							ArrDimSize dimSize=0;
							heap->a_Build_Array_appended_array_6 = PDAArrNewEmptyWithNDimsStatic( uCharDataType, (ArrDimSize)1, &g_staticArray_24 );
							if (!heap->a_Build_Array_appended_array_6){
								CGenErr();
							}
							dimSize += 1;
							dimSize += 1;
							dimSize += 1;
							dimSize += 1;
							PDAArrSetDim(((PDAArrPtr)heap->a_Build_Array_appended_array_6), (ArrDimSize)0, dimSize);
							if (!PDAArrAllocData(&heap->a_Build_Array_appended_array_6)){
								CGenErr();
							}
							i=0;
							if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_6), i, &heap->by_Split_Number_hi_x__5, uCharDataType)) {
								CGenErr();
							}
							i++;
							if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_6), i, &heap->by_Split_Number_lo_x__5, uCharDataType)) {
								CGenErr();
							}
							i++;
							if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_6), i, &heap->by_Split_Number_hi_x__4, uCharDataType)) {
								CGenErr();
							}
							i++;
							if (!PDAArrSetData(((PDAArrPtr)heap->a_Build_Array_appended_array_6), i, &heap->by_Split_Number_lo_x__4, uCharDataType)) {
								CGenErr();
							}
							i++;
						}
						/*SetSignalReady( 0x1, 0);*//* a_Build_Array_appended_array_6 */
						UpdateProbes(&state, debugOffset, 10 /*0x125DF1B0*/, (uChar*)&(heap->a_Build_Array_appended_array_6)); /* assign */
						SetSignalReady(1, 1);
					}
					heap->runStat125DFB70 = eFinished;
					continue;
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat125DFCF0 != eFinished)
			/*&& GetSignalReady( 0x1, 6)*//* by_Command_1 */
			/*&& GetSignalReady( 0x1, 0)*//* a_Build_Array_appended_array_6 *//*) {*/
			&& GetSignalReady( 1 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat125DFCF0 == eReady) {
						if (!GetNumericFieldValue( FPData(Unit_Address__1___269185128_ctlid), &heap->by_Unit_Address__1__4, uCharDataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x2, 5);*//* by_Unit_Address__1__4 */
						UpdateProbes(&state, debugOffset, 2 /*0x125DF5D0*/, (uChar*)&(heap->by_Unit_Address__1__4)); /* assign */
						MemMove( &heap->c_error_in__no_error__7, ((ClusterControlData*)FPData(error_in__no_error___269183208_ctlid))->pVal, sizeof( cl_00000 ) );
						MemSet(((ClusterControlData*)FPData(error_in__no_error___269183208_ctlid))->pVal, sizeof( cl_00000 ), 0);
						/*SetSignalReady( 0x0, 2);*//* c_error_in__no_error__7 */
						UpdateProbes(&state, debugOffset, 14 /*0x125DEF70*/, (uChar*)&(heap->c_error_in__no_error__7)); /* assign */
						heap->s_VISA_resource_name_7 = FPData(VISA_resource_name__269185608_ctlid);
						PDAStrIncRefCnt(heap->s_VISA_resource_name_7, (uInt16)1);
						/*SetSignalReady( 0x0, 4);*//* s_VISA_resource_name_7 */
						UpdateProbes(&state, debugOffset, 17 /*0x125DAB08*/, (uChar*)&(heap->s_VISA_resource_name_7)); /* assign */
					}
					CCGDebugSynchIUse(&state, 4, 5, 1, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility MODBUS RTU Send Message.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStat125DFCF0 == eReady) {
							CreateArgListStatic(heap->Args125DFCF1, 5, 3 );
							argIn(heap->Args125DFCF1, 0).nType = uCharDataType;
							argIn(heap->Args125DFCF1, 0).pValue = (void *)&heap->by_Command_1;
							argIn(heap->Args125DFCF1, 1).nType = uCharDataType;
							argIn(heap->Args125DFCF1, 1).pValue = (void *)&heap->by_Unit_Address__1__4;
							argIn(heap->Args125DFCF1, 2).nType = 0x0 | ClusterDataType;
							argIn(heap->Args125DFCF1, 2).pValue = (void *)&heap->c_error_in__no_error__7;
							argIn(heap->Args125DFCF1, 3).nType = 0x100000 | ArrayDataType;
							argIn(heap->Args125DFCF1, 3).pValue = (void *)&heap->a_Build_Array_appended_array_6;
							argIn(heap->Args125DFCF1, 4).nType = StringDataType;
							argIn(heap->Args125DFCF1, 4).pValue = (void *)&heap->s_VISA_resource_name_7;
							argOut(heap->Args125DFCF1, 0).nType = 0x0 | ClusterDataType;
							argOut(heap->Args125DFCF1, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_Send_Messa_1;
							argOut(heap->Args125DFCF1, 1).nType = uCharDataType;
							argOut(heap->Args125DFCF1, 1).pValue = (void *)&heap->by_Utility_MODBUS_RTU_Send_Mess_1;
							argOut(heap->Args125DFCF1, 2).nType = StringDataType;
							argOut(heap->Args125DFCF1, 2).pValue = (void *)&heap->s_Utility_MODBUS_RTU_Send_Messa_1;
						}
						if (!Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFCF0.callerID) {
							Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFCF0.callerID = ++gCallerID;
						}
						heap->runStat125DFCF0 = Watflow_F4_lvlib_Utility_MODBUS_RTU_Send_Message_Run( &Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFCF0, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args125DFCF1)[0], (ArgList *)((ArgList **)heap->Args125DFCF1)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 5, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStat125DFCF0 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStat125DFCF0 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStat125DFCF0 == eFinished)) {
							/*SetSignalReady( 0x0, 0);*//* c_Utility_MODBUS_RTU_Send_Messa_1 */
							UpdateProbes(&state, debugOffset, 13 /*0x125DF030*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_Send_Messa_1)); /* assign */
							SetSignalReady(0, 1);
							/*SetSignalReady( 0x2, 3);*//* by_Utility_MODBUS_RTU_Send_Mess_1 */
							UpdateProbes(&state, debugOffset, 5 /*0x125DF450*/, (uChar*)&(heap->by_Utility_MODBUS_RTU_Send_Mess_1)); /* assign */
							SetSignalReady(0, 1);
							/*SetSignalReady( 0x0, 7);*//* s_Utility_MODBUS_RTU_Send_Messa_1 */
							UpdateProbes(&state, debugOffset, 12 /*0x125DF0F0*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_Send_Messa_1)); /* assign */
							SetSignalReady(0, 1);
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (heap->runStat125DFCF0 == eFinished) {
						InitSignalReady(1, 2);
						continue;
					}
				}
			}
/* start q el struct (2 struct) */
			if ((heap->runStat125DFC30 != eFinished)
			/*&& GetSignalReady( 0x1, 1)*//* e_Receive_Message_Type_1 */
			/*&& GetSignalReady( 0x0, 0)*//* c_Utility_MODBUS_RTU_Send_Messa_1 */
			/*&& GetSignalReady( 0x1, 6)*//* by_Command_1 */
			/*&& GetSignalReady( 0x2, 3)*//* by_Utility_MODBUS_RTU_Send_Mess_1 */
			/*&& GetSignalReady( 0x0, 7)*//* s_Utility_MODBUS_RTU_Send_Messa_1 *//*) {*/
			&& GetSignalReady( 0 )) {
				if (pass == 0) {
					nReady++;
				}
				else {
					if (heap->runStat125DFC30 == eReady) {
					}
					CCGDebugSynchIUse(&state, 5, 6, 1, debugOffset, &gPauseThisVI, "Watflow F4.lvlib:Utility MODBUS RTU Receive Message.vi");
					if(gAppStop) {
						gAppStop = true;
						return eFinished;
					}
					{
						ControlDataItemPtr cdPtr = LVGetCurrentControlData();
						if (heap->runStat125DFC30 == eReady) {
							CreateArgListStatic(heap->Args125DFC31, 5, 3 );
							argIn(heap->Args125DFC31, 0).nType = 0x110000 | Enum16DataType;
							argIn(heap->Args125DFC31, 0).pValue = (void *)&heap->e_Receive_Message_Type_1;
							argIn(heap->Args125DFC31, 1).nType = 0x0 | ClusterDataType;
							argIn(heap->Args125DFC31, 1).pValue = (void *)&heap->c_Utility_MODBUS_RTU_Send_Messa_1;
							argIn(heap->Args125DFC31, 2).nType = uCharDataType;
							argIn(heap->Args125DFC31, 2).pValue = (void *)&heap->by_Command_1;
							argIn(heap->Args125DFC31, 3).nType = uCharDataType;
							argIn(heap->Args125DFC31, 3).pValue = (void *)&heap->by_Utility_MODBUS_RTU_Send_Mess_1;
							argIn(heap->Args125DFC31, 4).nType = StringDataType;
							argIn(heap->Args125DFC31, 4).pValue = (void *)&heap->s_Utility_MODBUS_RTU_Send_Messa_1;
							argOut(heap->Args125DFC31, 0).nType = 0x0 | ClusterDataType;
							argOut(heap->Args125DFC31, 0).pValue = (void *)&heap->c_Utility_MODBUS_RTU_Receive__2;
							argOut(heap->Args125DFC31, 1).nType = 0;
							argOut(heap->Args125DFC31, 1).pValue = NULL;
							argOut(heap->Args125DFC31, 2).nType = StringDataType;
							argOut(heap->Args125DFC31, 2).pValue = (void *)&heap->s_Utility_MODBUS_RTU_Receive__1;
						}
						if (!Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFC30.callerID) {
							Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFC30.callerID = ++gCallerID;
						}
						heap->runStat125DFC30 = Watflow_F4_lvlib_Utility_MODBUS_RTU_Receive_Message_Run( &Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr->i125DFC30, false, (Boolean)(bRunToFinish && (nReady < 2)), (ArgList *)((ArgList **)heap->Args125DFC31)[0], (ArgList *)((ArgList **)heap->Args125DFC31)[1], &gPauseThisVI );
						LVSetCurrentControlData(cdPtr);
						CCGDebugSynchAfterSNode(&state, &gPauseThisVI, 6, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}

						if (heap->runStat125DFC30 == eNotFinished) {
							runStat = eNotFinished;
						}
						if (heap->runStat125DFC30 == eFail || gLastError) {
							CGenErr();
						}
						if (gAppStop || (heap->runStat125DFC30 == eFinished)) {
							/*SetSignalReady( 0x0, 1);*//* c_Utility_MODBUS_RTU_Receive__2 */
							UpdateProbes(&state, debugOffset, 3 /*0x125DF570*/, (uChar*)&(heap->c_Utility_MODBUS_RTU_Receive__2)); /* assign */
							/*SetSignalReady( 0x0, 5);*//* s_Utility_MODBUS_RTU_Receive__1 */
							UpdateProbes(&state, debugOffset, 16 /*0x125DEDF0*/, (uChar*)&(heap->s_Utility_MODBUS_RTU_Receive__1)); /* assign */
						}
						if (gAppStop) {
							gAppStop=true;/* opt bug fix*/
							return eFinished;
						}
					}
					if (heap->runStat125DFC30 == eFinished) {
						{
							if (!SetClusterControlFieldValue( FPData(error_out__269184360_ctlid), &heap->c_Utility_MODBUS_RTU_Receive__2, 0x0 | ClusterDataType, false )){
								CGenErr();
							}
						}
						/* Update front panel indicator */
						CCGDebugUpdateFPControl(&state, debugOffset, error_out__269184360_ctlid);
	if (FPData(VISA_resource_name_out__269186088_ctlid) && --((PDAStrPtr)FPData(VISA_resource_name_out__269186088_ctlid))->refcnt == 0 && !((PDAStrPtr)FPData(VISA_resource_name_out__269186088_ctlid))->staticStr) {
							MemHandleFree( FPData(VISA_resource_name_out__269186088_ctlid) );
						}
						FPData(VISA_resource_name_out__269186088_ctlid)=PDAStrCopyOnModify(heap->s_Utility_MODBUS_RTU_Receive__1);
						/* Update front panel indicator */
						CCGDebugUpdateFPControl(&state, debugOffset, VISA_resource_name_out__269186088_ctlid);
						InitSignalReady(0, 5);
						continue;
					}
				}
			}
			if (pass == 1) bEndDiagram = true;
		}
		if (bEndDiagram &&runStat == eFinished) {
			CCGDebugSynchSRN(&state, 6, 1, pauseCaller, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat1 = eReady;
			heap->runStat125DFB70 = eReady;
			heap->runStat125DFCF0 = eReady;
			heap->runStat125DFC30 = eReady;
			break;
		}
		if (!bRunToFinish) {
			if (bEndDiagram) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		}
	}
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr Watflow_F4_lvlib_Utility_Write_To_Register_VIName = "Watflow F4.lvlib:Utility Write To Register.vi";

static VIInfo _DATA_SECTION viInfo = {
	&Watflow_F4_lvlib_Utility_Write_To_Register_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _Watflow_F4_lvlib_Utility_Write_To_Register_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)8,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)NULL,
	(uInt32)0,
	false,
	(uInt8**)&stepArr,
	(uInt8**) &Watflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeapPtr,
	(uInt32)sizeof (struct _tWatflow_F4_lvlib_Utility_Write_To_Register_viInstanceHeap),
	Watflow_F4_lvlib_Utility_Write_To_Register_InitFPTerms,
	Watflow_F4_lvlib_Utility_Write_To_Register_FrontPanelInit,
	Watflow_F4_lvlib_Utility_Write_To_Register_BlockDiagram,
	Watflow_F4_lvlib_Utility_Write_To_Register_DrawLabels,
	Watflow_F4_lvlib_Utility_Write_To_Register_GetFPTerms,
	Watflow_F4_lvlib_Utility_Write_To_Register_Cleanup,
	Watflow_F4_lvlib_Utility_Write_To_Register_CleanupLSRs,
	Watflow_F4_lvlib_Utility_Write_To_Register_AddSubVIInstanceData,
	Watflow_F4_lvlib_Utility_Write_To_Register_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION Watflow_F4_lvlib_Utility_Write_To_Register_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


