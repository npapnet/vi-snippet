/****************************************************************************************
 *	LabVIEW (TM) Code Generator 9.0f3
 *	(C) Copyright 1997-2005 by National Instruments Corp.
 *	All rights reserved.
 *	Delimited VI name: F4 Controller handle Global Function Variable.vi
 *	Generated from: C:\Documents and Settings\pansino\����\Source Code(0925 check UI)\SubVIs\Controller Communication.llb\F4 Controller handle Global Function Variable.vi
 *	Generated on: 2010-2-8 13:46
 *  Generated UI: false
 *  Generated Debug Info: true
 *  Generated Serial Only: false
 *  Generated Stack Variables: false
 *  Generated Guard Code: false
 *  Generated Interrupt Code: false
 *  Generated C Function Calls: false
 *  Generated Integer Only : false
 *  Generated Expression Folding : false
 *  Generated memory model: static
*****************************************************************************************/
#include "LVCGenIncludes.h"
#if CGEN_VERSION != 9000
#error CGenerator version mismatch
#endif
/* VI heap data */
#include "LVDebugTable.h"
static uInt32 debugOffset = 11;
static Boolean gPauseThisVI = false;
static Boolean *pauseCaller = NULL;
static Boolean snode72FD04C = false;
static Boolean snode72F8CCC = false;
static Boolean snodeF85DB2C = false;
struct _F4_Controller_handle_Global_Function_Variable_heap { 
	cl_C0000 c_Index_Array_element;
	cl_C0000 c_F4_Controller_Handle_In;
	cl_C0000 c_While_Loop_LT;
	int32 l___________;
	int32 l_While_Loop_CT_2;
	int32 l_For_Loop_i_4;
	int32 l_While_Loop_i_2;
	int32 l_Case_Structure_CT_2;
	int32 l_While_Loop_SR_1;
	int32 l_For_Loop_N_4;
	int32 l____________1;
	int32 l_While_Loop_CT_1;
	int32 l_Case_Structure_SR;
	int32 l_While_Loop_CT;
	int32 l_Case_Structure_CT_3;
	int32 l_While_Loop_CT_3;
	VoidHand a_While_Loop_CT;
	VoidHand a_While_Loop_LT;
	VoidHand s_Unbundle_By_Name_F4Ctrller_Na;
	VoidHand Args9BC81E9;  
	VoidHand a_While_Loop_CT_1;
	VoidHand a_Insert_Into_Array_output_arra;
	VoidHand a_Case_Structure_CT_18;
	VoidHand a_While_Loop_SR_1;
	VoidHand a_Case_Structure_SR_2;
	VoidHand a_While_Loop_CT_3;
	VoidHand a_Constant_1;
	VoidHand a_While_Loop_CT_4;
	VoidHand a_While_Loop_CT_2;
	VoidHand a_Unbundle_By_Name_F4Ctrller_Na;
	VoidHand a_Case_Structure_CT_19;
	uInt16 e_F4_Controller_handle_Global_F_1;
	uInt16 e_F4_Controller_handle_Global_1;
	uInt16 e_F4_Controller_handle_Global__1;
	uInt16 e_F4_Controller_handle_Global_2;
	uInt8 runStatF85DB2C;  
	uInt8 runStat9BD5511;  
	uInt8 runStat9BCC4A8;  
	uInt8 runStat9BD5512;  
	uInt8 runStat9BCC148;  
	uInt8 runStat9BD5311;  
	uInt8 runStat9BC81E8;  
	uInt8 runStat9BD5811;  
	uInt8 runStat9C196C1;  
	uInt8 runStat9C196C2;  
	uInt8 runStat9BD49D1;  
	uInt8 runStat9BD49D2;  
	uInt8 runStat72F8CCC;  
	uInt8 runStat9BD5812;  
	uInt8 runStat9C19501;  
	uInt8 runStat9C19502;  
	uInt8 runStat72FD04C;  
	uInt8 runStat9BD5312;  
	uInt8 runStat9BD5151;  
	uInt8 runStat9BD5152;  
	uInt8 runStat1;  
	Boolean b_While_Loop_End_1;
	Boolean b_Constant;
} _DATA_SECTION __F4_Controller_handle_Global_Function_Variable_heap; /* heap */

static uInt32 _DATA_SECTION _F4_Controller_handle_Global_Function_Variable_signalsReadyTable[12];

static struct _F4_Controller_handle_Global_Function_Variable_heap _DATA_SECTION *heap = &__F4_Controller_handle_Global_Function_Variable_heap; /* heap */

struct _tF4_Controller_handle_Global_Function_Variable_GlobalConstantsHeap {
	uInt8	refCnt;
	VoidHand	i09BC8838;
} _DATA_SECTION __F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeap;
static struct _tF4_Controller_handle_Global_Function_Variable_GlobalConstantsHeap _DATA_SECTION *F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr = &__F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeap;

static StepArray _DATA_SECTION stepArr = NULL;
static uInt32 _DATA_SECTION *signalsReady = (uInt32 *) _F4_Controller_handle_Global_Function_Variable_signalsReadyTable; /* heap */
static eRunStatus _DATA_SECTION gRunStatus = eReady;
static int32 _DATA_SECTION gCurrentCallerID = 0;
static uInt32 InitSignalReadyValues[12] = {3, 2, 1, 2, 1, 1, 1, 2, 2, 2, 1, 3};
struct _F4_Controller_handle_Global_Function_Variable_heap_lsr { 
	int32 l_While_Loop_SR;  
	VoidHand a_While_Loop_SR;  
} _DATA_SECTION __F4_Controller_handle_Global_Function_Variable_heap_lsr; /* heap */

struct _F4_Controller_handle_Global_Function_Variable_heap_lsr _DATA_SECTION *F4_Controller_handle_Global_Function_Variable_heap_lsr = &__F4_Controller_handle_Global_Function_Variable_heap_lsr; /* heap */
struct _g_array_3 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_3 g_array_3 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_array_1 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_1 g_array_1 = { 
	StringDataType, 0, 1, 0, 1, 0
};

struct _g_array_2 {
	DataType	el_1;
	int16	el_2;
	uInt8	el_3;
	uInt8	el_4;
	ArrDimSize	el_5;
	ArrDimSize	el_6;
};
_DATA_SECTION static struct _g_array_2 g_array_2 = { 
	0xC0000 | ClusterDataType, 0, 1, 0, 1, 0
};

struct _g_string_1 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_1 g_string_1 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_2 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_2 g_string_2 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_3 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_3 g_string_3 = { 
	0, 1, 0, _LVT("")
};

struct _g_string_4 {
	uInt16	el_1;
	uInt16	el_2;
	PDAStrLen_t	el_3;
	TextChar	el_4[2];
};
static struct _g_string_4 g_string_4 = { 
	0, 1, 0, _LVT("")
};

static ClusterControlData g_control_3 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

struct {
	DataType	el_0;
	uInt32	el_1;
	uInt32	el_2;
	uInt32	el_3;
	uInt8	el_4;
	uInt8	el_5;
}
static g_control_4 = {
	0, 0, 0, 5, 1, 0
};

static NumericData g_control_5 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ArrayControlData g_control_7 = {
	0, 0, true, 1, 0, 0
};

static NumericData g_control_8 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ClusterControlData g_control_11 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_12 = {
	0, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ClusterControlData g_control_16 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0
};

static NumericData g_control_13 = {
	0, 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

static ArrayControlData g_control_17 = {
	0, 0, true, 1, 0, 0
};

struct {
	int32	el_0;
	int32	el_1;
	uInt8	el_2:1;
	uInt8	el_3[3];
	int32	el_4;
}
static g_control_6 = {
	0, 1, true, 0, 0, 0, 0
};



/****** Control & Indicator IDs used to reference terminals from block diagram **********/


#define gFormID 3100UL
#define F4_Controller_Handle_In__278204128_ctlid 3100
#define F4_Controller_handle_Global_Function_Enum__278204704_ctlid 3101
#define A_________________278205376_ctlid 3102
#define A_____________278205760_ctlid 3103
#define A_____________278207304_ctlid 3104
#define A_________________278207688_ctlid 3105
#define A_________________278209800_ctlid 3106
#define N_CONTROLS 7L
#define gArrControlData F4_Controller_handle_Global_Function_Variable_gArrControlData
ControlDataItem _DATA_SECTION F4_Controller_handle_Global_Function_Variable_gArrControlData[7] = {
	{ F4_Controller_Handle_In__278204128_ctlid, 0, NULL, 0xC0000 | ClusterDataType, cluster_control },
	{ F4_Controller_handle_Global_Function_Enum__278204704_ctlid, 0, NULL, VoidHandDataType, enum_control },
	{ A_________________278205376_ctlid, 0, NULL, 0x30000 | ArrayDataType, array_control },
	{ A_____________278205760_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ A_____________278207304_ctlid, 0, NULL, 0xC0000 | ClusterDataType, cluster_control },
	{ A_________________278207688_ctlid, 0, NULL, VoidHandDataType, numeric_control },
	{ A_________________278209800_ctlid, 0, NULL, 0x130000 | ArrayDataType, array_control },
};


/****** Initialize Front Panel Terminals to their default values or to the values passed in **********/


Boolean _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel);
Boolean _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_InitFPTerms(ArgList *argsIn, Boolean bShowFrontPanel){
	int32 nIdx=0;
	if (!(FPData(F4_Controller_Handle_In__278204128_ctlid) = ClusterControlDataCreateStatic(&g_control_3, GetControlDataPtr(), gFormID, F4_Controller_Handle_In__278204128_ctlid, 1, 0, 0xC0000 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	if (argsIn && argsIn->size > 2 && argsIn->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, F4_Controller_Handle_In__278204128_ctlid);
		InitClusterControlFieldValue( gArrControlData[nIdx].hValue, argsIn->args[2].pValue, argsIn->args[2].nType );
	}
	else {
		VoidPtr vpCls = PDAClusterNewEmpty( 0xC0000 | ClusterDataType );
		{
			cl_C0000* cl_000;
			cl_000 = (cl_C0000*)vpCls;
			cl_000->el_0 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb88);
			cl_000->el_1 = 0 ;
			cl_000->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb89);
		}
		InitClusterControlFieldValue( FPData(F4_Controller_Handle_In__278204128_ctlid),  vpCls, 0xC0000 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	F4_Controller_Handle_In__278204128_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("F4 Controller Handle In"),23,0,-17,141,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(F4_Controller_handle_Global_Function_Enum__278204704_ctlid) = EnumCtlDataCreateStatic((EnumCtlData*)&g_control_4, F4_Controller_handle_Global_Function_Enum__278204704_ctlid, (ControlID)0, (ControlID)0, (int32)5, 0xE0000 | Enum16DataType, 0 ))){
		return false;
	}
	if (argsIn && argsIn->size > 1 && argsIn->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, F4_Controller_handle_Global_Function_Enum__278204704_ctlid);
		if (!SetEnumCtlFieldValue(GetControlHValue(nIdx), argsIn->args[1].pValue, argsIn->args[1].nType )) {
			return false;
		}
	}
	else {
		{			int16 lVal = 0 ;
			if (!SetEnumCtlFieldValue( FPData(F4_Controller_handle_Global_Function_Enum__278204704_ctlid), &lVal, IntDataType )){
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	F4_Controller_handle_Global_Function_Enum__278204704_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("F4 Controller handle Global Function Enum"),41,-4,-20,249,16,
	_LVT("0"),12,0,0,0, false);
	FPData(A_________________278205376_ctlid) = NULL;
/* Declare array */
	{
		FPData(A_________________278205376_ctlid) = (void*)&g_array_1.el_1;
		NDims(((PDAArrPtr)&g_array_1.el_1)) = 1;
		((PDAArrPtr)&g_array_1.el_1)->datatype = StringDataType;
		((PDAArrPtr)&g_array_1.el_1)->staticArray = 1;
		((PDAArrPtr)&g_array_1.el_1)->refcnt = 2;
		NthDim(((PDAArrPtr)&g_array_1.el_1), (ArrDimSize)0) = 0;
	}
	if (!(FPData(A_________________278205376_ctlid) = ArrayControlDataCreateStatic(&g_control_7, FPData(A_________________278205376_ctlid), A_________________278205376_ctlid, 0, 0, 1, bShowFrontPanel, 1, 0x30000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	A_________________278205376_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("\277\330\326\306\306\367\301\320\261\355\312\375\327\351"),14,0,-16,87,16,
	_LVT("0"),12,0,0,0, false);
	{int32 dVal = (int32)0 ;
		{
			static NumericInitialData numData = {
				A_____________278205760_ctlid,
				0,
				0,
				0,
				int32DataType,
				-2.1474836480000000000E+9,
				2.1474836470000000000E+9,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
			};
			if (!(FPData(A_____________278205760_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_8, &numData, &dVal))){
				return false;
			}
		}
	}
	if (argsIn && argsIn->size > 0 && argsIn->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, A_____________278205760_ctlid);
		if (!SetNumericFieldValue(GetControlHValue(nIdx), argsIn->args[0].pValue, argsIn->args[0].nType )) {
			return false;
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	A_____________278205760_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("\277\330\326\306\306\367\321\241\324\361"),10,-4,-20,63,16,
	_LVT("0"),12,0,0,0, false);
	if (!(FPData(A_____________278207304_ctlid) = ClusterControlDataCreateStatic(&g_control_11, GetControlDataPtr(), gFormID, A_____________278207304_ctlid, 0, 0, 0xC0000 | ClusterDataType, 0, NULL, NULL))){
		return false;
	}
	{
		VoidPtr vpCls = PDAClusterNewEmpty( 0xC0000 | ClusterDataType );
		{
			cl_C0000* cl_001;
			cl_001 = (cl_C0000*)vpCls;
			cl_001->el_0 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb93);
			cl_001->el_1 = 0 ;
			cl_001->el_2 = PDAStrNewFromBufStatic(_LVT(""),(uInt32)0, g_staticArb94);
		}
		InitClusterControlFieldValue( FPData(A_____________278207304_ctlid),  vpCls, 0xC0000 | ClusterDataType );
		MemPtrFree( vpCls );
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	A_____________278207304_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("\277\330\326\306\306\367\320\305\317\242"),10,0,-17,63,16,
	_LVT("0"),12,0,0,0, false);
	{int32 dVal = (int32)0 ;
		{
			static NumericInitialData numData = {
				A_________________278207688_ctlid,
				0,
				0,
				0,
				int32DataType,
				-2.1474836480000000000E+9,
				2.1474836470000000000E+9,
				0.0000000000000000000E+0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
			};
			if (!(FPData(A_________________278207688_ctlid) = NumericDataCreateStatic((NumericData*)&g_control_12, &numData, &dVal))){
				return false;
			}
		}
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	A_________________278207688_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("\277\330\326\306\306\367\321\241\324\361\312\344\263\366"),14,-4,-20,87,16,
	_LVT("0"),12,0,0,0, false);
	FPData(A_________________278209800_ctlid) = NULL;
	if(bShowFrontPanel) {
/* Declare array */
		{
			FPData(A_________________278209800_ctlid) = (void*)&g_array_2.el_1;
			NDims(((PDAArrPtr)&g_array_2.el_1)) = 1;
			((PDAArrPtr)&g_array_2.el_1)->datatype = 0xC0000 | ClusterDataType;
			((PDAArrPtr)&g_array_2.el_1)->staticArray = 1;
			((PDAArrPtr)&g_array_2.el_1)->refcnt = 2;
			NthDim(((PDAArrPtr)&g_array_2.el_1), (ArrDimSize)0) = 0;
		}
	}
	if (!(FPData(A_________________278209800_ctlid) = ArrayControlDataCreateStatic(&g_control_17, FPData(A_________________278209800_ctlid), A_________________278209800_ctlid, 0, 0, 1, bShowFrontPanel, 1, 0x130000 | ArrayDataType))) {
		return false;
	}
	LVInitLabel( GetControlDataPtr(),  gFormID,
	A_________________278209800_ctlid,
	0,0,0,
	1,0,0,0,
	_LVT("\277\330\326\306\306\367\320\305\317\242\312\375\327\351"),14,0,-16,87,16,
	_LVT("0"),12,0,0,0, false);
	InitHostFPTerms(&state, debugOffset);
	return true;
}
#define F4_Controller_handle_Global_Function_Variable_FrontPanelInit NULL
#define F4_Controller_handle_Global_Function_Variable_DrawLabels NULL
#define FPBuildMenu NULL


/****** Free all memory used by this VI except uninitialized left shift registers and globals **********/


void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_Cleanup(Boolean bShowFrontPanel);
void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_Cleanup(Boolean bShowFrontPanel){
	if (FPData(F4_Controller_Handle_In__278204128_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(F4_Controller_Handle_In__278204128_ctlid), false );
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(A_________________278205376_ctlid), 1 );
	if (FPData(A_____________278207304_ctlid)) ClusterControlFreeData( GetControlDataPtr(), gFormID, FPData(A_____________278207304_ctlid), false );
	ArrayControlFreeData( GetControlDataPtr(), gFormID, FPData(A_________________278209800_ctlid), 1 );
#if defined(_Include_Events) || defined(_Include_Everything)
#endif
	return;
}


/****** Transfer block diagram terminal values to parent VI caller **********/


Boolean _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_GetFPTerms( ArgList *argsOut );
Boolean _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_GetFPTerms( ArgList *argsOut ){
	int32 nIdx=0;
	if (!argsOut) {
		return true;
	}
	if (argsOut->size > 1 && argsOut->args[1].pValue) {
		nIdx = CalcControlOffset( gFormID, A_________________278205376_ctlid);
		GetArrayControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[1].pValue);
	}
	if (argsOut->size > 2 && argsOut->args[2].pValue) {
		nIdx = CalcControlOffset( gFormID, A_____________278207304_ctlid);
		GetClusterControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[2].pValue, argsOut->args[2].nType );
	}
	if (argsOut->size > 3 && argsOut->args[3].pValue) {
		nIdx = CalcControlOffset( gFormID, A_________________278207688_ctlid);
		if (!GetNumericFieldValue(GetControlHValue(nIdx), argsOut->args[3].pValue, argsOut->args[3].nType )) {
			return false;
		}
	}
	if (argsOut->size > 0 && argsOut->args[0].pValue) {
		nIdx = CalcControlOffset( gFormID, A_________________278209800_ctlid);
		GetArrayControlFieldValue( gArrControlData[nIdx].hValue, argsOut->args[0].pValue);
	}
	return true;
}


/****** Clean Up Uninitialized Left Shift Registers before program exits to prevent memory leaks **********/


void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_CleanupLSRs(void);
void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_CleanupLSRs(void) {
	if (F4_Controller_handle_Global_Function_Variable_heap_lsr->a_While_Loop_SR) {
	PDAArrFree(F4_Controller_handle_Global_Function_Variable_heap_lsr->a_While_Loop_SR);
	}
}


/****** Add Sub VI Instance Data to global list **********/


void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_AddSubVIInstanceData(void);
void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_AddSubVIInstanceData(void) {
}


/****** Allocate VI Constants  **********/


void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_AddVIGlobalConstants(void);
void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_AddVIGlobalConstants(void) {
	(F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr->refCnt)++;
	if (F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr->refCnt > 1) return;

/* Declare array */
	{
		F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr->i09BC8838 = (void*)&g_array_3.el_1;
		NDims(((PDAArrPtr)&g_array_3.el_1)) = 1;
		((PDAArrPtr)&g_array_3.el_1)->datatype = 0xC0000 | ClusterDataType;
		((PDAArrPtr)&g_array_3.el_1)->staticArray = 1;
		((PDAArrPtr)&g_array_3.el_1)->refcnt = 2;
		NthDim(((PDAArrPtr)&g_array_3.el_1), (ArrDimSize)0) = 0;
	}
}


/****** Cleanup VI Constants  **********/


void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_CleanupVIGlobalConstants(void);
void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_CleanupVIGlobalConstants(void) {
	if (F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr->refCnt > 0) return;

	PDAArrFree(F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr->i09BC8838);
	MemSet(F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr,sizeof(*(F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr)),0);
}


/****** VI Constant Initialization function **********/


void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_InitVIConstantList(void);
void _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_InitVIConstantList(void) {
	heap->a_Constant_1 = F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr->i09BC8838;
}


/****** Block diagram code **********/


eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_RunFunc_F85DB2C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_RunFunc_F85DB2C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* for loop */
		uInt32 id = LVGetTimerFlag();
		static uInt16 nStep = 0;
		uInt32 diagramIdx = 12;
		if (heap->runStatF85DB2C == eReady) {
			CCGDebugSynchSNode(&state, 10, 11, 10, &snodeF85DB2C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->l_For_Loop_N_4 = MaxArrDimSize;
			heap->l_For_Loop_N_4 = LVMIN(heap->l_For_Loop_N_4, ( heap->a_While_Loop_CT_3 ? FirstDim( heap->a_While_Loop_CT_3 ) : 0 ));
			if (!(heap->a_Unbundle_By_Name_F4Ctrller_Na = PDAArrCreateLpTunArrStatic( (ArrDimSize)heap->l_For_Loop_N_4, StringDataType, uCharDataType, (ArrDimSize)0, &g_staticArray_25, &g_staticArb101))){
				CGenErr();
			}
			heap->a_While_Loop_LT = heap->a_While_Loop_CT_3;
			/*SetSignalReady( 0x2, 1);*//* a_While_Loop_LT */
			heap->l_For_Loop_i_4 = 0;
		}
		while (!gAppStop && !gLastError) {
			if (heap->l_For_Loop_i_4 < heap->l_For_Loop_N_4) {
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(4, 1);
						/*InitSignalReady( 0x2, 2);*//* s_Unbundle_By_Name_F4Ctrller_Na */
						InitSignalReady(5, 1);
						/*InitSignalReady( 0x0, 2);*//* c_While_Loop_LT */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						{ /* Array Index 1D */
							int32 nIndex = 0;
							nIndex = (int32)heap->l_For_Loop_i_4;
							MemSet( &heap->c_While_Loop_LT, GetClusterSize( ((PDAArrPtr)heap->a_While_Loop_LT)->datatype ), 0 );
							PDAClusterSet(NthElem(((PDAArrPtr)heap->a_While_Loop_LT), nIndex), ((PDAArrPtr)heap->a_While_Loop_LT)->datatype, &heap->c_While_Loop_LT, ((PDAArrPtr)heap->a_While_Loop_LT)->datatype );
							/*SetSignalReady( 0x0, 2);*//* c_While_Loop_LT */
							UpdateProbes(&state, debugOffset, 21 /*0x9BC8068*/, (uChar*)&(heap->c_While_Loop_LT)); /* assign */
							SetSignalReady(5, 1);
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						CCGDebugSynchNode(&state, 12, 13, 12, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
/* Unbundle by name */
						{
							cl_C0000* cl_002 = (cl_C0000*)&heap->c_While_Loop_LT;
							PDAStrIncRefCnt(cl_002->el_0, (uInt16)1); /*  */
							heap->s_Unbundle_By_Name_F4Ctrller_Na = cl_002->el_0;
							/*SetSignalReady( 0x2, 2);*//* s_Unbundle_By_Name_F4Ctrller_Na */
							UpdateProbes(&state, debugOffset, 20 /*0x9BC8128*/, (uChar*)&(heap->s_Unbundle_By_Name_F4Ctrller_Na)); /* assign */
							SetSignalReady(4, 1);
	/* Free Cluster */
							{
								cl_C0000* cl_003 = (cl_C0000*)&heap->c_While_Loop_LT;
		if (cl_003->el_0 && --((PDAStrPtr)cl_003->el_0)->refcnt == 0 && !((PDAStrPtr)cl_003->el_0)->staticStr) {
									MemHandleFree( cl_003->el_0 );
								}
		if (cl_003->el_2 && --((PDAStrPtr)cl_003->el_2)->refcnt == 0 && !((PDAStrPtr)cl_003->el_2)->staticStr) {
									MemHandleFree( cl_003->el_2 );
								}
							}
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 2 : {
						if (!PDAArrAddElToLpTunArr( &heap->a_Unbundle_By_Name_F4Ctrller_Na, &heap->s_Unbundle_By_Name_F4Ctrller_Na )){
							CGenErr();
						}
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 13, 12, &snodeF85DB2C, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep=0;
			}
			(heap->l_For_Loop_i_4)++;
			if (heap->l_For_Loop_i_4 >= heap->l_For_Loop_N_4) {
				/* FreeLoopInputs. */
	PDAArrFree(heap->a_While_Loop_LT);
				heap->a_Unbundle_By_Name_F4Ctrller_Na = PDAArrCreate1DArrFromLpTunArr( heap->a_Unbundle_By_Name_F4Ctrller_Na );
				/*SetSignalReady( 0x3, 5);*//* a_Unbundle_By_Name_F4Ctrller_Na */
				UpdateProbes(&state, debugOffset, 18 /*0x9BC7EE8*/, (uChar*)&(heap->a_Unbundle_By_Name_F4Ctrller_Na)); /* assign */
				break;
			}
			if (!bRunToFinish) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		} /* end while */
	} /* end for loop */
	CCGDebugSynchAfterSNode(&state, &snodeF85DB2C, 11, debugOffset);
	if(gAppStop) {
		gAppStop = true;
		return eFinished;
	}

	if (!SetArrayControlFieldValueStatic( FPData(A_________________278205376_ctlid), &heap->a_Unbundle_By_Name_F4Ctrller_Na, false, &g_staticArray_26))
	CGenErr();
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, A_________________278205376_ctlid);
	return eFinished;
}
eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_RunFunc_72F8CCC(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_RunFunc_72F8CCC(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	{ /* Select */
		uInt32 id = LVGetTimerFlag();
		if (heap->runStat72F8CCC == eReady) {
			CCGDebugSynchSNode(&state, 3, 4, 3, &snode72F8CCC, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->runStat9BD5311 = eReady;
			heap->runStat9BCC148 = eReady;
			heap->runStat9BD5312 = eReady;
			heap->runStat9BD49D1 = eReady;
			heap->runStatF85DB2C = eReady;
			heap->runStat9BD49D2 = eReady;
			heap->runStat9C19501 = eReady;
			heap->runStat9C19502 = eReady;
			heap->runStat9BD5151 = eReady;
			heap->runStat9BD5152 = eReady;
			heap->runStat9BD5511 = eReady;
			heap->runStat9BCC4A8 = eReady;
			heap->runStat9BD5512 = eReady;
			heap->e_F4_Controller_handle_Global_2 = heap->e_F4_Controller_handle_Global_1;
			/*SetSignalReady( 0x4, 2);*//* e_F4_Controller_handle_Global_2 */
			heap->a_While_Loop_CT = heap->a_While_Loop_SR_1;
			/*SetSignalReady( 0x2, 0);*//* a_While_Loop_CT */
			heap->l_While_Loop_CT = heap->l_While_Loop_SR_1;
			/*SetSignalReady( 0x1, 5);*//* l_While_Loop_CT */
		}
		switch ( heap->e_F4_Controller_handle_Global_2 ) {
			/* begin case */
			case 1 : {
				uInt32 diagramIdx = 7;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						/*InitSignalReady( 0x0, 0);*//* c_Index_Array_element */
						InitSignalReady(7, 2);
						InitSignalReady(8, 2);
						/*InitSignalReady( 0x0, 4);*//* l_While_Loop_CT_2 */
						/*InitSignalReady( 0x3, 4);*//* a_While_Loop_CT_2 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->a_While_Loop_CT_2 = heap->a_While_Loop_CT;
						/*SetSignalReady( 0x3, 4);*//* a_While_Loop_CT_2 */
						UpdateProbes(&state, debugOffset, 14 /*0x9BCBFC8*/, (uChar*)&(heap->a_While_Loop_CT_2)); /* assign */
						SetSignalReady(7, 1);
						SetSignalReady(8, 1);
						PDAArrIncRefCnt(heap->a_While_Loop_CT_2, (uInt16)1); /* SelectTunnel */
						heap->l_While_Loop_CT_2 = heap->l_While_Loop_CT;
						/*SetSignalReady( 0x0, 4);*//* l_While_Loop_CT_2 */
						UpdateProbes(&state, debugOffset, 13 /*0x9BCC028*/, (uChar*)&(heap->l_While_Loop_CT_2)); /* assign */
						SetSignalReady(7, 1);
						SetSignalReady(8, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						CCGDebugSynchNode(&state, 7, 8, 7, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						{ /* Array Index 1D */
							int32 nIndex = 0;
							nIndex = (int32)heap->l_While_Loop_CT_2;
							MemSet( &heap->c_Index_Array_element, GetClusterSize( ((PDAArrPtr)heap->a_While_Loop_CT_2)->datatype ), 0 );
							PDAClusterSet(NthElem(((PDAArrPtr)heap->a_While_Loop_CT_2), nIndex), ((PDAArrPtr)heap->a_While_Loop_CT_2)->datatype, &heap->c_Index_Array_element, ((PDAArrPtr)heap->a_While_Loop_CT_2)->datatype );
							/*SetSignalReady( 0x0, 0);*//* c_Index_Array_element */
							UpdateProbes(&state, debugOffset, 12 /*0x9BCC088*/, (uChar*)&(heap->c_Index_Array_element)); /* assign */
						}
	PDAArrFree(heap->a_While_Loop_CT_2);
						{
							if (!SetClusterControlFieldValue( FPData(A_____________278207304_ctlid), &heap->c_Index_Array_element, 0xC0000 | ClusterDataType, false )){
								CGenErr();
							}
						}
						/* Update front panel indicator */
						CCGDebugUpdateFPControl(&state, debugOffset, A_____________278207304_ctlid);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 2 : {
						heap->a_Case_Structure_CT_19 = heap->a_While_Loop_CT_2;
						/*SetSignalReady( 0x3, 6);*//* a_Case_Structure_CT_19 */
						heap->l_Case_Structure_CT_3 = heap->l_While_Loop_CT_2;
						/*SetSignalReady( 0x1, 6);*//* l_Case_Structure_CT_3 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 8, 7, &snode72F8CCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			case 2 : {
				uInt32 diagramIdx = 10;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(3, 2);
						/*InitSignalReady( 0x1, 7);*//* l_While_Loop_CT_3 */
						/*InitSignalReady( 0x3, 5);*//* a_Unbundle_By_Name_F4Ctrller_Na */
						InitSignalReady(6, 1);
						/*InitSignalReady( 0x3, 1);*//* a_While_Loop_CT_3 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->a_While_Loop_CT_3 = heap->a_While_Loop_CT;
						/*SetSignalReady( 0x3, 1);*//* a_While_Loop_CT_3 */
						UpdateProbes(&state, debugOffset, 19 /*0x9BC7E28*/, (uChar*)&(heap->a_While_Loop_CT_3)); /* assign */
						SetSignalReady(3, 1);
						SetSignalReady(6, 1);
						PDAArrIncRefCnt(heap->a_While_Loop_CT_3, (uInt16)1); /* SelectTunnel */
						heap->l_While_Loop_CT_3 = heap->l_While_Loop_CT;
						/*SetSignalReady( 0x1, 7);*//* l_While_Loop_CT_3 */
						UpdateProbes(&state, debugOffset, 17 /*0x9BC7FA8*/, (uChar*)&(heap->l_While_Loop_CT_3)); /* assign */
						SetSignalReady(3, 1);
						nStep++;}
/* start q el struct (0 or 1 struct)*/
					case 1 : {
						heap->runStatF85DB2C = F4_Controller_handle_Global_Function_Variable_RunFunc_F85DB2C( bRunToFinish  );
						if (heap->runStatF85DB2C == eNotFinished) {
							return eNotFinished;
						}
						else if (heap->runStatF85DB2C == eFail) {
							CGenErr();
						}
						heap->runStatF85DB2C = eReady;
						nStep++; }
/* start q el linear (0 or 1 struct) */
					case 2 : {
						heap->a_Case_Structure_CT_19 = heap->a_While_Loop_CT_3;
						/*SetSignalReady( 0x3, 6);*//* a_Case_Structure_CT_19 */
						heap->l_Case_Structure_CT_3 = heap->l_While_Loop_CT_3;
						/*SetSignalReady( 0x1, 6);*//* l_Case_Structure_CT_3 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 11, 10, &snode72F8CCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			case 3 : {
				uInt32 diagramIdx = 14;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(2, 1);
						/*InitSignalReady( 0x3, 3);*//* a_While_Loop_CT_4 */
						/*InitSignalReady( 0x0, 3);*//* l___________ */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->a_While_Loop_CT_4 = heap->a_While_Loop_CT;
						/*SetSignalReady( 0x3, 3);*//* a_While_Loop_CT_4 */
						UpdateProbes(&state, debugOffset, 22 /*0x9BC7D68*/, (uChar*)&(heap->a_While_Loop_CT_4)); /* assign */
						SetSignalReady(2, 1);
						if (!GetNumericFieldValue( FPData(A_____________278205760_ctlid), &heap->l___________, int32DataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x0, 3);*//* l___________ */
						UpdateProbes(&state, debugOffset, 23 /*0x9BC7CA8*/, (uChar*)&(heap->l___________)); /* assign */
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						heap->a_Case_Structure_CT_19 = heap->a_While_Loop_CT_4;
						/*SetSignalReady( 0x3, 6);*//* a_Case_Structure_CT_19 */
						heap->l_Case_Structure_CT_3 = heap->l___________;
						/*SetSignalReady( 0x1, 6);*//* l_Case_Structure_CT_3 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 14, 14, &snode72F8CCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			case 4 : {
				uInt32 diagramIdx = 9;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(1, 2);
						/*InitSignalReady( 0x1, 2);*//* l____________1 */
						/*InitSignalReady( 0x3, 2);*//* a_Constant_1 */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						/* Free unwired input select tunnel. */
	PDAArrFree(heap->a_While_Loop_CT);
						/*SetSignalReady( 0x3, 2);*//* a_Constant_1 */
						UpdateProbes(&state, debugOffset, 16 /*0x9BC82A8*/, (uChar*)&(heap->a_Constant_1)); /* assign */
						SetSignalReady(1, 1);
						PDAArrIncRefCnt(heap->a_Constant_1, (uInt16)1); /* BDConst - alloc type */
						heap->l____________1 = 0;
						/*SetSignalReady( 0x1, 2);*//* l____________1 */
						UpdateProbes(&state, debugOffset, 15 /*0x9BC8368*/, (uChar*)&(heap->l____________1)); /* assign */
						SetSignalReady(1, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						heap->a_Case_Structure_CT_19 = heap->a_Constant_1;
						/*SetSignalReady( 0x3, 6);*//* a_Case_Structure_CT_19 */
						heap->l_Case_Structure_CT_3 = heap->l____________1;
						/*SetSignalReady( 0x1, 6);*//* l_Case_Structure_CT_3 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 9, 9, &snode72F8CCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
			/* begin case */
			default : {
				uInt32 diagramIdx = 5;
				static uInt16 nStep = 0;
				switch(nStep)
				{
/* start q el linear (0 or 1 struct) */
					case 0 : {
						InitSignalReady(9, 2);
						/*InitSignalReady( 0x1, 3);*//* l_While_Loop_CT_1 */
						InitSignalReady(10, 1);
						/*InitSignalReady( 0x2, 4);*//* a_While_Loop_CT_1 */
						/*InitSignalReady( 0x2, 5);*//* a_Insert_Into_Array_output_arra */
						/*InitSignalReady( 0x0, 1);*//* c_F4_Controller_Handle_In */
						HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
						heap->l_While_Loop_CT_1 = heap->l_While_Loop_CT;
						/*SetSignalReady( 0x1, 3);*//* l_While_Loop_CT_1 */
						UpdateProbes(&state, debugOffset, 8 /*0x9BCC3E8*/, (uChar*)&(heap->l_While_Loop_CT_1)); /* assign */
						SetSignalReady(9, 1);
						heap->a_While_Loop_CT_1 = heap->a_While_Loop_CT;
						/*SetSignalReady( 0x2, 4);*//* a_While_Loop_CT_1 */
						UpdateProbes(&state, debugOffset, 9 /*0x9BCC328*/, (uChar*)&(heap->a_While_Loop_CT_1)); /* assign */
						SetSignalReady(10, 1);
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 1 : {
						if (!GetClusterControlFieldValue( FPData(F4_Controller_Handle_In__278204128_ctlid), &heap->c_F4_Controller_Handle_In, 0xC0000 | ClusterDataType )){
							CGenErr();
						}
						/*SetSignalReady( 0x0, 1);*//* c_F4_Controller_Handle_In */
						UpdateProbes(&state, debugOffset, 11 /*0x9BCC1A8*/, (uChar*)&(heap->c_F4_Controller_Handle_In)); /* assign */
						CCGDebugSynchNode(&state, 5, 6, 5, debugOffset);
						if(gAppStop) {
							gAppStop = true;
							return eFinished;
						}
						{
							ArrDimSize nPos = 0;
							if (heap->a_While_Loop_CT_1) {
								nPos = PDAArrNthDim( ((PDAArrPtr)heap->a_While_Loop_CT_1), 0);
							}
							if (nPos >= 0) {
								if (!PDAArrInsStatic( heap->a_While_Loop_CT_1, &heap->c_F4_Controller_Handle_In, 0xC0000 | ClusterDataType, (ArrDimSize)0, nPos, &heap->a_Insert_Into_Array_output_arra, 0x130000 | ArrayDataType, &g_staticArray_31, &g_staticArb102, &g_staticArray_32)){
									CGenErr();
								}
/* Insert Scalar */
								{
									if (!PDAArrSetData(((PDAArrPtr)heap->a_Insert_Into_Array_output_arra), nPos, &heap->c_F4_Controller_Handle_In, 0xC0000 | ClusterDataType )) {
										CGenErr();
									}
								}
								/*SetSignalReady( 0x2, 5);*//* a_Insert_Into_Array_output_arra */
								UpdateProbes(&state, debugOffset, 10 /*0x9BCC268*/, (uChar*)&(heap->a_Insert_Into_Array_output_arra)); /* assign */
								SetSignalReady(9, 1);
							}
							else {
								heap->a_Insert_Into_Array_output_arra = PDAArrCopyOnModify( heap->a_While_Loop_CT_1 );
							}
						}
						nStep++;}
/* start q el linear (0 or 1 struct) */
					case 2 : {
						heap->l_Case_Structure_CT_3 = heap->l_While_Loop_CT_1;
						/*SetSignalReady( 0x1, 6);*//* l_Case_Structure_CT_3 */
						heap->a_Case_Structure_CT_19 = heap->a_Insert_Into_Array_output_arra;
						/*SetSignalReady( 0x3, 6);*//* a_Case_Structure_CT_19 */
						nStep++;}
					default: {
						; /* do nothing */
					}
				}
				CCGDebugSynchSRN(&state, 6, 5, &snode72F8CCC, debugOffset);
				if(gAppStop) {
					gAppStop = true;
					return eFinished;
				}
				nStep = 0;
			} /* end case */
			break;
		}
		heap->a_Case_Structure_CT_18 = heap->a_Case_Structure_CT_19;
		/*SetSignalReady( 0x2, 6);*//* a_Case_Structure_CT_18 */
		UpdateProbes(&state, debugOffset, 5 /*0x9BC77C8*/, (uChar*)&(heap->a_Case_Structure_CT_18)); /* assign */
		SetSignalReady(0, 1);
		heap->l_Case_Structure_CT_2 = heap->l_Case_Structure_CT_3;
		/*SetSignalReady( 0x0, 7);*//* l_Case_Structure_CT_2 */
		UpdateProbes(&state, debugOffset, 2 /*0x9BC79A8*/, (uChar*)&(heap->l_Case_Structure_CT_2)); /* assign */
		SetSignalReady(0, 1);
		CCGDebugSynchAfterSNode(&state, &snode72F8CCC, 4, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}

	} /* end switch */
	PDAArrIncRefCnt(heap->a_Case_Structure_CT_18, (uInt16)1); /* Select: sel tunnels */
	if (!SetArrayControlFieldValueStatic( FPData(A_________________278209800_ctlid), &heap->a_Case_Structure_CT_18, false, &g_staticArray_33))
	CGenErr();
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, A_________________278209800_ctlid);
	{
		if (!SetNumericFieldValue( FPData(A_________________278207688_ctlid), &heap->l_Case_Structure_CT_2, int32DataType )){
			CGenErr();
		}
	}
	/* Update front panel indicator */
	CCGDebugUpdateFPControl(&state, debugOffset, A_________________278207688_ctlid);
	return eFinished;
}
eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_RunFunc_72FD04C(Boolean bRunToFinish);
eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_RunFunc_72FD04C(Boolean bRunToFinish) {
	eRunStatus runStat = eReady;
	int16 nReady = 0;
	if (heap->runStat72FD04C == eReady) {
		if (!GetEnumCtlFieldValue( FPData(F4_Controller_handle_Global_Function_Enum__278204704_ctlid), &heap->e_F4_Controller_handle_Global_F_1 )){
			CGenErr();
		}
		/*SetSignalReady( 0x3, 7);*//* e_F4_Controller_handle_Global_F_1 */
		UpdateProbes(&state, debugOffset, 1 /*0x9BC7588*/, (uChar*)&(heap->e_F4_Controller_handle_Global_F_1)); /* assign */
	}
	{ /* while loop */
		uInt32 id = LVGetTimerFlag();
		static uInt16 nStep = 0;
		uInt32 diagramIdx = 3;
		if (heap->runStat72FD04C == eReady) {
			CCGDebugSynchSNode(&state, 1, 2, 1, &snode72FD04C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			heap->e_F4_Controller_handle_Global__1 = heap->e_F4_Controller_handle_Global_F_1;
			/*SetSignalReady( 0x4, 1);*//* e_F4_Controller_handle_Global__1 */
			heap->l_While_Loop_i_2 = 0;
		}
		while (!gAppStop && !gLastError) {
			switch(nStep)
			{
/* start q el linear (0 or 1 struct) */
				case 0 : {
					InitSignalReady(0, 3);
					/*InitSignalReady( 0x0, 7);*//* l_Case_Structure_CT_2 */
					InitSignalReady(11, 3);
					/*InitSignalReady( 0x1, 0);*//* l_While_Loop_SR_1 */
					/*InitSignalReady( 0x2, 7);*//* a_While_Loop_SR_1 */
					/*InitSignalReady( 0x2, 6);*//* a_Case_Structure_CT_18 */
					/*InitSignalReady( 0x7, 1);*//* b_Constant */
					/*InitSignalReady( 0x4, 0);*//* e_F4_Controller_handle_Global_1 */
					HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
					if (!F4_Controller_handle_Global_Function_Variable_heap_lsr->a_While_Loop_SR) {
						F4_Controller_handle_Global_Function_Variable_heap_lsr->a_While_Loop_SR = PDAArrNewEmptyWithNDimsStatic( 0xC0000 | ClusterDataType, (ArrDimSize)1, &g_staticArray_34 );
					}
					heap->a_While_Loop_SR_1 = F4_Controller_handle_Global_Function_Variable_heap_lsr->a_While_Loop_SR;
					/*SetSignalReady( 0x2, 7);*//* a_While_Loop_SR_1 */
					UpdateProbes(&state, debugOffset, 4 /*0x9BC7888*/, (uChar*)&(heap->a_While_Loop_SR_1)); /* assign */
					SetSignalReady(11, 1);
					heap->e_F4_Controller_handle_Global_1 = heap->e_F4_Controller_handle_Global_F_1;
					/*SetSignalReady( 0x4, 0);*//* e_F4_Controller_handle_Global_1 */
					UpdateProbes(&state, debugOffset, 7 /*0x9BC76A8*/, (uChar*)&(heap->e_F4_Controller_handle_Global_1)); /* assign */
					SetSignalReady(11, 1);
					heap->b_Constant = true;
					/*SetSignalReady( 0x7, 1);*//* b_Constant */
					UpdateProbes(&state, debugOffset, 6 /*0x9BC7768*/, (uChar*)&(heap->b_Constant)); /* assign */
					SetSignalReady(0, 1);
					heap->l_While_Loop_SR_1 = F4_Controller_handle_Global_Function_Variable_heap_lsr->l_While_Loop_SR;
					/*SetSignalReady( 0x1, 0);*//* l_While_Loop_SR_1 */
					UpdateProbes(&state, debugOffset, 3 /*0x9BC7948*/, (uChar*)&(heap->l_While_Loop_SR_1)); /* assign */
					SetSignalReady(11, 1);
					nStep++;}
/* start q el struct (0 or 1 struct)*/
				case 1 : {
					heap->runStat72F8CCC = F4_Controller_handle_Global_Function_Variable_RunFunc_72F8CCC( bRunToFinish  );
					if (heap->runStat72F8CCC == eNotFinished) {
						return eNotFinished;
					}
					else if (heap->runStat72F8CCC == eFail) {
						CGenErr();
					}
					heap->runStat72F8CCC = eReady;
					nStep++; }
/* start q el linear (0 or 1 struct) */
				case 2 : {
					if (!PDAClusterGetElemByPosStatic( &heap->b_Constant, BooleanDataType, 0, &heap->b_While_Loop_End_1, BooleanDataType, NULL )) {
						CGenErr();
					}
					heap->a_Case_Structure_SR_2 = heap->a_Case_Structure_CT_18;
					/*SetSignalReady( 0x3, 0);*//* a_Case_Structure_SR_2 */
					F4_Controller_handle_Global_Function_Variable_heap_lsr->a_While_Loop_SR = heap->a_Case_Structure_SR_2;
					/*SetSignalReady( 0x7, 2);*//* 9BD58D0 */
					heap->l_Case_Structure_SR = heap->l_Case_Structure_CT_2;
					/*SetSignalReady( 0x1, 4);*//* l_Case_Structure_SR */
					F4_Controller_handle_Global_Function_Variable_heap_lsr->l_While_Loop_SR = heap->l_Case_Structure_SR;
					/*SetSignalReady( 0x7, 2);*//* 9BD5850 */
					nStep++;}
				default: {
					; /* do nothing */
				}
			}
			CCGDebugSynchSRN(&state, 4, 3, &snode72FD04C, debugOffset);
			if(gAppStop) {
				gAppStop = true;
				return eFinished;
			}
			nStep = 0;
			(heap->l_While_Loop_i_2)++;
			if ( heap->b_While_Loop_End_1) {
				break;
			}
			if (!bRunToFinish) {
				if ((LVGetTimerFlag() > id) || ((LVGetTimerFlag()-id) < 0)) {
					if (!gAppStop && !gLastError) {
						return eNotFinished;
					}
					if (gAppStop) {
						return eFinished;
					}
					if (gLastError) {
						CGenErr();
					}
				}
			}
		} /* end while */
	} /* end while loop */
	CCGDebugSynchAfterSNode(&state, &snode72FD04C, 2, debugOffset);
	if(gAppStop) {
		gAppStop = true;
		return eFinished;
	}

	return eFinished;
}


/****** Block diagram main entry point **********/


eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish);
eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_BlockDiagram(Boolean bProcessFrontPanel, Boolean bRunToFinish){
	eRunStatus runStat = eReady;
	int16 nReady = 1;
	static uInt16 nStep = 0;
	uInt32 diagramIdx = 1;
	if (gRunStatus == eReady) {
	}
	switch(nStep) {
/* start q el linear (0 or 1 struct) */
		case 0 : {
			/*InitSignalReady( 0x3, 7);*//* e_F4_Controller_handle_Global_F_1 */
			HighlightExecutionPrepare(&state, debugOffset, diagramIdx);
			nStep++;}
/* start q el struct (0 or 1 struct)*/
		case 1 : {
			heap->runStat72FD04C = F4_Controller_handle_Global_Function_Variable_RunFunc_72FD04C( bRunToFinish  );
			if (heap->runStat72FD04C == eNotFinished) {
				return eNotFinished;
			}
			else if (heap->runStat72FD04C == eFail) {
				CGenErr();
			}
			heap->runStat72FD04C = eReady;
			nStep++; }
		nStep = 0;
		default: {
			; /* do nothing */
		}
		CCGDebugSynchSRN(&state, 2, 1, pauseCaller, debugOffset);
		if(gAppStop) {
			gAppStop = true;
			return eFinished;
		}
	}
	(F4_Controller_handle_Global_Function_Variable_GlobalConstantsHeapPtr->refCnt)--;
	return eFinished;
}

/****** VI Configuration data **********/

TextPtr F4_Controller_handle_Global_Function_Variable_VIName = "F4 Controller handle Global Function Variable.vi";

static VIInfo _DATA_SECTION viInfo = {
	&F4_Controller_handle_Global_Function_Variable_VIName,
	&gRunStatus,
	&gCurrentCallerID,
	true,
	true,
	false,
	NULL,
	NULL,
	gFormID,
	(uInt8 **)&heap,
	(uInt32)sizeof (struct _F4_Controller_handle_Global_Function_Variable_heap),
	&signalsReady,
	(uInt32 *)&InitSignalReadyValues,
	(uInt32)48,
	(ControlDataItemPtr*)&gArrControlData,
	N_CONTROLS,
	(uInt8**)&F4_Controller_handle_Global_Function_Variable_heap_lsr,
	(uInt32)sizeof (struct _F4_Controller_handle_Global_Function_Variable_heap_lsr),
	false,
	(uInt8**)&stepArr,
	NULL,
	0,
	F4_Controller_handle_Global_Function_Variable_InitFPTerms,
	F4_Controller_handle_Global_Function_Variable_FrontPanelInit,
	F4_Controller_handle_Global_Function_Variable_BlockDiagram,
	F4_Controller_handle_Global_Function_Variable_DrawLabels,
	F4_Controller_handle_Global_Function_Variable_GetFPTerms,
	F4_Controller_handle_Global_Function_Variable_Cleanup,
	F4_Controller_handle_Global_Function_Variable_CleanupLSRs,
	F4_Controller_handle_Global_Function_Variable_AddSubVIInstanceData,
	F4_Controller_handle_Global_Function_Variable_InitVIConstantList
};

/****** Main Entry Point for VI **********/

eRunStatus _TEXT_SECTION F4_Controller_handle_Global_Function_Variable_Run(subVIInstanceDataPtr viInstanceData, Boolean bShowFrontPanel, Boolean bRunToFinish, ArgList* argsIn, ArgList* argsOut, Boolean *pause){
	uInt8 *pHeap_lsr=NULL;
	eRunStatus stat=eReady;
#ifdef NOTDEF
    uInt8 *pHeap=NULL;
	if (0) { /* reentrant? */
		pHeap = (uInt8 *)heap;
		viInfo.heap = &pHeap;
	}
#endif
	viInfo.bShowFrontPanel = bShowFrontPanel;
	viInfo.bRunToFinish = bRunToFinish;
	viInfo.argsIn = argsIn;
	viInfo.argsOut = argsOut;
	pHeap_lsr = (uInt8*)F4_Controller_handle_Global_Function_Variable_heap_lsr;
	viInfo.heap_lsr=&pHeap_lsr;
	PDAEnterVI(&state, debugOffset, (ControlDataItemPtr *)&gArrControlData);
	pauseCaller = pause;
	stat =  RunVI(viInstanceData, &viInfo, 0 );
	PDALeaveVI(&state, debugOffset);
	return stat;
}


/****** End of generated code **********/


