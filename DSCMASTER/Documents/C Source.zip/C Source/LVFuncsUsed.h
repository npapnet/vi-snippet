
#define _Include_PDA_DEBUG

#define _Include_AllFlatten

#define _Include_AllUnflatten

#define _Include_String_Utils

#define _Include_Array_Utils

#define _Include_Cluster_Utils

#define _Include_PDAStrLen

#define _Include_PDAStrUtils

#define _Include_PDAFXPFlatten

#define _Include_PDAFXPUnflatten

#define _Include_LoopIndexing

#define _Include_ArrayControl

#define _Include_LVGetTicks

#define _Include_VisaSupport

#define _Include_Time_Utils

#define _Include_PDAStrTextToNum

#define _Include_NumText

#define _Include_LVClusterControl

#define _Include_LVBoolean

#define _Include_LVNumeric

#define _Include_PDAFltBinop_opEq

#define _Include_PDAFltBinop_opOr

#define _Include_PropNode

#define _Include_PDAArrToClust

#define _Include_PDAJoin

#define _Include_PDASplit

#define _Include_ArrayAdd

#define _Include_PDAFltBinop_opLT

#define _Include_PDAFltBinop_opAnd

#define _Include_LVRing

#define _Include_PDAStrToArray

#define _Include_PDAFltUnop_opDecr

#define _Include_PDAFltBinop_opPlus

#define _Include_PDAFltBinop_opMinus

#define _Include_PDAFltBinop_opNE

#define _Include_CallChain

#define _Include_PDAArrayToString

#define _Include_PDAFltBinop_opXor

#define _Include_PDARoxR

#define _Include_PDAArrToString

#define _Include_Enum_Utils

#define _Include_LVEnumCtl

#define _Include_PDAEnum

#define _Include_PDAArrIns

#define ARR_DIM_SIZE 2
